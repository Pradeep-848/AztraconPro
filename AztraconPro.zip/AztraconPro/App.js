import { createAppContainer } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';

import * as SplashScreen from 'expo-splash-screen';
import React, { Component, useEffect, useState, useRef } from 'react';
import { AppState, Dimensions } from 'react-native'
import { useFonts } from "@use-expo/font";

import Login from './component/Login';
import Register from './component/Register';
import HomeRegister from './component/HomeRegister';
import HomeProject from './component/HomeProject';
import AboutUs from './component/AboutUs'
import EmployeeProfile from './component/EmployeeProfile';
import EmployeeTimeSheetAdd from './component/EmployeeTimeSheetAdd';
import TagList from './component/TagList';
import ProjectMaterialDetail from './component/ProjectMaterialDetail';
import PRAppProPending from './component/PRAppProPending';
import PRAppPro from './component/PRAppPro';
import PRAppGen from './component/PRAppGen';
import POAppProPending from './component/POAppProPending';
import POAppPro from './component/POAppPro';
import POStatus from './component/POStatus';
import ContactMaster from './component/ContactMaster'
import ConstructionTimeSheet from './component/ConstructionTimeSheet'
import ConstructionTimeSheetAdd from './component/ConstructionTimeSheetAdd'
import AccountPayable from './component/AccountsPayable'
import EmployeeWTR from './component/EmployeeWTR'
import EmpSalaryPeriod from './component/EmpSalaryPeriod'
import SalarySlip from './component/SalarySlip'
import ProjectMaster from './component/ProjectMaster'
import ProjectMasterDetails from './component/ProjectMasterDetails'
import ProjectDetails from './component/ProjectDetails'
import TagDetails from './component/TagDetails'
import BomListType from './component/BomListType'
import BomList from './component/BomList'
import BomDetails from './component/BomDetails'
import TaskList from './component/TaskList'
import TaskDetails from './component/TaskDetails'
import TimeSheets from './component/TimeSheets'
import TimeSheetDetail from './component/TimeSheetDetail'
import CostAnalysis from './component/CostAnalysis'
import CostAnalysisDetail from './component/CostAnalysisDetail'
import BillingSchedule from './component/BillingSchedule'
import Drawings from './component/Drawings'
import NMRDetails from './component/NMRDetails'
import NMRHistory from './component/NMRHistory'
import PurchaseRequest from './component/PurchaseRequest'
import PRDetail from './component/PRDetail'
import PurchaseOrder from './component/PurchaseOrder'
import PODetail from './component/PODetail'
import WarehouseList from './component/WarehouseList'
import WarehouseDetail from './component/WarehouseDetail'
import WarehouseDetailLot from './component/WarehouseDetailLot'
import PullList from './component/PullList'
import PullListDetail from './component/PullListDetail'
import QuotationMaster from './component/QuotationMaster'
import QuotationMasterDetails from './component/QuotationMasterDetails'
import QuotationDetails from './component/QuotationDetails'
import QuotationTagList from './component/QuotationTaglist'
import QuotationNMR from './component/QuotationNMR'
import QuotationStatus from './component/QuotationStatus'
import QuotationDocument from './component/QuotationDocument'
import QuotationHistory from './component/QuotationHistory'
import QuotationMail from './component/QuotationMail'
import SupplierMaster from './component/SupplierMaster'
import SupplierProfile from './component/SupplierProfile'
import SupplierPO from './component/SupplierPO'
import SupplierContactMaster from './component/SupplierContactMaster'
import SupplierLedger from './component/SupplierLedger'
import SupplierFinanceDetail from './component/SupplierFinanceDetail'
import CustomerMaster from './component/CustomerMaster'
import CustomerProfile from './component/CustomerProfile'
import CustomerProjectMaster from './component/CustomerProjectMaster'
import CustomerContactMaster from './component/CustomerContactMaster'
import CustomerLedger from './component/CustomerLedger'
import CustomerReportDetail from './component/CustomerReportDetail'
import SupplierFinanceList from './component/SupplierFinanceList'
import AgeList from './component/AgeList'
import GraphBar from './component/GraphBar'
import AgeListCustomer from './component/AgeListCustomer'
import CustomerReportList from './component/CustomerReportList'
import AccountsReceivable from './component/AccountsReceivable'
import LeaveRequest from './component/LeaveRequest'
import LeaveApprovalList from './component/LeaveApprovalList'
import LeaveApproval from './component/LeaveApproval'
import LeaveApprovalStatus from './component/LeaveApprovalStatus'
import PRStatus from './component/PRStatus'
import POAppGen from './component/POAppGen'
import ChangePassword from './component/ChangePassword'
import Home from './component/Home'
import JournalSiteApproval from './component/JournalSiteApproval'
import JournalSite from './component/JournalSite'
import JournalSiteEntry from './component/JournalSiteEntry'
import ProjectMaterialList from './component/ProjectMaterialList'
import PhysicalStockSave from './component/PhysicalStockSave'
import CostApprovalList from './component/CostApprovalList';
import BudgetApproval from './component/BudgetApproval';
import ForecastApproval from './component/ForecastApproval';
import PayApproval from './component/PayApproval';
import PayAppPending from './component/PayAppPending';
import PayAppStatus from './component/PayAppStatus';
import RegisterCustomerProfile from './component/RegisterCustomerProfile';
import Aztraconweb from './component/Aztraconweb';
import ManPowerRequest from './component/ManPowerRequest';
import ManPowerRequestList from './component/ManPowerRequestList';
import ERPToDoList from './component/ERPToDoList';
import ERPToDoDetail from './component/ERPToDoDetail'
import ProjectMail from './component/ProjectMail';
import CustomerInvBalance from './component/CustomerInvBalance';
import PunchList from './component/PunchList'
import ProjectLedger from './component/ProjectLedger';
import DeliveryNoteReport from './component/DeliveryNoteReport';
import DashBoard from './component/DashBoard';
import TaskGallery from './component/TaskGallery';
import ManPowerDistribution from './component/ManPowerDistribution';

//Aprove
import ApprovalList from './component/ApprovalList';
import HRApprovalList from './component/approvals/HRApprovalList'
import PayRollApproval from './component/approvals/PayRollApproval'
import SalaryAdjustApproval from './component/approvals/SalaryAdjustApproval'
import RecruitmentApproval from './component/approvals/RecruitmentApproval'
import SiteTransferApproval from './component/approvals/SiteTransferApproval'
import EmployeeJoiningApproval from './component/approvals/EmployeeJoiningApproval'
import ProjectInvoiceApprovalList from './component/approvals/ProjectInvoiceApprovalList'
import ProjectInvoiceApproval from './component/approvals/ProjectInvoiceApproval'
import ScrapInvoiceApproval from './component/approvals/ScrapInvoiceApproval'
import EmpLeaveSettlementApproval from './component/approvals/EmpLeaveSettlementApproval'
import FinalSettlementApproval from './component/approvals/FinalSettlementApproval';
import ProjMaterialTransferList from './component/approvals/ProjMaterialTransferList';
import ProjMaterialTransferApproval from './component/approvals/ProjMaterialTransferApproval'
import SupplierApprovalList from './component/approvals/SupplierApprovalList'
import SupplierApproval from './component/approvals/SupplierApproval'
import CustomerPOApprovalList from './component/approvals/CustomerPOApprovalList'
import CustomerPOApproval from './component/approvals/CustomerPOApproval'
import JournalApprovalList from './component/approvals/JournalApprovalList';
import JournalApproval from './component/approvals/JournalApproval';
import ProjectDrawingApprovalList from './component/approvals/ProjectDrawingApprovalList';
import ProjectDrawingApproval from './component/approvals/ProjectDrawingApproval';
import ProjectDrawingSOSApproval from './component/approvals/ProjectDrawingSOSApproval';
import EquipmentTransferList from './component/approvals/EquipmentTransferList';
import EquipmentTransferApproval from './component/approvals/EquipmentTransferApproval';
import EmpReleaseAppList from './component/approvals/EmpReleaseAppList';
import EmpReleaseApproval from './component/approvals/EmpReleaseApproval';
import DeliveryNoteAppList from './component/approvals/DeliveryNoteAppList';
import DeliveryNoteApproval from './component/approvals/DeliveryNoteApproval';
import EquipmentTransferRepairApproval from './component/approvals/EquipmentTransferRepairApproval'
import EmpLeaveReturnAppList from './component/approvals/EmpLeaveReturnAppList';
import EmpLeaveReturnApp from './component/approvals/EmpLeaveReturnApp';
import OTApproval from './component/approvals/OTApproval';
import OTApprovalList from './component/approvals/OTApprovalList';


//Production
import HomeProduction from './component/production/HomeProduction';
import InspectionRequest from './component/production/InspectionRequest';
import InspectionRequestST from './component/production/InspectionRequestST'
import InspectionRequestNoz from './component/production/InspectionRequestNoz';
import InspectionRequestRT from './component/production/InspectionRequestRT';

//Document
import Document from './component/Document';
import DocumentViewer from './component/DocumentViewer'


//Customer
import HomeCustomer from './component/Customer/HomeCustomer'
import { GestureHandlerRootView } from 'react-native-gesture-handler';

const RootStack = createStackNavigator(
  {
    LoginActivity: { screen: Login },
    RegisterActivity: { screen: Register },
    HomeProjectActivity: { screen: HomeProject },
    HomeRegisterActivity: { screen: HomeRegister },
    CustomerRegisterProfileActivity: { screen: RegisterCustomerProfile },
    AboutUsActivity: { screen: AboutUs },
    AztraconwebActivity: { screen: Aztraconweb },
    ManPowerRequestActivity: { screen: ManPowerRequest },
    ManPowerRequestListActivity: { screen: ManPowerRequestList },
    EmployeeProfileActivity: { screen: EmployeeProfile },
    EmployeeTimeSheetAddActivity: { screen: EmployeeTimeSheetAdd },
    ProjectMaterialDetailActivity: { screen: ProjectMaterialDetail },
    PRAppProPendingActivity: { screen: PRAppProPending },
    PRAppProActivity: { screen: PRAppPro },
    PRAppGenActivity: { screen: PRAppGen },
    POAppProPendingActivity: { screen: POAppProPending },
    POAppProActivity: { screen: POAppPro },
    POStatusActivity: { screen: POStatus },
    ContactMasterActivity: { screen: ContactMaster },
    ConstructionTimeSheetActivity: { screen: ConstructionTimeSheet },
    ConstructionTimeSheetAddActivity: { screen: ConstructionTimeSheetAdd },
    AccountPayableActivity: { screen: AccountPayable },
    EmployeeWTRActivity: { screen: EmployeeWTR },
    EmpSalaryPeriodActivity: { screen: EmpSalaryPeriod },
    SalarySlipActivity: { screen: SalarySlip },
    ProjectMasterActivity: { screen: ProjectMaster },
    ProjectMasterDetailsActivity: { screen: ProjectMasterDetails },
    ProjectDetailsActivity: { screen: ProjectDetails },
    TagListActivity: { screen: TagList },
    TagDetailsActivity: { screen: TagDetails },
    BomListTypeActivity: { screen: BomListType },
    BomListActivity: { screen: BomList },
    BomDetailsActivity: { screen: BomDetails },
    TaskListActivity: { screen: TaskList },
    TaskDetailsActivity: { screen: TaskDetails },
    TimeSheetsActivity: { screen: TimeSheets },
    TimeSheetDetailActivity: { screen: TimeSheetDetail },
    CostAnalysisActivity: { screen: CostAnalysis },
    CostAnalysisDetailActivity: { screen: CostAnalysisDetail },
    BillingScheduleActivity: { screen: BillingSchedule },
    DrawingsActivity: { screen: Drawings },
    NMRDetailsActivity: { screen: NMRDetails },
    NMRHistoryActivity: { screen: NMRHistory },
    PurchaseRequestActivity: { screen: PurchaseRequest },
    PRDetailActivity: { screen: PRDetail },
    PurchaseOrderActivity: { screen: PurchaseOrder },
    PODetailActivity: { screen: PODetail },
    WarehouseListActivity: { screen: WarehouseList },
    WarehouseDetailActivity: { screen: WarehouseDetail },
    WarehouseDetailLotActivity: { screen: WarehouseDetailLot },
    PullListActivity: { screen: PullList },
    PullListDetailActivity: { screen: PullListDetail },
    QuotationMasterActivity: { screen: QuotationMaster },
    QuotationMasterDetailsActivity: { screen: QuotationMasterDetails },
    QuotationDetailsActivity: { screen: QuotationDetails },
    QuotationTagListActivity: { screen: QuotationTagList },
    QuotationNMRActivity: { screen: QuotationNMR },
    QuotationStatusActivity: { screen: QuotationStatus },
    QuotationDocumentActivity: { screen: QuotationDocument },
    QuotationHistoryActivity: { screen: QuotationHistory },
    QuotationMailActivity: { screen: QuotationMail },
    SupplierMasterActivity: { screen: SupplierMaster },
    SupplierProfileActivity: { screen: SupplierProfile },
    SupplierPOActivity: { screen: SupplierPO },
    SupplierContactMasterActivity: { screen: SupplierContactMaster },
    SupplierLedgerActivity: { screen: SupplierLedger },
    SupplierFinanceDetailActivity: { screen: SupplierFinanceDetail },
    CustomerMasterActivity: { screen: CustomerMaster },
    CustomerProfileActivity: { screen: CustomerProfile },
    CustomerProjectMasterActivity: { screen: CustomerProjectMaster },
    CustomerContactMasterActivity: { screen: CustomerContactMaster },
    CustomerLedgerActivity: { screen: CustomerLedger },
    CustomerReportDetailActivity: { screen: CustomerReportDetail },
    SupplierFinanceListActivity: { screen: SupplierFinanceList },
    AgeListActivity: { screen: AgeList },
    GraphBarActivity: { screen: GraphBar },
    AgeListCustomerActivity: { screen: AgeListCustomer },
    CustomerReportListActivity: { screen: CustomerReportList },
    AccountsReceivableActivity: { screen: AccountsReceivable },
    LeaveRequestActivity: { screen: LeaveRequest },
    LeaveApprovalListActivity: { screen: LeaveApprovalList },
    LeaveApprovalActivity: { screen: LeaveApproval },
    LeaveApprovalStatusActivity: { screen: LeaveApprovalStatus },
    PRStatusActivity: { screen: PRStatus },
    POAppGenActivity: { screen: POAppGen },
    ChangePasswordActivity: { screen: ChangePassword },
    HomeActivity: { screen: Home },
    JournalSiteApprovalActivity: { screen: JournalSiteApproval },
    JournalSiteActivity: { screen: JournalSite },
    JournalSiteEntryActivity: { screen: JournalSiteEntry },
    ProjectMaterialListActivity: { screen: ProjectMaterialList },
    PhysicalStockSaveActivity: { screen: PhysicalStockSave },
    CostApprovalListActivity: { screen: CostApprovalList },
    BudgetApprovalActivity: { screen: BudgetApproval },
    ForecastApprovalActivity: { screen: ForecastApproval },
    PayAppPendingActivity: { screen: PayAppPending },
    PayApprovalActivity: { screen: PayApproval },
    PayAppStatusActivity: { screen: PayAppStatus },
    ERPToDoListActivity: { screen: ERPToDoList },
    ERPToDoDetailActivity: { screen: ERPToDoDetail },
    //ssPdfViewActivity:{screen:PdfView},
    ProjectMailActivity: { screen: ProjectMail },
    CustomerInvBalanceActivity: { screen: CustomerInvBalance },
    PunchListActivity: { screen: PunchList },
    ProjectLedgerActivity: { screen: ProjectLedger },
    DeliveryNoteReportActivity: { screen: DeliveryNoteReport },
    DashBoardActivity: { screen: DashBoard },

    //Approve
    ApprovalListActivity: { screen: ApprovalList },
    HRApprovalListActivity: { screen: HRApprovalList },
    PayRollApprovalActivity: { screen: PayRollApproval },
    SalaryAdjustApprovalActivity: { screen: SalaryAdjustApproval },
    RecruitmentApprovalActivity: { screen: RecruitmentApproval },
    SiteTransferApprovalActivity: { screen: SiteTransferApproval },
    EmployeeJoiningApprovalActivity: { screen: EmployeeJoiningApproval },
    ProjectInvoiceApprovalListActivity: { screen: ProjectInvoiceApprovalList },
    ProjectInvoiceApprovalActivity: { screen: ProjectInvoiceApproval },
    ScrapInvoiceApprovalActivity: { screen: ScrapInvoiceApproval },
    EmpLeaveSettlementApprovalActivity: { screen: EmpLeaveSettlementApproval },
    FinalSettlementApprovalActivity: { screen: FinalSettlementApproval },
    ProjMaterialTransferListActivity: { screen: ProjMaterialTransferList },
    ProjMaterialTransferApprovalActivity: { screen: ProjMaterialTransferApproval },
    SupplierApprovalListActivity: { screen: SupplierApprovalList },
    SupplierApprovalActivity: { screen: SupplierApproval },
    CustomerPOApprovalListActivity: { screen: CustomerPOApprovalList },
    CustomerPOApprovalActivity: { screen: CustomerPOApproval },
    JournalApprovalListActivity: { screen: JournalApprovalList },
    JournalApprovalActivity: { screen: JournalApproval },
    ProjectDrawingApprovalListActivity: { screen: ProjectDrawingApprovalList },
    ProjectDrawingApprovalActivity: { screen: ProjectDrawingApproval },
    ProjectDrawingSOSApprovalActivity: { screen: ProjectDrawingSOSApproval },
    EquipmentTransferListActivity: { screen: EquipmentTransferList },
    EquipmentTransferApprovalActivity: { screen: EquipmentTransferApproval },
    EmpReleaseAppListActivity: { screen: EmpReleaseAppList },
    EmpReleaseApprovalActivity: { screen: EmpReleaseApproval },
    DeliveryNoteAppListActivity: { screen: DeliveryNoteAppList },
    DeliveryNoteApprovalActivity: { screen: DeliveryNoteApproval },
    EquipmentTransferRepairApprovalActivity: { screen: EquipmentTransferRepairApproval },
    EquipmentTransferListActivity: { screen: EquipmentTransferList },
    EquipmentTransferApprovalActivity: { screen: EquipmentTransferApproval },
    EmpLeaveReturnAppListActivity: { screen: EmpLeaveReturnAppList },
    EmpLeaveReturnAppActivity: { screen: EmpLeaveReturnApp },
    OTAppListActivity: { screen: OTApprovalList },
    OTAppActivity: { screen: OTApproval },
    TaskGalleryActivity: { screen: TaskGallery },
    ManPowerDistributionActivity: { screen: ManPowerDistribution },

    //Production
    HomeProductionActivity: { screen: HomeProduction },
    InspectionRequestActivity: { screen: InspectionRequest },
    InspectionRequestSTActivity: { screen: InspectionRequestST },
    InspectionRequestNozActivity: { screen: InspectionRequestNoz },
    InspectionRequestRTActivity: { screen: InspectionRequestRT },

    //Document
    DocumentActivity: { screen: Document },
    DocumentViewerActivity: { screen: DocumentViewer },

    //Customer
    HomeCustomerActivity: { screen: HomeCustomer }
  },
  {
    // initialRouteName: 'CustomerInvBalanceActivity',
    initialRouteName: 'LoginActivity',
    // using headermode removelistner error to solve
    headerMode: 'float'
  }

);


const RootApp = createAppContainer(RootStack);

const customFonts = {
  Regular: require('./component/res/font/Sansation_Regular.ttf'),
  Bold: require('./component/res/font/Sansation_Bold.ttf'),
  Italic: require('./component/res/font/Sansation_Italic.ttf'),
  ItalicBold: require('./component/res/font/Sansation_Bold_Italic.ttf')
};


const App = () => {

  const [isLoaded] = useFonts(customFonts);
  const [appisReady, setAppIsReady] = useState(false);

  //App State 
  const appState = useRef(AppState.currentState);
  const [appStateVisible, setAppStateVisible] = useState(appState.current);
  const [dimensions, setDimensions] = useState(Dimensions.get('window'));

  useEffect(() => {
    async function prepare() {
      try {
        // Prevent the splash screen from auto-hiding
        await SplashScreen.preventAutoHideAsync();
        // Load other resources like fonts, images, etc.
        // Wait for fonts to be loaded
        if (!isLoaded) return;
        // Update app state when resources are ready
        setAppIsReady(true);
      } catch (e) {
        console.warn(e);
      } finally {
        // Hide splash screen after the app is ready
        if (appisReady) {
          await SplashScreen.hideAsync();
        }
      }
    }

    prepare();
  }, [isLoaded, appisReady]);

  //handle App State Change
  useState(appState.current);

  useEffect(() => {
    const subscription = AppState.addEventListener('change',
      nextAppState => {
        if (
          appState.current.match(/inactive|background/) &&
          nextAppState === 'active'
        ) {
          console.log('App has come to the foreground!');
        }

        appState.current = nextAppState;
        setAppStateVisible(appState.current);
        console.log('AppState', appState.current);
      });

    return () => {
      subscription.remove();
    };
  }, []);


  if (!appisReady) {
    return null; // Render nothing until the app is ready
  }

  return (
    <GestureHandlerRootView>
      <RootApp />
    </GestureHandlerRootView>
  );

}

export default App

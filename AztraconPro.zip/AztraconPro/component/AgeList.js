import React, { Component } from 'react';
import { ScrollView, StyleSheet, View, Dimensions, FlatList, TextInput, TouchableOpacity, Image, Alert } from 'react-native';
import { Col, Grid, Row } from 'react-native-easy-grid';
import axios from 'axios';
import { Card, CardItem } from 'native-base';
import { Overlay } from 'react-native-elements';
import { NavigationActions, StackActions } from 'react-navigation';
import strings from './res/strings';
import color from './res/colors';
import { VictoryBar, VictoryChart, VictoryTheme, VictoryLabel, VictoryPie } from "victory-native";
import { numeral } from 'numeral';
import Toast from 'react-native-whc-toast';
import { PieChart } from 'react-native-svg-charts';

import { Text } from 'react-native-svg';
import Modal from 'react-native-modal';  
import { logouttask } from './class/logout';

const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);

const ip = strings.values.commonvalues.ip;
const tokken = strings.values.commonvalues.tokken;

const lightblue = color.values.Colors.lightblue;
const blue = color.values.Colors.blue;
const colorprimary = color.values.Colors.colorPrimary;
const white = color.values.Colors.white;
const black = color.values.Colors.black;

var Localdata = [];
let bardata = [];

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class AgeList extends React.Component {
  static navigationOptions = ({ navigation }) => ({
    title: "Accounts Payable",
    color: white,
    headerStyle: {
      backgroundColor: colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily: 'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{ paddingRight: 10 }} onPress={() =>
        navigation.state.params.handlelogin()
      }>
        <Image
          style={{ alignSelf: 'center', justifyContent: 'center' }}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),

  });
  constructor(props) {
    super(props);
    this.state = {
      handlelogin: '',
      isLoading: false,
      dataSource: '',
      tot_amt: 0.0, UserID: '',
      data: '',
      isVisible: false,
      bardatasource: '',
      agecode: '',
    };
  }

  login = async () => {

    Alert.alert(
      'Logout',
      'Would you like to logout?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {
          text: 'OK', onPress: () => {
            logouttask()
            this.props.navigation.dispatch(resetAction);
          }
        },
      ],
      { cancelable: false },
    );

  }


  gotosupplierfinancelist = (index) => {
    const id = index

    const { AgeCode } = this.state.dataSource[id]
    this.props.navigation.navigate('SupplierFinanceListActivity', {
      UserID: this.state.UserID,
      AgeCode: AgeCode
    });

  }

  getagelist = () => {
    const config = {
      headers: {
        'currentToken': tokken,
      },
    };

    this.setState({ isLoading: true })
    axios.get(ip + '/getAGEList', config)
      .then(response => this.setState({ dataSource: response.data }, () => {
        if (response.status == 200) {
          let a = 0
          for (let i = 0; i < this.state.dataSource.length; i++) {
            const { Amount } = this.state.dataSource[i]
            a = parseFloat(a) + parseFloat(Amount)
          }
          this.setState({ tot_amt: a.toFixed(2) }, () => {
            this.getchartdata()
          })
        }
      }))
      .catch(err => {
        this.setState({
          isLoading: false
        }, () => {
          let error = err

          this.refs.toast.showBottom(error.toString())

          setTimeout(
            () => {
              this.props.navigation.goBack();
            },
            2000
          )

        })
      }
      );
  }
  randomColor = () => ('#' + (Math.random() * 0xFFFFFF << 0).toString(16) + '000000').slice(0, 7)

  opendialog(age) {


    this.setState({ isLoading: true, agecode: age }, () => {
      this.getbardata()
    })
  }
  getbardata() {
    bardata = []
    console.log(this.state.agecode)
    const config = {
      headers: {
        'currentToken': tokken,
      },
      params: {
        AgeCode: this.state.agecode,
      }

    };

    this.setState({ isLoading: true })
    axios.get(ip + '/getSupplierListBar', config)
      .then(response => this.setState({ bardatasource: response.data }, () => {
        if (response.status == 200) {

          for (let i = 0; i < this.state.bardatasource.length; i++) {
            const { Party, Percent, Amount } = this.state.bardatasource[i]

            var s = {
              Party: Party,
              Percent: parseInt(Percent),
              Amount: Amount,
              fill: this.randomColor()
            }
            bardata.push(s)
          }

          this.setState({
            isLoading: false, isVisible: true
          })
        }
      }))
      .catch(err => {
        this.setState({
          isLoading: false
        }, () => {
          let error = err

          this.refs.toast.showBottom(error.toString())

          setTimeout(
            () => {
              this.props.navigation.goBack();
            },
            2000
          )

        })
      }
      );
  }
  getchartdata() {

    Localdata = []

    const config = {
      headers: {
        'currentToken': tokken,
      },
    };

    axios.get(ip + '/getPayableAgeingGraph', config)
      .then(response => this.setState({ data: response.data }, () => {
        if (response.status == 200) {

          for (let i = 0; i < this.state.data.length; i++) {
            const { AgeDesc, Amount } = this.state.dataSource[i]

            var Percent = ''

            Percent = (parseFloat(Amount) / parseFloat(this.state.tot_amt)) * 100


            var s = {
              age: AgeDesc,
              percent: Percent,
              svg: {
                fill: this.randomColor(),
                onPress: () => this.opendialog(AgeDesc),
              }
            }



            Localdata.push(s)

          }
          this.setState({
            isLoading: false
          })
        }
      }))
      .catch(err => {
        this.setState({
          isLoading: false
        }, () => {
          let error = err

          this.refs.toast.showBottom(error.toString())

          setTimeout(
            () => {
              this.props.navigation.goBack();
            },
            2000
          )

        })
      }
      );
  }

  format(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  }

  componentDidMount() {


    console.disableYellowBox = true;

    this.props.navigation.setParams({
      handlelogin: this.login.bind(this)
    });

    this.setState(
      {
        UserID: this.props.navigation.getParam('UserID', '')
      }, () => { this.getagelist(); })

  }
  render() {

    const Labels = ({ slices, height, width }) => {
      return slices.map((slice, index) => {
        const { labelCentroid, pieCentroid, data } = slice;
        return (
          <Text
            key={index}

            x={pieCentroid[0]}
            y={pieCentroid[1]}
            fill={'white'}
            textAnchor='middle'
            alignmentBaseline='middle'
            fontSize={12}
            stroke={'black'}
            strokeWidth={0.2}
          >
            {data.age.toString() + "\n" + parseFloat(data.percent).toFixed(1).toString() + "%"
            }
          </Text>
        )
      })
    }

    if (this.state.isLoading) {
      return (
        <Modal
          transparent={false}
          supportedOrientations={['portrait', 'landscape']}
          visible={this.state.isLoading}
        >
          <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
            <Image
              style={{ width: 300, height: 200 }}
              source={require('./src/gears.gif')} />
          </View>
        </Modal>
      )
    }
    return (
      <View style={{ flex: 1, backgroundColor: lightblue }}>
        <ScrollView style={{ height: '8%' }}>
          <View style={{ flex: 1, paddingTop: '2%' }}>
            <Grid style={{ backgroundColor: colorprimary, padding: 4, width: "97%", alignSelf: 'center', borderRadius: 4 }}>
              <Row>
                <Col style={{ alignItems: 'flex-start', width: '70%' }}>
                  <TextInput editable={false} style={styles.textContent} value={"Age Desc"}></TextInput>
                </Col>
                <Col style={{ alignItems: 'flex-end', width: '30%' }}>
                  <TextInput editable={false} style={styles.textContent} value={"Balance Amount"}></TextInput>
                </Col>
              </Row>
            </Grid>
          </View>

        </ScrollView>
        <ScrollView style={{ height: '92%' }}>
          <FlatList
            data={this.state.dataSource}
            renderItem={({ item, index }) =>
              <Card style={{ width: '97%', alignSelf: 'center' }}>
                <CardItem style={{
                  alignItems: "flex-start", width: '100%', flexWrap: 'wrap',
                  paddingLeft: 5, paddingRight: 5, paddingTop: 5, paddingBottom: 5
                }}>
                  <Grid onPress={() => this.gotosupplierfinancelist(index)}>
                    <Row>
                      <Col style={{ alignItems: 'flex-start', width: '70%' }}>
                        <TextInput editable={false} style={{ fontSize: 12, color: black, fontFamily: 'Regular' }} value={item.AgeDesc.toString()}></TextInput>
                      </Col>
                      <Col style={{ alignItems: 'flex-end', width: '30%' }}>
                        <TextInput editable={false} style={{ fontSize: 12, color: black, fontFamily: 'Regular' }} value={this.format(item.Amount.toString())}></TextInput>
                      </Col>
                    </Row>
                  </Grid>
                </CardItem>
              </Card>
            }

            keyExtractor={(item, index) => index.toString()}
          />



          <PieChart
            style={{ height: 400 }}
            valueAccessor={({ item }) => item.percent}
            data={Localdata}
            spacing={0}
            outerRadius={'90%'}
            innerRadius={5}
          >
            <Labels />
          </PieChart>


          <Overlay
            overlayStyle={{ width: "100%", height: "100%" }}
            animationType="slide"
            isVisible={this.state.isVisible}
            onBackdropPress={() => this.setState({ isVisible: false })}>

            <TouchableOpacity style={styles.FacebookStyle} activeOpacity={0.5} onPress={() => {
              this.setState({ isVisible: !this.state.isVisible })
            }}>

              <Grid>
                <Row>
                  <Col style={{ width: '90%', alignItems: 'flex-start', alignSelf: 'center' }}>
                    <TextInput editable={false} style={{ paddingLeft: '3%', fontSize: 14, color: white, fontFamily: 'Bold', textAlign: 'left' }}
                      value='Detail Chart'></TextInput>
                  </Col>

                  <Col style={{ width: '10%', alignItems: 'center', alignSelf: 'center' }}>
                    <Image
                      source={require('./src/back.png')}
                      style={{ height: 22, width: 22 }}
                    />
                  </Col>
                </Row>
              </Grid>


            </TouchableOpacity>


            <VictoryChart
              height={700}
              theme={VictoryTheme.material}>
              <VictoryBar
                barWidth={10}
                labels={({ datum }) => `${datum.Percent}`}
                style={{
                  data: {
                    fill: ({ datum }) => datum.fill,
                  }
                }}
                minDomain={{ x: 1 }}
                horizontal    
                data={bardata}
                x="Party"
                y="Percent" />
            </VictoryChart>

          </Overlay>



          <Toast ref="toast"
          />

        </ScrollView>
      </View>
    )
  }
};
const styles = StyleSheet.create({
  titleText: {
    flex: 1,
    flexWrap: 'wrap',
    color: white,
    fontSize: 12,
    padding: 5
  },
  textContent: {
    color: white,
    fontSize: 13,
    fontFamily: 'Bold'
  },
  FacebookStyle: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colorprimary,
    borderWidth: 0.5,
    borderColor: white,
    height: 40,
    width: '100%',
    borderRadius: 5,
  },
  lottie: { width: 300, height: 100, }
});



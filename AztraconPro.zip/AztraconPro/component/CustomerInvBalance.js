import React,{ Component }  from 'react';
import {ScrollView,StyleSheet,Text,View,Modal,FlatList,TouchableOpacity,Image,Alert} from 'react-native';
import { Col,Grid,Row } from 'react-native-easy-grid';
import { NavigationActions, StackActions } from 'react-navigation';
import axios from 'axios';
import {Card,CardItem} from 'native-base';
import Toast from 'react-native-whc-toast'
import strings from './res/strings'
import color from './res/colors'
import {logouttask} from './class/logout';
import { Divider } from 'react-native-paper';

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const colorprimary=color.values.Colors.colorPrimary;
const gray=color.values.Colors.gray
const white=color.values.Colors.white;
const  red = color.values.Colors.red;
const black = color.values.Colors.black;
const lightblue=color.values.Colors.lightblue;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class CustomerInvBalance extends React.Component {

  static navigationOptions = ({ navigation }) => ({ 
    title: "Customer Invoice Balance",
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor:white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
        UserID:'',
        CusCode:'',
        CusName:'',
        isLoading: false, 
        handlelogin:'',
        dataSource:[],
    };
 
}
login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
        this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}

getCustomerInvBalance = () => {  
  const config = {
    headers: {   
    'currentToken':tokken,
  },      
  params: {
    CusCode:this.state.CusCode,
    }
  };   
    this.setState({isLoading:true,dataSource:''})

    axios.get(ip+'/getCustomerInvBalanceList', config)
    .then(response => this.setState({dataSource:response.data},() => {
     if(response.status==200){
      this.setState({isLoading:false});
  }

}))
.catch(err => 
  {
    this.setState({
      isLoading:false
    },()=>{
     let error=err
     
     this.refs.toast.showBottom(error.toString())

     setTimeout(
      () => { 
        this.props.navigation.goBack();
       },
      2000
    )

    })
  }
  );
     
}

format(x) {
    return Number(x)
    .toFixed(2)
    .replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  }

getdate(duedate){
    var duedate = new Date(duedate);
    var curdate = new Date();

    if(curdate > duedate){
        return true
    }
    return false
}

componentDidMount(){
  console.disableYellowBox = true;

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
   this.setState({
    UserID:this.props.navigation.getParam('UserID', ''),
    CusCode:"ENP       ",//this.props.navigation.getParam('CusCode', ''),
    CusName:this.props.navigation.getParam('CusName', '')
  },()=>{
   this.getCustomerInvBalance();
})

}


render() {
    if (this.state.isLoading) {
      return (
        <Modal
        transparent={false}
        supportedOrientations={['portrait', 'landscape']}
        visible={this.state.isLoading}
        >
         <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
          useNativeDriver={true}
          style={{width: 300, height: 200}}
          source={require('./src/gears.gif')}  />
          </View>     
        </Modal>
           )
  }
    return (
<View style={{flex:1,backgroundColor:lightblue}}>     
<ScrollView style={{height:'9%'}}>
<View  style={{ flex: 1,paddingTop:'2%',width:"97%",alignSelf:'center'}}>
    <Grid style={{backgroundColor:colorprimary,padding:5,borderRadius:4}}>
             <Row>
             <Col style={{alignItems:'flex-start',width:'10%'}}>
             <Text style={styles.textContent}>PID</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'34%'}}>
             <Text style={styles.textContent}>Inv. No</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'28%'}}>
             <Text style={styles.textContent}>Invoice Date</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'28%'}}>
             <Text style={styles.textContent}>Due Date</Text>
             </Col> 
             </Row>

             <View style={{ borderBottomColor: white,borderBottomWidth: StyleSheet.hairlineWidth,
                paddingTop:3,paddingBottom:3}}/>

             <Row style={{paddingTop:3}}>
             <Col style={{alignItems:'flex-end',width:'25%'}}>
             <Text style={styles.textContent}>Credit Note</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'25%'}}>
             <Text style={styles.textContent}>Net Invoice</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'25%'}}>
             <Text style={styles.textContent}>Paid Amount</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'25%'}}>
             <Text style={styles.textContent}>Inv Amount</Text>
             </Col> 
             </Row>
             </Grid>
    </View>
</ScrollView>
<ScrollView style={{height:'91%'}}>
    <FlatList
       data={ this.state.dataSource}
       renderItem={({item,index}) =>  
       <Card style={{alignSelf:'center',width:'97%'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
                paddingLeft:5,paddingRight:5,paddingTop:10,paddingBottom:10}}>
            <Grid>
            <Row>
              <Col style={{alignItems:'flex-start',width:'10%'}}>
              <Text style={{fontSize:13,fontFamily:'Bold'}}>{item.PID}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'34%'}}>
              <Text style={{fontSize:13,fontFamily:'Bold'}}>{item.InvNo}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'28%'}}>
              <Text style={{fontSize:13,fontFamily:'Bold'}}>{item.InvDate}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'28%'}}>
              <Text style={{fontSize:13,fontFamily:'Bold'}}>{item.DueDate}</Text>
              </Col> 
             </Row>

             <View style={{ borderBottomColor: gray,borderBottomWidth: StyleSheet.hairlineWidth,
                paddingTop:3,paddingBottom:3}}/>
                
             <Row style={{paddingTop:3}}>
              <Col style={{alignItems:'flex-end',width:'25%'}}>
              <Text style={{fontSize:13,fontFamily:'Italic',textAlign:'right'}}>{this.format(item.CreditNote)}</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'25%'}}>
              <Text style={{fontSize:13,fontFamily:'Italic',textAlign:'right'}}>{this.format(item.NetInvoice)}</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'25%'}}>
              <Text style={{fontSize:13,fontFamily:'Italic',textAlign:'right'}}>{this.format(item.Paid)}</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'25%'}}>
              <Text style={{fontSize:13,fontFamily:'Italic',textAlign:'right'}}>{this.format(item.InvAmt)}</Text>
              </Col> 
             </Row>

             <View style={{ borderBottomColor: gray,borderBottomWidth: StyleSheet.hairlineWidth,
                paddingTop:3,paddingBottom:3,display:parseFloat(item.BalAmt)>0?'flex':'none'}}/>

             <Row  style={{paddingTop:3,display:parseFloat(item.BalAmt)>0?'flex':'none'}}>
                <Col style={{alignItems:'flex-end',width:'75%'}}>
                <Text style={{fontSize:13,fontFamily:'Bold',alignSelf:'flex-end',color:colorprimary}}>Balance : </Text>
                </Col> 
                 <Col style={{alignItems:'flex-end',width:'25%'}}>
                     <Text style={{fontSize:14,fontFamily:'Bold',alignSelf:'flex-end',color:parseFloat(item.BalAmt)>0 & this.getdate(item.DueDate) ? red:black}}>
                         {this.format(item.BalAmt)}
                     </Text>
                 </Col>
             </Row>
            </Grid>  
             </CardItem>
           </Card>
        }

       keyExtractor={(item, index) => index.toString()}
       
      />

<Toast ref="toast"
        />
          </ScrollView>
          </View> 
        )

      }
 
 };

 const styles = StyleSheet.create({
    titleText: {
        flex:1,
        flexWrap:'wrap',
        color:white,
        fontSize:12,
        fontFamily:'Bold',
        padding:5
      },
      textContent:{
        color:white,
        fontSize:13,
        fontFamily:'Bold'
      }
  });

  


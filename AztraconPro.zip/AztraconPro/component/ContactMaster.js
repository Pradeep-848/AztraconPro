import React, { Component } from 'react';
import {
  TouchableWithoutFeedback, Linking, Platform, ScrollView, TouchableOpacity,
  StyleSheet, Text, View, Image, Modal, FlatList, Alert, Dimensions
} from 'react-native';
import { Col, Grid, Row } from 'react-native-easy-grid';
import { SearchBar } from 'react-native-elements';
import axios from 'axios';
import sms from 'react-native-sms-linking'
import { NavigationActions, StackActions } from 'react-navigation';
import { Card, CardItem } from 'native-base';
import Toast from 'react-native-whc-toast'
import { RFValue } from "react-native-responsive-fontsize";
//expo
import * as Contacts from 'expo-contacts';
//import * as Permissions from 'expo-permissions';

//own lib
import strings from './res/strings'
import color from './res/colors'
import { logouttask } from './class/logout';
import { isPortrait } from './class/useOrientation'

//constant
const ip = strings.values.commonvalues.ip;
const tokken = strings.values.commonvalues.tokken;

const colorprimary = color.values.Colors.colorPrimary;
const white = color.values.Colors.white;
const loading = color.values.Colors.loading;
const greydark = color.values.Colors.greydark;
const lightblue = color.values.Colors.lightblue;

//common style
const style_common = require('./class/style');

//logout
const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class ContactMaster extends React.Component {
  static navigationOptions = ({ navigation }) => ({
    title: "Contact Master",
    color: white,
    headerStyle: {
      backgroundColor: colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily: 'Bold',
      fontSize: RFValue(20)
    },
    headerRight: (
      <TouchableOpacity style={{ paddingRight: 10 }} onPress={() =>
        navigation.state.params.handlelogin()
      }>
        <Image
          style={{ alignSelf: 'center', justifyContent: 'center' }}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),

  });

  constructor(props) {
    super(props);
    this.state = {
      USER: '',
      handlelogin: '',
      isLoading: false,
      dataSource: [],
      data: '',
      orientation: '',
      DeviceType: '',
    };
    this.arrayholder = [];
  }
  login = async () => {

    Alert.alert(
      'Logout',
      'Would you like to logout?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {
          text: 'OK', onPress: () => {
            logouttask()
            this.props.navigation.dispatch(resetAction);
          }
        },
      ],
      { cancelable: false },
    );

  }

  getcontactlist() {
    const config = {
      headers: {
        'currentToken': tokken,
      },
    };
    this.setState({ isLoading: true })
    axios.get(ip + '/getContactlist', config)
      .then(response => this.setState({ dataSource: response.data }, () => {
        if (response.status == 200) {
          this.arrayholder = this.state.dataSource;
          this.setState({ isLoading: false })
        }
      }))
      .catch(err => {
        this.setState({
          isLoading: false
        }, () => {
          let error = err

          this.refs.toast.showBottom(error.toString())

          setTimeout(
            () => {
              this.props.navigation.goBack();
            },
            2000
          )

        })
      }
      );
  }
  SearchFilterFunction(text) {
    const newData = this.arrayholder.filter(function (item) {
      const itemData = item.CusCode.toUpperCase()
      const textData = text.toUpperCase()
      return itemData.indexOf(textData) > -1
    })
    this.setState({
      dataSource: newData,
      text: text
    })
  }


  componentDidMount() {
    console.disableYellowBox = true;


    Dimensions.addEventListener('change', () => {
      this.setState({
        orientation: isPortrait() ? 'portrait' : 'landscape'
      });
    });

    this.props.navigation.setParams({
      handlelogin: this.login.bind(this)
    });


    this.setState({
      orientation: isPortrait() ? 'portrait' : 'landscape',
      DeviceType: this.props.navigation.getParam('DeviceType', '')
    }, () => {
      this.getcontactlist()
    })

  }

  call(ID) {

    let index = ID

    const { Phone } = this.state.dataSource[index]

    if (Platform.OS === 'android') {
      Linking.openURL('tel:${' + Phone.toString() + '}');
    }
    else {
      Linking.openURL('telprompt:${' + Phone.toString() + '}');
    }
  }
  sms(ID) {

    let index = ID

    const { Mobile } = this.state.dataSource[index]

    sms(Mobile.toString(), 'Hi AZ').catch(console.error)
  }
  email(ID) {

    let index = ID

    const { Email } = this.state.dataSource[index]

    Linking.openURL('mailto:' + Email.toString() + '?subject=Type Something&body=Type Something')

    title = "support@example.com"
  }
  // contact(ID)
  // {

  //   let index=ID

  //   const{Mobile,CusCode,CusName}=this.state.dataSource[index]


  //   const { status } =  Permissions.askAsync(Permissions.CONTACTS);

  //   if (status === 'granted') {

  //     const contact = {
  //       [Contacts.Fields.FirstName]:CusCode ,
  //       [Contacts.Fields.LastName]: CusName ,
  //       [Contacts.Fields.PhoneNumbers]:Mobile
  //       }
  //       try{
  //       const contactId =  Contacts.addContactAsync(contact);
  //       console.log(contactId);
  //       if(contactId){
  //       alert("Contact Saved")
  //       }
  //       else{
  //       alert("ontact not saved.")
  //       }}
  //       catch(err){
  //       alert("ontact not saved.")
  //       }

  //   }

  // }

  contact = async (ID) => {
    let index = ID;
    const { Mobile, CusCode, CusName } = this.state.dataSource[index];

    // Request permission to access contacts
    const { status } = await Contacts.requestPermissionsAsync();

    if (status === 'granted') {
      const contact = {
        [Contacts.Fields.FirstName]: CusCode,
        [Contacts.Fields.LastName]: CusName,
        [Contacts.Fields.PhoneNumbers]: [{ label: 'mobile', number: Mobile }],
      };

      try {
        const contactId = await Contacts.addContactAsync(contact);
        console.log(contactId);
        if (contactId) {
          alert("Contact Saved");
        } else {
          alert("Contact not saved.");
        }
      } catch (err) {
        alert("Contact not saved.");
      }
    } else {
      alert('Permission to access contacts was denied');
    }
  };

  getheight(which) {
    let orient = ''
    let device = ''

    orient = this.state.orientation
    device = this.state.DeviceType

    if (which == '1') { //header
      if (device == 'phone') {

        if (orient == 'portrait') {
          return '10%'
        } else {
          //landscape
          return '10%'
        }

      } else {
        //tab
        if (orient == 'portrait') {
          return '5%'
        } else {
          //landscape
          return '10%'
        }

      }
    }


    if (which == '2') { //body
      if (device == 'phone') {

        if (orient == 'portrait') {
          return '95%'
        } else {
          //landscape
          return '90%'
        }

      } else {
        //tab
        if (orient == 'portrait') {
          return '95%'
        } else {
          //landscape
          return '90%'
        }

      }
    }

  }


  render() {
    if (this.state.isLoading) {
      return (
        <Modal
          transparent={false}
          supportedOrientations={['portrait', 'landscape']}
          visible={this.state.isLoading}
        >
          <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
            <Image
              style={style_common.load_gif}
              source={require('./src/gears.gif')} />
          </View>
        </Modal>
      )
    }
    return (

      <View style={{ flex: 1, backgroundColor: lightblue }}>
        <ScrollView style={{ height: this.getheight('1') }}>
          <SearchBar
            placeholder="Search Customer ID / Name"
            onChangeText={(text) => this.SearchFilterFunction(text)}
            value={this.state.text}
            platform={'ios'}
          />
        </ScrollView>
        <ScrollView style={{ height: this.getheight("2") }}>
          <FlatList
            data={this.state.dataSource}
            initialNumToRender={this.state.dataSource.length}
            renderItem={({ item, index }) =>
              <Card style={{ width: '97%', alignSelf: 'center' }}>
                <CardItem style={{ alignItems: "flex-start", width: '100%', flexWrap: 'wrap' }}>
                  <Grid>
                    <Row>
                      <Col style={{ alignItems: 'flex-start', width: "20%" }}>
                        <Text style={styles.tittle}>{item.CusCode}</Text>
                      </Col>
                      <Col tyle={{ alignItems: 'flex-start', width: "80%" }}>
                        <Text style={styles.tittle}>{item.CusName}</Text>
                      </Col>
                    </Row>
                    <Row>
                      <Col style={{ alignItems: 'flex-start', width: "100%" }}>
                        <Text style={styles.values}>{item.Concode}</Text>
                      </Col>
                    </Row>

                    <Row>
                      <Col style={{ alignItems: 'flex-start', width: "40%" }}>
                        <Text style={styles.values}>{item.ConName}</Text>
                      </Col>
                      <Col style={{ alignItems: 'flex-start', width: "20%" }}>
                        <Text style={styles.values}>{item.Phone}</Text>
                      </Col>
                      <Col style={{ alignItems: 'flex-start', width: "10%" }}>
                        <TouchableWithoutFeedback onPress={() => this.call(index)}>
                          <Image
                            style={styles.imagebutton}
                            source={require('./src/tm_call.png')}></Image>
                        </TouchableWithoutFeedback>
                      </Col>
                      <Col style={{ alignItems: 'flex-start', width: "10%" }}>
                        <TouchableWithoutFeedback onPress={() => this.sms(index)}>
                          <Image
                            style={styles.imagebutton}
                            source={require('./src/tm_sms.png')}></Image>
                        </TouchableWithoutFeedback>
                      </Col>
                      <Col style={{ alignItems: 'flex-start', width: "10%" }}>
                        <TouchableWithoutFeedback onPress={() => this.email(index)}>
                          <Image
                            style={styles.imagebutton}
                            source={require('./src/tm_email.png')}></Image>
                        </TouchableWithoutFeedback>
                      </Col>
                      <Col style={{ alignItems: 'flex-start', width: "10%" }}>
                        <TouchableOpacity activeOpacity={.5} onPress={() => this.contact(index)}>
                          <Image
                            style={styles.imagebutton}
                            source={require('./src/tm_save_contact.png')}></Image>
                        </TouchableOpacity>
                      </Col>
                    </Row>
                    <Row>
                      <Col style={{ alignItems: 'flex-start', width: "50%" }}>
                        <Text style={styles.values}>{item.Designation}</Text>
                      </Col>
                      <Col style={{ alignItems: 'flex-start', width: "30%" }}>
                        <Text style={styles.values}>{item.PhoneEtn}</Text>
                      </Col>

                    </Row>
                    <Row>
                      <Col style={{ alignItems: 'flex-start', width: "50%" }}>
                        <Text style={styles.values}>{item.Email}</Text>
                      </Col>
                      <Col style={{ alignItems: 'flex-start', width: "50%" }}>
                        <Text style={styles.values}>{item.Mobile}</Text>
                      </Col>
                    </Row>
                  </Grid>

                </CardItem>
              </Card>
            }
            keyExtractor={(item, index) => index.toString()}
          />
        </ScrollView>
        <Toast ref="toast"
        />
      </View>
    )
  }
};
const styles = StyleSheet.create({
  tittle: {
    color: colorprimary,
    fontSize: RFValue(13),
    fontFamily: 'Bold'
  },
  values: {
    color: greydark,
    fontSize: RFValue(12),
    fontFamily: 'Regular'
  },
  imagebutton: {
    width: RFValue(30),
    height: RFValue(30),
  },
});



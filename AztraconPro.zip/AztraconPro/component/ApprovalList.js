import React,{ Component }  from 'react';
import {TextInput,ScrollView,Modal,StyleSheet,Text,View,Image,FlatList,TouchableOpacity,YellowBox,
  Alert,Dimensions,ImageBackground,StatusBar} from 'react-native';
import { Col, Grid, Row } from 'react-native-easy-grid';
import { Divider ,Badge } from 'react-native-elements';
import { NavigationActions, StackActions } from 'react-navigation';
import axios from 'axios';
import Toast from 'react-native-whc-toast'
import {Card,CardItem} from 'native-base';
import { RFValue } from "react-native-responsive-fontsize";

//own lib
import { getimage } from './class/ImageGetter';
import strings from './res/strings'
import color from './res/colors'
import {isPortrait} from './class/useOrientation'
import {logouttask} from './class/logout';

//common style
const style_common = require('./class/style');

//constant
const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);

//color
const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;

var MenudataA = [];

//logout
const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

var { height, width } = Dimensions.get("window");

 export default class ApprovalList extends React.Component {
  static navigationOptions = ({ navigation }) => ({ 
    title: "Approval List",
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
      fontSize:RFValue(20)
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center',resizeMode:'contain'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,   
      handlelogin:'',
      dataSource:[],
      UserID:'',
      username:'',
      Designation:'', 
      RCenter:'',
      Department:'',
      DeviceType:'',
      orientation:'',
      layout: {
        height: height,
        width: width
    }
    };
}
login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
      this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}


gotonextpage=(index)=>{
  const id=index

  const {C,E}=MenudataA[id]

  console.log('here '+C)
  let AType
  if (E=='undefined' || C==null || C.length==0) {
      AType='';
  }else{
      AType=E;
  }

  if(C=='undefined' || C==null || C.length==0){
    this.refs.toast.showBottom("This Feature Update Soon")
  }else{
    this.props.navigation.navigate(C,{
      UserID:this.state.UserID,
      Name:this.state.username,
      RCenter:this.state.RCenter,
      Department:this.state.Department,
      Designation:this.state.Designation,
      Type:AType,
      DeviceType:this.state.DeviceType
  });
  }

}

getmenulist(){

  const config = {
    headers: {   
    'currentToken': tokken,
  },
    params: {
        UserID:this.state.UserID,
    }
    
  };
  MenudataA=[]
  this.setState({dataSource:null,isLoading:true})
  axios.get(ip+'/getAppHomeIOS', config)
  .then(response => this.setState({ dataSource:response.data},() => {if(response.status==200){

     
    console.log(this.state.dataSource)

      for(let i=0;i<this.state.dataSource.length;i++){
          
        const{A,B,C,D,E,F}=this.state.dataSource[i]
          
        var s={
          A:A,
          B:getimage(B),
          C:C,
          D:D,
          E:E,
          F:F
          }
        
        MenudataA.push(s)


      }

      this.setState({isLoading:false})

    }}))
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
}

componentDidMount(){

  YellowBox.ignoreWarnings([
    'VirtualizedLists should never be nested', // TODO: Remove when fixed
  ])
  
  console.disableYellowBox = true;

  this.props.navigation.setParams({
    handlelogin: this.login.bind(this)
    });

    Dimensions.addEventListener('change', () => {
      this.setState({
          orientation: isPortrait() ? 'portrait' : 'landscape'
      });
    });


    this.setState({
      username:this.props.navigation.getParam('Name', ''),
      Designation:this.props.navigation.getParam('Designation', ''),
      UserID:this.props.navigation.getParam('UserID', ''),
      RCenter:this.props.navigation.getParam('RCenter', ''),
      Department:this.props.navigation.getParam('Department', ''),
      DeviceType:this.props.navigation.getParam('DeviceType', ''),
      orientation: isPortrait() ? 'portrait' : 'landscape'
    },()=>{
    this.getmenulist();
    })
    
}

_onLayout = event => {
  this.setState({
      layout: {
          height: event.nativeEvent.layout.height,
          width: event.nativeEvent.layout.width
      }
  });
};


  render() {
    if (this.state.isLoading) {
      return (
        <Modal
         transparent={false}
         supportedOrientations={['portrait', 'landscape']}
        visible={this.state.isLoading}
        >
         <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
          useNativeDriver={true}
          style={style_common.load_gif}
          source={require('./src/gears.gif')}  />
          </View>     
        </Modal>
      )
  }
return (

  <View
  style={{ flex: 1 }}
  onLayout={this._onLayout}
   >
    <ImageBackground  source={require('./src/aztracon_bg.jpg')}   style={{
                    height: this.state.layout.height,
                    width: this.state.layout.width,
                }}>

  <ScrollView style={{flexGrow:1}}>

  <Grid style={{paddingTop:'2%'}}>
  <Row style={{backgroundColor:colorprimary,padding:RFValue(5),width:'97%',alignSelf:'center',borderRadius:4}}>
  <Text style={styles.titleText}>Approvals</Text>
  </Row>
  </Grid>

<ScrollView>

    <FlatList
       data={ MenudataA }
       renderItem={({item,index}) =>
     
       <Grid style={{flex: 1 / 3,paddingTop:10}} >
          <Col style={{alignItems:'center',width:'100%',alignSelf:'center'}}>
          <TouchableOpacity activeOpacity = { .5 } onPress={() => this.gotonextpage(index)}>

          <Card style={{borderColor:colorprimary,padding:RFValue(8),borderRadius:RFValue(5),paddingTop:0,paddingBottom:0}} > 
       
          <View
              style={{
                height: (height*12)/100,
                width:(width*15)/100,
                justifyContent: 'center',
                alignItems: 'center',
              }}
             >
           <Image style={styles.imagebutton} source={item.B}></Image>
        
          

           
           <Badge  value={item.F} status="error" 
           badgeStyle={{ borderRadius: 15,height:item.F==0?0:RFValue(20),width:RFValue(20)}}
           textStyle={{fontSize: RFValue(12),fontFamily:'Bold'}}
           containerStyle={{ position: 'absolute', top: -1, right: -8,}}>
           </Badge>
        
          
          </View>
         

            </Card> 
            </TouchableOpacity>
          <Text numberOfLines={1} style={{alignSelf:'center', flexWrap: 'wrap',fontSize:RFValue(12),fontFamily:'Bold'}}>{item.A}</Text>
     
          </Col> 
       </Grid>
      
      }
       numColumns={3}
       keyExtractor={(item, index) => index}
      />
</ScrollView>

           <Toast ref="toast"/>

  </ScrollView>
    </ImageBackground>
</View>
        )
      }
 };
 const styles = StyleSheet.create({
  titleText: {
    flex:1,
    flexWrap:'wrap',
    color:white,
    fontSize:RFValue(13),
    fontFamily:'Bold'
  },
  imagebutton: {
    width: '100%',
    height: '100%',
    alignSelf:'center',
    resizeMode: 'contain'
  },
  container: {
    flex:1,
    alignItems: 'center',
  },
  welcome: {
    fontSize: RFValue(13),
    textAlign: 'center',
    margin: 10,
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
  },
  imageStyle:{
    width: screenWidth, 
    height: screenHeight, 
    justifyContent: 'center',
    alignItems: 'center'
   },
   
   tcenter: {
    flex: 1,
    justifyContent:'flex-start',
    flexDirection: 'column',
    paddingLeft:10,
  },
  image: {
    width: 40,
    height: 40,
    marginTop:5,
    marginRight:10,
  },
  });
  
  
  
import React, { Component } from "react";
import {
  ScrollView,
  StyleSheet,
  Text,
  View,
  Modal,
  Image,
  FlatList,
  TouchableOpacity,
  Alert,
  Dimensions,
} from "react-native";
import { Col, Grid, Row } from "react-native-easy-grid";
import { SearchBar } from "react-native-elements";
import { NavigationActions, StackActions } from "react-navigation";
import axios from "axios";
import {
  Card,
  CardItem,
  Item,
  Input,
  Form,
  Label,
  Icon,
  Picker,
} from "native-base";
// import { Picker as Picker1 } from "@react-native-picker/picker";
import SelectDropdown from "react-native-select-dropdown";
import Toast from "react-native-whc-toast";
import { RFValue } from "react-native-responsive-fontsize";

//own lib
import { logouttask } from "./class/logout";
import strings from "./res/strings";
import color from "./res/colors";
import { isPortrait } from "./class/useOrientation";
import { Size } from "react-native-popover-view";

//ip
const ip = strings.values.commonvalues.ip;
const tokken = strings.values.commonvalues.tokken;

//color
const lightblue = color.values.Colors.lightblue;
const colorprimary = color.values.Colors.colorPrimary;
const white = color.values.Colors.white;
const dark = color.values.Colors.colorPrimaryDark;
const loading = color.values.Colors.loading;
const greylight = color.values.Colors.greylight;
const skyblue = color.values.Colors.skyblue;

//size
const screenWidth = Math.round(Dimensions.get("window").width);
const screenHeight = Math.round(Dimensions.get("window").height);

//common style
const style_common = require("./class/style");

//logout function
const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: "LoginActivity" })],
});

export default class QuotationMaster extends React.Component {
  static navigationOptions = ({ navigation }) => ({
    title: "Quotation Master",
    color: white,
    headerStyle: {
      backgroundColor: colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily: "Bold",
      fontSize: RFValue(18),
    },
    headerRight: (
      <TouchableOpacity
        style={{ paddingRight: 10 }}
        onPress={() => navigation.state.params.handlelogin()}
      >
        <Image
          style={{ alignSelf: "center", justifyContent: "center" }}
          source={require("./src/logout.png")}
        />
      </TouchableOpacity>
    ),
  });
  constructor(props) {
    super(props);
    this.state = {
      UserID: "",
      handlelogin: "",
      isLoading: false,
      dataSource: [],
      orientation: "",
      DeviceType: "",
      pickerstatus: "",
      value: "",
      filter: "",
    };
    this.arrayholder = [];
  }
  login = async () => {
    Alert.alert(
      "Logout",
      "Would you like to logout?",
      [
        {
          text: "Cancel",
          onPress: () => console.log("Cancel Pressed"),
          style: "cancel",
        },
        {
          text: "OK",
          onPress: () => {
            logouttask();
            this.props.navigation.dispatch(resetAction);
          },
        },
      ],
      { cancelable: false }
    );
  };

  goquotationmasterdetail(index) {
    let id = index;
    const { qid, qcus, qcid } = this.state.dataSource[id];

    this.props.navigation.navigate("QuotationMasterDetailsActivity", {
      UserID: this.state.UserID,
      QID: qid,
      CusID: qcid,
      CusName: qcus,
      DeviceType: this.state.DeviceType,
    });
  }

  getquotationV1(value) {
    const config = {
      headers: {
        currentToken: tokken,
      },
      params: {
        userid: this.state.USER,
        Status: value,
      },
    };
    this.setState({ isLoading: true });

    axios
      .get(ip + "/getQuotationlistV1", config)
      .then((response) =>
        this.setState({ dataSource: response.data }, () => {
          if (response.status == 200) {
            this.arrayholder = this.state.dataSource;
            this.setState({ pickerstatus: value }, () => {
              setTimeout(() => {
                this.setState({
                  isLoading: false,
                });
              }, 2000);
            });
          }
        })
      )
      .catch((err) => {
        this.setState(
          {
            isLoading: false,
          },
          () => {
            let error = err;

            this.refs.toast.showBottom(error.toString());

            setTimeout(() => {
              this.props.navigation.goBack();
            }, 2000);
          }
        );
      });
  }

  // getquotation(){
  //     const config = {
  //         headers: {
  //         'currentToken':tokken,
  //       },
  //       params: {
  //         userid:this.state.USER,
  //     }

  //       };
  //       this.setState({isLoading:true})

  //       axios.get(ip+'/getQuotationlist', config)
  //       .then(response => this.setState({dataSource:response.data},() => {
  //        if(response.status==200){
  //           this.arrayholder = this.state.dataSource;
  //           this.setState({isLoading:false});
  //     }

  //   }))
  //   .catch(err =>
  //     {
  //       this.setState({
  //         isLoading:false
  //       },()=>{
  //        let error=err

  //        this.refs.toast.showBottom(error.toString())

  //        setTimeout(
  //         () => {
  //           this.props.navigation.goBack();
  //          },
  //         2000
  //       )

  //       })
  //     }
  //     );
  // }

  filtersearch(text) {
    const newData = this.arrayholder.filter(function (item) {
      const itemData =
        item.qid.toString().toUpperCase() + item.qcid.toString().toUpperCase();
      const textData = text.toUpperCase();
      return itemData.indexOf(textData) > -1;
    });
    this.setState({
      dataSource: newData.sort(),
      text: text,
    });
  }

  getheight(which) {
    let orient = "";
    let device = "";

    orient = this.state.orientation;
    device = this.state.DeviceType;

    if (which == "1") {
      //header
      if (device == "phone") {
        if (orient == "portrait") {
          return "20%";
        } else {
          //landscape
          return "23%";
        }
      } else {
        //tab
        if (orient == "portrait") {
          return "15%";
        } else {
          //landscape
          return "10%";
        }
      }
    }

    if (which == "2") {
      //body
      if (device == "phone") {
        if (orient == "portrait") {
          return "80%";
        } else {
          //landscape
          return "77%";
        }
      } else {
        //tab
        if (orient == "portrait") {
          return "85%";
        } else {
          //landscape
          return "90%";
        }
      }
    }
  }

  componentDidMount() {
    console.disableYellowBox = true;

    Dimensions.addEventListener("change", () => {
      this.setState({
        orientation: isPortrait() ? "portrait" : "landscape",
      });
    });

    this.props.navigation.setParams({
      handlelogin: this.login.bind(this),
    });
    this.setState(
      {
        UserID: this.props.navigation.getParam("UserID", ""),
        pickerstatus: "P",
        orientation: isPortrait() ? "portrait" : "landscape",
        DeviceType: this.props.navigation.getParam("DeviceType", ""),
      },
      () => {
        this.getquotationV1("P");
      }
    );
  }
  render() {
    if (this.state.isLoading) {
      return (
        <Modal
          transparent={false}
          supportedOrientations={["portrait", "landscape"]}
          visible={this.state.isLoading}
        >
          <View
            style={{ flex: 1, alignItems: "center", justifyContent: "center" }}
          >
            <Image
              useNativeDriver={true}
              style={style_common.load_gif}
              source={require("./src/gears.gif")}
            />
          </View>
        </Modal>
      );
    }
    return (
      <View style={{ flex: 1, backgroundColor: lightblue }}>
        <ScrollView
          style={{
            height: this.getheight("1"),
            display: this.state.orientation == "portrait" ? "flex" : "none",
          }}
        >
          <Text
            style={{
              fontSize: RFValue(16),
              fontFamily: "Bold",
              color: dark,
              paddingLeft: "2%",
            }}
          >
            Status
          </Text>

          <Card
            style={{
              borderRadius: RFValue(4),
              width: "97%",
              alignSelf: "center",
              borderBottomColor: colorprimary,
            }}
          >
            <CardItem style={style_common.card_item_padding}>
              <Grid>
                <Row>
                  <Form
                    style={{
                      flex: 1,
                      alignItems: "flex-start",
                      fontFamily: "Regular",
                    }}
                  >
                    <Item style={{ marginLeft: 0, height: 45 }}>
                      <SelectDropdown
                        data={[
                          { title: "In Process", value: "P" },
                          { title: "Quoted", value: "Q" },
                          { title: "Awarded", value: "A" },
                        ]}
                        onSelect={(selectedItem, index) => {
                          console.log("Selected Item:", selectedItem.value);
                          this.setState(
                            { pickerstatus: selectedItem.value },
                            () => {
                              this.getquotationV1(selectedItem.value);
                            }
                          );
                        }}
                        renderButton={(isOpened) => {
                          const data = [
                            { title: "In Process", value: "P" },
                            { title: "Quoted", value: "Q" },
                            { title: "Awarded", value: "A" },
                          ];

                          const buttonText = this.state.pickerstatus
                            ? data.find(
                                (item) => item.value === this.state.pickerstatus
                              )?.title
                            : "Select Quotation Status";

                          return (
                            <View style={styles.dropdownButtonStyle}>
                              <Text
                                style={{
                                  flex: 1,
                                  fontSize: 16,
                                  color: "black",
                                }}
                              >
                                {buttonText}
                              </Text>
                              <Icon
                                name={isOpened ? "chevron-up" : "chevron-down"}
                                style={{
                                  fontSize: 20,
                                  color: colorprimary,
                                }}
                              />
                            </View>
                          );
                        }}
                        renderItem={(item, index, isSelected) => {
                          return (
                            <View
                              style={{
                                ...styles.dropdownItemStyle,
                                ...(isSelected && {
                                  backgroundColor: "#D2D9DF",
                                }),
                              }}
                            >
                              <Text
                                style={{
                                  fontSize: 16,
                                  color: "black",
                                }}
                              >
                                {item.title}
                              </Text>
                            </View>
                          );
                        }}
                        showsVerticalScrollIndicator={false}
                        dropdownStyle={{
                          borderRadius: 8,
                          borderWidth: 1,
                          borderColor: "#ccc",
                          backgroundColor: "#fff",
                        }}
                      />
                    </Item>
                  </Form>
                </Row>
              </Grid>
            </CardItem>
          </Card>

          <SearchBar
            inputContainerStyle={{ height: 25 }}
            inputStyle={{ fontSize: RFValue(14) }}
            containerStyle={{ width: "97%", alignSelf: "center", height: 50 }}
            placeholder="Search Customer / Quotation ID "
            placeholderStyle={{ fontFamily: "Regular" }}
            onChangeText={(text) => this.filtersearch(text)}
            value={this.state.text}
            searchIcon={{ name: "search", size: 19, color: colorprimary }}
            clearIcon={{ name: "close-circle", size: 19 }}
            loadingProps={{ size: "small" }}
            platform={"ios"}
          ></SearchBar>
        </ScrollView>
        {/* landscape */}
        <ScrollView
          style={{
            height: this.getheight("1"),
            display: this.state.orientation != "portrait" ? "flex" : "none",
          }}
        >
          <Grid>
            <Row>
              <Col
                style={{
                  width: "100%",
                  alignItems: "center",
                  alignSelf: "center",
                }}
              >
                <Row>
                  <Col
                    style={{
                      width: "10%",
                      alignItems: "center",
                      alignSelf: "center",
                    }}
                  >
                    <Text
                      style={{
                        fontSize: RFValue(16),
                        fontFamily: "Bold",
                        color: dark,
                        paddingLeft: "2%",
                      }}
                    >
                      Status
                    </Text>
                  </Col>
                  <Col
                    style={{
                      width: "40%",
                      alignItems: "center",
                      alignSelf: "center",
                    }}
                  >
                    <Card
                      style={{
                        borderRadius: RFValue(4),
                        width: "97%",
                        alignSelf: "center",
                        borderBottomColor: colorprimary,
                      }}
                    >
                      <CardItem style={style_common.card_item_padding}>
                        <Grid>
                          <Row>
                            <Form
                              style={{
                                flex: 1,
                                alignItems: "flex-start",
                                fontFamily: "Regular",
                              }}
                            >
                              <Item style={{ marginLeft: 0, height: 45 }}>
                                <SelectDropdown
                                  data={[
                                    { title: "In Process", value: "P" },
                                    { title: "Quoted", value: "Q" },
                                    { title: "Awarded", value: "A" },
                                  ]}
                                  onSelect={(selectedItem, index) => {
                                    console.log(
                                      "Selected Item:",
                                      selectedItem.value
                                    );
                                    this.setState(
                                      { pickerstatus: selectedItem.value },
                                      () => {
                                        this.getquotationV1(selectedItem.value);
                                      }
                                    );
                                  }}
                                  renderButton={(isOpened) => {
                                    const data = [
                                      { title: "In Process", value: "P" },
                                      { title: "Quoted", value: "Q" },
                                      { title: "Awarded", value: "A" },
                                    ];

                                    const buttonText = this.state.pickerstatus
                                      ? data.find(
                                          (item) =>
                                            item.value ===
                                            this.state.pickerstatus
                                        )?.title
                                      : "Select Quotation Status";

                                    return (
                                      <View style={styles.dropdownButtonStyle}>
                                        <Text
                                          style={{
                                            flex: 1,
                                            fontSize: 16,
                                            color: "black",
                                          }}
                                        >
                                          {buttonText}
                                        </Text>
                                        <Icon
                                          name={
                                            isOpened
                                              ? "chevron-up"
                                              : "chevron-down"
                                          }
                                          style={{
                                            fontSize: 20,
                                            color: colorprimary,
                                          }}
                                        />
                                      </View>
                                    );
                                  }}
                                  renderItem={(item, index, isSelected) => {
                                    return (
                                      <View
                                        style={{
                                          ...styles.dropdownItemStyle,
                                          ...(isSelected && {
                                            backgroundColor: "#D2D9DF",
                                          }),
                                        }}
                                      >
                                        <Text
                                          style={{
                                            fontSize: 16,
                                            color: "black",
                                          }}
                                        >
                                          {item.title}
                                        </Text>
                                      </View>
                                    );
                                  }}
                                  showsVerticalScrollIndicator={false}
                                  dropdownStyle={{
                                    borderRadius: 8,
                                    borderWidth: 1,
                                    borderColor: "#ccc",
                                    backgroundColor: "#fff",
                                  }}
                                />
                              </Item>
                            </Form>
                          </Row>
                        </Grid>
                      </CardItem>
                    </Card>
                  </Col>
                  <Col
                    style={{
                      width: "50%",
                      alignItems: "center",
                      alignSelf: "center",
                    }}
                  >
                    <SearchBar
                      inputContainerStyle={{ height: 25 }}
                      inputStyle={{ fontSize: RFValue(14) }}
                      containerStyle={{
                        width: "97%",
                        alignSelf: "center",
                        height: 50,
                      }}
                      placeholder="Search Customer / Quotation ID"
                      placeholderStyle={{ fontFamily: "Regular" }}
                      onChangeText={(text) => this.filtersearch(text)}
                      value={this.state.text}
                      searchIcon={{
                        name: "search",
                        size: 19,
                        color: colorprimary,
                      }}
                      clearIcon={{
                        name: "close-circle",
                        size: 19,
                      }}
                      loadingProps={{ size: "small", color: colorprimary }}
                      platform={"ios"}
                    />
                  </Col>
                </Row>
                <Row></Row>
              </Col>
            </Row>
          </Grid>
        </ScrollView>

        <ScrollView style={{ height: this.getheight("2") }}>
          <FlatList
            data={this.state.dataSource}
            removeClippedSubviews={true}
            maxToRenderPerBatch={10}
            windowSize={10}
            initialNumToRender={this.state.dataSource.length}
            renderItem={({ item, index }) => (
              <Card style={{ width: "97%", alignSelf: "center" }}>
                <CardItem style={style_common.card_item_padding}>
                  <Grid onPress={() => this.goquotationmasterdetail(index)}>
                    <Row style={style_common.row_padding}>
                      <Col style={{ alignItems: "flex-start", width: "30%" }}>
                        <Text
                          style={{
                            color: colorprimary,
                            fontSize: RFValue(12),
                            fontFamily: "Bold",
                          }}
                        >
                          Quotation ID -{" "}
                        </Text>
                      </Col>
                      <Col style={{ alignItems: "flex-start", width: "20%" }}>
                        <Text
                          style={{
                            fontSize: RFValue(12),
                            fontFamily: "Regular",
                          }}
                        >
                          {item.qid}
                        </Text>
                      </Col>
                      <Col style={{ alignItems: "flex-start", width: "20%" }}>
                        {/* <Text style={{color:colorprimary,fontSize:12,fontFamily:'Bold'}}></Text> Status */}
                      </Col>
                      <Col style={{ alignItems: "flex-start", width: "30%" }}>
                        {/* <Text style={{fontSize:12,fontFamily:'Regular'}}>{item.qstatus}</Text>  */}
                      </Col>
                    </Row>
                    <Row style={style_common.row_padding}>
                      <Col>
                        <Text
                          style={{
                            fontSize: RFValue(12),
                            width: "100%",
                            fontFamily: "Regular",
                          }}
                        >
                          {item.qdesc}
                        </Text>
                      </Col>
                    </Row>
                    <Row style={style_common.row_padding}>
                      <Col style={{ width: "20%", alignItems: "flex-start" }}>
                        <Text
                          style={{
                            color: colorprimary,
                            fontSize: RFValue(12),
                            fontFamily: "Bold",
                          }}
                        >
                          Customer -{" "}
                        </Text>
                      </Col>
                      <Col style={{ width: "80%", alignItems: "flex-start" }}>
                        <Text
                          style={{
                            fontSize: RFValue(12),
                            fontFamily: "Regular",
                          }}
                        >
                          {item.qcus}
                        </Text>
                      </Col>
                    </Row>
                  </Grid>
                </CardItem>
              </Card>
            )}
            keyExtractor={(item, index) => index.toString()}
          />
        </ScrollView>

        <Toast ref="toast" />
      </View>
    );
  }
}
const styles = StyleSheet.create({
  tittle: {
    color: colorprimary,
    fontSize: RFValue(13),
  },
  values: {
    color: greylight,
    fontSize: 12,
  },
  imagebutton: {
    width: 30,
    height: 30,
  },
  input: {
    maxHeight: 100,
    borderColor: skyblue,
    borderWidth: 1,
    padding: 10,
    width: 320,
    marginBottom: 10,
  },
  pickerStyle: {
    width: "100%", // Full width of the container
    height: 50, // Height of the picker
    marginBottom: "auto",
  },
  itemStyle: {
    fontSize: RFValue(16), // Font size for the items
    fontFamily: "Regular", // Custom font family, if any
    height: 44, // Height for each item (default is around 44)
  },
  dropdownButtonStyle: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 10,
    paddingVertical: 12,
    backgroundColor: "#fff",
  },
  dropdownItemStyle: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 10,
    paddingHorizontal: 15,
  },
});

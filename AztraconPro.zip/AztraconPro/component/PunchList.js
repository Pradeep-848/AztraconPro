import React from 'react';
import {ScrollView,Dimensions,Image,Modal,SectionList,StyleSheet,Text,View,TouchableOpacity,Alert} from 'react-native';
import axios from 'axios';
import { NavigationActions, StackActions } from 'react-navigation';
import { Col, Grid, Row} from 'react-native-easy-grid';
import {Card,CardItem} from 'native-base';
import { Divider } from 'react-native-elements'
import strings from './res/strings'
import {getStatus} from './class/Status'
import {logouttask} from './class/logout';
import Toast from 'react-native-whc-toast'
import color from './res/colors'


const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const { width, height } = Dimensions.get('window');

const blue=color.values.Colors.skyblue;
const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const lightblue=color.values.Colors.lightblue;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class NMRDetails extends React.Component{
  static navigationOptions = ({ navigation }) => ({ 
    title: "Punch List",
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor:white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
      super(props);
      this.state = { 
        isLoading: true, 
        data: "",
        handlelogin:'',
        pid:'',UserID:'',pdesc:''
    };
      console.disableYellowBox = true;
  }

  login = async () => 
  {
  
    Alert.alert(
      'Logout',
      'Would you like to logout?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {text: 'OK', onPress: () => { logouttask()
          this.props.navigation.dispatch(resetAction);} },
      ],
      {cancelable: false},
    );
   
  }
  
  
componentDidMount() {
  console.disableYellowBox = true;

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
  
  this.setState({
    pid:this.props.navigation.getParam('PID', ''),
    pdesc:this.props.navigation.getParam('PDesc', ''),
    UserID:this.props.navigation.getParam('UserID', ''),
    
    },()=>{this.getPunchDetails();})
}

getPunchDetails(){
    const config = {
      headers: {   
      'currentToken':tokken,
    },
      params: {
      pid:this.state.pid,
      }
    };
    this.setState({isLoading:true});
axios.get(ip+'/getPunchList', config)
  .then(response => this.setState({data:response.data},() => {if(response.status==200){
   this.setState({isLoading:false});
  }
}))
.catch(err => 
  {
    this.setState({
      isLoading:false
    },()=>{
     let error=err
     
     this.refs.toast.showBottom(error.toString())

     setTimeout(
      () => { 
        this.props.navigation.goBack();
       },
      2000
    )

    })
  }
  );
  
}

  renderItem(item) {    
      const {PNo,PDate,Category,PSource,PDesc,PStatus,PCComment,PCloseBy,ResName,PCloseDate,PDueDate} = item.item;
      return (
            <Card style={{width:'97%',alignSelf:'center'}}>
               <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
        paddingLeft:0,paddingRight:0,paddingTop:10,paddingBottom:0}}>
               <Grid>
               <Row>
               <Col style={{alignItems:'flex-start',width:'33%'}}>
               <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>{PNo}</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'33%'}}>
               <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>{PDate}</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'33%'}}>
               <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>{PCloseDate}</Text>
               </Col>
               </Row>
               <View style={{borderBottomColor:'#A9A9A9',borderBottomWidth: 1,height:5,
             width:'100%',alignSelf:'center'}}/>
             <View style={{backgroundColor:'#EBF1FF'}}>
               <Row style={styles.rowstyle}>
               <Col style={{alignItems:'flex-start',width:'20%'}}>
               <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Category - </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'5%'}}>
               <Text style={{fontSize:13,fontFamily:'Italic'}}>{Category}</Text>
               </Col> 
               <Col style={{alignItems:'flex-start',width:'20%'}}>
               <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Source - </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'20%'}}>
               <Text style={{fontSize:13,fontFamily:'Italic'}}>{PSource}</Text>
               </Col> 
               <Col style={{alignItems:'flex-start',width:'15%'}}>
               <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Status - </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'20%'}}>
               <Text style={{fontSize:13,fontFamily:'Italic'}}>{getStatus(PStatus)}</Text>
               </Col> 
               </Row>

               <Row style={styles.rowstyle}>
               <Col style={{alignItems:'flex-start',width:'27%'}}>
               <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Description</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'63%'}}>
               <Text style={{fontSize:13,fontFamily:'Italic'}}>{PDesc}</Text>
               </Col> 
               </Row>
 
               <Row style={styles.rowstyle}>
               <Col style={{alignItems:'flex-start',width:'25%'}}>
               <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Close By</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'75%'}}>
               <Text style={{fontSize:13,fontFamily:'Italic'}}>{PCloseBy+'-'+ResName}</Text>
               </Col> 
               </Row>

               <Row style={styles.rowstyle}>
               <Col style={{alignItems:'flex-start',width:'25%'}}>
               <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Comment</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'75%'}}>
               <Text style={{fontSize:13,fontFamily:'Italic'}}>{PCComment==''?'-':PCComment}</Text>
               </Col> 
               </Row>
               </View>
               </Grid>   
               </CardItem>
               </Card>
      );

  }

  render() {
      if (this.state.isLoading) {
          return (
            <Modal
            transparent={false}
            supportedOrientations={['portrait', 'landscape']}
            visible={this.state.isLoading}
            >
             <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
              <Image
              style={{width: 300, height: 200}}
              source={require('./src/gears.gif')}  />
              </View>     
            </Modal>
          )
      }

      return (
    <View style={{flex:1,backgroundColor:lightblue}}>
    
    <ScrollView style={{height:'5%'}}>

    <View  style={{ flex: 1,paddingTop:5,paddingBottom:5}}>
    <Grid style={{backgroundColor:colorprimary,padding:4,width:"97%",alignSelf:'center'}}>
             <Row>
             <Col style={{alignItems:'flex-start',width:'33%'}}>
             <Text style={styles.textContent}>Punch No</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'33%'}}>
             <Text style={styles.textContent}>Punch Date</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'33%'}}>
             <Text style={styles.textContent}>Close Date</Text>
             </Col> 
             </Row>
             </Grid>
    </View>
   </ScrollView>
   <ScrollView style={{height:'95%'}}>
              <SectionList
                  sections={this.state.data}
                  style={{paddingTop:2}}
                  initialNumToRender={this.state.data.length}
                  renderItem={this.renderItem.bind(this)}
                  renderSectionHeader={({ section }) => 
                  
                   <View  style={{ flex: 1,paddingTop:5,paddingBottom:5}}>
                   <Grid style={{backgroundColor:blue,padding:5,width:"97%",alignSelf:'center',borderRadius:2}}>
                   <Row>
                   <Col style={{alignItems:'flex-start',width:'100%'}}>
                   <Text style={styles.sectionHeader}>{section.TagID}</Text>
                   </Col> 
                   </Row>
                   </Grid>
                   </View>
                  
               }
                  keyExtractor={(item, index) => index}
              />
                <Toast ref="toast"/>
          </ScrollView>
          </View>    
      );
  }
}

const styles = StyleSheet.create({
  container: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: '#F5FCFF',
  },
  sectionHeader: {
      alignSelf:'flex-start',
      fontSize: 13,
      fontFamily:'Bold',
      color:'#fff',
  },
  itemView: {
    flex: 1,
    width,
    borderBottomWidth: 0.5,
    borderColor: '#cdcdcd',
    borderStyle: 'solid',
    paddingHorizontal: 12,
    flexDirection: 'row',
    paddingTop:2
},
textContent:{
  color:white,
  fontSize:12,
  fontFamily:'Bold'
},
titleText: {
  flex:1,
  flexWrap:'wrap',
  color:white,
  fontSize:12,
  padding:5,
  fontFamily:'Bold'
},
rowstyle:{
  paddingLeft:5,
  paddingRight:5,
  paddingTop:3,
  paddingBottom:3
}

});


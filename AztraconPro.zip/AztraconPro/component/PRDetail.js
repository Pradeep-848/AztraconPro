import React,{ Component }  from 'react';
import {ScrollView,StyleSheet,Text,View,Image,Dimensions,Modal,FlatList,
                            TouchableOpacity,Alert} from 'react-native';
import { Col, Grid, Row } from 'react-native-easy-grid';
import { Divider } from 'react-native-elements';
import axios from 'axios';
import { NavigationActions, StackActions } from 'react-navigation';
import {Card,CardItem} from 'native-base';
import Toast from 'react-native-whc-toast'
import strings from './res/strings'
import color from './res/colors'
import {logouttask} from './class/logout';

const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const blue=color.values.Colors.blue;
const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const lightblue=color.values.Colors.lightblue;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});
 export default class PRDetail extends React.Component {
  static navigationOptions = ({ navigation }) => ({ 
    title: "PR Detail",
    color:color,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false, 
      dataSource:'',
      handlelogin:'',
      pid:'',UserID:'',pdesc:'',cid:'',cname:'',prno:'',
    };
}
login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
        this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}

getPRDetail=()=>{
  const config = {
    headers: {   
    'currentToken': tokken,
  },
    params: {
        prno:this.state.prno,
    }
    
  };

  this.setState({isLoading:true})
  axios.get(ip+'/getPRDetail', config)
  .then(response => this.setState({ dataSource:response.data},() => {if(response.status==200){this.setState({isLoading:false})}}))
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
}


componentDidMount(){
  console.disableYellowBox = true;

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
  
  this.setState({
      pid:this.props.navigation.getParam('PID', ''),
      cid:this.props.navigation.getParam('CusID', ''),
      pdesc:this.props.navigation.getParam('PDesc', ''),
      cname:this.props.navigation.getParam('CusName', ''),
      UserID:this.props.navigation.getParam('UserID', ''),
      prno:this.props.navigation.getParam('PRNo', '')
},()=>{this.getPRDetail();})
}
  render() {
    if (this.state.isLoading) {
      return (
        <Modal
        transparent={false}
        supportedOrientations={['portrait', 'landscape']}
        visible={this.state.isLoading}
        >
         <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
           useNativeDriver={true}
          style={{width: 300, height: 200}}
          source={require('./src/gears.gif')}  />
          </View>     
        </Modal>
      )
  }
    return (
  <View style={{flex:1,backgroundColor:lightblue}}>    
  <ScrollView style={{height:'12%'}}>
  <Grid style={{paddingTop:'2%'}}>
  <Row style={{backgroundColor:colorprimary,width:'97%',alignSelf:'center',borderRadius:3}}>
  <Text numberOfLines={2} style={styles.titleText}>
          {this.state.pid+" - "+this.state.pdesc}
  </Text>
   </Row>
   <Divider style={{ backgroundColor:white}} />
   <Divider style={{ backgroundColor:white}} />
   <Row style={{backgroundColor:colorprimary,width:'97%',alignSelf:'center',borderRadius:3}}>
   <Text numberOfLines={1} style={styles.titleText}>
          {this.state.cid.toString().trim()+" - "+this.state.cname}
  </Text>
  </Row>  
  </Grid>
</ScrollView>
<ScrollView style={{height:"88%"}}>
    <FlatList
       data={ this.state.dataSource }
       initialNumToRender={this.state.dataSource.length}
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
                          paddingLeft:5,paddingRight:5,paddingTop:10,paddingBottom:10}}>
            <Grid>
            <Row style={styles.paddingrow}>
              <Col style={{alignItems:'flex-start',width:'14%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>SlNo - </Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'36%'}}>
              <Text style={{fontSize:13,fontFamily:'Italic'}}>{item.SlNo}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'25%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Item Type - </Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'25%'}}>
              <Text style={{fontSize:13,fontFamily:'Italic'}}>{item.ItemType}</Text>
              </Col> 
             </Row>
             <View style={{borderBottomColor:'#A9A9A9',borderBottomWidth: 1,height:5,width:'100%',alignSelf:'center'}}/>
            <Row style={styles.paddingrow}>
              <Col style={{alignItems:'flex-start'}}>
              <Text style={{fontSize:13,fontFamily:'Italic'}}>{item.Description}</Text>
              </Col> 
            </Row>
            <View style={{borderBottomColor:'#A9A9A9',borderBottomWidth: 1,height:5,width:'100%',alignSelf:'center'}}/>
            <Row style={styles.paddingrow}>
              <Col style={{alignItems:'flex-start',width:'40%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Required Quantity</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'60%'}}>
              <Text style={{fontSize:13,fontFamily:'Italic'}}>{item.RequiredQty}</Text>
              </Col> 
            </Row>
            <Row style={styles.paddingrow}>
              <Col style={{alignItems:'flex-start',width:'40%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Total Weight</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'60%'}}>
              <Text style={{fontSize:13,fontFamily:'Italic'}}>{item.TotalWeight}</Text>
              </Col> 
            </Row>
            <Row style={styles.paddingrow}>
              <Col style={{alignItems:'flex-start',width:'40%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Total Value</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'60%'}}>
              <Text style={{fontSize:13,fontFamily:'Italic'}}>{item.TotalValue}</Text>
              </Col> 
            </Row>
            </Grid>  
             </CardItem>
           </Card>
        }

       keyExtractor={(item, index) => index.toString()}
       
      />
  <Toast ref="toast"/>
          </ScrollView>
          </View>
        )
      }
 };
 const styles = StyleSheet.create({
  titleText: {
    flex:1,
    flexWrap:'wrap',
    color:white,
    fontSize:12,
    padding:5,
    fontFamily:'Bold'
  },
  paddingrow:{
    paddingTop:2
  }
  });
  
  
  
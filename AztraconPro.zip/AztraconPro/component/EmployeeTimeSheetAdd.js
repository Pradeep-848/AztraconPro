import React,{ Component }  from 'react';
import {TouchableHighlight,TouchableOpacity,StyleSheet, Text,View,TextInput,Button,Image,ImageBackground,Dimensions,AsyncStorage,NetInfo,StatusBar,ActivityIndicator,Alert,Modal,FlatList} from 'react-native';
import {createStackNavigator, createAppContainer,StackNavigator,NavigationActions, StackActions} from 'react-navigation';
import {Item,Input,Label,Picker,Icon } from 'native-base'
import Toast from 'react-native-whc-toast'
import { Col, Grid, Row } from 'react-native-easy-grid';
import { ScrollView } from 'react-native-gesture-handler';
import axios from 'axios';
import DateTimePicker from "react-native-modal-datetime-picker";
import moment from 'moment';

const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);
const screen = Math.round(Dimensions.get('window').width)/3;
const mheight=Math.round(Dimensions.get('window').height)/2;
const sheight=(mheight/2)+mheight;
import strings from './res/strings'
const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

 export default class EmployeeTimeSheetAdd extends React.Component {
   static navigationOptions = {
    title: "Employee TimeSheet",
    headerStyle: {
      backgroundColor: "#2452b2"
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontFamily:'Bold',
    },
   
  }; 
  
  constructor(props) {
    super(props);
    this.state = {
      username:'',
      Designation:'',
      USER:'',
      PickerValueHolder : '',
      dataSourcep:[],
      dataSourcet:[],
      pid:'',
      isVisible: false,
      isVisibleT: false,
      showtext:'Project Details',
      showtextT:'Tag Details',
      isDateTimePickerVisible: false,
      TaskDate:'Task Date',
      Icode:'',
      taskdesc:'',
      Complete:'',
      Regular:'',
      Over:'',
      pdate:''
    };
}

onSave() {
if(this.state.pid===""){
  this.refs.toast.showBottom('Please select project');
}else if(this.state.taskdesc.length===0 || this.state.taskdesc===''){
  this.refs.toast.showBottom('Please enter description');
}else{
this.getSaveEmployeeTime();
}

}

getSaveEmployeeTime(){
this.setState({isLoading:true})
  axios({
    method: 'post',
    url:ip+'/addEmployeeTimeSheetAdd',
    headers: {'currentToken':tokken}, 
    data: {
     // EmpID:this.state.USER,
      EmpID:'2927',
      PID:this.state.pid,
      TagClass:this.state.Icode,
      TaskDesc:this.state.taskdesc,
      RegTime:this.state.Regular,
      RCenter:'2132',
      OverTime:this.state.Over,
      Percent:this.state.Complete,
      ActivityDate:this.state.pdate
    }
  }).then(response=>{if(response.status===200){
    this.setState({isLoading:false,TaskDate:'',taskdesc:'',pid:'',Icode:'',Over:'',Complete:'',Regular:'',showtext:'',showtextT:''},()=>{ this.refs.toast.showBottom('Save Success');})
  }else{
    this.refs.toast.showBottom('Save Failed');
  }});

}

componentDidMount() {
  this.setState({username:this.props.navigation.getParam('username', ''),Designation:this.props.navigation.getParam('Designation', ''),USER:this.props.navigation.getParam('USER', '')},()=>{this.getspnproject();})
}
  getspnproject(){
    const config = {
        headers: {   
        'currentToken':tokken,
      },
        params: {
          uid:this.state.USER,
        }
        
      };
      this.setState({isLoading:true})
      axios.get(ip+'/getSpnProject', config)
      .then(response => this.setState({ dataSourcep:response.data},() => {if(response.status==200){this.setState({isLoading:false})}}))
      .catch(err => console.log(err));  
  }
  getspntag(){
    const config = {
        headers: {   
        'currentToken':tokken,
      },
        params: {
          pid:this.state.pid,
        }
        
      };
      
      axios.get(ip+'/getSpnTag', config)
      .then(response => this.setState({ dataSourcet:response.data},() => {if(response.status==200){this.setState({isLoading:false})}}))
      .catch(err => console.log(err));  
  }

  GetPickerSelectedItemValue=()=>{
    Alert.alert(this.state.PickerValueHolder);
  }
  GetPickerSelectedItemValueProject=()=>{
    this.setState({pid:this.state.PickerValueHolder},()=>{this.getspntag();})
  }
 
  FlatListItemSeparator = () => {
    return (
      <View
        style={{
          height: 1,
          width: "100%",
          backgroundColor: "#607D8B",
        }}
      />
    );
  }
 
  GetFlatListItem (sPid,sCusCode,sPdesc,sStatus) {
    this.setState({ isVisible:!this.state.isVisible})
  //  Alert.alert(sPid);
    this.setState({pid:sPid},() =>{if(this.state.pid!=""){
      this.getspntag();
    }})
    this.setState({showtext:sPid+" "+sCusCode+" "+sPdesc+" "+sStatus})
  }
  GetFlatListItemT (sIcode,sIdesc,sQty,sThk) {
    this.setState({ isVisibleT:!this.state.isVisibleT})
    this.setState({Icode:sIcode},() =>{if(this.state.Icode!=""){
      }})
    this.setState({showtextT:sIcode+" "+sIdesc+" "+sQty+" "+sThk})
  }
  
  showDateTimePicker = () => {
    this.setState({ isDateTimePickerVisible: true });
  };
 
  hideDateTimePicker = () => {
    this.setState({ isDateTimePickerVisible: false });
  };
 
  handleDatePicked = date => {
    this.setState({pdate:date})
    const NewDate =moment(date).format('DD-MM-YYYY')
    this.setState({TaskDate:NewDate})

    this.hideDateTimePicker();
  };


render() {
     if (this.state.isLoading) {
        return (
            <View style={{ flex: 1,
              justifyContent: 'center',
              flexDirection: 'column' }}>
                <ActivityIndicator size="large" color="#0000ff" />
            </View>
        )
    }
  
  return (
   
<ScrollView style={styles.container}>

<Text style={styles.spinner}  onPress={this.showDateTimePicker}  >
        {this.state.TaskDate}
      </Text>   

<DateTimePicker
          isVisible={this.state.isDateTimePickerVisible}
          onConfirm={this.handleDatePicked}
          onCancel={this.hideDateTimePicker}
        />
    
     <Text style={styles.textContent}>
          Project Detail
      </Text>     
      <Text style={styles.spinners}  onPress = {() => {this.setState({ isVisible: true})}}  >
        {this.state.showtext}
      </Text>     

      <Modal            
          animationType = {"fade"}  
          transparent = {true}  
          visible = {this.state.isVisible}  
          onRequestClose = {() =>{ console.log("Modal has been closed.") } }>  
          {/*All views of Modal*/}  
      <View style = {styles.modal}>  
  <TouchableOpacity style={styles.FacebookStyle} activeOpacity={0.5} onPress = {() => {  
                  this.setState({ isVisible:!this.state.isVisible})}}>

    <Text style={{color:'#fff',textDecorationStyle:'solid',paddingLeft:'3%'}}>Project Details</Text>
    <Image
     source={require('./src/back.png')}
     style={{height:22,width:22}}         
    />
</TouchableOpacity>

      <FlatList
       data={ this.state.dataSourcep }
        ItemSeparatorComponent = {this.FlatListItemSeparator}
        renderItem={({item}) => 
        <Grid onPress={this.GetFlatListItem.bind(this, item.sPid,item.sCusCode,item.sPdesc,item.sStatus)}>
              <Col style={{alignItems:'flex-start',width:50}}>
              <Text style={{fontSize:13}}>{item.sPid}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:50}}>
              <Text style={{fontSize:13}}>{item.sCusCode}</Text>
              </Col> 
              <Col>
              <Row style={{alignItems:'flex-start'}}>
              <Text style={{fontSize:13}}>{item.sPdesc}</Text>
              </Row> 
              <Row style={{alignItems:'flex-start'}}>
              <Text style={{fontSize:13}}>{item.sStatus}</Text>
              </Row> 
             </Col>  
        </Grid>
        }
       keyExtractor={(item, index) => index.toString()}
       onEndReached={() => {this.setState({loadervisibleP:false})}}
      />

          </View>  
        </Modal>  
  
    <Text style={styles.textContent}>
          Tag Detail
      </Text> 
      <Text style={styles.spinners}  onPress = {() => {this.setState({ isVisibleT: true})}}  >
        {this.state.showtextT}
      </Text>     

      <Modal            
          animationType = {"fade"}  
          transparent = {true}  
          visible = {this.state.isVisibleT}  
          onRequestClose = {() =>{ console.log("Modal has been closed.") } }>  
          {/*All views of Modal*/}  
      <View style = {styles.modal}>  
  <TouchableOpacity style={styles.FacebookStyle} activeOpacity={0.5} onPress = {() => {  
                  this.setState({ isVisibleT:!this.state.isVisibleT})}}>
 
    <Text style={{color:'#fff',textDecorationStyle:'solid',paddingLeft:'3%'}}>Tag Details</Text>
    <Image
     source={require('./src/back.png')}
     style={{height:22,width:22}}         
    />
</TouchableOpacity>

      <FlatList
       data={ this.state.dataSourcet }
        ItemSeparatorComponent = {this.FlatListItemSeparator}
        renderItem={({item}) => 
        <Grid onPress={this.GetFlatListItemT.bind(this, item.sIcode,item.sIdesc,item.sQty,item.sThk)}>
              <Col style={{alignItems:'flex-start',width:40}}>
              <Text style={{fontSize:13}}>{item.sIcode}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:screenWidth-40}}>
              <Text style={{fontSize:13}}>{item.sIdesc}</Text>
              </Col> 
              <Col>
              <Row style={{alignItems:'flex-start',width:0}}>
              <Text style={{fontSize:13}}>{item.sQty}</Text>
              </Row> 
              <Row style={{alignItems:'flex-start',width:0}}>
              <Text style={{fontSize:13}}>{item.sThk}</Text>
              </Row> 
             </Col>  
        </Grid>
        }
       keyExtractor={(item, index) => index.toString()}
       onEndReached={() => {console.log('list ended');}}
      />

          </View>  
        </Modal>

    <Item floatingLabel>
              <Label style={{color:'#2452b2',fontSize:13}}>Task Description</Label>
              <Input  value={this.state.taskdesc}
          onChangeText={(taskdesc) => this.setState({ taskdesc })} />
    </Item>
 
          <View style={styles.b}>
            <Grid>
              <Col style={{alignItems:'flex-start',width:screen}}>
              <Item floatingLabel>
              <Label style={{color:'#2452b2',fontSize:13}}>%Complete</Label>
              <Input  keyboardType={'numeric'}
               value={this.state.Complete}
          onChangeText={(Complete) => this.setState({ Complete })}
               />
              </Item>
              </Col> 
              <Col style={{alignItems:'flex-start',width:screen}}>
              <Item floatingLabel>
              <Label style={{color:'#2452b2',fontSize:13}}>Regular Time</Label>
              <Input  keyboardType={'numeric'} 
          value={this.state.Regular}
          onChangeText={(Regular) => this.setState({ Regular })}
              />
              </Item>
              </Col> 
              <Col style={{alignItems:'flex-start',width:screen}}>
              <Item floatingLabel>
              <Label style={{color:'#2452b2',fontSize:13}}>Over Time</Label>
              <Input  keyboardType={'numeric'}
               value={this.state.Over}
              onChangeText={(Over) => this.setState({ Over })}
               />
              </Item>
              </Col> 
            </Grid>  
          </View> 


<View style={[{ width: "35%", margin: 20,alignSelf:'center'}]}>
          <Button
            onPress={this.onSave.bind(this)}
            title="Save"         
          />
        </View> 
        <Toast style={{bottom:0}} ref="toast"/>
    </ScrollView>
  )
}

 
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'white',
      },
      labelInput: {
        color: '#2452b2',
        fontSize:12,

      },
      formInput: {    
        borderBottomWidth: 1.5, 
        borderColor: '#A8A8A8',     
      },
      input: {
        borderWidth: 0,
        fontSize:13
      },
      textContent: {
        backgroundColor:'#2452b2',
        fontSize: 12,
        padding:4,
        color: '#fff',
        fontWeight: 'bold'
      },
      spinner: {
        fontSize: 15,
        padding:10,
        height:40,
        flexWrap: 'wrap',
        color: 'grey',
      },
      spinners: {
        fontSize: 13,
        padding:10,
        height:50,
        flexWrap: 'wrap',
        color: 'grey',
      },
      b: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop:5,
      },
      tbutton: {
        flex:1,
        paddingTop:10,
        height:50,
        width:40,
      },
      innerContainer: {
        flexDirection: 'row',
        alignItems: 'stretch'
      },
      text: {
        fontSize: 18
      },
      headerFooterContainer: {
        padding: 10,
        alignItems: 'center'
      },
      clearButton: { backgroundColor: 'grey', borderRadius: 5, marginRight: 10, padding: 5 },
      optionContainer: {
        padding: 10,
        borderBottomColor: 'grey',
        borderBottomWidth: 1
      },
      optionInnerContainer: {
        flex: 1,
        flexDirection: 'row'
      },
      box: {
        width: 20,
        height: 20,
        marginRight: 10
      },
      pick:{
        flex: 1, 
        flexDirection: 'row',
        flexWrap: 'wrap'
      },
      headerText: {
        fontSize: 20,
        margin: 10,
        fontWeight: "bold"
      },
      menuContent: {
        color: "#000",
        fontWeight: "bold",
        padding: 2,
        fontSize: 20
      },
   
      innerContainer: {
        flexDirection: 'row',
        alignItems: 'stretch'
      },
      text: {
        fontSize: 18
      },
      headerFooterContainer: {
        padding: 10,
        alignItems: 'center'
      },
      clearButton: { backgroundColor: 'grey', borderRadius: 5, marginRight: 10, padding: 5 },
      optionContainer: {
        padding: 10,
        borderBottomColor: 'grey',
        borderBottomWidth: 1
      },
      optionInnerContainer: {
        flex: 1,
        flexDirection: 'row'
      },
      box: {
        width: 20,
        height: 20,
        marginRight: 10
      },
      modal: {  
        flex: 1,
        backgroundColor: '#fff',
        height: sheight, 
        position: 'absolute',
        bottom: 0
         },  
         text: {  
            color: '#3f2949',  
            marginTop: 10  
         },
         FacebookStyle: {
          flexDirection: 'row',
          alignItems:'center',
          backgroundColor: '#1ca0ff',
          borderWidth: 0.5,
          borderColor: '#fff',
          height: 40,
          width: screenWidth,
          borderRadius: 5,
        },
        tcenter: {
          flex: 1,
          //justifyContent: 'center',
          marginTop: 50,
          alignItems: 'center'
        },
});

      


 


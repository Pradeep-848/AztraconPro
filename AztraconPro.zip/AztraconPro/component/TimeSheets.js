import React, { Component } from 'react';
import {
  ScrollView, Modal, StyleSheet, Text, View, Image,
  Dimensions, FlatList, TouchableOpacity, Alert
} from 'react-native';
import { Col, Grid, Row } from 'react-native-easy-grid';
import { Divider } from 'react-native-elements';
import axios from 'axios';
import { NavigationActions, StackActions } from 'react-navigation';
import Toast from 'react-native-whc-toast'
import { Card, CardItem } from 'native-base';
import { RFValue } from "react-native-responsive-fontsize";

//own lib
import strings from './res/strings'
import color from './res/colors'
import { logouttask } from './class/logout';
import { isPortrait } from './class/useOrientation'

//constants
const ip = strings.values.commonvalues.ip;
const tokken = strings.values.commonvalues.tokken;

const blue = color.values.Colors.blue;
const colorprimary = color.values.Colors.colorPrimary;
const white = color.values.Colors.white;
const gray = color.values.Colors.gray;
const lightblue = color.values.Colors.lightblue;

//common style
const style_common = require('./class/style');

//logout
const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class TimeSheets extends React.Component {
  static navigationOptions = ({ navigation }) => ({
    title: "Time Sheets",
    color: "#fff",
    headerStyle: {
      backgroundColor: colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily: 'Bold',
      fontSize: RFValue(20)
    },
    headerRight: (
      <TouchableOpacity style={{ paddingRight: 10 }} onPress={() =>
        navigation.state.params.handlelogin()
      }>
        <Image
          style={{ alignSelf: 'center', justifyContent: 'center' }}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),

  });
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      dataSource: '',
      handlelogin: '',
      orientation: '',
      DeviceType: '',
      pid: '',
      UserID: '',
      pdesc: '',
      cid: '',
      cname: ''
    };
  }
  login = async () => {

    Alert.alert(
      'Logout',
      'Would you like to logout?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {
          text: 'OK', onPress: () => {
            logouttask()
            this.props.navigation.dispatch(resetAction);
          }
        },
      ],
      { cancelable: false },
    );

  }

  gettimesheetdetails = (index) => {

    const id = index

    const { ResourceCenter } = this.state.dataSource[id]

    this.props.navigation.navigate('TimeSheetDetailActivity', {
      RID: ResourceCenter,
      PID: this.state.pid,
      UserID: this.state.UserID,
      PDesc: this.state.pdesc,
      CusID: this.state.cid,
      CusName: this.state.cname,
    });

  }

  gettimesheet = () => {
    const config = {
      headers: {
        'currentToken': tokken,
      },
      params: {
        pid: this.state.pid,
      }

    };

    this.setState({ isLoading: true })
    axios.get(ip + '/getTimeSheets', config)
      .then(response => this.setState({ dataSource: response.data }, () => {
        if (response.status == 200) {
          console.log(this.state.dataSource)
          this.setState({
            isLoading: false
          })
        }
      }))
      .catch(err => {
        this.setState({
          isLoading: false
        }, () => {
          let error = err

          this.refs.toast.showBottom(error.toString())

          setTimeout(
            () => {
              this.props.navigation.goBack();
            },
            2000
          )

        })
      }
      );
  }

  getheight(which) {

    let orient = ''
    let device = ''

    orient = this.state.orientation
    device = this.state.DeviceType

    if (which == '1') { //header
      if (device == 'phone') {

        if (orient == 'portrait') {
          return '10%'
        } else {
          //landscape
          return '25%'
        }

      } else {
        //tab
        if (orient == 'portrait') {
          return '10%'
        } else {
          //landscape
          return '15%'
        }

      }
    }


    if (which == '2') { //body
      if (device == 'phone') {

        if (orient == 'portrait') {
          return '90%'
        } else {
          //landscape
          return '75%'
        }

      } else {
        //tab
        if (orient == 'portrait') {
          return '90%'
        } else {
          //landscape
          return '85%'
        }

      }
    }

  }

  componentDidMount() {
    console.disableYellowBox = true;

    this.props.navigation.setParams({
      handlelogin: this.login.bind(this)
    });

    Dimensions.addEventListener('change', () => {
      this.setState({
        orientation: isPortrait() ? 'portrait' : 'landscape'
      });
    });


    this.setState({
      pid: this.props.navigation.getParam('PID', ''),
      cid: this.props.navigation.getParam('CusID', ''),
      pdesc: this.props.navigation.getParam('PDesc', ''),
      cname: this.props.navigation.getParam('CusName', ''),
      UserID: this.props.navigation.getParam('UserID', ''),
      orientation: isPortrait() ? 'portrait' : 'landscape',
      DeviceType: this.props.navigation.getParam('DeviceType', '')
    }, () => { this.gettimesheet(); })

  }
  render() {
    if (this.state.isLoading) {
      return (
        <Modal
          transparent={false}
          supportedOrientations={['portrait', 'landscape']}
          visible={this.state.isLoading}
        >
          <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
            <Image
              style={style_common.load_gif}
              source={require('./src/gears.gif')} />
          </View>

        </Modal>
      )
    }
    return (

      <View style={{ flex: 1, backgroundColor: lightblue }}>
        <ScrollView style={{ height: this.getheight('1') }}>
          <Grid style={{ paddingTop: '2%' }}>
            <Row style={{ backgroundColor: colorprimary, width: '97%', alignSelf: 'center', borderRadius: 3 }}>
              <Text numberOfLines={1} style={styles.titleText}>
                {this.state.pid + "-" + this.state.pdesc}
              </Text>
            </Row>
            <Divider style={{ backgroundColor: white }} />
            <Divider style={{ backgroundColor: white }} />
            <Row style={{ backgroundColor: colorprimary, width: '97%', alignSelf: 'center', borderRadius: 3 }}>
              <Text numberOfLines={1} style={styles.titleText}>
                {this.state.cid.toString().trim() + "-" + this.state.cname}
              </Text>
            </Row>
          </Grid>
        </ScrollView>
        <ScrollView style={{ height: this.getheight('2') }}>
          <FlatList
            data={this.state.dataSource}
            initialNumToRender={this.state.dataSource.length}
            renderItem={({ item, index }) =>
              <Card style={{ width: '97%', alignSelf: 'center' }}>
                <CardItem style={{
                  alignItems: "flex-start", width: '100%', flexWrap: 'wrap',
                  paddingLeft: RFValue(5), paddingRight: RFValue(5), paddingTop: RFValue(5), paddingBottom: RFValue(5), backgroundColor: colorprimary
                }}>
                  <Grid onPress={() => this.gettimesheetdetails(index)}>
                    <Row>
                      <Text style={{ alignItems: 'flex-start', fontSize: RFValue(12), color: white, fontFamily: 'Bold' }}>{item.RSCName}</Text>
                    </Row>
                  </Grid>
                </CardItem>
                <CardItem style={style_common.card_item_padding}>
                  <Grid onPress={() => this.gettimesheetdetails(index)}>

                    <Row style={{ alignItems: 'center', width: '100%', flexWrap: 'wrap' }}>
                      <Col style={{ width: '100%' }}>
                        <Text style={{ fontSize: RFValue(13), alignSelf: 'center', fontFamily: 'Bold' }}>{item.ActivityDate}</Text>
                      </Col>
                    </Row>

                    <View style={{
                      borderBottomColor: '#A9A9A9', borderBottomWidth: 1, height: 10, width: '100%',
                      alignSelf: 'center'
                    }} />

                    <Row style={{ paddingTop: RFValue(4) }}>
                      <Col style={{ alignItems: 'center', width: '25%' }}>
                        <Text style={styles.tittle}>Regular Time</Text>
                      </Col>
                      <Col style={{ alignItems: 'center', width: '25%' }}>
                        <Text style={styles.tittle}>Over Time</Text>
                      </Col>
                      <Col style={{ alignItems: 'center', width: '25%' }}>
                        <Text style={styles.tittle}>Total Hours</Text>
                      </Col>
                      <Col style={{ alignItems: 'center', width: '25%' }}>
                        <Text style={styles.tittle}>Cost Total</Text>
                      </Col>
                    </Row>
                    <Row>
                      <Col style={{ alignItems: 'center', width: '25%' }}>
                        <Text style={{ fontSize: RFValue(12), fontFamily: 'Italic' }}>{item.RegularTime}</Text>
                      </Col>
                      <Col style={{ alignItems: 'center', width: '25%' }}>
                        <Text style={{ fontSize: RFValue(12), fontFamily: 'Italic' }}>{item.OverTime}</Text>
                      </Col>
                      <Col style={{ alignItems: 'center', width: '25%' }}>
                        <Text style={{ fontSize: RFValue(12), fontFamily: 'Italic' }}>{item.TotalHours}</Text>
                      </Col>
                      <Col style={{ alignItems: 'center', width: '25%' }}>
                        <Text style={{ fontSize: RFValue(12), fontFamily: 'Italic' }}>{item.CostTotal}</Text>
                      </Col>
                    </Row>
                  </Grid>
                </CardItem>
              </Card>
            }

            keyExtractor={(item, index) => index.toString()}

          />
          <Toast ref="toast" />
        </ScrollView>
      </View>

    )
  }
};
const styles = StyleSheet.create({
  titleText: {
    flex: 1,
    flexWrap: 'wrap',
    color: white,
    fontSize: RFValue(12),
    padding: RFValue(7),
    fontFamily: 'Bold'
  },
  tittle: {
    color: '#36428a',
    fontSize: RFValue(13),
    fontFamily: 'Bold'
  },
});



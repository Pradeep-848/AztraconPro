import React,{ Component }  from 'react';
import {ScrollView,StyleSheet,Text,View,Image,Dimensions,FlatList,Modal,TouchableOpacity,Alert} from 'react-native';
import { Col, Grid, Row } from 'react-native-easy-grid';
import {SearchBar} from 'react-native-elements'
import { NavigationActions, StackActions } from 'react-navigation';
import axios from 'axios';
import {Card,CardItem} from 'native-base';
import Toast from 'react-native-whc-toast'
import {logouttask} from './class/logout';
import strings from './res/strings'
import color from './res/colors'

const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const lightblue=color.values.Colors.lightblue;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class AccountsPayable extends React.Component {
  static navigationOptions = ({ navigation }) => ({ 
    title: "Accounts Payable",
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false, 
      dataSource:'',
      tot_ccb :'',
      UserID:'',
      handlelogin:'',
    };
    this.arrayholder = [] ;
}

login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
        this.props.navigation.dispatch(resetAction);
      } },
    ],
    {cancelable: false},
  );
 
}

gotosupplierleder=(index)=>{
  const id=index

  const {A,B}=this.state.dataSource[id]

  this.props.navigation.navigate('SupplierLedgerActivity',{
      UserID:this.state.UserID,
      SupID:A,
      SupName:B,
  }
  );

}

getpayableage=()=>{
  const config = {
    headers: {   
    'currentToken': tokken,
  },

  };

  this.setState({isLoading:true})
  axios.get(ip+'/getAccPayable', config)
  .then(response => this.setState({ dataSource:response.data},() => {if(response.status==200){

  this.arrayholder = this.state.dataSource ;  

  let a=0;

  for(let i=0;i<this.state.dataSource.length;i++){
      const{E}=this.state.dataSource[i]
      if(E.toString().charAt(0)=='['){
        //let str=E.toString().replace(",","").replace("[^a-zA-Z0-9]","")
      //  console.log(str)
       // a=parseFloat(a)-parseFloat(str.substring(1, str.length - 1).toString()) 
        a=parseFloat(a)-parseFloat(E.toString().replace(/[^a-zA-Z0-9-. ]/g, "")) 
      }else{
        a=parseFloat(a)+parseFloat(E.toString().replace(/[^a-zA-Z0-9-. ]/g, "")) 
      }      
  }
    this.setState({tot_ccb:a.toString(),isLoading:false})}}))

    .catch(err => 
      {
        this.setState({
          isLoading:false
        },()=>{
         let error=err
         
         this.refs.toast.showBottom(error.toString())
  
         setTimeout(
          () => { 
            this.props.navigation.goBack();
           },
          2000
        )
  
        })
      }
      );
}

format(x) {
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

SearchFilterFunction(text){
  const newData = this.arrayholder.filter(function(item){
      const itemData = item.A.toString().toUpperCase()+item.B.toString().toUpperCase()
      const textData = text.toUpperCase()
      return itemData.indexOf(textData) > -1
  })
  this.setState({
      dataSource: newData,
      text: text
  })
}
componentDidMount(){
  console.disableYellowBox = true;

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
  
 this.setState({
      UserID:this.props.navigation.getParam('UserID', ''),
},()=>{this.getpayableage();})

}
  render() {
    if (this.state.isLoading){
      return (
        <Modal
        transparent={false}
        supportedOrientations={['portrait', 'landscape']}
        visible={this.state.isLoading}
        >
        <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
          style={{width: 300, height: 200}}
          source={require('./src/gears.gif')}  />
          </View>     
         </Modal>
      )
  }
    return (

      <View style={{flex:1,backgroundColor:lightblue}}>
      <ScrollView style={{height:'15%'}}>
      <SearchBar
        placeholder="Search Supplier ID/Name"
        onChangeText={(text) => this.SearchFilterFunction(text)}
        value={this.state.text}
        searchIcon={{ name: "search", size: 19, color: colorprimary }}
        clearIcon={{ name: "close-circle", size: 19 }}
        loadingProps={{ size: "small" }}
        platform={'ios'}
      />


            <View  style={{ flex: 1}}>
             <Grid style={{backgroundColor:colorprimary,padding:5,width:"97%",alignSelf:'center',borderRadius:4}}>
             <Row>
             <Col style={{alignItems:'flex-start',width:'27%'}}>
             <Text style={styles.textContent}>Supplier</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'21%'}}>
             <Text style={styles.textContent}>Year OB</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'21%'}}>
             <Text style={styles.textContent}>Month OB</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'21%'}}>
             <Text style={styles.textContent}>Current OB</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'10%'}}>
             <Text style={styles.textContent}>DLR</Text>
             </Col> 
             </Row>
             </Grid>
             </View> 
      </ScrollView>

    <ScrollView style={{height:'77%'}}>

    <FlatList
       data={ this.state.dataSource}
       initialNumToRender={this.state.dataSource.length}
       renderItem={({item,index}) =>  

       <Card style={{alignSelf:'center',width:'97%'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
        paddingLeft:5,paddingRight:5,paddingTop:10,paddingBottom:10}}>
            <Grid  onPress={() => this.gotosupplierleder(index)}>
            <Row>
              <Col style={{alignItems:'flex-start',width:'27%'}}>
              <Text style={{fontSize:12,fontFamily:'Bold'}}>{item.A}</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'21%'}}>
              <Text style={{fontSize:12,fontFamily:'Bold'}}>{item.C}</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'21%'}}>
              <Text style={{fontSize:12,fontFamily:'Bold'}}>{item.D}</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'21%'}}>
              <Text style={{fontSize:12,fontFamily:'Bold'}}>{item.E}</Text>
              </Col> 
              <Col style={{alignItems:'center',width:'10%'}}>
              <Text style={{fontSize:12,fontFamily:'Bold'}}>{item.F}</Text>
              </Col> 
             </Row>
             <Row>
             <Col style={{alignItems:'flex-start',width:'100%'}}>
             <Text style={{fontSize:12,fontFamily:'Italic'}}>{item.B}</Text>
             </Col> 
             </Row>
            </Grid>  
             </CardItem>
           </Card>
        }

       keyExtractor={(item, index) => index.toString()}
       
      />
   </ScrollView>
   <ScrollView style={{height:'8%'}}>
   <Card style={{alignSelf:'center',width:'97%',height:40}}>
   <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
        paddingLeft:5,paddingRight:5,paddingTop:10,paddingBottom:10}}>
  <Row>
  <Col style={{alignItems:'flex-end',width:'66%'}}>
  <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Total :</Text>
  </Col>
  <Col style={{alignItems:'flex-end',width:'24%'}}>
  <Text style={{fontSize:13,fontFamily:'Bold'}}>{this.format(this.state.tot_ccb.toString())}</Text>
  </Col>
  <Col style={{alignItems:'flex-start',width:'10%'}}>
  <Text style={{fontSize:13}}>{}</Text>
  </Col> 
  </Row>
  </CardItem>
</Card>
      </ScrollView>

      <Toast ref="toast"
        />
      </View>
        )
      }
 };
 const styles = StyleSheet.create({
  titleText: {
    flex:1,
    flexWrap:'wrap',
    color:white,
    fontSize:12,
    padding:5
  },
  textContent:{
    color:white,
    fontSize:13,
   fontFamily:'Bold'
  },
  });
  
  
  
import React,{ Component }  from 'react';
import {ScrollView,StyleSheet,Text,View,Dimensions,ImageBackground,Modal,Image,TouchableOpacity,Alert} from 'react-native';
import { Col, Grid, Row } from 'react-native-easy-grid';
import axios from 'axios';
import { Divider } from 'react-native-elements';
import { NavigationActions, StackActions } from 'react-navigation';
import Toast from 'react-native-whc-toast'
import { RFValue } from "react-native-responsive-fontsize";

//own lib
import {logouttask} from './class/logout';
import color from './res/colors'
import strings from './res/strings'


//constant
const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const blue=color.values.Colors.blue;
const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const lightblue=color.values.Colors.lightblue;

//common style
const style_common = require('./class/style');

//logout
const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

var { height, width } = Dimensions.get("window");

export default class TagDetails extends React.Component {
  static navigationOptions = ({ navigation }) => ({ 
    title: "Tag Details",
    color:"#fff",
    headerStyle: {
      backgroundColor: colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
      fontSize:RFValue(20)
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false, 
      dataSource:'',
      handlelogin:'',
      tid:'',tcode:'',desc:'',tweight:'',ddate:'',progress:'',tstatus:'',
      pid:'',UserID:'',pdesc:'',cid:'',cname:'',
      layout: {
        height: height,
        width: width
      }
    };
}

_onLayout = event => {
  this.setState({
      layout: {
          height: event.nativeEvent.layout.height,
          width: event.nativeEvent.layout.width
      }
  });
};

login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
        this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}

gettagdetails=()=>{
    console.log(this.state.tid)
  const config = {
    headers: {   
    'currentToken': tokken,
  },
    params: {
        tid:parseInt(this.state.tid,10),
    }
    
  };

  this.setState({isLoading:true})
  axios.get(ip+'/getTagDetails', config)
  .then(response => this.setState({ dataSource:response.data},() => {if(response.status==200){
      console.log(this.state.dataSource)
    const{tid,tcode,desc,tweight,ddate,progress,tstatus}=this.state.dataSource
       this.setState({
        tid:tid,
        tcode:tcode,
        desc:desc,
        tweight:tweight,
        ddate:ddate,
        progress:progress,
        tstatus:tstatus,
        isLoading:false    
        })
}}))
.catch(err => 
  {
    this.setState({
      isLoading:false
    },()=>{
     let error=err
     
     this.refs.toast.showBottom(error.toString())

     setTimeout(
      () => { 
        this.props.navigation.goBack();
       },
      2000
    )

    })
  }
  );
}



componentDidMount(){
  
console.disableYellowBox = true;

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
  
this.setState({tid:this.props.navigation.getParam('TID', ''),pid:this.props.navigation.getParam('PID', '')
,pdesc:this.props.navigation.getParam('PDesc', ''),
cid:this.props.navigation.getParam('CusID', ''),
pdesc:this.props.navigation.getParam('PDesc', ''),
cname:this.props.navigation.getParam('CusName', ''),
UserID:this.props.navigation.getParam('UserID', '')
},()=>{this.gettagdetails();})


}
  render() {
    if (this.state.isLoading) {
      return (
        <Modal
        supportedOrientations={['portrait', 'landscape']}
        transparent={false}
        visible={this.state.isLoading}
        >
         <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
           style={style_common.load_gif}
          source={require('./src/gears.gif')}  />
          </View>     
        </Modal>
      )
  }
    return (
      <View
      style={{ flex: 1 }}
      onLayout={this._onLayout}
       >
       <ImageBackground
              source={require('./src/aztracon_bg.jpg')}
                style={{
                    height: this.state.layout.height,
                    width: this.state.layout.width,
                }} >
  <ScrollView style={{flexGrow:1}}>
  <Grid style={{paddingTop:'2%'}}>
  <Row style={{backgroundColor:colorprimary,width:'97%',alignSelf:'center',borderRadius:3}}>
  <Text numberOfLines={1} style={styles.titleText}>
          {this.state.pid+" - "+this.state.pdesc}
  </Text>
   </Row>
   <Divider style={{ backgroundColor:white}} />
   <Divider style={{ backgroundColor:white}} />
   <Row style={{backgroundColor:colorprimary,width:'97%',alignSelf:'center',borderRadius:3}}>
   <Text numberOfLines={1} style={styles.titleText}>
          {this.state.cid.toString().trim()+" - "+this.state.cname}
  </Text>
  </Row>  
  </Grid>
  <Grid style={{paddingTop:5,width:'97%',alignSelf:'center',paddingBottom:10}}>
                <Row style={{paddingTop:RFValue(4)}}>
                  <Col style={styles.headcol}>
                  <Text style={styles.tittle}>Tag ID</Text>
                  </Col> 
                  <Col style={styles.detailcol}>
                  <Text style={{fontSize:RFValue(13),fontWeight:'bold'}}>{this.state.tid}</Text>
                  </Col> 
                </Row>
                <Row style={{paddingTop:RFValue(4)}}>
                <Col style={styles.headcol}>
                  <Text style={styles.tittle}>Tag Code</Text>
                  </Col> 
                  <Col style={styles.detailcol}>
                  <Text style={{fontSize:RFValue(13),fontWeight:'bold'}}>{this.state.tcode}</Text>
                  </Col> 
                </Row>
                <Row style={{paddingTop:RFValue(4)}}>
                <Col style={styles.headcol}>
                  <Text style={styles.tittle}>Tag Description</Text>
                  </Col> 
                  <Col style={styles.detailcol}>
                  <Text style={{fontSize:RFValue(13),fontWeight:'bold'}}>{this.state.desc}</Text>
                  </Col> 
                </Row>   
                <Row style={{paddingTop:RFValue(4)}}>
                <Col style={styles.headcol}>
                   <Text style={styles.tittle}>Tag weight</Text>   
                  </Col>
                  <Col style={styles.detailcol}>
                    <Text style={{fontSize:RFValue(13),fontWeight:'bold'}}>{this.state.tweight}</Text>  
                  </Col>
                  </Row>
                  <Row style={{paddingTop:RFValue(4)}}>
                  <Col style={styles.headcol}>
                     <Text style={styles.tittle}>Delivery date</Text> 
                  </Col>
                  <Col style={styles.detailcol}>
                     <Text style={{fontSize:RFValue(13),fontWeight:'bold'}}>{this.state.ddate}</Text> 
                  </Col>
                  </Row>
                  <Row style={{paddingTop:RFValue(4)}}>
                  <Col style={styles.headcol}>
                     <Text style={styles.tittle}>Progress %</Text> 
                  </Col>
                  <Col style={styles.detailcol}>
                     <Text style={{fontSize:RFValue(13),fontWeight:'bold'}}>{this.state.progress}</Text> 
                  </Col>
                  </Row>
                  <Row style={{paddingTop:RFValue(4)}}>
                  <Col style={styles.headcol}>
                     <Text style={styles.tittle}>Tag status</Text> 
                  </Col>
                  <Col style={styles.detailcol}>
                     <Text style={{fontSize:RFValue(13),fontWeight:'bold'}}>{this.state.tstatus}</Text> 
                  </Col>
                  </Row>
                </Grid>   
                <Toast ref="toast"/>          
              </ScrollView>
      </ImageBackground>
      </View>
        )
      }
 };
 const styles = StyleSheet.create({
    textContent: {
        backgroundColor:'#fff',
        fontSize: RFValue(15),
        padding:RFValue(8),
        textAlign:'center',
        color: '#36428a',
        fontFamily:'Bold',
        textShadowColor: 'rgba(0, 0, 0, 0.75)',
        textShadowOffset: {width: -1, height: 1},
        textShadowRadius: 10
      },
     tittle:{
      color:'#36428a',
      fontSize:RFValue(14),
      paddingLeft:RFValue(6),
      fontFamily:'Bold'
     },
     Headtittle:{
      color:'#36428a',
      fontSize:RFValue(13),
      fontFamily:'Bold'
     },
     headcol:{
      alignItems:'flex-start',
      width:"40%"
     },
     detailcol:{
      alignItems:'flex-start',
      width:"60%"
     },
     titleText:{
         flex:1,
         flexWrap:'wrap',
         color:white,
         fontSize:RFValue(12),
         padding:RFValue(7),
         fontFamily:'Bold'
     },
     imageStyle:{
      width: screenWidth, 
      height: screenHeight, 
     },
  });
  
  
  
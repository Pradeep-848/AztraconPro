import React from 'react';
import {ScrollView,Dimensions,Image,Modal,SectionList,StyleSheet,Text,View,
  TouchableOpacity,Alert,FlatList} from 'react-native';
import axios from 'axios';
import { NavigationActions, StackActions } from 'react-navigation';
import { Col, Grid, Row} from 'react-native-easy-grid';
import {Card,CardItem} from 'native-base';
import Toast from 'react-native-whc-toast'
import { RFValue } from "react-native-responsive-fontsize";

//own lib
import color from './res/colors'
import {logouttask} from './class/logout';
import strings from './res/strings'
import {isPortrait} from './class/useOrientation'
import { colorsDark } from 'react-native-elements/dist/config';

//constant
const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const { width, height } = Dimensions.get('window');

const blue=color.values.Colors.skyblue;
const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const lightblue=color.values.Colors.lightblue;
const colorPrimaryDark =color.values.Colors.colorPrimaryDark;

//common style
const style_common = require('./class/style');

//logout
const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class DeliveryNoteReport extends React.Component{
  static navigationOptions = ({ navigation }) => ({ 
    title: "Delivery Note Report",
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor:white,
    headerTitleStyle: {
      fontFamily:'Bold',
      fontSize:RFValue(20),
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
      super(props);
      this.state = { 
        isLoading: true, 
        isVisible:false,
        data: "",
        handlelogin:'',
        orientation:'',
        DeviceType:'',
        UserID:'',
        CdelId:'',Ccategory:'',Cpid:'',Ccus:'',CcusName:'',CcateDesc:'',
        CplateNo:'',Csupp:'',CsuppName:'',CtoLoc:'',CtoWeight:'',CchildData:''
    };
      console.disableYellowBox = true;
  }

  login = async () => 
  {
  
    Alert.alert(
      'Logout',
      'Would you like to logout?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {text: 'OK', onPress: () => { logouttask()
          this.props.navigation.dispatch(resetAction);} },
      ],
      {cancelable: false},
    );
   
  }
  
  
componentDidMount() {
  console.disableYellowBox = true;

  this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
  
  Dimensions.addEventListener('change', () => {
    this.setState({
        orientation: isPortrait() ? 'portrait' : 'landscape'
    });
  });

  this.setState({
    UserID:this.props.navigation.getParam('UserID', ''),
    orientation: isPortrait() ? 'portrait' : 'landscape',
    DeviceType:this.props.navigation.getParam('DeviceType', '')
    },()=>{this.getDelDetails();})
}

openModel(item) {
    
  const{ childData ,delId,category,cateDesc,pid,cus,
    cusName,plateNo,supp,suppName,toLoc,toWeight } = item

this.setState({
  CchildData:null
})


  this.setState({
    isVisible : true,
    CdelId:delId,
    Ccategory:category,
    CcateDesc:cateDesc,
    Cpid:pid,
    Ccus:cus,
    CcusName:cusName,
    CplateNo:plateNo,
    Csupp:supp,
    CsuppName:suppName,
    CtoLoc:toLoc,
    CtoWeight:toWeight,
    CchildData : childData
  })
  



}

getDelDetails(){
    const config = {
      headers: {   
      'currentToken':tokken,
    },
      params: {
        userId:this.state.UserID,
      }
    };
    this.setState({isLoading:true});
axios.get(ip+'/getDeliveryReport', config)
  .then(response => this.setState({data:response.data},() => {if(response.status==200){
   this.setState({isLoading:false});
  }
}))
.catch(err => 
  {
    this.setState({
      isLoading:false
    },()=>{
     let error=err
     
     this.refs.toast.showBottom(error.toString())

     setTimeout(
      () => { 
        this.props.navigation.goBack();
       },
      2000
    )

    })
  }
  );
  
}

format(x) {
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

   amountformatter(amount) {

    let FV
    FV=parseFloat(amount).toFixed(2)
    return this.format(FV).toString()
  
  }

  renderItem(item) {    

      const { delId,cateDesc,pid,toWeight,plateNo,toLoc,cusName,suppName} = item.item;

      return (
            <Card style={{width:'97%',alignSelf:'center'}}>
               <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
        paddingLeft:5,paddingRight:5,paddingTop:10,paddingBottom:10}}>
               <Grid onPress={this.openModel.bind(this,item.item)}>
               <Row>
               <Col style={{alignItems:'flex-start',width:'20%'}}>
               <Text style={{fontSize:RFValue(13),color:colorprimary,fontFamily:'Bold'}}>{delId}</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'40%'}}>
               <Text style={{fontSize:RFValue(13),color:colorprimary,fontFamily:'Bold'}}>{cateDesc}</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'15%'}}>
               <Text style={{fontSize:RFValue(13),color:colorprimary,fontFamily:'Bold'}}>{pid}</Text>
               </Col>
               <Col style={{alignItems:'flex-end',width:'25%'}}>
               <Text style={{fontSize:RFValue(13),color:colorprimary,fontFamily:'Bold'}}>{this.amountformatter(toWeight)}</Text>
               </Col>
               </Row>
               <View style={{borderBottomColor:'#A9A9A9',borderBottomWidth: 1,height:5,
             width:'100%',alignSelf:'center'}}/>
               <Row>
               <Col style={{alignItems:'flex-start',width:'25%'}}>
               <Text style={{fontSize:RFValue(13),color:colorprimary,fontFamily:'Bold'}}>Plate No : </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'25%'}}>
               <Text style={{fontSize:RFValue(13),fontFamily:'Italic'}}>{plateNo}</Text>
               </Col> 
               <Col style={{alignItems:'flex-start',width:'25%'}}>
               <Text style={{fontSize:RFValue(13),color:colorprimary,fontFamily:'Bold'}}>To Location : </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'25%'}}>
               <Text style={{fontSize:RFValue(13),fontFamily:'Italic'}}>{toLoc}</Text>
               </Col> 
               </Row>
               <Row>
               <Col style={{alignItems:'flex-start',width:'25%'}}>
               <Text style={{fontSize:RFValue(13),color:colorprimary,fontFamily:'Bold'}}>Client</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'75%'}}>
               <Text style={{fontSize:RFValue(13),fontFamily:'Italic'}}>{cusName}</Text>
               </Col> 
               </Row>
               <Row>
               <Col style={{alignItems:'flex-start',width:'25%'}}>
               <Text style={{fontSize:RFValue(13),color:colorprimary,fontFamily:'Bold'}}>Supplier</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'75%'}}>
               <Text style={{fontSize:RFValue(13),fontFamily:'Italic'}}>{suppName}</Text>
               </Col> 
               </Row>
               </Grid>   
               </CardItem>
               </Card>
      );

  }

  getheight(which){
  
    let orient=''
    let device=''
  
    orient = this.state.orientation
    device = this.state.DeviceType
  
    if(which=='1') { //header
      if(device=='phone'){
  
        if(orient=='portrait'){
          return '5%'
        }else{
          //landscape
          return '10%'
        }
    
      }else{
        //tab
        if(orient=='portrait'){
          return '5%'
        }else{
           //landscape
           return '10%'
        }
    
      }
    }
  
  
    if(which=='2') { //body
      if(device=='phone'){
  
        if(orient=='portrait') {
          return '95%'
        } else {
          //landscape
          return '90%'
        }
    
      }else{
        //tab
        if(orient=='portrait') {
          return '95%'
        } else {
           //landscape
           return '90%'
        }
    
      }
    }
  
  }

  render() {
      if (this.state.isLoading) {
          return (
            <Modal
            transparent={false}
            supportedOrientations={['portrait', 'landscape']}
            visible={this.state.isLoading}
            >
             <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
              <Image
              style={style_common.load_gif}
              source={require('./src/gears.gif')}  />
              </View>     
            </Modal>
          )
      }

      return (
    <View style={{flex:1,backgroundColor:lightblue}}>
    
    <ScrollView style={{height:this.getheight('1')}}>

    <View  style={{ flex: 1,paddingTop:RFValue(5),paddingBottom:RFValue(5)}}>
    <Grid style={{backgroundColor:colorprimary,padding:RFValue(4),width:"97%",alignSelf:'center'}}>
             <Row>
             <Col style={{alignItems:'flex-start',width:'20%'}}>
             <Text style={styles.textContent}>Del. ID</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'40%'}}>
             <Text style={styles.textContent}>Category</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'15%'}}>
             <Text style={styles.textContent}>PID</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'25%'}}>
             <Text style={styles.textContent}>Weight</Text>
             </Col> 
             </Row>
             </Grid>
    </View>
    </ScrollView>

    <ScrollView style={{height:this.getheight('2')}}>
              <SectionList
                  sections={this.state.data}
                  style={{paddingTop:2}}
                  initialNumToRender={this.state.data.length}
                  renderItem={this.renderItem.bind(this)}
                  renderSectionFooter={({section}) => 
                   <View  style={{ flex: 1,paddingTop:RFValue(5),paddingBottom:RFValue(5)}}>
                   <Grid style={{backgroundColor:white,padding:RFValue(5),width:"97%",alignSelf:'center',borderRadius:2}}>
                   <Row>
                   <Col style={{alignItems:'flex-end',width:'65%'}}>
                   <Text style={styles.sectionFooter}>Total Weight : </Text>
                   </Col> 
                   <Col style={{alignItems:'flex-end',width:'35%'}}>
                   <Text style={styles.sectionFooter}>{this.amountformatter(section.Footer)}</Text>
                   </Col> 
                   </Row>
                   </Grid>
                   </View>
                }
                  renderSectionHeader={({ section }) => 
                  
                   <View  style={{ flex: 1,paddingTop:RFValue(5),paddingBottom:RFValue(5)}}>
                   <Grid style={{backgroundColor:blue,padding:RFValue(5),width:"97%",alignSelf:'center',borderRadius:2}}>
                   <Row>
                   <Col style={{alignItems:'flex-start',width:'100%'}}>
                   <Text style={styles.sectionHeader}>{section.Head}</Text>
                   </Col> 
                   </Row>
                   </Grid>
                   </View>
                  
               }
                  keyExtractor={(item, index) => index}
              />
                <Toast ref="toast"/>
    </ScrollView>
    
    <Modal            
          animationType = {"slide"}  
          transparent = {true}  
          supportedOrientations={['portrait', 'landscape']}
          visible = {this.state.isVisible}  
          onRequestClose = {() =>{ console.log("Modal has been closed.") } }>  
          {/*All views of Modal*/}  
          <View style = {styles.modal}>  
          <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress = {() =>
           {  
            this.setState({ isVisible:!this.state.isVisible})
           }}>
       
              <Grid>
              <Row>
               <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
               <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontSize:RFValue(13),fontFamily:'Bold',alignSelf:'flex-start'}}>
               Delivery Note Detail
               </Text>
               </Col>
               <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
                <Image
                source={require('./src/back.png')}
                style={{height:RFValue(22),width:RFValue(22)}}         
                />
                </Col>
              </Row>
              </Grid>

          </TouchableOpacity>
          
          <ScrollView style={{margin:RFValue(10)}}>

            <View style={styles.b}>
              <Grid>
                <Col style={styles.C}>
                  <Text style={styles.tittle} >Delivery ID</Text>
                </Col> 
                <Col>
                  <Text style={styles.detail}>{this.state.CdelId}</Text>
                </Col> 
              </Grid>
            </View>
            
<View style={styles.b}>
<Grid>
  <Col style={styles.C}>
  <Text style={styles.tittle}>Category</Text>
  </Col> 
  <Col>
  <Text style={styles.detail}>{this.state.CcateDesc}</Text>
  </Col> 
</Grid>
</View>
<View style={styles.b}>
<Grid>
  <Col style={styles.C}>
  <Text style={styles.tittle}>PID</Text>
  </Col> 
  <Col>
  <Text style={styles.detail}>{this.state.Cpid}</Text>
  </Col> 
</Grid>
</View>
<View style={styles.b}>
<Grid>
  <Col style={styles.C}>
  <Text style={styles.tittle}>Weight</Text>
  </Col> 
  <Col>
  <Text style={styles.detail}>{this.amountformatter(this.state.CtoWeight)}</Text>
  </Col> 
</Grid>
</View>
<View style={styles.b}>
<Grid>
  <Col style={styles.C}>
  <Text style={styles.tittle}>Plate No</Text>
  </Col> 
  <Col>
  <Text style={styles.detail}>{this.state.CplateNo}</Text>
  </Col> 
</Grid>
</View>
<View style={styles.b}>
<Grid>
  <Col style={styles.C}>
  <Text style={styles.tittle}>To Location</Text>
  </Col> 
  <Col>
  <Text style={styles.detail}>{this.state.CtoLoc}</Text>
  </Col> 
</Grid>
</View>
<View style={styles.b}>
<Grid>
  <Col style={styles.C}>
  <Text style={styles.tittle}>Client Name</Text>
  </Col> 
  <Col>
  <Text style={styles.detail}>{this.state.CcusName + ' [ '+ this.state.Ccus.trim() + ' ] '}</Text>
  </Col> 
</Grid>
</View> 
<View style={styles.b}>
<Grid>
  <Col style={styles.C}>
  <Text style={styles.tittle}>Supplier</Text>
  </Col> 
  <Col>
  <Text style={styles.detail}>{this.state.CsuppName + ' [ '+this.state.Csupp.trim() + ' ] '}</Text>
  </Col> 
</Grid>
</View> 



<View  style={{ flex: 1,width:'97%',alignSelf:'center',paddingTop:'2%'}}>
    <Grid style={{backgroundColor:colorprimary,padding:RFValue(5),borderRadius:2,alignSelf:'center'}}>
             <Row>
             <Col style={{alignItems:'flex-start',width:'15%'}}>
             <Text style={styles.textContent}>SNo</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'45%'}}>
             <Text style={styles.textContent}>Tag Id</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'40%'}}>
             <Text style={styles.textContent}>Tag Desc</Text>
             </Col> 
             </Row>
             </Grid>
    </View>


    <FlatList
       data={ this.state.CchildData}
       initialNumToRender={this.state.CchildData.length}
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
       <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
          paddingLeft:RFValue(5),paddingRight:RFValue(5),paddingTop:RFValue(8),paddingBottom:RFValue(8)}}>
       <Grid>

       <Row>
       <Col style={{alignItems:'flex-start',width:'15%'}}>
       <Text style={{fontSize:RFValue(12),color:colorsDark,fontFamily:'Regular'}}>{item.sno}</Text>
       </Col>
       <Col style={{alignItems:'flex-start',width:'45%'}}>
       <Text style={{fontSize:RFValue(12),color:colorsDark,fontFamily:'Regular'}}>{item.tagId}</Text>
       </Col>
       <Col style={{alignItems:'flex-start',width:'40%'}}>
       <Text style={{fontSize:RFValue(12),color:colorsDark,fontFamily:'Regular'}}>{item.desc}</Text>
       </Col>
    
       </Row>
     
       </Grid>   
       </CardItem>
       </Card>
        }
       keyExtractor={(item, index) => index.toString()}
       
      />




</ScrollView>
      

          </View>
    </Modal>
    </View>    
      );
  }
}

const styles = StyleSheet.create({
  container: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: '#F5FCFF',
  },
  sectionFooter: {
    alignSelf:'flex-end',
    fontSize: RFValue(14),
    fontFamily:'Bold',
    color:colorPrimaryDark,
  },
  sectionHeader: {
      alignSelf:'flex-start',
      fontSize: RFValue(13),
      fontFamily:'Bold',
      color:'#fff',
  },
  itemView: {
    flex: 1,
    width,
    borderBottomWidth: 0.5,
    borderColor: '#cdcdcd',
    borderStyle: 'solid',
    paddingHorizontal: RFValue(12),
    flexDirection: 'row',
    paddingTop:RFValue(2)
},
 textContent:{
  color:white,
  fontSize:RFValue(12),
  fontFamily:'Bold'
},
 titleText: {
  flex:1,
  flexWrap:'wrap',
  color:white,
  fontSize:RFValue(12),
  padding:RFValue(5),
  fontFamily:'Bold'
},
modal: {  
  flex:1,
  backgroundColor:white,
  height:'auto',
  position: 'absolute',
  bottom: 0,
  width:'100%',
   },
   headerback: {
    flexDirection: 'row',
    alignItems:'center',
    backgroundColor: colorprimary,
    borderWidth: 0.5,
    borderColor:white,
    height: 40,
    width:'100%',
    borderRadius: 5,
  },
  tittle:{
    color:'#36428a',
    fontSize:RFValue(13),
    fontFamily:'Bold'
   },
   C:{
    alignItems:"flex-start",
    width:150
   },
   b: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop:5,
  },
  detail:{
    fontSize:RFValue(13),
    fontFamily:'Regular'
  },

});


import React,{ Component }  from 'react';
import {ScrollView,Modal,StyleSheet, Text,View,Image,Dimensions,TouchableOpacity,Alert,FlatList} from 'react-native';
import {logouttask} from './class/logout';
import { Col, Grid, Row } from 'react-native-easy-grid';
import { Divider } from 'react-native-elements';
import { NavigationActions, StackActions } from 'react-navigation';
import axios from 'axios';
import {Card,CardItem} from 'native-base';
import Toast from 'react-native-whc-toast'
import strings from './res/strings'
import color from './res/colors'


const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const blue=color.values.Colors.blue;
const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const lightblue=color.values.Colors.lightblue;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class WarehouseList extends React.Component {
  static navigationOptions = ({ navigation }) => ({ 
    title: "WareHouse Receipt",
    color:color,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false, 
      dataSource:'',
      handlelogin:'',
      pid:'',UserID:'',pdesc:'',cid:'',cname:'',
    };
}

login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
        this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}


gotowarehousedetail=(index)=>{

  const id=index

  const {WhReceiptNo}=this.state.dataSource[id]

  this.props.navigation.navigate('WarehouseDetailActivity',{
    WHRNo:WhReceiptNo,
    PID:this.state.pid,
    UserID:this.state.UserID,
    PDesc:this.state.pdesc,
    CusID:this.state.cid,
    CusName:this.state.cname,
  });

}

getwarehouselist=()=>{
  const config = {
    headers: {   
    'currentToken': tokken,
  },
    params: {
    pid:this.state.pid,
    }
    
  };

  this.setState({isLoading:true})
  axios.get(ip+'/getWHList', config)
  .then(response => this.setState({ dataSource:response.data},() => {if(response.status==200){this.setState({isLoading:false})}}))
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
}




componentDidMount(){

  console.disableYellowBox = true;

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
  
  this.setState({
      pid:this.props.navigation.getParam('PID', ''),
      cid:this.props.navigation.getParam('CusID', ''),
      pdesc:this.props.navigation.getParam('PDesc', ''),
      cname:this.props.navigation.getParam('CusName', ''),
      UserID:this.props.navigation.getParam('UserID', '')
},()=>{this.getwarehouselist();})
}
  render() {
    if (this.state.isLoading) {
      return (
        <Modal
        transparent={false}
        visible={this.state.isLoading}
        supportedOrientations={['portrait', 'landscape']}
        >
         <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
           useNativeDriver={true}
          style={{width: 300, height: 200}}
          source={require('./src/gears.gif')}  />
          </View>     
        </Modal>
      )
  }
  return (
  <View style={{flex:1,backgroundColor:lightblue}}> 
  <ScrollView style={{height:'14%'}}>
  <Grid style={{paddingTop:'2%'}}>
  <Row style={{backgroundColor:colorprimary,width:'97%',alignSelf:'center',borderRadius:3}}>
  <Text numberOfLines={1} style={styles.titleText}>
          {this.state.pid+" - "+this.state.pdesc}
  </Text>
   </Row>
   <Divider style={{ backgroundColor:white}} />
   <Divider style={{ backgroundColor:white}} />
   <Row style={{backgroundColor:colorprimary,width:'97%',alignSelf:'center',borderRadius:3}}>
   <Text numberOfLines={1} style={styles.titleText}>
          {this.state.cid.toString().trim()+" - "+this.state.cname}
  </Text>
  </Row>  
  </Grid>
  <View  style={{ flex: 1,paddingTop:5,paddingBottom:5}}>
    <Grid style={{backgroundColor:colorprimary,padding:4,width:"97%",alignSelf:'center'}}>
             <Row>
             <Col style={{alignItems:'flex-start',width:'35%'}}>
             <Text style={styles.textContent}>Receipt No.</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'30%'}}>
             <Text style={styles.textContent}>Date</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'35%'}}>
             <Text style={styles.textContent}>QC Status</Text>
             </Col> 
             </Row>
             </Grid>
    </View>
    </ScrollView>
    <ScrollView style={{height:'86%'}}> 
    <FlatList
       data={ this.state.dataSource }
       initialNumToRender={this.state.dataSource.length}
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
                     paddingLeft:5,paddingRight:5,paddingTop:10,paddingBottom:10}}>
            <Grid  onPress={() => this.gotowarehousedetail(index)}>
            <Row style={styles.paddingrow}>
              <Col style={{alignItems:'flex-start',width:'35%'}}>
              <Text style={{fontSize:13,color:colorprimary, fontFamily:'Bold'}}>{item.WhReceiptNo}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={{fontSize:13,color:colorprimary, fontFamily:'Bold'}}>{item.WhReceiptDate}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'35%'}}>
              <Text style={{fontSize:13,color:colorprimary, fontFamily:'Bold'}}>{item.InspStatusDesc}</Text>
              </Col> 
             </Row>
             <View style={{borderBottomColor:'#A9A9A9',borderBottomWidth: 1,height:5,width:'100%',alignSelf:'center'}}/>
            <Row style={styles.paddingrow}>
              <Col style={{alignItems:'flex-start',width:'20%'}}>
              <Text style={{fontSize:13,color:colorprimary, fontFamily:'Bold'}}>PO No.</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={{fontSize:13, fontFamily:'Italic'}}>{item.PONo}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'20%'}}>
              <Text style={{fontSize:13,color:colorprimary, fontFamily:'Bold'}}>Value - </Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={{fontSize:13, fontFamily:'Italic'}}>{item.InvoiceValue}</Text>
              </Col> 
            </Row>
            <View style={{borderBottomColor:'#A9A9A9',borderBottomWidth: 1,height:5,width:'100%',alignSelf:'center'}}/>
            <Row style={styles.paddingrow}>
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={{fontSize:13,color:colorprimary, fontFamily:'Bold'}}>Invoice No.</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'70%'}}>
              <Text style={{fontSize:13, fontFamily:'Italic'}}>{item.InvoiceNo}</Text>
              </Col> 
            </Row>
            <Row style={styles.paddingrow}>
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={{fontSize:13,color:colorprimary, fontFamily:'Bold'}}>DC No.</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'70%'}}>
              <Text style={{fontSize:13, fontFamily:'Italic'}}>{item.DCNo}</Text>
              </Col> 
            </Row>
            <Row style={styles.paddingrow}>
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={{fontSize:13,color:colorprimary, fontFamily:'Bold'}}>PO Type</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'70%'}}>
              <Text style={{fontSize:13, fontFamily:'Italic'}}>{item.POType}</Text>
              </Col> 
            </Row>
            <Row style={styles.paddingrow}>
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={{fontSize:13,color:colorprimary, fontFamily:'Bold'}}>Supplier</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'70%'}}>
              <Text style={{fontSize:13, fontFamily:'Italic'}}>{item.SupName}</Text>
              </Col> 
            </Row>
            <Row style={styles.paddingrow}>
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={{fontSize:13,color:colorprimary, fontFamily:'Bold'}}>Location</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'70%'}}>
              <Text style={{fontSize:13, fontFamily:'Italic'}}>{item.LocName}</Text>
              </Col> 
            </Row>
            </Grid>  
             </CardItem>
           </Card>
        }

       keyExtractor={(item, index) => index.toString()}
       
      />
  <Toast ref="toast"/>
          </ScrollView>
          </View>   
        )
      }
 };
 const styles = StyleSheet.create({
  titleText: {
    flex:1,
    flexWrap:'wrap',
    color:white,
    fontSize:12,
    padding:5,
    fontFamily:'Bold'
  },
  textContent:{
    color:white,
    fontSize:13,
    fontFamily:'Bold'
  },
  paddingrow:{
    paddingTop:2
  }
  });
  
  
  
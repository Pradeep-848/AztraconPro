import React,{ Component }  from 'react';
import {ScrollView,StyleSheet,Text,View,Dimensions,ImageBackground,Modal,Image,TouchableOpacity,Alert} from 'react-native';
import { Col, Grid, Row } from 'react-native-easy-grid';
import axios from 'axios';
import { NavigationActions, StackActions } from 'react-navigation';
import { Divider } from 'react-native-elements';
import { RFValue } from "react-native-responsive-fontsize";

//own lib
import strings from './res/strings'
import Toast from 'react-native-whc-toast'
import color from './res/colors'

//common style
const style_common = require('./class/style');

//constant
const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const blue=color.values.Colors.blue;
const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;

//logout
const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});


//dimension
var { height, width } = Dimensions.get("window");

export default class TaskDetails extends React.Component {
  static navigationOptions = ({ navigation }) => ({ 
    title: "Task Details",
    color:"#fff",
    headerStyle: {
      backgroundColor: colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
      fontSize:RFValue(20)
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false, 
      dataSource:'',
      tid:'',tgroup:'',desc:'',esdate:'',efdate:'',duration:'',planned:'',asdate:'',
      afdate:'',rstatus:'',tagid:'',pid:'',UserID:'',pdesc:'',cid:'',cname:'',
      layout: {
        height: height,
        width: width
    }
    };
}

_onLayout = event => {
  this.setState({
      layout: {
          height: event.nativeEvent.layout.height,
          width: event.nativeEvent.layout.width
      }
  });
};

login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
      this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}
gettaskdetails=()=>{
    console.log(this.state.tid)
  const config = {
    headers: {   
    'currentToken': tokken,
  },
    params: {
        tid:this.state.tid,
        tagidno:this.state.tagid,
    }
    
  };

  this.setState({isLoading:true})
  axios.get(ip+'/getTaskDetails', config)
  .then(response => this.setState({ dataSource:response.data},() => {if(response.status==200){
    const{tgroup,tid,desc,esdate,efdate,duration,planned,asdate,afdate,rstatus}=this.state.dataSource
       this.setState({
        tgroup:tgroup,
        tid:tid,
        desc:desc,
        esdate:esdate,
        efdate:efdate,
        duration:duration,
        planned:planned,
        asdate:asdate,
        afdate:afdate,
        rstatus:rstatus,
        isLoading:false    
        })
}}))
.catch(err => 
  {
    this.setState({
      isLoading:false
    },()=>{
     let error=err
     
     this.refs.toast.showBottom(error.toString())

     setTimeout(
      () => { 
        this.props.navigation.goBack();
       },
      2000
    )

    })
  }
  );
}


componentDidMount(){

  console.disableYellowBox = true;

  this.props.navigation.setParams({
    handlelogin: this.login.bind(this)
    });
  
    
this.setState({
    tid:this.props.navigation.getParam('TID', ''),
    tagid:this.props.navigation.getParam('TagID', ''),
    pid:this.props.navigation.getParam('PID', ''),
    cid:this.props.navigation.getParam('CusID', ''),
    pdesc:this.props.navigation.getParam('PDesc', ''),
    cname:this.props.navigation.getParam('CusName', ''),
    UserID:this.props.navigation.getParam('UserID', '')
},()=>{this.gettaskdetails();})


}
  render() {
    if (this.state.isLoading) {
      return (
        <Modal
        transparent={false}
        supportedOrientations={['portrait', 'landscape']}
        visible={this.state.isLoading}
        >
         <View onLayout={this._onLayout} style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
           useNativeDriver={true}
           style={style_common.load_gif}
           source={require('./src/gears.gif')}  />
          </View>     
        </Modal>
      )
  }
    return (
      <View
      style={{ flex: 1 }}
      onLayout={this._onLayout}
       >
      <ImageBackground 
      source={require('./src/aztracon_bg.jpg')}
      style={{
        height: this.state.layout.height,
        width: this.state.layout.width,
       }} >
              <ScrollView>
  <Grid style={{paddingTop:'2%'}}>
  <Row style={{backgroundColor:colorprimary,width:'97%',alignSelf:'center',borderRadius:3}}>
  <Text numberOfLines={1} style={styles.titleText}>
          {this.state.pid+" - "+this.state.pdesc}
  </Text> 
   </Row>
   <Divider style={{ backgroundColor:white}} />
   <Divider style={{ backgroundColor:white}} />
   <Divider style={{ backgroundColor:white}} />
   <Row style={{backgroundColor:colorprimary,width:'97%',alignSelf:'center',borderRadius:3}}>
   <Text numberOfLines={1} style={styles.titleText}>
          {this.state.cid.toString().trim()+" - "+this.state.cname}
  </Text>
  </Row>  
  </Grid>
        <Grid style={{paddingTop:RFValue(7),width:'97%',alignSelf:'center'}}>
                <Row style={styles.pad}>
                  <Col style={styles.headcol}>
                  <Text style={styles.tittle}>Task Group</Text>
                  </Col> 
                  <Col style={styles.detailcol}>
                  <Text style={{fontSize:RFValue(15),fontFamily:'Italic'}}>{this.state.tgroup}</Text>
                  </Col> 
                </Row>
                <Row style={styles.pad}>
                <Col style={styles.headcol}>
                  <Text style={styles.tittle}>Task ID</Text>
                  </Col> 
                  <Col style={styles.detailcol}>
                  <Text style={{fontSize:RFValue(15),fontFamily:'Italic'}}>{this.state.tid}</Text>
                  </Col> 
                </Row>
                <Row style={styles.pad}>
                <Col style={styles.headcol}>
                  <Text style={styles.tittle}>Description</Text>
                  </Col> 
                  <Col style={styles.detailcol}>
                  <Text style={{fontSize:RFValue(15),fontFamily:'Italic'}}>{this.state.desc}</Text>
                  </Col> 
                </Row>   
                <Row style={styles.pad}>
                <Col style={styles.headcol}>
                   <Text style={styles.tittle}>Expected Start date</Text>   
                  </Col>
                  <Col style={styles.detailcol}>
                    <Text style={{fontSize:RFValue(15),fontFamily:'Italic'}}>{this.state.esdate}</Text>  
                  </Col>
                  </Row>
                  <Row style={styles.pad}>
                  <Col style={styles.headcol}>
                     <Text style={styles.tittle}>Expected Finish date</Text> 
                  </Col>
                  <Col style={styles.detailcol}>
                     <Text style={{fontSize:RFValue(15),fontFamily:'Italic'}}>{this.state.efdate}</Text> 
                  </Col>
                  </Row>
                  <Row style={styles.pad}>
                  <Col style={styles.headcol}>
                     <Text style={styles.tittle}>Duration (days)</Text> 
                  </Col>
                  <Col style={styles.detailcol}>
                     <Text style={{fontSize:RFValue(15),fontFamily:'Italic'}}>{this.state.duration}</Text> 
                  </Col>
                  </Row>
                  <Row style={styles.pad}>
                  <Col style={styles.headcol}>
                     <Text style={styles.tittle}>Planned (man hrs)</Text> 
                  </Col>
                  <Col style={styles.detailcol}>
                     <Text style={{fontSize:RFValue(15),fontFamily:'Italic'}}>{this.state.planned}</Text> 
                  </Col>
                  </Row>
                  <Row style={styles.pad}>
                  <Col style={styles.headcol}>
                     <Text style={styles.tittle}>Actual Start date</Text> 
                  </Col>
                  <Col style={styles.detailcol}>
                     <Text style={{fontSize:RFValue(15),fontFamily:'Italic'}}>{this.state.asdate}</Text> 
                  </Col>
                  </Row>
                         <Row style={styles.pad}>
                  <Col style={styles.headcol}>
                     <Text style={styles.tittle}>Actual Finish date</Text> 
                  </Col>
                  <Col style={styles.detailcol}>
                     <Text style={{fontSize:RFValue(15),fontFamily:'Italic'}}>{this.state.afdate}</Text> 
                  </Col>
                  </Row>
                         <Row style={styles.pad}>
                  <Col style={styles.headcol}>
                     <Text style={styles.tittle}>Status</Text> 
                  </Col>
                  <Col style={styles.detailcol}>
                     <Text style={{fontSize:RFValue(15),fontFamily:'Italic'}}>{this.state.rstatus}</Text> 
                  </Col>
                  </Row>
                </Grid>

                
<Toast ref="toast"/>
             
              </ScrollView>
      </ImageBackground>
      </View>
        )
      }
 };
 const styles = StyleSheet.create({
    textContent: {
        backgroundColor:'#fff',
        fontSize: RFValue(15),
        padding:RFValue(10),
        textAlign:'center',
        color: '#36428a',
        fontFamily:'Bold',
        textShadowColor: 'rgba(0, 0, 0, 0.75)',
        textShadowOffset: {width: -1, height: 1},
        textShadowRadius: 10
      },
     tittle:{
      color:'#36428a',
      fontSize:RFValue(15),
      paddingLeft:RFValue(6),
      fontFamily:'Bold'
     },
     Headtittle:{
      color:'#36428a',
      fontSize:RFValue(13),
      fontFamily:'Bold'
     },
     headcol:{
      alignItems:'flex-start',
      width:"40%"
     },
     detailcol:{
      alignItems:'flex-start',
      width:"60%"
     },
     titleText:{
         flex:1,
         flexWrap:'wrap',
         color:white,
         fontSize:RFValue(12),
         padding:RFValue(7),
         fontFamily:'Bold'
     },
     pad:{
         paddingTop:'4%'
     },
     imageStyle:{
      width: screenWidth, 
      height: screenHeight, 
     
     },
  });
  
  
  
import * as React from 'react';
import { WebView } from 'react-native-webview';
import {StyleSheet,Image,Dimensions,View,TouchableOpacity,Alert} from 'react-native';
import {logouttask} from './class/logout';
import { NavigationActions, StackActions } from 'react-navigation';
import color from './res/colors'
const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class Aztraconweb extends React.Component {
  static navigationOptions  = ({ navigation }) => ({ 
    title: "Aztracon Site",
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });

  constructor(props) {
    super(props);
     this.state = {
         UserID:'',
         handlelogin:'',
    };
}
login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
        this.props.navigation.dispatch(resetAction);
    } },
    ],
    {cancelable: false},
  );

 
 
}
componentDidMount(){
    this.setState({
        UserID:this.props.navigation.getParam('UserID', '')
    })

  console.disableYellowBox = true;
  this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
  
}

  render() {
    return <WebView source={{ uri: 'http://www.alzamilmetal.com/' }} style={{ marginTop: 10 }} />;
  }
}
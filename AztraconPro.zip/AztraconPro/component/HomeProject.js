import React, { Component } from 'react';
import { TouchableOpacity, StyleSheet, Alert, Text, View, TextInput, Image, AsyncStorage } from 'react-native';
import { Col, Grid, Row } from 'react-native-easy-grid';
import { ScrollView } from 'react-native-gesture-handler';
import { NavigationActions, StackActions } from 'react-navigation';
import { Card, CardItem } from 'native-base';
import { logouttask } from './class/logout';
import Toast from 'react-native-whc-toast'

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class HomeProject extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      username: '',
      Designation: '',
      USER: '',
      DEPT: '',
      RCenter: '',
      Department: '',
      handlelogin: ''
    };

  }

  static navigationOptions = ({ navigation }) => ({
    title: "Aztracon",
    headerStyle: {
      backgroundColor: "#2452b2"
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontFamily: 'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{ paddingRight: 10 }} onPress={() =>
        navigation.state.params.handlelogin()
      }>
        <Image
          style={{ alignSelf: 'center', justifyContent: 'center' }}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),

  });

  //login=()=>
  login = async () => {

    Alert.alert(
      'Logout',
      'Would you like to logout?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {
          text: 'OK', onPress: () => {
            logouttask()
            this.props.navigation.dispatch(resetAction);
          }
        },
      ],
      { cancelable: false },
    );

  }
  changepass = () => {
    this.props.navigation.navigate('ChangePasswordActivity', { UserID: this.state.USER });
  }
  profile = () => {
    this.props.navigation.navigate('EmployeeProfileActivity', { username: this.state.username, Designation: this.state.Designation, USER: this.state.USER });
  }
  Quotation = () => {
    this.props.navigation.navigate('QuotationMasterActivity', { UserID: this.state.USER });
  }
  po = () => {
    this.props.navigation.navigate('POAppProPendingActivity', { username: this.state.username, Designation: this.state.Designation, USER: this.state.USER });
  }
  pr = () => {
    this.props.navigation.navigate('PRAppProPendingActivity', { username: this.state.username, Designation: this.state.Designation, USER: this.state.USER });
  }
  EmployeeWtr = () => {
    this.props.navigation.navigate('EmployeeWTRActivity', { USER: this.state.USER });
  }
  EmployeeSalary = () => {
    this.props.navigation.navigate('EmpSalaryPeriodActivity', { USER: this.state.USER });
  }
  accountspayable = () => {
    this.props.navigation.navigate('AccountPayableActivity', { UserID: this.state.USER });
  }
  Project = () => {
    this.props.navigation.navigate('ProjectMasterActivity', { USER: this.state.USER, DEPT: this.state.Designation });
  }
  Supplier = () => {
    this.props.navigation.navigate('SupplierMasterActivity', { UserID: this.state.USER });
  }
  Customer = () => {
    this.props.navigation.navigate('CustomerMasterActivity', { UserID: this.state.USER });
  }
  AccountsReceive = () => {
    this.props.navigation.navigate('AccountsReceivableActivity', { UserID: this.state.USER });
  }
  PayableAgeing = () => {
    this.props.navigation.navigate('AgeListActivity', { UserID: this.state.USER });
  }

  ReceivableAgeing = () => {
    this.props.navigation.navigate('AgeListCustomerActivity', { UserID: this.state.USER });
  }

  LeaveRequest = () => {
    //this.props.navigation.navigate('LeaveRequestActivity',{UserID:this.state.USER});
    alert('Feature will update soon!')
  }

  LeaveApproval = () => {
    this.props.navigation.navigate('LeaveApprovalListActivity', {
      UserID: this.state.USER, RCenter: this.state.RCenter,
      Department: this.state.Department, Name: this.state.username, Designation: this.state.Designation
    });
  }
  
  Aboutus = () => {
    this.props.navigation.navigate('AboutUsActivity', { UserID: this.state.USER });
  }

  // DashBoard = () => {
  //   this.props.navigation.navigate('DashBoardActivity', { UserID: this.state.USER });
  // }


  componentDidMount() {

    console.disableYellowBox = true;


    this.props.navigation.setParams({
      handlelogin: this.login.bind(this)
    });

    this.setState({
      username: this.props.navigation.getParam('username', ''),
      Designation: this.props.navigation.getParam('Designation', ''),
      USER: this.props.navigation.getParam('USER', ''),
      RCenter: this.props.navigation.getParam('RCenter', ''),
      Department: this.props.navigation.getParam('Department', ''),
    }, () => {
      //this.getprpo()
      console.log(this.state.username)
    })

  }


  getprpo() {
    const config = {
      headers: {
        'currentToken': tokken,
      },
      params: {
        userid: this.state.USER,
      }

    };

    this.setState({ isLoading: true })
    axios.get(ip + '/getPrPo', config)
      .then(response => this.setState({ dataSource: response.data }, () => { if (response.status == 200) { this.setState({ isLoading: false }) } }))
      .catch(err => {
        this.setState({
          isLoading: false
        }, () => {
          let error = err

          this.refs.toast.showBottom(error.toString())

          setTimeout(
            () => {
              this.props.navigation.goBack();
            },
            2000
          )

        })
      }
      );
  }

  render() {
    return (
      <ScrollView>
        <Card style={{ alignSelf: 'center', width: '96%' }}>
          <CardItem style={{ alignSelf: 'center', width: '96%', alignItems: 'flex-start' }}>
            <View style={{ flexDirection: 'row' }}>
              <View style={styles.tcenter}>
                <TextInput
                  value={this.state.username}
                  onChangeText={(username) => this.setState({ username })}
                  placeholder={'Username'}
                  style={{ color: "#2452b2" }}
                  editable={false} selectTextOnFocus={false}
                />
                <TextInput
                  value={this.state.Designation}
                  onChangeText={(Designation) => this.setState({ Designation })}
                  placeholder={'Designation'}
                  style={{ color: "#2452b2" }}
                  editable={false} selectTextOnFocus={false}
                />
              </View>
              <TouchableOpacity activeOpacity={.5} onPress={this.profile}>
                <Image
                  style={styles.image}
                  source={require('./src/ic_prof.png')} />
              </TouchableOpacity>

              <TouchableOpacity activeOpacity={.5} onPress={this.changepass}>
                <Image
                  style={styles.image}
                  source={require('./src/ic_change_pass.png')} />
              </TouchableOpacity>
            </View>
          </CardItem>
        </Card>



        <Text style={styles.textContent}>
          Master
        </Text>

        <Grid>
          <Row style={styles.i}>
            <Col style={{ alignItems: 'center', width: '50%' }}>
              <TouchableOpacity activeOpacity={.5} onPress={this.profile}>
                <Image style={styles.imagebutton}
                  source={require('./src/ic_profile.png')} />
              </TouchableOpacity>
              <Text style={{ alignSelf: 'center' }}>Profile</Text>
            </Col>
            <Col style={{ alignItems: 'center', width: '50%' }}>
              <TouchableOpacity activeOpacity={.5} onPress={this.Quotation}>
                <Image style={styles.imagebutton}
                  source={require('./src/ic_quotation.png')} />
                <Text style={{ alignSelf: 'center' }}>Quotation</Text>
              </TouchableOpacity>
            </Col>
          </Row>
          <Row style={styles.i}>
            <Col style={{ alignItems: 'center', width: '50%' }}>
              <TouchableOpacity activeOpacity={.5} onPress={this.Project}>
                <Image style={styles.imagebutton}
                  source={require('./src/ic_project.png')} />
              </TouchableOpacity>
              <Text style={{ alignSelf: 'center' }}>Project</Text>
            </Col>
            <Col style={{ alignItems: 'center', width: '50%' }}>
              <TouchableOpacity activeOpacity={.5} onPress={this.Supplier}>
                <Image style={styles.imagebutton}
                  source={require('./src/ic_supplier.png')} />
                <Text style={{ alignSelf: 'center' }}>Supplier</Text>
              </TouchableOpacity>
            </Col>
          </Row>
          <Row style={styles.i}>
            <Col style={{ alignItems: 'center', width: '50%' }}>
              <TouchableOpacity activeOpacity={.5} onPress={this.Customer}>
                <Image style={styles.imagebutton}
                  source={require('./src/ic_customer.png')} />
              </TouchableOpacity>
              <Text style={{ alignSelf: 'center' }}>Customer</Text>
            </Col>
            <Col style={{ alignItems: 'center', width: '50%' }}>
              <TouchableOpacity activeOpacity={.5} onPress={this.AccountsReceive}>
                <Image style={styles.imagebutton}
                  source={require('./src/ic_ar.png')} />
                <Text style={{ alignSelf: 'center' }}>Accounts Receivable</Text>
              </TouchableOpacity>
            </Col>
          </Row>
          <Row style={styles.i}>
            <Col style={{ alignItems: 'center', width: '50%' }}>
              <TouchableOpacity activeOpacity={.5} onPress={this.accountspayable}>
                <Image style={styles.imagebutton}
                  source={require('./src/ic_ap.png')} />
              </TouchableOpacity>
              <Text style={{ alignSelf: 'center' }}>Accounts Payable</Text>
            </Col>
            <Col style={{ alignItems: 'center', width: '50%' }}>
              <TouchableOpacity activeOpacity={.5} onPress={this.EmployeeWtr}>
                <Image style={styles.imagebutton}
                  source={require('./src/ic_timesheet.png')} />
                <Text style={{ alignSelf: 'center' }}>WTR TimeSheet</Text>
              </TouchableOpacity>
            </Col>
          </Row>
          <Row style={styles.i}>
            <Col style={{ alignItems: 'center', width: '50%' }}>
              <TouchableOpacity activeOpacity={.5} onPress={this.PayableAgeing}>
                <Image style={styles.imagebutton}
                  source={require('./src/ic_pay_age.png')} />
              </TouchableOpacity>
              <Text style={{ alignSelf: 'center' }}>Payable Ageing</Text>
            </Col>
            <Col style={{ alignItems: 'center', width: '50%' }}>
              <TouchableOpacity activeOpacity={.5} onPress={this.ReceivableAgeing}>
                <Image style={styles.imagebutton}
                  source={require('./src/ic_rec_age.png')} />
                <Text style={{ alignSelf: 'center' }}>Receivable Ageing</Text>
              </TouchableOpacity>
            </Col>
          </Row>
          <Text style={styles.textContent}>
            Transaction
          </Text>
          <Row style={styles.i}>
            <Col style={{ alignItems: 'center', width: '50%' }}>
              <TouchableOpacity activeOpacity={.5} onPress={this.LeaveRequest}>
                <Image style={styles.imagebutton}
                  source={require('./src/ic_leave_req.png')} />
              </TouchableOpacity>
              <Text style={{ alignSelf: 'center' }}>Leave Request</Text>
            </Col>
            <Col style={{ alignItems: 'center', width: '50%' }}>
              <TouchableOpacity activeOpacity={.5} onPress={this.LeaveApproval}>
                <Image style={styles.imagebutton}
                  source={require('./src/ic_leave_app.png')} />
                <Text style={{ alignSelf: 'center' }}>Leave Approval</Text>
              </TouchableOpacity>
            </Col>
          </Row>
          <Row style={styles.i}>
            <Col style={{ alignItems: 'center', width: '50%' }}>
              <TouchableOpacity activeOpacity={.5} onPress={this.pr} >
                <Image style={styles.imagebutton}
                  source={require('./src/ic_pr_pending.png')} />
              </TouchableOpacity>
              <Text style={{ alignSelf: 'center' }}>Pending PR Approval</Text>
            </Col>
            <Col style={{ alignItems: 'center', width: '50%' }}>
              <TouchableOpacity activeOpacity={.5} onPress={this.po}>
                <Image style={styles.imagebutton}
                  source={require('./src/ic_po_pending.png')} />
                <Text style={{ alignSelf: 'center' }}>Pending PO Approval</Text>
              </TouchableOpacity>
            </Col>
          </Row>
          <Row style={styles.i}>
            {/*   <Col style={{alignItems:'center',width:'50%'}}>
          <TouchableOpacity activeOpacity = { .5 } onPress={ this.EmployeeSalary }>
          <Image style={styles.imagebutton}
          source={require('./src/ic_payslip.png')}/>
          </TouchableOpacity>
          <Text style={{alignSelf:'center'}}>Salary Slip</Text>
          </Col>  */}
            <Col style={{ alignItems: 'center', width: '50%' }}>
              <TouchableOpacity activeOpacity={.5} onPress={this.Aboutus}>
                <Image style={styles.imagebutton}
                  source={require('./src/ic_about.png')} />
                <Text style={{ alignSelf: 'center' }}>About us</Text>
              </TouchableOpacity>
            </Col>
          </Row>
        </Grid>
        <Toast ref="toast"
        />
      </ScrollView>
    )
  }
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'stretch'
  },
  tcenter: {
    flex: 1,
    justifyContent: 'flex-start',
    flexDirection: 'column',
    paddingLeft: 10,
  },
  image: {
    width: 40,
    height: 40,
    marginTop: 5,
    marginRight: 10,
  },
  imagebutton: {
    width: 80,
    height: 80,
    marginTop: 3,
    justifyContent: "center",
    alignItems: "center",
    alignSelf: 'center'
  },
  textContent: {
    backgroundColor: '#36428a',
    fontSize: 12,
    padding: 4,
    marginLeft: 10,
    marginRight: 10,
    color: '#fff',
    fontWeight: 'bold'
  },
  imagetext: {
    fontSize: 12,
    color: '#A0A0A0',
  },
  b: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 10,
  },
  i: {
    paddingTop: 10,
  },
});

import React,{ Component }  from 'react';
import {ScrollView,Modal,StyleSheet,Text,View,Image,Dimensions,FlatList,TouchableOpacity,Alert,ProgressBarAndroid} from 'react-native';
import {logouttask} from './class/logout';
import { Col, Grid, Row } from 'react-native-easy-grid';
import { Divider } from 'react-native-elements';
import { NavigationActions, StackActions } from 'react-navigation';
import axios from 'axios';
import Toast from 'react-native-whc-toast'
import {Card,CardItem} from 'native-base';
import strings from './res/strings'
import color from './res/colors'

const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});
export default class ManPowerRequestList extends React.Component {
  static navigationOptions = ({ navigation }) => ({ 
    title: "ManPower Status",
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false, 
      handlelogin:'',
      dataSource:'',
      name:'',
      pid:'',UserID:'',pdesc:'',cid:'',tot_bud:0.0,tot_act:0.0
    };
}



login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
      this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}

getmanpowerstatus=()=>{

  const config = {
    headers: {   
    'currentToken': tokken,
  },
    params: {
      UserId:this.state.UserID,
    }
    
  };

  this.setState({isLoading:true})
  axios.get(ip+'/getWorkRequestStatus', config)
  .then(response => this.setState({ dataSource:response.data},() => {if(response.status==200){
      this.setState({isLoading:false})
    }}))
    .catch(err => 
      {
        this.setState({
          isLoading:false
        },()=>{
         let error=err
         
         this.refs.toast.showBottom(error.toString())
  
         setTimeout(
          () => { 
            this.props.navigation.goBack();
           },
          2000
        )
  
        })
      }
      );

}

componentDidMount(){
  console.disableYellowBox = true;

  this.props.navigation.setParams({
    handlelogin: this.login.bind(this)
    });
  this.setState({
      name:this.props.navigation.getParam('Name', ''),
      UserID:this.props.navigation.getParam('UserID', ''),

},()=>{this.getmanpowerstatus();})
}
  render() {
    if (this.state.isLoading) {
      return (
        <Modal
        transparent={false}
        supportedOrientations={['portrait', 'landscape']}
        visible={this.state.isLoading}
        >
         <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
          useNativeDriver={true}
          style={{width: 300, height: 200}}
          source={require('./src/gears.gif')}  />
          </View>     
        </Modal>
      )
  }
return (
<View style={{flex:1}}>
<ScrollView style={{height:"17%",paddingTop:"1%"}}>
<Card style={{width:'97%',alignSelf:'center',paddingTop:'1%'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}} >
            <Grid>
            <Row style={{alignSelf:'center'}}>
            <Col style={{alignItems:'flex-start',width:'17%',paddingLeft:5}}>
            <Text style={styles.titleText}>Name -</Text>
            </Col> 
            <Col style={{alignItems:'flex-start',width:'83%',paddingLeft:4}}>
            <Text style={styles.titleText}>{this.state.name}
            </Text>
            </Col> 
            </Row>
            <Row style={{alignSelf:'center'}}>
            <Col style={{alignItems:'flex-start',width:'17%',paddingLeft:5}}>
            <Text style={styles.titleText}>Email -</Text>
            </Col> 
            <Col style={{alignItems:'flex-start',width:'83%',paddingLeft:4}}>
            <Text style={styles.titleText}>{this.state.UserID}
            </Text>
            </Col> 
            </Row>  
            </Grid>
            </CardItem>
</Card>            
   
<View style={{ flex: 1,paddingTop:5}}>
             <Grid style={{backgroundColor:colorprimary,padding:4,width:"97%",alignSelf:'center'}}>
             <Row>
             <Col style={{alignItems:'flex-start',width:'10%',paddingLeft:10}}>
             <Text style={styles.textContent}>SNo</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'45%',paddingLeft:8}}>
             <Text style={styles.textContent}>Category</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'30%',paddingRight:8}}>
             <Text style={styles.textContent}>Req Date</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'15%'}}>
             <Text style={styles.textContent}>Count</Text>
             </Col> 
             </Row>
             </Grid>
</View>
</ScrollView>
<ScrollView style={{height:'83%'}}>
    <FlatList
       data={ this.state.dataSource }
       initialNumToRender={this.state.dataSource.length}
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}} >
            <Grid>
            <Row>
            <Col style={{alignItems:'flex-start',width:'10%'}}>
            <Text style={{fontSize:12}}>{item.SeqNo}</Text>
            </Col> 
            <Col style={{alignItems:'flex-start',width:'45%'}}>
            <Text style={{fontSize:12}}>{item.GroupDesc}</Text>
            </Col> 
            <Col style={{alignItems:'flex-start',width:'30%'}}>
            <Text style={{fontSize:12}}>{item.ReqDate}</Text>
            </Col> 
            <Col style={{alignItems:'flex-start',width:'15%'}}>
            <Text style={{fontSize:12,paddingLeft:14}}>{item.ReqCount}</Text>
            </Col> 
             </Row>
             <View style={{borderBottomColor:'#A9A9A9',borderBottomWidth: 1,height:5,
             width:'100%',alignSelf:'center'}}/>
              <Row style={{paddingTop:'1%',paddingBottom:'1%'}}>
               <Col style={{alignItems:'flex-start',width:'20%'}}>
               <Text style={{fontSize:12,color:colorprimary,fontWeight:'bold'}}>Job Type</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'80%'}}>
               <Text style={{fontSize:12}}>{item.CodeDesc}</Text>
               </Col> 
               </Row>
             
               <Row style={{paddingTop:'1%',paddingBottom:'1%'}}>
               <Col style={{alignItems:'flex-start',width:'20%'}}>
               <Text style={{fontSize:12,color:colorprimary,fontWeight:'bold'}}>Remark</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'80%'}}>
               <Text style={{fontSize:12}}>{item.Remark}</Text>
               </Col> 
               </Row>

               <Row style={{paddingTop:'1%',paddingBottom:'1%'}}>
               <Col style={{alignItems:'flex-start',width:'20%'}}>
               <Text style={{fontSize:12,color:colorprimary,fontWeight:'bold'}}>Status</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'80%'}}>
               <Text style={{fontSize:12}}>{item.StatusDesc}</Text>
               </Col> 
               </Row>
             </Grid>  
             </CardItem>
           </Card>
        }

       keyExtractor={(item, index) => index.toString()}
       
      />

<Toast ref="toast"
        />

      </ScrollView>

    </View>
        )
      }
 };
 const styles = StyleSheet.create({
  titleText: {
    flex:1,
    flexWrap:'wrap',
    color:'#36428a',
    fontSize:13,
    fontWeight:'bold',
    padding:1,
    textShadowColor: '#36428a',
    textShadowOffset: {width: -1, height: 1},
    textShadowRadius: 10
  },
      tittle:{
      color:'#36428a',
      fontSize:13,
     },
    textContent:{
    color:white,
    fontSize:12,
    fontWeight:'bold'
  }
  });
  

  
  
  
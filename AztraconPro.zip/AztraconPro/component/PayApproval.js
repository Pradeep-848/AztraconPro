import React from 'react';
import {
  ScrollView, Dimensions, Image, Modal, StyleSheet, Text, View,
  TouchableOpacity, Alert, KeyboardAvoidingView, Platform, FlatList, TextInput
} from 'react-native';
import axios from 'axios';
import { Col, Grid, Row } from 'react-native-easy-grid';
import { Card, CardItem, Item, Input, Form, Label, Icon } from 'native-base';
import moment from 'moment';
import { NavigationActions, StackActions } from 'react-navigation';
import Timeline from 'react-native-timeline-flatlist'
import RadioGroup from 'react-native-radio-buttons-group';
import strings from './res/strings'
import { logouttask } from './class/logout';
import Toast from 'react-native-whc-toast'
import color from './res/colors'
import { Divider } from 'react-native-elements';


// import * as WebBrowser from 'expo-web-browser';
// import * as MediaLibrary from 'expo-media-library';
// import * as FileSystem from 'expo-file-system';
// import * as Permissions from 'expo-permissions';

import { CustomButton } from './custom-button.js';
import SelectDropdown from 'react-native-select-dropdown';

const ip = strings.values.commonvalues.ip;
const tokken = strings.values.commonvalues.tokken;

const { width, height } = Dimensions.get('window');

const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);

const blue = color.values.Colors.blue;
const black = color.values.Colors.black;
const colorprimary = color.values.Colors.colorPrimary;
const colorprimarydark = color.values.Colors.colorPrimaryDark;
const white = color.values.Colors.white;
const lightblue = color.values.Colors.lightblue;
let selectedButton;
let AppStatus;
let passdata = [];

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class PayApproval extends React.Component {
  static navigationOptions = ({ navigation }) => ({
    title: "Payment Approval",
    color: white,
    headerStyle: {
      backgroundColor: colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily: 'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{ paddingRight: 10 }} onPress={() =>
        navigation.state.params.handlelogin()
      }>
        <Image
          style={{ alignSelf: 'center', justifyContent: 'center' }}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),

  });
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      isVisible: false,
      UserID: '',

      rdate: '',
      payto: '',
      pid: '',
      pname: '',
      payid: '',
      newid: '',
      amt: '',
      cb: '',
      bal: '',
      doc: '',
      file: '',
      rem: '',
      reqby: '',
      ptype: '',
      aprAmt: '',
      pdate: '',
      PayData: [],
      data: [],
      StatusData: [],
      seqno: '',
      ver: '',
      isApramt: false,
      editflag: '',
      AprUser: [
        {
          id: '2002',
        },
        {
          id: '4760',
        },
        {
          id: '2354',
        }
      ],
      radiovalues: [
        {
          label: 'Approve',
          value: "Approve",
          color: '#2452b2'
        },
        {
          label: 'Reject',
          value: "Reject",
          color: '#2452b2'
        },
        {
          label: 'ReWork',
          value: 'ReWork',
          color: '#2452b2'
        },

      ],
      pickerpayment: ""
    };
    console.disableYellowBox = true;
    this.arrayholder = [];
  }

  login = async () => {

    Alert.alert(
      'Logout',
      'Would you like to logout?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {
          text: 'OK', onPress: () => {
            logouttask()
            this.props.navigation.dispatch(resetAction);
          }
        },
      ],
      { cancelable: false },
    );

  }


  componentDidMount() {

    console.disableYellowBox = true;

    this.props.navigation.setParams({
      handlelogin: this.login.bind(this)
    });


    this.setState({
      UserID: this.props.navigation.getParam('UserID', ''),
      rdate: this.props.navigation.getParam('rdate', ''),
      payto: this.props.navigation.getParam('payto', ''),
      pid: this.props.navigation.getParam('pid', ''),
      pname: this.props.navigation.getParam('pname', ''),
      payid: this.props.navigation.getParam('payid', ''),
      newid: this.props.navigation.getParam('newid', ''),
      amt: this.props.navigation.getParam('amt', ''),
      cb: this.props.navigation.getParam('cb', ''),
      bal: this.props.navigation.getParam('bal', ''),
      doc: this.props.navigation.getParam('doc', ''),
      file: this.props.navigation.getParam('file', ''),
      rem: this.props.navigation.getParam('rem', ''),
      reqby: this.props.navigation.getParam('reqby', ''),
      pickerpayment: this.props.navigation.getParam('ptype', ''),
      pdate: this.props.navigation.getParam('pdate', ''),
      seqno: this.props.navigation.getParam('seqno', ''),
      ver: this.props.navigation.getParam('ver', ''),
      aprAmt: this.props.navigation.getParam('aprAmt', '') != '' ?
        parseFloat(this.props.navigation.getParam('aprAmt', '')).toFixed(2) :
        this.props.navigation.getParam('aprAmt', ''),
      editflag: this.props.navigation.getParam('aprAmt', '') != '' ? editFlag = "Y" : editFlag = "N"
    }, () => {
      this.getPaypoList()
    })
  }


  CheckAppUser() {

    let idValid = false

    for (let i = 0; i < this.state.AprUser.length; i++) {

      if (this.state.UserID == this.state.AprUser[i].id) {
        idValid = true
        return idValid
      }

    }

    return idValid

  }
  format(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  }

  downloadtask = async (file) => {

    const uri = ip + "/PayDownload/file?FileName=" + file + "&PID=" + this.state.payid;
    await WebdatetimepickeropenBrowserAsync(uri);

  }


  getPaypoList() {

    let isapr

    isapr = this.CheckAppUser()

    console.log(isapr)

    const config = {
      headers: {
        'currentToken': tokken,
      },
      params: {
        pid: this.state.payid,
      }
    };
    this.setState({ isLoading: true });
    axios.get(ip + '/getPayPOList', config)
      .then(response => this.setState({ PayData: response.data }, () => {
        if (response.status == 200) {
          this.setState({ isLoading: false, isApramt: isapr });
        }
      }))
      .catch(err => {
        this.setState({
          isLoading: false
        }, () => {
          let error = err

          this.refs.toast.showBottom(error.toString())

          setTimeout(
            () => {
              this.props.navigation.goBack();
            },
            2000
          )

        })
      }
      );

  }

  display() {
    for (let i = 0; i < this.state.StatusData.length; i++) {
      const { E, C, D, A, F } = this.state.StatusData[i]
      let Desc, tit
      if (E !== '') {
        if (D !== '' && D != null) {
          if (F == 'O' || F == 'P') {
            Desc = C + "\n" + "Remarks : " + E
          } else {
            Desc = C + "\n" + moment(D).format('DD-MM-YYYY').toString() + "\n" + "Remarks : " + E
          }

        }
        else {
          Desc = C + "\n" + "Remarks : " + E
        }

      } else {

        if (D !== '' && D != null) {

          if (F == 'O' || F == 'P') {
            Desc = C
          } else {
            Desc = C + "\n" + moment(D).format('DD-MM-YYYY').toString()
          }

        } else {
          Desc = C
        }

      }

      if (F === 'A') {
        this.state.data.push({
          title: A,
          description: Desc,
          lineColor: "#15ca7d",
          icon: require('./src/ic_approved.png')
        })
      } else if (F === 'P') {
        this.state.data.push({
          title: A,
          description: Desc,
          lineColor: "#f4b825",
          icon: require('./src/ic_pending.png')
        })
      } else if (F === 'R') {
        this.state.data.push({
          title: A,
          description: Desc,
          lineColor: "#f6634b",
          icon: require('./src/ic_rejected.png')
        })
      } else if (F === 'O') {
        this.state.data.push({
          title: A,
          description: Desc,
          lineColor: "#2d353a",
          icon: require('./src/ic_opened.png')
        })
      } else if (F == 'W') {
        this.state.data.push({
          title: A,
          description: Desc,
          lineColor: "#2d353a",
          icon: require('./src/ic_opened.png')
        })
      }

    }
    this.setState({ isLoading: false, isVisible: true })
  }


  gettimeline() {

    this.setState({ isLoading: true })
    const config = {
      headers: {
        'currentToken': tokken,
      },
      params: {
        payid: this.state.payid,
      }

    };

    axios.get(ip + '/getPayStatus', config)
      .then(response => this.setState({ StatusData: response.data }, () => {
        if (response.status == 200) {
          console.log(this.state.StatusData)
          this.display()
        }
      }))
      .catch(err => {
        this.setState({
          isLoading: false
        }, () => {
          let error = err

          this.refs.toast.showBottom(error.toString())

          setTimeout(
            () => {
              this.props.navigation.goBack();
            },
            2000
          )

        })
      }
      );

  }
  DOCUMENT() {


    this.props.navigation.navigate('DocumentActivity', {
      UserID: this.state.UserID,
      DocType: "PT",
      Param1: this.state.payid,
      Param2: '0',
    });

  }


  STATUS() {


    this.setState({
      StatusData: [], data: []
    }, () => {
      this.gettimeline()
    })


  }

  SUBMIT() {

    if (this.CheckAppUser() && selectedButton == "Approve") {

      if (this.state.editflag == "Y" && this.state.aprAmt.length > 0) {

        if (parseFloat(this.state.aprAmt).toFixed(2) < 1) {
          this.refs.toast.showBottom('Approved Amount Should be more than 0')
          return;
        }

      } else if (this.state.editflag == "N") {

        if (this.state.aprAmt.length > 0) {

          if (parseFloat(this.state.aprAmt).toFixed(2) < 1) {
            this.refs.toast.showBottom('Approved Amount Should be more than 0')
            return;
          }

        }


      } else {
        this.refs.toast.showBottom('Please Enter Approved Amount')
        return;
      }


      // if(this.state.aprAmt.length>0){

      //   if (parseFloat(this.state.amt).toFixed(2) <= parseFloat(this.state.aprAmt).toFixed(2) ){
      //     this.refs.toast.showBottom("Approved Amount Should Be "+this.format(parseFloat(this.state.amt).toFixed(2)))
      //     return;
      //   }


      // }

    }

    if (selectedButton == "Approve") {
      AppStatus = "A"
    } else if (selectedButton == "Reject") {
      AppStatus = "R"
    } else {
      AppStatus = "W"
    }

    if (AppStatus !== "A") {
      if (this.state.FRemark == "" || this.state.FRemark == "undefinde" || this.state.FRemark == undefined) {
        this.refs.toast.showBottom("Please enter Remark!")
        return
      }
    }

    this.saveon()

    // if(this.state.FRemark=="" || this.state.FRemark=="undefinde" || this.state.FRemark==undefined){
    //   this.refs.toast.showBottom("Please enter Remark!")
    //   return
    // }else{
    //  this.saveon()
    // }  

  }

  saveon() {
    let url

    this.setState({
      isLoading: true
    })

    if (AppStatus == "A") {
      url = "/setPayAppV1"
    } else if (AppStatus == "R") {
      url = "/setPayRej"
    } else {
      url = "/setPayRew"
    }

    axios({
      method: 'post',
      url: ip + url,
      headers: { 'currentToken': tokken },
      data: {
        "payid": this.state.payid,
        "userid": this.state.UserID,
        "comments": this.state.FRemark,
        "status": AppStatus,
        "seqno": this.state.seqno,
        "ver": this.state.ver,
        "balance": this.state.bal,
        "aprAmt": this.state.aprAmt,
        "ptype": this.state.pickerpayment,
      }
    }).then(response => {
      if (response.status === 200) {
        this.setState({ isLoading: false }, () => {
          this.refs.toast.showBottom('Submitted Successfully')
          this.props.navigation.goBack();
        })
      } else {
        this.refs.toast.showBottom('Some Error Occured!')
      }
    })
      .catch(err => {
        this.setState({
          isLoading: false
        }, () => {
          let error = err

          this.refs.toast.showBottom(error.toString())

          setTimeout(
            () => {
              this.props.navigation.goBack();
            },
            2000
          )

        })
      }
      );
  }

  onPress = radiovalues => this.setState({ radiovalues });


  format(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  }

  render() {
    selectedButton = this.state.radiovalues.find(e => e.selected == true);
    selectedButton = selectedButton ? selectedButton.value : this.state.radiovalues[0].label;
    if (this.state.isLoading) {
      return (
        <Modal
          transparent={false}
          supportedOrientations={['portrait', 'landscape']}
          visible={this.state.isLoading}
        >
          <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
            <Image
              style={{ width: 300, height: 200 }}
              source={require('./src/gears.gif')} />
          </View>
        </Modal>
      )
    }

    return (
      <View style={{ flex: 1, backgroundColor: lightblue }}>
        <ScrollView style={{ height: "18%" }}>

          <View style={{ flex: 1, paddingTop: '2%', width: '97%', alignSelf: "center" }}>
            <Grid style={{ backgroundColor: colorprimary, padding: 5, alignSelf: 'center', borderRadius: 4 }}>
              <Row>
                <Col style={{ alignItems: 'flex-start', width: '100%', paddingLeft: 8 }}>
                  <Text style={styles.textContent}>Payment Approval</Text>
                </Col>
              </Row>
            </Grid>
          </View>

          <Card style={{ width: '97%', alignSelf: 'center' }}>
            <CardItem style={{ alignItems: "flex-start", width: '100%', flexWrap: 'wrap' }}>
              <Grid>
                <Row style={{ paddingTop: 2, paddingBottom: 2 }}>
                  <Col style={{ alignItems: 'flex-start', width: '23%' }}>
                    <Text style={{ fontSize: 12, color: colorprimary, fontFamily: 'Bold' }}>Payment ID - </Text>
                  </Col>
                  <Col style={{ alignItems: 'flex-start', width: '27%' }}>
                    <Text style={{ fontSize: 12, color: black, fontFamily: 'Bold' }}>{this.state.newid}</Text>
                  </Col>
                  <Col style={{ alignItems: 'flex-start', width: '25%' }}>
                    <Text style={{ fontSize: 12, color: colorprimary, fontFamily: 'Bold' }}>Request Date- </Text>
                  </Col>
                  <Col style={{ alignItems: 'flex-start', width: '25%' }}>
                    <Text style={{ fontSize: 12, color: black, fontFamily: 'Bold' }}>{this.state.rdate}</Text>
                  </Col>
                </Row>
                <Divider></Divider>
                <Divider></Divider>
                <Row style={{ paddingTop: 3, paddingBottom: 3 }}>
                  <Col style={{ alignItems: 'flex-start', width: '30%' }}>
                    <Text style={{ fontSize: 12, color: colorprimary, fontFamily: 'Bold' }}>Payment To - </Text>
                  </Col>
                  <Col style={{ alignItems: 'flex-start', width: '70%' }}>
                    <Text style={{ fontSize: 12, color: black, fontFamily: 'Bold' }}>{this.state.pname + " [" + this.state.payto + "]"}</Text>
                  </Col>
                </Row>
              </Grid>
            </CardItem>
          </Card>

        </ScrollView>

        <ScrollView style={{ height: "12%" }}>

          <Card style={{ width: '97%', alignSelf: 'center' }}>
            <CardItem style={{ alignItems: "flex-start", width: '100%', flexWrap: 'wrap' }}>
              <Grid>
                <Row style={{ paddingTop: 3, paddingBottom: 3 }}>
                  <Col style={{ alignItems: 'flex-start', width: '23%' }}>
                    <Text style={{ fontSize: 12, color: colorprimary, fontFamily: 'Bold' }}>Amount - </Text>
                  </Col>
                  <Col style={{ alignItems: 'flex-start', width: '25%' }}>
                    <Text style={{ fontSize: 12, color: black, fontFamily: 'Bold' }}>{this.format((Math.round(this.state.amt * 100) / 100).toFixed(2))}</Text>
                  </Col>
                  <Col style={{ alignItems: 'flex-start', width: '27%' }}>
                    <Text style={{ fontSize: 12, color: colorprimary, fontFamily: 'Bold' }}>OutStanding - </Text>
                  </Col>
                  <Col style={{ alignItems: 'flex-start', width: '25%' }}>
                    <Text style={{ fontSize: 12, color: black, fontFamily: 'Bold' }}>{this.format((Math.round(this.state.bal * 100) / 100).toFixed(2))}</Text>
                  </Col>
                </Row>
                <Divider></Divider>
                <Divider></Divider>
                <Row style={{ paddingTop: 3, paddingBottom: 3 }}>
                  <Col style={{ alignItems: 'flex-start', width: '25%' }}>
                    <Text style={{ fontSize: 12, color: colorprimary, fontFamily: 'Bold' }}>Cash Bank - </Text>
                  </Col>
                  <Col style={{ alignItems: 'flex-start', width: '20%' }}>
                    <Text style={{ fontSize: 12, color: black, fontFamily: 'Bold' }}>{this.state.cb}</Text>
                  </Col>
                  <Col style={{ alignItems: 'flex-start', width: '30%' }}>
                    <Text style={{ fontSize: 12, color: colorprimary, fontFamily: 'Bold' }}>Payment Date - </Text>
                  </Col>
                  <Col style={{ alignItems: 'flex-start', width: '25%' }}>
                    <Text style={{ fontSize: 12, color: black, fontFamily: 'Bold' }}>{this.state.pdate}</Text>
                  </Col>
                </Row>
              </Grid>
            </CardItem>
          </Card>

        </ScrollView>


        <ScrollView style={{ height: "17%" }}>

          <Card style={{ width: '97%', alignSelf: 'center' }}>
            <CardItem style={{ alignItems: "flex-start", width: '100%', flexWrap: 'wrap' }}>
              <Grid>
                <Row style={{ paddingTop: 3, paddingBottom: 3 }}>
                  <Col style={{ alignItems: 'flex-start', width: '30%' }}>
                    <Text style={{ fontSize: 12, color: colorprimary, fontFamily: 'Bold' }}>Request by</Text>
                  </Col>
                  <Col style={{ alignItems: 'flex-start', width: '70%' }}>
                    <Text style={{ fontSize: 12, color: black, fontFamily: 'Bold' }}>{this.state.reqby}</Text>
                  </Col>
                </Row>
                <Row style={{ paddingTop: 3, paddingBottom: 3 }}>
                  <Col style={{ alignItems: 'flex-start', width: '30%' }}>
                    <Text style={{ fontSize: 12, color: colorprimary, fontFamily: 'Bold' }}>Reference doc</Text>
                  </Col>
                  <Col style={{ alignItems: 'flex-start', width: '70%' }}>
                    <Text style={{ fontSize: 12, color: black, fontFamily: 'Bold' }}>{this.state.doc}</Text>
                  </Col>
                </Row>
                <Row style={{ paddingTop: 3, paddingBottom: 3 }}>
                  <Col style={{ alignItems: 'flex-start', width: '30%' }}>
                    <Text style={{ fontSize: 12, color: colorprimary, fontFamily: 'Bold' }}>Remarks</Text>
                  </Col>
                  <Col style={{ alignItems: 'flex-start', width: '70%' }}>
                    <Text style={{ fontSize: 12, color: black, fontFamily: 'Bold' }}>{this.state.rem}</Text>
                  </Col>
                </Row>
                <Row style={{ display: 'none', paddingTop: 3, paddingBottom: 3 }}>
                  <Col style={{ alignItems: 'flex-start', width: '30%' }}>
                    <Text style={{ fontSize: 12, color: colorprimary, fontFamily: 'Bold' }}>Attachment</Text>
                  </Col>
                  <Col onPress={this.downloadtask.bind(this, this.state.file)} style={{ alignItems: 'flex-start', width: '70%' }}>
                    <Row>
                      <Col style={{ alignItems: 'flex-start', width: '20%' }}>
                        <Image
                          style={{ resizeMode: 'stretch', width: 20, height: 20, alignSelf: 'center', justifyContent: 'center', display: this.state.file == "" ? 'none' : 'flex' }}
                          source={require('./src/pin.png')} />
                      </Col>
                      <Col style={{ alignItems: 'flex-start', width: '80%' }}>
                        <Text
                          style={{ fontSize: 12, color: black, fontFamily: 'Bold' }}>{this.state.file}</Text>
                      </Col>
                    </Row>
                  </Col>
                </Row>
              </Grid>
            </CardItem>
          </Card>
        </ScrollView>

        <KeyboardAvoidingView
          behavior='padding'
          keyboardVerticalOffset={
            Platform.select({
              ios: () => 0,
              android: () => 10
            })()
          }>
          <ScrollView style={{ height: "53%" }}>

            <Modal
              animationType={"slide"}
              transparent={true}
              visible={this.state.isVisible}
              onRequestClose={() => { console.log("Modal has been closed.") }}>
              {/*All views of Modal*/}
              <View style={styles.modal}>
                <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress={() => {
                  this.setState({ isVisible: !this.state.isVisible })
                }}>

                  <Grid>
                    <Row>
                      <Col style={{ width: '90%', alignItems: 'center', alignSelf: 'center' }}>
                        <Text style={{ paddingLeft: '3%', color: '#fff', textDecorationStyle: 'solid', fontFamily: 'Bold', alignSelf: 'flex-start' }}>
                          Approve Timeline
                        </Text>
                      </Col>

                      <Col style={{ width: '10%', alignItems: 'center', alignSelf: 'center' }}>
                        <Image
                          source={require('./src/back.png')}
                          style={{ height: 22, width: 22 }}
                        />
                      </Col>
                    </Row>
                  </Grid>

                </TouchableOpacity>


                <Timeline
                  style={styles.list}
                  data={this.state.data}
                  circleSize={25}
                  showTime={false}
                  circleColor='rgba(0,0,0,0)'
                  lineColor='rgb(45,156,219)'
                  descriptionStyle={{ color: 'gray', fontFamily: 'Regular' }}
                  innerCircle={'icon'}
                />


              </View>
            </Modal>

            <View style={{ flex: 1, paddingTop: 4, display: this.state.PayData.length == 0 ? 'none' : 'flex' }}>
              <Grid style={{ backgroundColor: '#36428a', padding: 4, width: "98%", alignSelf: 'center', borderRadius: 2 }}>
                <Row>
                  <Col style={{ alignItems: 'flex-start', width: '33%' }}>
                    <Text style={styles.textContent}>PO No.</Text>
                  </Col>
                  <Col style={{ alignItems: 'flex-start', width: '33%' }}>
                    <Text style={styles.textContent}>PO Value</Text>
                  </Col>
                  <Col style={{ alignItems: 'flex-end', width: '34%' }}>
                    <Text style={styles.textContent}>Payable Amount</Text>
                  </Col>
                </Row>
              </Grid>
            </View>
            <FlatList
              data={this.state.PayData}
              initialNumToRender={this.state.PayData.length}
              renderItem={({ item }) =>
                <Card style={{ width: '98%', alignSelf: 'center' }}>
                  <CardItem style={{
                    alignItems: "flex-start", width: '100%', flexWrap: 'wrap',
                    paddingLeft: 5, paddingRight: 5, paddingTop: 4, paddingBottom: 4
                  }}>
                    <Grid>
                      <Row>
                        <Col style={{ alignItems: 'flex-start', width: '33%' }}>
                          <Text style={{ fontSize: 13 }}>{item.pono}</Text>
                        </Col>
                        <Col style={{ alignItems: 'flex-start', width: '33%' }}>
                          <Text style={{ fontSize: 13 }}>{item.value}</Text>
                        </Col>
                        <Col style={{ alignItems: 'flex-end', width: '34%' }}>
                          <Text style={{ fontSize: 13 }}>{item.amt}</Text>
                        </Col>
                      </Row>
                    </Grid>
                  </CardItem>
                </Card>
              }
              keyExtractor={(item, index) => index.toString()}
            />




            <Card style={{ borderRadius: 4, width: '97%', alignSelf: 'center', borderBottomColor: colorprimary }} >
              <CardItem style={{
                alignItems: "flex-start", width: '100%', flexWrap: 'wrap',
                paddingLeft: 5, paddingRight: 5, paddingTop: 0, paddingBottom: 0
              }}>

                <Grid>
                  <Row>

                    <Text style={{ fontSize: 14, fontFamily: "Bold", color: colorprimary, paddingLeft: '3%' }}>Payment Type</Text>
                  </Row>
                  <Row>
                    <Col style={{ width: '100%', alignSelf: 'center', alignItems: 'center' }}>
                      <Form style={{ flex: 1, alignItems: 'flex-start' }}>
                        <Item style={{ marginLeft: 0, height: 45 }} picker>

                        <SelectDropdown
                          data={[
                            { title: "Advance", value: "ADV" },
                            { title: "Government", value: "GOV" },
                            { title: "LCs", value: "LCS" },
                            { title: "Payroll", value: "PAY" },
                            { title: "Settlement", value: "SET" },
                          ]}
                          onSelect={(selectedItem, index) => {
                            console.log("Selected Item:", selectedItem.value);
                            this.setState(  
                              { pickerpayment: selectedItem.value },
                              () => {
                                this.state.pickerpayment;
                              }
                            );
                          }}
                          renderButton={(isOpened) => {
                            const data = [
                              { title: "Advance", value: "ADV" },
                              { title: "Government", value: "GOV" },
                              { title: "LCs", value: "LCS" },
                              { title: "Payroll", value: "PAY" },
                              { title: "Settlement", value: "SET" },
                            ];

                            const buttonText = this.state.pickerpayment
                              ? data.find(
                                  (item) => item.value === this.state.pickerpayment
                                )?.title
                              : "Select Payment Type";

                            return (
                              <View style={styles.dropdownButtonStyle}>
                                <Text
                                  style={{
                                    flex: 1,
                                    fontSize: 16,
                                    color: "black",
                                  }}
                                >
                                  {buttonText}
                                </Text>
                                <Icon
                                  name={
                                    isOpened ? "chevron-up" : "chevron-down"
                                  }
                                  style={{
                                    fontSize: 20,
                                    color: colorprimary,
                                  }}
                                />
                              </View>
                            );
                          }}
                          renderItem={(item, index, isSelected) => {
                            return (
                              <View
                                style={{
                                  ...styles.dropdownItemStyle,
                                  ...(isSelected && {
                                    backgroundColor: "#D2D9DF",
                                  }),
                                }}
                              >
                                <Text
                                  style={{
                                    fontSize: 16,
                                    color: "black",
                                  }}
                                >
                                  {item.title}
                                </Text>
                              </View>
                            );
                          }}
                          showsVerticalScrollIndicator={false}
                          dropdownStyle={{
                            borderRadius: 8,
                            borderWidth: 1,
                            borderColor: "#ccc",
                            backgroundColor: "#fff",
                          }}
                        />

                        </Item>

                      </Form>
                    </Col>
                  </Row>
                </Grid>
              </CardItem>
              <View style={styles.tcenter}>
                <Text style={{
                  display: this.state.isApramt == true ? 'flex' : 'none', fontSize: 16, fontFamily: 'Bold', color: colorprimarydark,
                  paddingTop: "2%", paddingBottom: "2%"
                }}>Approval Amount</Text>

                <TextInput
                  value={this.state.aprAmt}
                  onChangeText={(aprAmt) => this.setState({ aprAmt })}
                  placeholder={'Approval Amount'}
                  length={50}
                  style={{
                    display: this.state.isApramt == true ? 'flex' : 'none', maxHeight: 80,
                    borderColor: colorprimarydark,
                    borderWidth: 1,
                    padding: 6,
                    width: 320,
                    marginBottom: 5,
                    alignSelf: 'stretch',
                    borderRadius: 5,
                    fontFamily: 'Regular'
                  }}
                  keyboardType="numeric"
                  returnKeyType={"next"}
                  ref='amt'
                  autoCapitalize={"none"}
                  onSubmitEditing={(event) => {
                    this.refs.remark.focus();
                  }}
                />

                <Text style={{
                  fontSize: 16, fontFamily: 'Bold', color: colorprimarydark,
                  paddingTop: "2%", paddingBottom: "2%"
                }}>Remark</Text>

                <TextInput
                  value={this.state.FRemark}
                  onChangeText={(FRemark) => this.setState({ FRemark })}
                  placeholder={'Remark'}
                  length={50}
                  keyboardType={"default"}
                  style={styles.input}
                  returnKeyType={"done"}
                  ref='remark'
                />

              </View>

              {/* <CardItem style={{display:this.state.isApramt==true?'flex':'none',alignItems:"flex-start",width:'100%',flexWrap:'wrap',paddingLeft:1,paddingRight:1}}>
              
               
                <Item>
                <Input placeholder="Approval Amount"
                style={{fontFamily:'Regular'}}
                keyboardType='numeric'
                returnKeyType = {"done"}
                value={this.state.aprAmt}
                onChangeText={val => this.setState({ aprAmt: val })}
               />
               </Item>
              </CardItem>

            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',paddingLeft:1,paddingRight:1}}>
                <Item>
                <Input placeholder="Remarks"
                style={{fontFamily:'Regular'}}
                returnKeyType = {"done"}
                value={this.state.FRemark}
                onChangeText={val => this.setState({ FRemark: val })}
               />
               </Item>
              </CardItem> */}


              <CardItem style={{ paddingLeft: 20 }}>
                <RadioGroup flexDirection='row'
                  radioButtons={this.state.radiovalues} onPress={this.onPress} />
              </CardItem>
            </Card>



            <Grid style={{ paddingTop: 5, width: '97%' }}>
              <Row>
                <Col style={{ alignItems: 'center', width: "33%" }}>
                  <CustomButton
                    title="STATUS"
                    onPress={() => this.STATUS()}
                    style={{ backgroundColor: '#3498db', width: '80%' }}
                    textStyle={{ fontSize: 13, fontFamily: 'Bold' }} />
                </Col>

                <Col style={{ alignItems: 'center', width: "34%" }}>
                  <CustomButton
                    title="DOCUMENT"
                    onPress={() => this.DOCUMENT()}
                    style={{ backgroundColor: '#3498db', width: '80%' }}
                    textStyle={{ fontSize: 13, fontFamily: 'Bold' }} />
                </Col>

                <Col style={{ alignItems: 'center', width: "33%" }}>
                  <CustomButton
                    title="SUBMIT"
                    onPress={() => this.SUBMIT()}
                    style={{ backgroundColor: '#3498db', width: '80%' }}
                    textStyle={{ fontSize: 13, fontFamily: 'Bold' }} />
                </Col>
              </Row>
            </Grid>

            <Toast ref="toast" />
          </ScrollView>
        </KeyboardAvoidingView>
      </View>

    );
  }
}

const styles = StyleSheet.create({
  input: {
    maxHeight: 80,
    borderColor: colorprimarydark,
    borderWidth: 1,
    padding: 6,
    width: 320,
    marginBottom: 5,
    alignSelf: 'stretch',
    borderRadius: 5,
    fontFamily: 'Regular'
  },
  tcenter: {
    flex: 1,
    alignSelf: 'center'
    //justifyContent: 'center',
    //alignItems: 'center'
  },
  list: {
    flex: 1,
    marginTop: 10,
  },

  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },

  itemView: {
    flex: 1,
    width,
    borderBottomWidth: 0.5,
    borderColor: '#cdcdcd',
    borderStyle: 'solid',
    paddingHorizontal: 12,
    flexDirection: 'row',
    paddingTop: 2
  },
  textContent: {
    color: white,
    fontSize: 12,
    fontFamily: 'Bold'
  },

  imagebutton: {
    width: 30,
    height: 30,
  },
  modal: {
    flex: 1,
    backgroundColor: white,
    height: 'auto',
    position: 'absolute',
    bottom: 0,
    width: '100%'
  },
  headerback: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colorprimary,
    borderWidth: 0.5,
    borderColor: white,
    height: 40,
    width: '100%',
    borderRadius: 5,
  },
  dropdownButtonStyle: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 10,
    paddingVertical: 12,
    backgroundColor: "#fff",
  },
  dropdownItemStyle: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 10,
    paddingHorizontal: 15,
  },
});


import React from 'react';
import {Dimensions,SectionList,StyleSheet,Modal,Image,Text,View,TouchableOpacity,Alert} from 'react-native';
import axios from 'axios';
import { Col, Grid,Row } from 'react-native-easy-grid';
import { NavigationActions, StackActions } from 'react-navigation';
import {Card,CardItem} from 'native-base';
import {format} from './class/Formater'
import strings from './res/strings'
import color from './res/colors'
import {logouttask} from './class/logout';
import { ScrollView } from 'react-native-gesture-handler';
import Toast from 'react-native-whc-toast'

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const { width, height } = Dimensions.get('window');

const blue=color.values.Colors.blue;
const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const lightblue=color.values.Colors.lightblue;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});
export default class CustomerReportDetail extends React.Component{
  static navigationOptions = ({ navigation }) => ({ 
    title: "Receivable Ageing",
    color:white,
    headerStyle: {
      backgroundColor: colorprimary,
    },
    headerTintColor:white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
      super(props);
      this.state = { 
        handlelogin:'',
        isLoading: true, 
        data: "",
        AgeCode:"",
        Party:'',
        UserID:''
    };
      
  }
  login = async () => 
  {
  
    Alert.alert(
      'Logout',
      'Would you like to logout?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {text: 'OK', onPress: () => { logouttask()
          this.props.navigation.dispatch(resetAction);
        } },
      ],
      {cancelable: false},
    );
   
  }
  
componentDidMount() {
  console.disableYellowBox = true;

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
  
  this.setState({
      AgeCode:this.props.navigation.getParam('AgeCode', ''),
      Party:this.props.navigation.getParam('Party', ''),
      UserID:this.props.navigation.getParam('UserID', '')
    },()=>{this.getcustomerreportdetail();})
}

getcustomerreportdetail(){
    const config = {
      headers: {   
      'currentToken':tokken,
    },
      params: {
      AgeCode:this.state.AgeCode,  
      Party:this.state.Party,
      }
    };

axios.get(ip+'/getCustomerReportDetailIos', config)
  .then(response => this.setState({data:response.data},() => {if(response.status==200){
   this.setState({isLoading:false});
  }
}))
.catch(err => 
  {
    this.setState({
      isLoading:false
    },()=>{
     let error=err
     
     this.refs.toast.showBottom(error.toString())

     setTimeout(
      () => { 
        this.props.navigation.goBack();
       },
      2000
    )

    })
  }
  );
}


  renderItem(item) {
      const {ProjectId,InvoiceNo,InvoiceDate,InvoiceAmt,BalanceAmt} = item.item;
      return (
               <Card style={{width:'97%',alignSelf:'center'}}>
               <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
        paddingLeft:5,paddingRight:5,paddingTop:10,paddingBottom:10}}>
               <Grid>
               <Row>
               <Col style={{alignItems:'flex-start',width:'15%'}}>
               <Text style={{fontSize:13,fontFamily:'Regular'}}>{ProjectId}</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'35%'}}>
               <Text style={{fontSize:13,fontFamily:'Regular'}}>{InvoiceNo}</Text>
               </Col> 
               <Col style={{alignItems:'flex-end',width:'25%'}}>
               <Text style={{fontSize:13,fontFamily:'Regular'}}>{format(InvoiceAmt,'N')}</Text>
               </Col> 
               <Col style={{alignItems:'flex-end',width:'25%'}}>
               <Text style={{fontSize:13,fontFamily:'Regular'}}>{format(BalanceAmt,'N')}</Text>
               </Col> 
               </Row>
               <Row style={{paddingTop:2}}>
               <Col style={{alignItems:'flex-start',width:'15%'}}>
               <Text style={{fontSize:13,fontFamily:'Regular'}}>{}</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'35%'}}>
               <Text style={{fontSize:13,fontFamily:'Regular'}}>{InvoiceDate}</Text>
               </Col> 
               <Col style={{alignItems:'flex-end',width:'50%'}}>
               <Text style={{fontSize:13,fontFamily:'Regular'}}>{}</Text>
               </Col> 
               </Row>
               </Grid>
               </CardItem>
               </Card>
      );
  }

  render() {
      if (this.state.isLoading) {
          return (
            <Modal
            transparent={false}
            supportedOrientations={['portrait', 'landscape']}
            visible={this.state.isLoading}
            >
             <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
              <Image
              style={{width: 300, height: 200}}
              source={require('./src/gears.gif')}  />
              </View>     
            </Modal>
          )
      }

      return (
    <View style={{flex:1,backgroundColor:lightblue}}>
    <ScrollView style={{height:'6%'}}>
    <View  style={{ flex: 1,paddingTop:'2%',paddingBottom:5,width:'97%',alignSelf:"center"}}>
    <Grid style={{backgroundColor:colorprimary,padding:5,borderRadius:4}}>
             <Row>
             <Col style={{alignItems:'flex-start',width:'15%'}}>
             <Text style={styles.textContent}>PID</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'35%'}}>
             <Text style={styles.textContent}>Inv No</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'25%'}}>
             <Text style={styles.textContent}>Inv Amt</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'25%'}}>
             <Text style={styles.textContent}>Bal Amt</Text>
             </Col> 
             </Row>
             </Grid>
    </View>
    </ScrollView>
    <ScrollView style={{height:'94%'}}>
              <SectionList
                  sections={this.state.data}
                  renderItem={this.renderItem.bind(this)}
                  renderSectionHeader={({ section }) =>       

                    <Grid style={{width:"97%",alignSelf:'center',backgroundColor:blue,borderRadius:2,padding:5}}>
                      <Row>
                        <Col style={{width:"100%"}}>
                        <Text style={{color:white,fontSize:13,fontFamily:'Bold'}}>{section.InvoiceAge}</Text>
                        </Col>
                      </Row>
                    </Grid>

                  }
                  keyExtractor={(item, index) => index}
              />
                <Toast ref="toast"
        />
          </ScrollView>  
    </View>    
      );
  }
}

const styles = StyleSheet.create({

  sectionHeader: {
      paddingTop: 2,
      paddingLeft: 10,
      paddingRight: 10,
      paddingBottom: 2,
      fontSize: 14,
      fontFamily: 'Bold',
      color:'#fff',
      backgroundColor: '#2452b2'
  },
textContent:{
    color:white,
    fontSize:13,
    fontFamily:'Bold'
  }

});


import React,{ Component }  from 'react';
import { ScrollView,StyleSheet,Text,View,Modal,FlatList,Dimensions,Image,TouchableOpacity,Alert} from 'react-native';
import { Col, Grid,Row } from 'react-native-easy-grid';
import axios from 'axios';
import { Card,CardItem,CheckBox } from 'native-base';
import DateTimePicker from "react-native-modal-datetime-picker";
import { NavigationActions, StackActions } from 'react-navigation';
import moment, { parseTwoDigitYear } from 'moment';
import { Overlay,Button,Divider } from 'react-native-elements';
import {logouttask} from './class/logout';
import color from './res/colors'
import strings from './res/strings'
import Toast from 'react-native-whc-toast'

const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;

const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class JournalSiteApproval extends React.Component {
  static navigationOptions = ({ navigation }) => ({ 
    title: "Journal Site",
    color:"#fff",
    headerStyle: {
      backgroundColor: "#2452b2",
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });


  constructor(props) {
    super(props);
    this.state = {
      handlelogin:'',
      USER:'',
      Name:'',
      isLoading: false, 
      Dept:'',
      dataSource:'',
      isDateTimePickerVisible:false,
      isDateTimePickerVisibleE:false,
      StartDate:'',
      EndDate:'',
      TotalAmount:'',
      isVisible:false,
      ssno:'',
      sglcode:'',
      snarration:'',
      sdebit:'',
      ssite:'',
      spid:'',
      sccode:'',
      sempid:'',
      ssid:'',
      sino:'',
      passingdataarray:[],
    };

}
login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
        this.props.navigation.dispatch(resetAction);
      } },
    ],
    {cancelable: false},
  );
 
}
hideDateTimePicker = () => {
    this.setState({ isDateTimePickerVisible: false });
}
hideDateTimePickerB = () => {
    this.setState({ isDateTimePickerVisibleE: false });
}
showDateTimePicker = () => {
    this.setState({ isDateTimePickerVisible: true });
}
showDateTimePickerE = () => {
    this.setState({ isDateTimePickerVisibleE: true });
}
handleDatePicked = date => {
    const NewDate =moment(date).format('DD/MM/YYYY')
    this.setState({StartDate:NewDate})
    this.hideDateTimePicker();
};
handleDatePickedB = date => {
    const NewDate =moment(date).format('DD/MM/YYYY')
    this.setState({EndDate:NewDate})
    this.hideDateTimePickerB();
};
componentDidMount(){ 
  console.disableYellowBox = true;

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
  
    this.setState({
      USER:this.props.navigation.getParam('UserID', ''),
      Name:this.props.navigation.getParam('Name', ''),
      Dept:this.props.navigation.getParam('Department', '')
    },()=>{this.getloadlist();})    
}
filter(){

if(this.state.StartDate.length>0 && this.state.EndDate.length>0){  
     this.filtertask();
}else{
  this.refs.toast.showBottom('Please Give the Start Date and End Date')
}

}


filtertask(){
  this.setState({ isLoading:true,dataSource:''})

  const SDATE = moment(this.state.StartDate,'DD/MM/YYYY').format('MM/DD/YYYY');
  const EDATE=moment(this.state.EndDate,'DD/MM/YYYY').format('MM/DD/YYYY');

  const config = {
      headers: {   
      'currentToken':tokken,
    },
   params: {
    UserID:this.state.USER,
    SDate:SDATE.toString(),
    EDate:EDATE.toString()
      }    
    };

axios.get(ip+'/getJournalSiteListAppFilter', config)
  .then(response => this.setState({dataSource:response.data},() => {if(response.status==200){

    let amo
    
    amo=0

  for(i=0;i<this.state.dataSource.length;i++){
    const{sDebit}=this.state.dataSource[i]
    amo=parseFloat(amo)+parseFloat(sDebit)
    this.state.dataSource[i].isSelect = true;
    console.log(sDebit)
  }
 
  this.setState({TotalAmount:this.format(amo),isLoading:false})

  }}))
    .catch(err => 
      {
        this.setState({
          isLoading:false
        },()=>{
         let error=err
         
         this.refs.toast.showBottom(error.toString())
  
         setTimeout(
          () => { 
            this.props.navigation.goBack();
           },
          2000
        )
  
        })
      }
      );
}


format(x) {
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

onsave(){

      let j=0

      console.log(this.state.dataSource)
      for(let i=0;i<this.state.dataSource.length>0;i++){
          const{isSelect}=this.state.dataSource[i]
    
         if(isSelect==true){
              j=j+1
          }
      }
    
      if(j!=0){
        Alert.alert(
            'Confirmation',
            'Would you like to Approve Selected Records?',
            [
              {
                text: 'Cancel',
                onPress: () => console.log('close'),
                style: 'cancel',
              },
              {text: 'OK', onPress: () => {
                  this.onsubmit()
            } },
            ],
            {cancelable: false},
          );
      }else{
          Alert.alert(
            'Journal',
            'Please Select Records ..',
            [
              {
                text: 'Ok',
                onPress: () => console.log('close'),
                style: 'cancel',
              },
            ],
            {cancelable: false},
          );
      }

}

onsubmit(){

  this.setState({
    isLoading:true
  })

    let url='/updateSiteApproval'

    for(i=0;i< this.state.dataSource.length ;i++){
        const{sSno,isSelect}=this.state.dataSource[i]
        if(isSelect==true){
            this.state.passingdataarray.push({SlNO:sSno,UserID:this.state.USER})
        }
      }

    axios({
        method: 'post',
        url:ip+url,
        headers: {'currentToken':tokken}, 
        data: {
            Items:this.state.passingdataarray,
        }
      }).then(response=>{if(response.status===200){
        this.setState({isLoading:false},()=>{
          this.refs.toast.showBottom('Submitted Successfully')
          this.getloadlist()
        })
      }else{
        this.refs.toast.showBottom('Some Error Occured!')
      }})
      .catch(err => 
        {
          this.setState({
            isLoading:false
          },()=>{
           let error=err
           
           this.refs.toast.showBottom(error.toString())
    
           setTimeout(
            () => { 
              this.props.navigation.goBack();
             },
            2000
          )
    
          })
        }
        );

}
getloadlist(){

this.setState({ isLoading:true,dataSource:''})

const config = {
      headers: {   
      'currentToken':tokken,
    },
   params: {
    UserID:this.state.USER,
      }    
    };
   
axios.get(ip+'/getJournalSiteListApp', config)
  .then(response => this.setState({dataSource:response.data},() => {if(response.status==200){

    let amo
    
    amo=0

  for(i=0;i<this.state.dataSource.length;i++){
    const{sDebit}=this.state.dataSource[i]
    amo=parseFloat(amo)+parseFloat(sDebit)

    this.state.dataSource[i].isSelect = true;

    console.log(amo)
  }
 
  this.setState({TotalAmount:this.format(amo),isLoading:false})

}}))
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );

}
hidemodel = (id) => {

    console.log('here')
  const{sSno,sGlcode,sNarration,sDebit,sSite,sPid,sCCode,sEmpid,sSid,sIno}=this.state.dataSource[id]

  this.setState({
      ssno:sSno,
      sglcode:sGlcode,
      snarration:sNarration,
      sdebit:sDebit,
      ssite:sSite,
      spid:sPid,
      sccode:sCCode,
      sempid:sEmpid,
      ssid:sSid,
      sino:sIno,
      isVisible:!this.state.isVisible
  })
}


selectItem = (data,index) => {
    data.isSelect = !data.isSelect;
   
    const i =index 
  
    this.state.dataSource[i] = data;
  
    this.setState({
      dataSource: this.state.dataSource,
    });
  };



   renderItem = (data,index) =>
  <TouchableOpacity activeOpacity={.6}   onLongPress={() => this.hidemodel(index)}>
       <Card style={{alignSelf:'center',width:'97%'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
            <Grid>
              <Col style={{alignItems:'flex-start',width:'90%'}}>
              <Row>
              <Col style={{alignItems:'flex-start',width:'25%'}}>
              <Text style={{fontSize:13}}>{data.sSno}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13}}>{data.sDate}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'25%'}}>
              <Text style={{fontSize:13,alignSelf:'flex-end'}}>{data.sDebit}</Text>
              </Col> 
              </Row>
              <Row>
              <Col style={{alignItems:'flex-start',width:'100%'}}>
              <Divider style={{ backgroundColor:colorprimary,width:"98%"}} />
              </Col>
              </Row>
              <Row>
              <Col style={{alignItems:'flex-start',width:'100%'}}>
              <Text style={{fontSize:13}}>{data.sGlcode}</Text>
              </Col> 
              </Row>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'10%'}}>
              <CheckBox   onPress={() => this.selectItem(data,index)} checked={data.isSelect}  />
              </Col>
            </Grid>  
            </CardItem>
        </Card>
        </TouchableOpacity>
 


  render() {
    if (this.state.isLoading) {
      return (
        <Modal
        transparent={false}
        supportedOrientations={['portrait', 'landscape']}
        visible={this.state.isLoading}
        >
         <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
          style={{width: 300, height: 200}}
          source={require('./src/gears.gif')}  />
          </View>     
        </Modal>
      )
  }
    return (
      <View style={{flex:1}}>
<ScrollView style={{height:'20%'}}>
            <Card style={{alignSelf:'center',width:'97%'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
            <Grid>
            <Col  style={{alignItems:'center',width:'80%'}}>
            <Row>
            <Col style={{alignItems:'flex-start',width:'50%'}}>
            <Text style={{fontSize:12,paddingBottom:5,color:colorprimary,fontWeight:'bold'}}>Start Date</Text>   
            </Col>
            <Col style={{alignItems:'flex-start',width:'50%'}}>
            <Text style={{fontSize:12,paddingBottom:5,color:colorprimary,fontWeight:'bold'}}>End Date</Text>   
            </Col>
            </Row>
            <Row>
            <Col style={{alignItems:'flex-start',width:'50%'}}>
            <TouchableOpacity onPress={this.showDateTimePicker.bind(this)} >
            <View style={styles.datePickerBox}>
            <Text style={styles.datePickerText}>{this.state.StartDate}</Text>
            </View>
            </TouchableOpacity>
            <DateTimePicker
            isVisible={this.state.isDateTimePickerVisible}
            onConfirm={this.handleDatePicked}
            onCancel={this.hideDateTimePicker}/>   
            </Col>
            <Col style={{alignItems:'flex-start',width:'50%'}}>
            <TouchableOpacity onPress={this.showDateTimePickerE.bind(this)} >
            <View style={styles.datePickerBox}>
            <Text style={styles.datePickerText}>{this.state.EndDate}</Text>
            </View>
            </TouchableOpacity>
            <DateTimePicker
            isVisible={this.state.isDateTimePickerVisibleE}
            onConfirm={this.handleDatePickedB}
            onCancel={this.hideDateTimePickerB}/>   
            </Col>
            </Row>

            </Col>
            <Col style={{alignItems:'center',width:'20%',alignSelf:'center'}}>
            <Col style={{alignItems:'center',width:'100%',alignSelf:'center'}}>
            <Button
            title={'Filter'}
            onPress={this.filter.bind(this)}
            state={styles.tbutton}
            />
            </Col>
            </Col>
           
            </Grid>
            </CardItem>
            </Card>
   
<View style={styles.Head}>
            <Grid style={{width:'98%',alignSelf:'center',backgroundColor:'#2452b2'}}>
              <Col style={{alignItems:'flex-start',width:'25%',backgroundColor:'#2452b2'}}>
              <Text style={{color:'#fff',fontSize:13,padding:4,paddingLeft:20}}>ID</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'40%',backgroundColor:'#2452b2'}}>
              <Text style={{color:'#fff',fontSize:13,padding:4,paddingLeft:14}}>Date</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'25%',backgroundColor:'#2452b2'}}>
              <Text style={{color:'#fff',fontSize:13,padding:4,paddingLeft:15}}>Amount</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'10%',backgroundColor:'#2452b2'}}>
              <Text></Text>
              </Col> 
            </Grid>  
</View> 
</ScrollView>
    <ScrollView style={{height:'64%'}}>
           <FlatList
            data={this.state.dataSource}
            initialNumToRender={this.state.dataSource.length}
            renderItem={({item,index}) => this.renderItem(item,index)}
            keyExtractor={(item, index) => index.toString()}
            extraData={this.state}
            />
    </ScrollView>
    <ScrollView style={{height:'16%'}}>
      <Card style={{alignSelf:'center',width:'97%'}}>
        <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
        <Grid>
        <Row>
        <Col style={{alignItems:'flex-end',width:'65%'}}>
        <Text style={{fontWeight:'bold',color:colorprimary,fontSize:16}}>Total : </Text>
        </Col>
        <Col style={{alignItems:'flex-end',width:'25%'}}>
        <Text style={{fontSize:13}}>{this.state.TotalAmount}</Text>
        </Col>
        <Col style={{alignItems:'flex-end',width:'10%'}}>
        <Text></Text>
        </Col>
        </Row>
        </Grid>
        </CardItem>
      </Card>

<View style={{alignSelf:'center',paddingTop:5,paddingBottom:5}}>
<Button
          title={'SUBMIT'}
          onPress={this.onsave.bind(this)}
          state={styles.tbutton}
        />
</View>
 </ScrollView>
<Overlay
  overlayStyle={{ width:"90%" , height:"50%"}}
  animationType='slide'
  isVisible={this.state.isVisible}
  onBackdropPress={() => this.setState({ isVisible: false })}>
  <ScrollView>
  <TouchableOpacity style={styles.FacebookStyle} activeOpacity={0.5} onPress = {() => {  
                  this.setState({ isVisible:!this.state.isVisible})}}>


<Grid>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontWeight:'bold',alignSelf:'flex-start'}}>
             Journal Details
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('./src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
       </Grid>
  
  </TouchableOpacity>
  <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle} >SNo</Text>
          </Col> 
          <Col>
          <Text style={styles.detail}>{this.state.ssno}</Text>
          </Col> 
        </Grid>
  </View>
  <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle} >GL Description</Text>
          </Col> 
          <Col>
          <Text style={styles.detail}>{this.state.sglcode}</Text>
          </Col> 
        </Grid>
  </View>
  <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle} >Amount</Text>
          </Col> 
          <Col>
          <Text style={styles.detail}>{this.state.sdebit}</Text>
          </Col> 
        </Grid>
  </View>
  <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle} >Site</Text>
          </Col> 
          <Col>
          <Text style={styles.detail}>{this.state.ssite}</Text>
          </Col> 
        </Grid>
  </View>
  <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle} >Narration</Text>
          </Col> 
          <Col>
          <Text style={styles.detail}>{this.state.snarration}</Text>
          </Col> 
        </Grid>
  </View>
  <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle} >Project</Text>
          </Col> 
          <Col>
          <Text style={styles.detail}>{this.state.spid}</Text>
          </Col> 
        </Grid>
  </View>
  <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle} >Cost Code</Text>
          </Col> 
          <Col>
          <Text style={styles.detail}>{this.state.sccode}</Text>
          </Col> 
        </Grid>
  </View>
  <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle} >Employee</Text>
          </Col> 
          <Col>
          <Text style={styles.detail}>{this.state.sempid}</Text>
          </Col> 
        </Grid>
  </View>
  <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle} >Vendor</Text>
          </Col> 
          <Col>
          <Text style={styles.detail}>{this.state.ssid}</Text>
          </Col> 
        </Grid>
  </View>
  <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle} >Invoice No.</Text>
          </Col> 
          <Col>
          <Text style={styles.detail}>{this.state.sino}</Text>
          </Col> 
        </Grid>
  </View>
  </ScrollView>

</Overlay>

<Toast ref="toast"
        />

</View>
        )
      }
 };
 const styles = StyleSheet.create({
    tbutton: {
        height:50,
        alignSelf:'center',
        justifyContent:'center'
      },
      spinner: {
        fontSize: 12,
        padding:10,
        height:40,
        flexWrap: 'wrap',
        color: 'grey',
      },
      Head: {
        flex: 1,
        paddingTop:5,
      },
      tittle:{
        color:'#36428a',
        fontSize:13
       },
       C:{
        alignItems:"flex-start",
        width:130
       },
       b: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop:5,
      },
      FacebookStyle: {
        flexDirection: 'row',
        alignItems:'center',
        backgroundColor: '#1ca0ff',
        borderWidth: 0.5,
        borderColor: '#fff',
        height: 40,
        width: screenWidth,
        borderRadius: 5,
      },




      
  datePickerBox:{
    borderColor: '#1ca0ff',
    borderWidth: 0.5,
    padding: 0,
    borderTopLeftRadius: 4,
    borderTopRightRadius: 4,
    borderBottomLeftRadius: 4,
    borderBottomRightRadius: 4,
    height: 38,
    width:100,
    justifyContent:'center'
  },
 
  datePickerText: {
    fontSize: 13,
    marginLeft: 5,
    borderWidth: 0,
    color: '#000',
  },
  });
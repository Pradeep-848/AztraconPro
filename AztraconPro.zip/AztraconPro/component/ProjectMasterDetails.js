import React, { Component } from 'react';
import { StyleSheet, TouchableOpacity, Alert, Text, View, Image, FlatList, ImageBackground, ScrollView, Dimensions } from 'react-native';
import { Col, Grid, Row } from 'react-native-easy-grid';
import { NavigationActions, StackActions } from 'react-navigation';
import { Card, CardItem } from 'native-base';
import { RFValue } from "react-native-responsive-fontsize";

//own lib
import { isPortrait } from './class/useOrientation'
import color from './res/colors'
import { logouttask } from './class/logout';

//constant
const colorprimary = color.values.Colors.colorPrimary;
const white = color.values.Colors.white;

//logout
const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

//common style
const style_common = require('./class/style');

var { height, width } = Dimensions.get("window");

export default class ProjectMasterDetails extends React.Component {
  static navigationOptions = ({ navigation }) => ({
    title: "Project Master",
    headerStyle: {
      backgroundColor: colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily: 'Bold',
      fontSize: RFValue(18)
    },
    headerRight: (
      <TouchableOpacity style={{ paddingRight: 10 }} onPress={() =>
        navigation.state.params.handlelogin()
      }>
        <Image
          style={{ alignSelf: 'center', justifyContent: 'center' }}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),

  });

  constructor(props) {
    super(props);
    this.state = {
      USER: '',
      Customer: '',
      handlelogin: '',
      PID: '',
      PDESC: '',
      CustomerName: '',
      DeviceType: '',
      orientation: '',
      MenudataProject: [
        {
          "A": "Project Detail",
          "B": require('./src/ic_projectdetail1.png'),
          "C": "ProjectDetailsActivity",
        },
        {
          "A": "Tag Details",
          "B": require('./src/ic_tagdetail1.png'),
          "C": "TagListActivity",
        },
        {
          "A": "BOM Details",
          "B": require('./src/ic_bomdetail1.png'),
          "C": "BomListTypeActivity",
        },
        {
          "A": "Task Detail",
          "B": require('./src/ic_taskdetail1.png'),
          "C": "TaskListActivity",
        },
        {
          "A": "Time Sheet",
          "B": require('./src/ic_timesheet1.png'),
          "C": "TimeSheetsActivity",
        },
        {
          "A": "Cost Analysis",
          "B": require('./src/ic_costanalysis1.png'),
          "C": "CostAnalysisActivity",
        },
        {
          "A": "Billing Schedule",
          "B": require('./src/ic_billschedule1.png'),
          "C": "BillingScheduleActivity",
        },
        {
          "A": "Drawings",
          "B": require('./src/ic_drawings1.png'),
          "C": "DrawingsActivity",
        },
        {
          "A": "NMR Details",
          "B": require('./src/ic_nmr1.png'),
          "C": "NMRDetailsActivity",
        },
        {
          "A": "Purchase Request",
          "B": require('./src/ic_pr1.png'),
          "C": "PurchaseRequestActivity",
        },
        {
          "A": "Purchase Order",
          "B": require('./src/ic_po1.png'),
          "C": "PurchaseOrderActivity",
        },
        {
          "A": "WareHouse Receipt",
          "B": require('./src/ic_wh1.png'),
          "C": "WarehouseListActivity",
        },
        {
          "A": "Pull List",
          "B": require('./src/ic_pulllist1.png'),
          "C": "PullListActivity",
        },
        {
          "A": "Ledger",
          "B": require('./src/ic_ledger1.png'),
          "C": "ProjectLedgerActivity",
        },
        {
          "A": "Punch List",
          "B": require('./src/ic_punch1.png'),
          "C": "PunchListActivity",
        },
        {
          "A": "Mail",
          "B": require('./src/tm_email1.png'),
          "C": "ProjectMailActivity",
        },
        {
          "A": "Task Gallery",
          "B": require('./src/ic_task_gallery.png'),
          "C": "TaskGalleryActivity",
        },
      ],
    };
  }
  login = async () => {

    Alert.alert(
      'Logout',
      'Would you like to logout?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {
          text: 'OK', onPress: () => {
            logouttask()
            this.props.navigation.dispatch(resetAction);
          }
        },
      ],
      { cancelable: false },
    );

  }

  gotonextpage = (index) => {

    const id = index

    const { C } = this.state.MenudataProject[id]

    if (C == 'undefined' || C == null || C.length == 0) {
      this.refs.toast.showBottom("This Feature Update Soon")
    } else {
      this.props.navigation.navigate(C, {
        PID: this.state.PID,
        CusID: this.state.Customer,
        USER: this.state.USER,
        PDesc: this.state.PDESC,
        CusName: this.state.CustomerName,
        DeviceType: this.state.DeviceType
      });

    }

  }

  // changeScreenOrientation() {
  //   ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT);
  // }



  componentDidMount() {
    console.disableYellowBox = true;

    Dimensions.addEventListener('change', () => {
      this.setState({
        orientation: isPortrait() ? 'portrait' : 'landscape'
      });
    });

    // this.changeScreenOrientation()
    this.props.navigation.setParams({
      handlelogin: this.login.bind(this)
    });
    this.setState({ USER: this.props.navigation.getParam('USER', '') })
    this.setState({ Customer: this.props.navigation.getParam('CusID', '') })
    this.setState({ CustomerName: this.props.navigation.getParam('CusName', '') })
    this.setState({ PID: this.props.navigation.getParam('PID', '') })
    this.setState({ PDESC: this.props.navigation.getParam('PDesc', '') })
    this.setState({
      DeviceType: this.props.navigation.getParam('DeviceType', ''),
      orientation: isPortrait() ? 'portrait' : 'landscape'
    })


  }

  getheight(which) {
    let orient = ''
    let device = ''

    orient = this.state.orientation
    device = this.state.DeviceType

    console.log(orient + device)
    if (which == '1') { //header
      if (device == 'phone') {
        console.log(device)
        if (orient == 'portrait') {
          return '10%'
        } else {
          //landscape
          return '25%'
        }

      } else {
        //tab
        if (orient == 'portrait') {
          return '10%'
        } else {
          //landscape
          return '13%'
        }

      }
    }


    if (which == '2') { //body
      if (device == 'phone') {

        if (orient == 'portrait') {
          return '90%'
        } else {
          //landscape
          return '75%'
        }

      } else {
        //tab
        if (orient == 'portrait') {
          return '90%'
        } else {
          //landscape
          return '87%'
        }

      }
    }

  }


  render() {
    return (
      <View style={{ flex: 1 }}>

        <ScrollView style={{ height: this.getheight('1') }}>
          <Card style={{ width: '97%', alignSelf: 'center', borderColor: colorprimary }}>
            <CardItem style={{
              alignItems: "flex-start", width: '100%', flexWrap: 'wrap',
              paddingLeft: 5, paddingRight: 5, paddingTop: 5, paddingBottom: 5
            }}>
              <View style={{ flexDirection: 'row' }}>
                <Grid>
                  <Row style={{ paddingTop: 5, paddingBottom: 5 }}>
                    <Text numberOfLines={1} style={styles.titleText}>
                      {this.state.PID.toString().trim() + " - " + this.state.PDESC}
                    </Text>
                  </Row>
                  <Row style={{ paddingTop: 5, paddingBottom: 5 }}>
                    <Text numberOfLines={1} style={styles.titleText}>
                      {this.state.Customer.toString().trim() + " - " + this.state.CustomerName}
                    </Text>
                  </Row>
                </Grid>
              </View>
            </CardItem>
          </Card>

        </ScrollView>
        <ScrollView style={{ height: this.getheight('2') }}>
          <FlatList
            data={this.state.MenudataProject}
            renderItem={({ item, index }) =>

              <Grid style={{ flex: 1 / 3 }}>
                <Row>
                  <Col style={{ alignItems: 'center', width: '100%', alignSelf: 'center' }}>
                    <TouchableOpacity activeOpacity={.5} onPress={() => this.gotonextpage(index)}>
                      <Card style={{
                        padding: 8, paddingTop: 0, paddingBottom: 0,
                        borderRadius: 8, borderColor: colorprimary
                      }} >

                        <View
                          style={{
                            height: (height * 12) / 100,
                            width: (width * 20) / 100,
                            justifyContent: 'center',
                            alignItems: 'center',
                          }}
                        >

                          <Image style={styles.imagebutton}
                            source={item.B} />

                        </View>


                      </Card>
                    </TouchableOpacity>
                  </Col>
                </Row>
                <Row>
                  <Col style={{ alignItems: 'center', width: '100%', alignSelf: 'center' }}>
                    <Text style={{ alignSelf: 'center', flexWrap: 'wrap', fontSize: RFValue(12), fontFamily: 'Bold' }}>{item.A}</Text>
                  </Col>
                </Row>



              </Grid>

            }
            numColumns={3}
            keyExtractor={(item, index) => index}
          />

        </ScrollView>

      </View>
    )
  }
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'stretch'
  },
  imagefinalbutton: {
    width: 60,
    height: 85,
    marginTop: 3,
    resizeMode: 'contain',
    justifyContent: "center",
    alignItems: "center",
    alignSelf: 'center',
    aspectRatio: 1,
    flex: 1 / 3
  },
  titleText: {
    fontSize: RFValue(12),
    fontFamily: 'Bold',
    color: colorprimary,
  },
  image: {
    width: 40,
    height: 40,
    marginTop: 5,
    marginRight: 10,
  },
  imagebutton: {
    width: '100%',
    height: '100%',
    alignSelf: 'center',
    resizeMode: 'contain'
  },
  textContent: {
    backgroundColor: '#36428a',
    fontSize: 12,
    padding: 4,
    marginLeft: 10,
    marginRight: 10,
    color: '#fff',
    fontWeight: 'bold'
  },
  imagetext: {
    fontSize: 12,
    color: '#A0A0A0',
  },
  b: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 10,
  },
  i: {
    paddingTop: 10,
  },
});






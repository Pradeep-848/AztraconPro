import React, { Component } from 'react';
import { ScrollView, StyleSheet, Text, View, Modal, FlatList, TouchableOpacity, Image, Alert, Dimensions } from 'react-native';
import { Col, Grid, Row } from 'react-native-easy-grid';
import { SearchBar, Overlay } from 'react-native-elements';
import { NavigationActions, StackActions } from 'react-navigation';
import axios from 'axios';
import { Card, CardItem } from 'native-base';
import Toast from 'react-native-whc-toast'
import { RFValue } from "react-native-responsive-fontsize";

//own library
import strings from './res/strings'
import color from './res/colors'
import { logouttask } from './class/logout';
import { isPortrait } from './class/useOrientation'

//common value
const ip = strings.values.commonvalues.ip;
const tokken = strings.values.commonvalues.tokken;
const colorprimary = color.values.Colors.colorPrimary;
const primarylite = color.values.Colors.primarylite
const white = color.values.Colors.white;
const lightblue = color.values.Colors.lightblue;

//common style
const style_common = require('./class/style');

//logout function
const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});


export default class CustomerMaster extends React.Component {

  static navigationOptions = ({ navigation }) => ({
    title: "Customer List",
    color: white,
    headerStyle: {
      backgroundColor: colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily: 'Bold',
      fontSize: RFValue(18)
    },
    headerRight: (
      <TouchableOpacity style={{ paddingRight: 10 }} onPress={() =>
        navigation.state.params.handlelogin()
      }>
        <Image
          style={{ alignSelf: 'center', justifyContent: 'center' }}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),

  });

  constructor(props) {
    super(props);
    this.state = {
      UserID: '',
      isLoading: false,
      handlelogin: '',
      dataSource: [],
      agecode: "",
      value: '',
      orientation: '',
      DeviceType: '',
      filter: '',
      ClickedCusID: '',
      ClickedCusName: '',
      isVisible: false,
      alphadata: [{ "key": "A" }, { "key": "B" }, { "key": "C" }, { "key": "D" }, { "key": "E" }, { "key": "F" }, { "key": "G" }, { "key": "H" }, { "key": "I" }, { "key": "J" }, { "key": "K" }, { "key": "L" }, { "key": "M" }
        , { "key": "N" }, { "key": "O" }, { "key": "P" }, { "key": "Q" }, { "key": "R" }, { "key": "S" }, { "key": "T" }, { "key": "U" }, { "key": "V" }, { "key": "W" }
        , { "key": "X" }, { "key": "Y" }, { "key": "Z" }],
      tag: "all",
    };
    this.arrayholder = [];
    this.alphaholder = [];
  }


  login = async () => {

    Alert.alert(
      'Logout',
      'Would you like to logout?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {
          text: 'OK', onPress: () => {
            logouttask()
            this.props.navigation.dispatch(resetAction);
          }
        },
      ],
      { cancelable: false },
    );

  }

  Profile = () => {

    this.setState({ isVisible: false }, () => {
      this.props.navigation.navigate('CustomerProfileActivity', { CusID: this.state.CusID, UserID: this.state.UserID, CusName: this.state.CusName });
    })

  }

  Projectlist = () => {

    this.setState({ isVisible: false }, () => {
      this.props.navigation.navigate('CustomerProjectMasterActivity', { CusID: this.state.CusID, UserID: this.state.UserID, CusName: this.state.CusName });
    })

  }

  Contact = () => {

    this.setState({ isVisible: false }, () => {
      this.props.navigation.navigate('CustomerContactMasterActivity', { CusID: this.state.CusID, UserID: this.state.UserID, CusName: this.state.CusName });
    })

  }

  Ledger = () => {

    this.setState({ isVisible: false }, () => {
      this.props.navigation.navigate('CustomerLedgerActivity', { CusID: this.state.CusID, UserID: this.state.UserID, CusName: this.state.CusName });
    })

  }

  Receivableageing = () => {
    this.getagecode();
  }

  opendialog(index) {
    let id = index

    const { sID, sName } = this.state.dataSource[id];

    this.setState({
      UserID: this.state.UserID,
      CusID: sID,
      CusName: sName,
      isVisible: true
    })

  }

  getagecode() {

    console.log("clicked" + this.state.CusID)

    const config = {
      headers: {
        'currentToken': tokken,
      },
      params: {
        sqlQuery: "SELECT ISNULL(Age,0) FROM Invoice_Ageing WHERE InvType = 'C' and Party ='" + this.state.CusID.toString() + "'"
      }
    };
    this.setState({ isLoading: true })

    axios.get(ip + '/getQuery', config)
      .then(response => this.setState({ agecode: response.data }, () => {
        console.log(response.data)
        if (response.status == 200) {
          this.setState({ isLoading: false, isVisible: false }, () => {
            console.log("agecode" + this.state.agecode)
            this.props.navigation.navigate('CustomerReportDetailActivity',
              {
                AgeCode: this.state.agecode,
                UserID: this.state.UserID,
                CusName: this.state.CusName,
                Party: this.state.CusID
              });
          });
        }

      }))
      .catch(err => {
        this.setState({
          isLoading: false
        }, () => {
          let error = err

          this.refs.toast.showBottom(error.toString())

          setTimeout(
            () => {
              this.props.navigation.goBack();
            },
            2000
          )

        })
      }
      );
  }

  getcustomer() {
    const config = {
      headers: {
        'currentToken': tokken,
      },
    };
    this.setState({ isLoading: true })

    axios.get(ip + '/getCustomerlist', config)
      .then(response => this.setState({ dataSource: response.data }, () => {
        if (response.status == 200) {
          this.arrayholder = this.state.dataSource;
          this.setState({ isLoading: false });
        }

      }))
      .catch(err => {
        this.setState({
          isLoading: false
        }, () => {
          let error = err

          this.refs.toast.showBottom(error.toString())

          setTimeout(
            () => {
              this.props.navigation.goBack();
            },
            2000
          )

        })
      }
      );

  }

  hidemodel() {
    this.setState({ isVisible: false })
  }

  filtersearch(text) {
    const newData = this.arrayholder.filter(function (item) {
      const itemData = item.sID.toString().toUpperCase() + item.sName.toString().toUpperCase()
      const textData = text.toUpperCase()
      return itemData.indexOf(textData) > -1
    }
    )
    this.setState({
      dataSource: newData.sort(),
      text: text
    })
  }

  getfiltervalue = (value) => {
    const config = {
      headers: {
        'currentToken': tokken,
      },
      params: {
        Filter: value.toString(),
      }
    };
    this.setState({ isLoading: true, dataSource: '' })

    axios.get(ip + '/getCustomerlistfilterios', config)
      .then(response => this.setState({ dataSource: response.data }, () => {
        if (response.status == 200) {
          this.arrayholder = this.state.dataSource;
          if (this.state.dataSource.length === 0 || this.state.dataSource === undefined) {
            // alert("No Record Found")
          }
          this.setState({ isLoading: false });
        }

      }))
      .catch(err => {
        this.setState({
          isLoading: false
        }, () => {
          let error = err

          this.refs.toast.showBottom(error.toString())

          setTimeout(
            () => {
              this.props.navigation.goBack();
            },
            2000
          )

        })
      }
      );

  }

  filterclick = (value) => {
    this.getfiltervalue(value)
  }

  componentDidMount() {

    console.disableYellowBox = true;

    Dimensions.addEventListener('change', () => {
      this.setState({
        orientation: isPortrait() ? 'portrait' : 'landscape'
      });
    });

    this.props.navigation.setParams({
      handlelogin: this.login.bind(this)
    });
    this.setState({
      UserID: this.props.navigation.getParam('UserID', ''),
      DeviceType: this.props.navigation.getParam('DeviceType', ''),
      orientation: isPortrait() ? 'portrait' : 'landscape',
    }, () => {
      this.getfiltervalue("A");
    })


  }
  render() {

    if (this.state.isLoading) {

      return (
        <Modal
          transparent={false}
          supportedOrientations={['portrait', 'landscape']}
          visible={this.state.isLoading}
        >
          <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
            <Image
              useNativeDriver={true}
              style={style_common.load_gif}
              source={require('./src/gears.gif')} />
          </View>
        </Modal>
      )

    }

    return (

      <View style={{ flex: 1, backgroundColor: lightblue }}>

        <ScrollView style={{ height: this.state.DeviceType == 'tablet' ? this.state.orientation == 'portrait' ? '6%' : '12%' : this.state.orientation == 'portrait' ? '12%' : '24%' }}>
          {/* <ScrollView  style={{ height:this.state.orientation == 'portrait' || this.state.DeviceType=='tablet' ? '12%' : '24%'}}> */}
          <SearchBar
            placeholder="Search Customer ID/ Name "
            onChangeText={(text) => this.filtersearch(text)}
            style={style_common.ios_search}
            value={this.state.text}
            searchIcon={{ name: "search", size: 19, color: colorprimary }}
            clearIcon={{ name: "close-circle", size: 19 }}
            loadingProps={{ size: "small" }}
            platform={'ios'}
          />
        </ScrollView>

        <ScrollView style={{ height: this.state.orientation == 'portrait' || this.state.DeviceType == 'tablet' ? '80%' : '60%' }}>
          <Overlay
            overlayStyle={{ height: '40%', width: '88%', backgroundColor: primarylite, borderRadius: 15 }}
            animationType='slide'
            supportedOrientations={['portrait', 'landscape']}
            isVisible={this.state.isVisible}
            onBackdropPress={() => this.setState({ isVisible: false })}>
            <ScrollView>

              <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress={() => {
                this.setState({ isVisible: !this.state.isVisible })
              }}>

                <Grid>
                  <Row>
                    <Col style={{ width: '90%', alignItems: 'center', alignSelf: 'center' }}>
                      <Text style={{ paddingLeft: '3%', color: '#fff', textDecorationStyle: 'solid', fontFamily: 'Bold', alignSelf: 'flex-start' }}>
                        Customer
                      </Text>
                    </Col>

                    <Col style={{ width: '10%', alignItems: 'center', alignSelf: 'center' }}>
                      <Image
                        source={require('./src/back.png')}
                        style={{ height: 22, width: 22 }}
                      />
                    </Col>
                  </Row>
                </Grid>


              </TouchableOpacity>


              <Grid style={{ flex: 1 / 3 }}>
                <Row style={styles.i}>
                  <Col style={{ alignItems: 'center' }}>
                    <TouchableOpacity activeOpacity={.5} onPress={this.Profile}>
                      <Image style={styles.imagebutton}
                        source={require('./src/ic_cus.png')} />
                    </TouchableOpacity>
                    <Text style={{ color: white, fontFamily: 'Bold' }}>Profile</Text>
                  </Col>
                  <Col style={{ alignItems: 'center' }}>
                    <TouchableOpacity activeOpacity={.5} onPress={this.Projectlist}>
                      <Image style={styles.imagebutton}
                        source={require('./src/ic_proj_list.png')} />
                      <Text style={{ color: white, fontFamily: 'Bold' }}>Project List</Text>
                    </TouchableOpacity>
                  </Col>
                  <Col style={{ alignItems: 'center' }}>
                    <TouchableOpacity activeOpacity={.5} onPress={this.Contact}>
                      <Image style={styles.imagebutton}
                        source={require('./src/ic_contacts.png')} />
                      <Text style={{ color: white, fontFamily: 'Bold' }}>Contact</Text>
                    </TouchableOpacity>
                  </Col>
                </Row>
                <Row style={styles.i}>
                  <Col style={{ alignItems: 'center' }}>
                    <TouchableOpacity activeOpacity={.5} onPress={this.Ledger}>
                      <Image style={styles.imagebutton}
                        source={require('./src/ic_ledger_book.png')} />
                    </TouchableOpacity>
                    <Text style={{ color: white, fontFamily: 'Bold' }}>Ledger</Text>
                  </Col>
                  <Col style={{ alignItems: 'center' }}>
                    <TouchableOpacity activeOpacity={.5} onPress={this.Receivableageing}>
                      <Image style={styles.imagebutton}
                        source={require('./src/ic_receive.png')} />
                      <Text style={{ color: white, fontFamily: 'Bold' }}>Receivable Ageing</Text>
                    </TouchableOpacity>
                  </Col>
                </Row>
              </Grid>

            </ScrollView>
          </Overlay>
          <FlatList
            data={this.state.dataSource}
            initialNumToRender={this.state.dataSource.length}
            renderItem={({ item, index }) =>
              <Card style={{ width: '97%', alignSelf: 'center' }}>
                <CardItem style={{
                  alignItems: "flex-start", width: '100%', flexWrap: 'wrap',
                  paddingLeft: 5, paddingRight: 5, paddingTop: 8, paddingBottom: 8
                }}>
                  <Grid onPress={() => this.opendialog(index)}>
                    <Row>
                      <Col style={{ alignItems: "flex-start", width: '20%' }}>
                        <Text style={style_common.bold_listitem}>{item.sID}</Text>
                      </Col>
                      <Col style={{ alignItems: "flex-start", width: '80%' }}>
                        <Grid>
                          <Row>
                            <Col style={{ alignItems: "flex-start", width: '100%' }}>
                              <Text style={style_common.bold_listitem}>{item.sName}</Text>
                            </Col>
                          </Row>
                          <Row>
                            <Col style={{ alignItems: "flex-end", width: '100%' }}>
                              <Text style={style_common.bold_italic_listtotal}>{item.sBalance == '0' ? '' : item.sBalance}</Text>
                            </Col>
                          </Row>
                        </Grid>
                      </Col>
                    </Row>
                  </Grid>
                </CardItem>
              </Card>
            }
            keyExtractor={(item, index) => index.toString()}
          />




        </ScrollView>

        <FlatList
          horizontal
          style={{ height: this.state.orientation == 'portrait' || this.state.DeviceType == 'tablet' ? '8%' : '16%', alignSelf: 'center' }}
          data={this.state.alphadata}
          renderItem={({ item: rowData }) => {
            return (

              <Text style={{
                fontSize: RFValue(20), paddingLeft: RFValue(12), alignSelf: 'center', color: colorprimary,
                fontFamily: "Bold"
              }}
                onPress={this.filterclick.bind(this, rowData.key)}
              >
                {rowData.key}
              </Text>

            );
          }}
          keyExtractor={(item, index) => index}
        />

        <Toast ref="toast"
        />

      </View>
    )

  }

};

const styles = StyleSheet.create({
  tittle: {
    color: '#36428a',
    fontSize: 13
  },
  values: {
    color: '#708090',
    fontSize: 12
  },
  imagebutton: {
    width: 80,
    height: 80,
    marginTop: 3,
    justifyContent: "center",
    alignItems: "center"
  },
  input: {
    maxHeight: 100,
    borderColor: "#1ca0ff",
    borderWidth: 1,
    padding: 10,
    width: 320,
    marginBottom: 10,
  },
  i: {
    paddingTop: 10,
  },
  headerback: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colorprimary,
    borderWidth: 0.5,
    borderColor: white,
    height: 35,
    width: '100%',
    borderRadius: 5,
  },
});

import React,{ Component }  from 'react';
import {Dimensions,ScrollView,StyleSheet,View,Image,FlatList,Text,Modal,Alert,TouchableOpacity,KeyboardAvoidingView} from 'react-native';
import { Col, Grid,Row } from 'react-native-easy-grid';
import axios from 'axios';
import {Card,CardItem,Item,Input} from 'native-base';
import {Overlay,Button} from 'react-native-elements'
import RadioGroup from 'react-native-radio-buttons-group';
import Toast from 'react-native-whc-toast'
import strings from './res/strings'
import color from './res/colors'

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;

const mheight=Math.round(Dimensions.get('window').height)/2;
const sheight=(mheight/2)+mheight;
let selectedButton;
let AppStatus;

let ID;

let m;
let m1;

 export default class PRAppGen extends React.Component {
  static navigationOptions = ({ navigation }) => ({ 
    title: "PR General",
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor:white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
      handlelogin:'',
      USER:'',
      PRNO:'',
      SEQNO:'',
      isLoading: false, 
      dataSource:[],
      Approve:false,
      Rework:false,
      Remarks:'',
      data:'',
      PRType:'',
      PRDate:'',
      ReqDate:'',
      Pid:'',
      Notes:'',
      BAmt:'',
      Cur:'',
      PRBy:'',
      Status:'',
      FAppby:'',
      value: 'first',

      radiovalues: [
        {
            label: 'Approve',
            value: "Approve",
            color:'#2452b2'
        },
        {
            label: 'ReWork',
            value: 'ReWork',
            color:'#2452b2'
        }
    ],
   // selectedButton:'',
   isVisible: false,
    DSNO:'',
    DITYPE:'',
    DICODE:'',
    DREQQTY:'',
    DBUOM:'',
    DRPUOM:'',
    DTOTWGT:'',
    DTOTVAL:'',
    DIMEMO:'',
    DADATE:'',
    DDESC:'',
    DMATERIAL:'',
    DLENGTH:'',
    DCOMMENT:'',
    Comment:'',
    RComment:'',
    dataRESULT:'',
    passingdata:[],
    DUNWGT:'',
    passingdataarray:[]
    };

}
onPress = radiovalues => this.setState({ radiovalues});

login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
      this.props.navigation.navigate('LoginActivity');} },
    ],
    {cancelable: false},
  );
 
}


DOCUMENT(){


  this.props.navigation.navigate('DocumentActivity',{
    UserID:this.state.UserID,
    DocType:"PR",
    Param1:this.state.PRNO,
    Param2:'0',
});

}

oncommentsumbit(){
  let dataSource=this.state.dataSource
  console.log(this.state.dataSource[ID].N)
  dataSource[ID].N=this.state.DCOMMENT
  console.log(this.state.dataSource[ID].N)
  this.setState({dataSource:dataSource},()=>{this.modelopen(!this.state.isVisible)})
}
listitempress(index) {
ID=index

const{A,B,C,D,E,F,G,H,I,J,K,L,M}=this.state.dataSource[ID]

this.setState({DSNO:A,DITYPE:B,DICODE:C,DREQQTY:D,DUNWGT:L,
  DBUOM:E,DRPUOM:F,DTOTWGT:G,DTOTVAL:H,DIMEMO:I,DADATE:J,DDESC:K,DCOMMENT:M},()=>{this.modelopen(true)})

}
modelopen(visible){
  this.setState({isVisible: visible});
}

onSave(){
  switch (selectedButton) {
    case "Approve":
        AppStatus = "A";
        break;
    case "ReWork":
        AppStatus = "W";
        break;
}

if(AppStatus!=="A"){
  if(this.state.Comment.length === 0) {
    alert("Please Enter Comment")
  }
}
this.onInsert();
}
onStatus(){
  this.props.navigation.navigate('PRStatusActivity',{UserID:this.state.USER,PRNo:this.state.PRNO});
}
onInsert(){
this.setState({isLoading:true})



for(i=0;i< this.state.dataSource.length ;i++){
  const{A,M}=this.state.dataSource[i]
  this.state.passingdataarray.push({sno:A,
    rwcmt:M}
  )
}

this.onpass();
}
onpass(){

  let url=''
  if(AppStatus==='A'){
   url='/setPRAppGen'
  }else if(AppStatus==='R'){
    url='/setPRRejGen'
  }
  axios({
    method: 'post',
    url:ip+url,
    headers: {'currentToken':tokken}, 
    data: {
      PR:{"prno":this.state.PRNO,
      "userid":this.state.USER,
      "comments":this.state.Comment,
      "status":AppStatus,
      "seqno":this.state.SEQNO},
       Items:this.state.passingdataarray//q,
    }
  }).then(response=>{if(response.status===200){
    this.setState({isLoading:false},()=>{
      this.refs.toast.showBottom('Success')

      this.props.navigation.goBack();
      
    })
  }else{
    this.refs.toast.showBottom('Failed')
  }})
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
}
componentDidMount(){
  console.disableYellowBox = true;

  this.props.navigation.setParams({
    handlelogin: this.login.bind(this)
    });

    this.setState({
      USER:this.props.navigation.getParam('UserID', ''),
      PRNO:this.props.navigation.getParam('PRNo', ''),
      SEQNO:this.props.navigation.getParam('SeqNo', '')},()=>{this.getPRListProDetail();})
}
approve(){
    alert(this.state.Approve)
    this.setState({Approve:!this.state.Approve})
}
rework(){
    this.setState({Rework:!this.state.Rework})
}
getPRListProDetail(){
    const config = {
        headers: {   
        'currentToken':tokken,
      },
        params: {
            prno:this.state.PRNO,
        }
        
      };
    
      this.setState({isLoading:true})
      axios.get(ip+'/getPRListProDetail', config)
      .then(response => this.setState({ data:response.data},() => {if(response.status==200){
        this.getPRListProItem()}}))
        .catch(err => 
          {
            this.setState({
              isLoading:false
            },()=>{
             let error=err
             
             this.refs.toast.showBottom(error.toString())
      
             setTimeout(
              () => { 
                this.props.navigation.goBack();
               },
              2000
            )
      
            })
          }
          );
}
getPRListProItem(){
    const config = {
        headers: {   
        'currentToken':tokken,
      },
        params: {
            prno: this.state.PRNO,
        }
        
      };

  axios.get(ip+'/getPRListGenItem', config)
    .then(response => this.setState({dataSource:response.data},() => {if(response.status==200){
      const {A,B,C,D,E,F,G,H,I,J} = this.state.data;
      this.setState({PRType:A,PRDate:B,ReqDate:C,Pid:D,Notes:E,BAmt:F,Cur:G,PRBy:H,Status:I,FAppby:J});
      this.setState({isLoading:false}); }}))
      .catch(err => 
        {
          this.setState({
            isLoading:false
          },()=>{
           let error=err
           
           this.refs.toast.showBottom(error.toString())
    
           setTimeout(
            () => { 
              this.props.navigation.goBack();
             },
            2000
          )
    
          })
        }
        );
}
  render() {
    selectedButton = this.state.radiovalues.find(e => e.selected == true);
    selectedButton = selectedButton ? selectedButton.value : this.state.radiovalues[0].label;    
 
    if (this.state.isLoading) {
      return (
        <Modal
        transparent={false}
        supportedOrientations={['portrait', 'landscape']}
        visible={this.state.isLoading}
        >
         <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
          style={{width: 300, height: 200}}
          source={require('./src/gears.gif')}  />
          </View>     
        </Modal>
      )
  }
    return (
    <ScrollView>
     <View style={{flex: 1,paddingTop:'2%',width:'97%',alignSelf:'center',
   }}>
       <Grid style={{backgroundColor:colorprimary,borderRadius:4,padding:5}}>
       <Row>
       <Col>
       <Text style={styles.textContent}>Purchase Request Details(General)</Text>
       </Col>
       </Row>
       </Grid>
    </View> 


<Card style={{width:'97%',alignSelf:'center'}}>
<CardItem style={{alignItems:'flex-start',width:'100%',flexWrap:'wrap'}}>
<Grid>
  <Row style={{paddingTop:4}}>
          <Col style={{alignItems:'flex-start',width:'20%'}}>
          <Text style={{color:'#2452b2',fontSize:13,fontFamily:'Bold'}}>PR No -</Text>
          </Col>
          <Col style={{alignItems:'flex-start',width:'30%'}}>
          <Text style={{fontSize:13,alignSelf:'flex-start',fontFamily:'Regular'}}>{this.state.PRNO}</Text>
          </Col>
          <Col style={{alignItems:'flex-start',width:'20%'}}>
          <Text style={{color:'#2452b2',fontSize:13,fontFamily:'Bold'}}>PR Date -</Text>
          </Col>
          <Col style={{alignItems:'flex-start',width:'30%'}}>
          <Text style={{fontSize:13,alignSelf:'flex-start',fontFamily:'Regular'}}>{this.state.PRDate}</Text>
          </Col>
  </Row>
  <View style={{borderBottomColor:'#A9A9A9',borderBottomWidth: 1,height:5,width:'100%',alignSelf:'center'}}/>
  <Row style={{paddingTop:6}}>
          <Col style={{alignItems:'flex-start',width:'10%'}}>
          <Text style={{alignItems:'flex-start',fontSize:12,fontFamily:'Bold',color:'#2452b2'}}>PID -</Text>
          </Col>
          <Col style={{alignItems:'flex-start',width:'8%'}}>
          <Text style={{alignself:'flex-start',fontSize:12,fontFamily:'Regular'}}>{this.state.Pid}</Text>
          </Col>
          <Col style={{alignItems:'flex-start',width:'18%'}}>
          <Text style={{alignItems:'flex-start',fontSize:12,fontFamily:'Bold',color:'#2452b2'}}>PR Type</Text>
          </Col>
          <Col style={{alignItems:'flex-start',width:'24%'}}>
          <Text style={{alignSelf:'flex-start',fontSize:12,fontFamily:'Regular'}}>{this.state.PRType}</Text>
          </Col>
          <Col style={{alignItems:'flex-start',width:'20%'}}>
          <Text style={{alignItems:'flex-start',fontSize:12,fontFamily:'Bold',color:'#2452b2'}}>PR Status</Text>
          </Col>
          <Col style={{alignItems:'flex-start',width:'20%'}}>
          <Text style={{alignItems:'flex-start',fontSize:12,fontFamily:'Regular'}}>{this.state.Status}</Text>
          </Col>
  </Row>
  <View style={{borderBottomColor:'#A9A9A9',borderBottomWidth: 1,height:5,width:'100%',alignSelf:'center'}}/>
  <Row style={{paddingTop:6}}>
          <Col style={{alignItems:'flex-start',width:'20%'}}>
          <Text style={{alignItems:'flex-start',fontSize:13,fontFamily:'Bold',color:'#2452b2'}}>PR Notes</Text>
          </Col>
          <Col style={{alignItems:'flex-start',width:'80%'}}>
          <Text style={{alignItems:'flex-start',fontSize:13,fontFamily:'Italic'}}>{this.state.Notes}</Text>
          </Col>
  </Row>
  <View style={{borderBottomColor:'#A9A9A9',borderBottomWidth: 1,height:5,width:'100%',alignSelf:'center'}}/>
  <Row style={{paddingTop:6}}>
          <Col style={{alignItems:'flex-start',width:'40%'}}>
          <Text style={{alignItems:'flex-start',fontSize:13,fontFamily:'Bold',color:'#2452b2'}}>PR by</Text>
          </Col>
          <Col style={{alignItems:'flex-start',width:'60%'}}>
          <Text style={{alignItems:'flex-start',fontSize:12,fontFamily:'Regular'}}>{this.state.PRBy}</Text>
          </Col>
  </Row>
  <Row style={{paddingTop:6}}>
          <Col style={{alignItems:'flex-start',width:'40%'}}>
          <Text style={{alignItems:'flex-start',fontSize:13,fontFamily:'Bold',color:'#2452b2'}}>Required Date</Text>
          </Col>
          <Col style={{alignItems:'flex-start',width:'60%'}}>
          <Text style={{alignItems:'flex-start',fontSize:12,fontFamily:'Regular'}}>{this.state.ReqDate}</Text>
          </Col>
  </Row>
  <Row style={{paddingTop:6}}>
          <Col style={{alignItems:'flex-start',width:'40%'}}>
          <Text style={{alignItems:'flex-start',fontSize:13,fontFamily:'Bold',color:'#2452b2'}}>Budget Amount</Text>
          </Col>
          <Col style={{alignItems:'flex-start',width:'60%'}}>
          <Text style={{alignItems:'flex-start',fontSize:12,fontFamily:'Regular'}}>{this.state.BAmt+" "+this.state.Cur}</Text>
          </Col>
  </Row>
  <Row style={{paddingTop:6}}>
          <Col style={{alignItems:'flex-start',width:'40%'}}>
          <Text style={{alignItems:'flex-start',fontSize:13,fontFamily:'Bold',color:'#2452b2'}}>First Approved By</Text>
          </Col>
          <Col style={{alignItems:'flex-start',width:'60%'}}>
          <Text style={{alignItems:'flex-start',fontSize:12,fontFamily:'Regular'}}>{this.state.FAppby}</Text>
          </Col>
  </Row>
</Grid>
</CardItem>
</Card>

<View style={styles.Head}>
            <Grid style={{width:'97%',alignSelf:'center',backgroundColor:'#2452b2',padding:5,borderRadius:4}}>
              <Col style={{alignItems:'flex-start',width:'20%',}}>
              <Text style={{color:'#fff',fontSize:13,fontFamily:'Regular'}}>SNo</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{color:'#fff',fontSize:13,fontFamily:'Regular'}}>Item Type</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={{color:'#fff',fontSize:13,fontFamily:'Regular'}}>Item Code</Text>
              </Col> 
            </Grid>  
</View> 
   <FlatList
       data={ this.state.dataSource }
       initialNumToRender={this.state.dataSource.length}
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
         
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
                  paddingLeft:5,paddingRight:5,paddingTop:5,paddingBottom:5}}>
            <Grid onPress={()=>this.listitempress(index)}>
            <Row>
              <Col style={{alignItems:'flex-start',width:'20%'}}>
              <Text style={{fontSize:13,fontFamily:'Regular'}}>{item.A}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,fontFamily:'Regular'}}>{item.B}</Text>
              </Col> 
               <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={{fontSize:13,fontFamily:'Regular'}}>{item.C}</Text>
              </Col> 
            </Row>
            <View style={{borderBottomColor:'#A9A9A9',borderBottomWidth: 1,height:5,width:'100%',alignSelf:'center'}}/>
        <Row style={{paddingTop:'1%'}}>
        <Col style={{alignItems:'flex-start',width:'100%'}}>
              <Text style={{fontSize:13,fontFamily:'Regular'}}>{item.K}</Text>
        </Col> 
        </Row>
            </Grid>  
             </CardItem>
           </Card>
        }

       keyExtractor={(item, index) => index.toString()} 
      />
      <Card style={{width:'97%',alignSelf:'center'}}>
          <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
          <Item>
              <Input placeholder="Approval Comments"
                value={this.state.Comment}
                style={{fontFamily:'Regular'}}
                onChangeText={val => this.setState({ Comment: val })}
               />
         </Item>
          </CardItem>
        <CardItem style={{paddingLeft:60}}>
        {/* <Text style={styles.valueText}>Value = {selectedButton} </Text> */}
      <RadioGroup  flexDirection='row' radioButtons={this.state.radiovalues} onPress={this.onPress} />
     </CardItem>
      </Card>


      <View style={{flexDirection:"row",alignItems:'center',paddingTop:20}}>
      <View style={styles.button_1}>
      <Button
            title="STATUS"
            containerStyle={{borderRadius:4}}
            titleStyle={{fontFamily:'Bold',fontSize:13}}
            onPress={this.onStatus.bind(this)}

            />
      </View>

      <View style={styles.button_1}>
      <Button
            title="DOCUMENT"
            containerStyle={{borderRadius:4}}
            titleStyle={{fontFamily:'Bold',fontSize:13}}
            onPress={this.DOCUMENT.bind(this)}

            />
      </View>

      <View style={styles.button_1}>
      <Button
            title="SUBMIT"
            containerStyle={{borderRadius:4}}
            titleStyle={{fontFamily:'Bold',fontSize:13}}
            onPress={this.onSave.bind(this)}
          />
      </View>
      </View>
     
      <Overlay
      overlayStyle={{ width:"90%" , height:"70%"}}
       animationType='slide'
       isVisible={this.state.isVisible}
       onBackdropPress={() => this.setState({ isVisible: false })}>

<View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle}>SNo</Text>
          </Col> 
          <Col>
          <Text style={{fontSize:13,fontFamily:'Bold'}}>{this.state.DSNO}</Text>
          </Col> 
        </Grid>
      </View>
      <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle}>Item Type</Text>
          </Col> 
          <Col>
          <Text style={{fontSize:13,fontFamily:'Bold'}}>{this.state.DITYPE}</Text>
          </Col> 
        </Grid>
      </View>
      <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle}>Item Code</Text>
          </Col> 
          <Col>
          <Text style={{fontSize:13,fontFamily:'Bold'}}>{this.state.DICODE}</Text>
          </Col> 
        </Grid>
      </View>
      <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle}>Item Description</Text>
          </Col> 
          <Col>
          <Text style={{fontSize:13,fontFamily:'Bold'}}>{this.state.DDESC}</Text>
          </Col> 
        </Grid>
      </View>
      <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle}>Required Quentity</Text>
          </Col> 
          <Col>
          <Text style={{fontSize:13,fontFamily:'Bold'}}>{this.state.DREQQTY}</Text>
          </Col> 
        </Grid>
      </View>

      <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle}>Unit Weight</Text>
          </Col> 
          <Col>
          <Text style={{fontSize:13,fontFamily:'Bold'}}>{this.state.DUNWGT}</Text>
          </Col> 
        </Grid>
      </View>

      <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle}>UOM</Text>
          </Col> 
          <Col>
          <Text style={{fontSize:13,fontFamily:'Bold'}}>{this.state.DBUOM}</Text>
          </Col> 
        </Grid>
      </View>
      <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle}>Rate Per UOM</Text>
          </Col> 
          <Col>
          <Text style={{fontSize:13,fontFamily:'Bold'}}>{this.state.DRPUOM}</Text>
          </Col> 
        </Grid>
      </View>
      <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle}>Budget Value</Text>
          </Col> 
          <Col>
          <Text style={{fontSize:13,fontFamily:'Bold'}}>{this.state.DTOTVAL}</Text>
          </Col> 
        </Grid>
      </View>
      <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle}>Total Weight</Text>
          </Col> 
          <Col>
          <Text style={{fontSize:13,fontFamily:'Bold'}}>{this.state.DTOTWGT}</Text>
          </Col> 
        </Grid>
      </View>
      <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle}>Item Memo</Text>
          </Col> 
          <Col>
          <Text style={{fontSize:13,fontFamily:'Bold'}}>{this.state.DIMEMO}</Text>
          </Col> 
        </Grid>
      </View>
      <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle}>Amendment Date</Text>
          </Col> 
          <Col>
          <Text style={{fontSize:13,fontFamily:'Bold'}}>{this.state.DADATE}</Text>
          </Col> 
        </Grid>
      </View>


      <Item style={{paddingBottom:5}}>
              <Input placeholder="Reject/Rework Comments"
                value={this.state.DCOMMENT}
                TextStyle={{fontFamily:'Regular'}}
                onChangeText={val => this.setState({ DCOMMENT: val})}
               />
      </Item>

      <View style={{flexDirection:"row",alignItems:'center',paddingTop:10}}>
      <View style={styles.button_2}>
      <Button
            title="SUBMIT"
            containerStyle={{borderRadius:4}}
            titleStyle={{fontFamily:'Bold'}}
            onPress={this.oncommentsumbit.bind(this)}
            />
      </View>
      <View style={styles.button_2}>
      <Button
            title="CANCEL"
            containerStyle={{borderRadius:4}}
            titleStyle={{fontFamily:'Bold'}}
            onPress={() => { this.modelopen(!this.state.isVisible)} } 
          />
      </View>
      </View>
      </Overlay>
       
  <Toast ref="toast"/>
   </ScrollView>
        )
      }
 };
 const styles = StyleSheet.create({
    textContent: {
        fontSize: 13,
        alignItems:'center',
        color: '#fff',
       fontFamily:'Bold'
      },
      Head: {
        flex: 1,
        paddingTop:'1%',
        alignSelf:'center',
        width:'100%'
      },
      text: {
        padding: 15,
        width:100,
        alignSelf:'center',
        color:'#fff',
        backgroundColor:"#1ca0ff"
     },
 
     Alert_Main_View:{
      alignItems: 'center',
      justifyContent: 'center',
      height:300,
      width: '90%',
      borderWidth: 1,
      borderColor: '#fff',
      borderRadius:7,
     
    },
     
      buttonStyle: {
          
          width: '50%',
          height: '100%',
          justifyContent: 'center',
          alignItems: 'center'
       
      },
         
      TextStyle:{
          color:'#fff',
          textAlign:'center',
          fontSize: 22,
          marginTop: -5
      },
      tittle:{
        color:'#36428a',
        fontSize:13,
       fontFamily:'Bold'
       },
       C:{
        alignItems:"flex-start",
        width:150
       },
       b: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
      },
      MainContainer :{
        flex:1,
        justifyContent: 'center',
        alignItems: 'center',
     
       },
       modal: {  
        flex: 1,
        paddingBottom:30
         }, 

         button_2:{
          width:'45%',
          height:50,
          paddingLeft:'10%',
         
        },

       button_1:{
          width:'33%',
          height:50,
          paddingLeft:6,
          paddingRight:6
        },
   
  });
  

import React,{ Component }  from 'react';
import {TextInput,ScrollView,Modal,StyleSheet,Text,View,Image,FlatList,TouchableOpacity,YellowBox,
  Alert,Dimensions,ImageBackground,SectionList} from 'react-native';
import { Col, Grid, Row } from 'react-native-easy-grid';
import { Divider,Overlay } from 'react-native-elements';
import { NavigationActions, StackActions } from 'react-navigation';
import axios from 'axios';
import { CustomButton } from './custom-button.js';
import Toast from 'react-native-whc-toast'
import {Card,CardItem} from 'native-base';
import { StatusBar } from 'expo-status-bar';
import {logouttask} from './class/logout';
import strings from './res/strings'
import color from './res/colors'

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);

const blue=color.values.Colors.blue;
const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const black=color.values.Colors.black;
const dark=color.values.Colors.colorPrimaryDark;
const primarylite=color.values.Colors.primarylite

var  Menudata=[
    {
    "A": "Profile",
    "B": "ic_profile",
    "C": "CustomerRegisterProfileActivity",
    "D": "M"
    },  
    {
      "A": "About",
      "B": "ic_about",
      "C": "AboutUsActivity",
      "D": "M"
    }, 
    {
        "A": "Az Web",
        "B": "ic_web",
        "C": "AztraconwebActivity",
        "D": "M"
    },   
    {
      "A": "ManPower Request",
      "B": "ic_about",
      "C": "ManPowerRequestActivity",
      "D": "M"
  },  
  {
    "A": "ManPower Status",
    "B": "ic_about",
    "C": "ManPowerRequestListActivity",
    "D": "M"
}, 
]

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});


 export default class HomeRegister extends React.Component {
  static navigationOptions = ({ navigation }) => ({ 
    title: "Aztracon",
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center',resizeMode:'contain'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,   
      handlelogin:'',
      dataSource:[],
      UserID:'',
      data: "",
      username:'',
      infocontent:'',
      isVisible:false,
    };
}
login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
        this.props.navigation.dispatch(resetAction);
      } },
    ],
    {cancelable: false},
  );
 
}

changepass=()=>
{
  this.props.navigation.navigate('ChangePasswordActivity',{UserID:this.state.UserID,From:'R'});
}
profile = () =>
{
  this.gotonextpage(0);
}

gotonextpage=(index)=>{
  const id=index

   const {C}=Menudata[id]
    
    if(C=='undefined' || C==null || C.length==0){
      this.refs.toast.showBottom("This Feature Update Soon")
    }else{
      console.log(C)
      this.props.navigation.navigate(C,{
        UserID:this.state.UserID,
        RCenter:this.state.RCenter,
        Department:this.state.Department,
        Name:this.state.username,
        Designation:this.state.Designation
    });
 
    }

}

getimage=(imagename)=>{

    switch (imagename) {
       case 'ic_profile':
            return require('./src/ic_profile.png');
       case 'ic_about':
              return require('./src/ic_about.png');  
       case 'ic_web':       
            return require('./src/ic_web.png');  
        default:
            return require('./src/ic_about.png');  
    }

}

getWorkCat=()=>{
  const config = {
    headers: {   
    'currentToken':tokken,
  },
  };
  this.setState({isLoading:true});
axios.get(ip+'/getManCategory', config)
.then(response => this.setState({data:response.data},() => {if(response.status==200){
 this.setState({isLoading:false,isVisible:!this.state.isVisible});
}
}))
.catch(err => 
{
  this.setState({
    isLoading:false
  },()=>{
   let error=err
   
   this.refs.toast.showBottom(error.toString())

   setTimeout(
    () => { 
      this.props.navigation.goBack();
     },
    2000
  )

  })
}
);

}
CLose=()=>{
  this.setState({
    isVisible:!this.state.isVisible
  })
}

renderItem(item) {    
  const {SNo,Code,Description} = item.item;
  return (
        <Card style={{width:'97%',alignSelf:'center'}}>
           <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
           <Grid>
           <Row>
           <Col style={{alignItems:'flex-start',width:'20%'}}>
           <Text style={{fontSize:13,color:black,fontWeight:'bold'}}>{SNo}</Text>
           </Col>
           <Col style={{alignItems:'flex-start',width:'80%'}}>
           <Text style={{fontSize:13,color:black,fontWeight:'bold'}}>{Description}</Text>
           </Col>
           </Row>
           </Grid>   
           </CardItem>
           </Card>
  );

}

componentDidMount(){

  YellowBox.ignoreWarnings([
    'VirtualizedLists should never be nested', // TODO: Remove when fixed
  ])
  
  console.disableYellowBox = true;

  this.props.navigation.setParams({
    handlelogin: this.login.bind(this)
    });
    
  this.setState({
  username:this.props.navigation.getParam('username', ''),
  UserID:this.props.navigation.getParam('USER', ''),
  infocontent:"hi"
  })

}
  render() {
    if (this.state.isLoading) {
      return (
        <Modal
         transparent={false}
        visible={this.state.isLoading}
        >
         <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
          useNativeDriver={true}
          style={{width: 300, height: 200}}
          source={require('./src/gears.gif')}  />
          </View>     
        </Modal>
      )
  }
    return (
<ImageBackground source={require('./src/aztracon_bg.jpg')} style={{width: '100%', height: '100%'}}>

<ScrollView style={{height:'22%'}}>

<Card style={{alignSelf:'center',width:'96%'}}> 
    <CardItem style={{alignSelf:'center',width:'96%',alignItems:'flex-start'}}>
    <View style={{flexDirection: 'row'}}>
    <View style={styles.tcenter}>
      <TextInput
          value={this.state.username}
          onChangeText={(username) => this.setState({ username })}
          placeholder={'Username'}
          style={{color:"#2452b2",fontWeight:'bold',fontSize:13}}
          editable={false} selectTextOnFocus={false}
        />
        <TextInput
          value={this.state.UserID}
          onChangeText={(UserID) => this.setState({ UserID })}
          placeholder={'UserID'}
          style={{color:"#2452b2",fontWeight:'bold',fontSize:13}}
          editable={false} selectTextOnFocus={false}
        />
      </View>
      <TouchableOpacity activeOpacity = { .5 } onPress={ this.profile }>
      <Image
          style={styles.image}
          source={require('./src/ic_prof.png')} />
      </TouchableOpacity>

      <TouchableOpacity activeOpacity = { .5 } onPress={ this.changepass }>
      <Image
          style={styles.image}
          source={require('./src/ic_change_pass.png')} />
      </TouchableOpacity>
      </View>
    </CardItem>
  </Card>

  <Grid style={{paddingTop:'2%'}}>
  <Row style={{backgroundColor:colorprimary,padding:5,width:'97%',alignSelf:'center',borderRadius:4}}>
  <Text style={styles.titleText}>Manpower Support Services</Text>
  </Row>
  </Grid>
 <Toast ref="toast"
        />
 <StatusBar style="light" />
</ScrollView>
<ScrollView style={{height:'78%'}}>



<Overlay
       overlayStyle={{ width:"90%" , height:"90%"}}
       borderRadius={15}
       overlayBackgroundColor={white}
       animationType='slide'
       isVisible={this.state.isVisible}
       onBackdropPress={() => this.setState({ isVisible: false })}>
        <ScrollView style={{height:'8%'}}>
        <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress = {() =>
           {  
            this.setState({ isVisible:!this.state.isVisible})
           }}>
          <Image
         source={require('./src/back.png')}
         style={{height:50,width:50}}         
         />
         <Text style={{color:'#fff',textDecorationStyle:'solid'}}>WorkCategory List</Text>
         </TouchableOpacity>
        </ScrollView>
       <ScrollView style={{height:'92%'}}>

       <SectionList
                  sections={this.state.data}
                  style={{paddingTop:2}}
                  initialNumToRender={this.state.data.length}
                  renderItem={this.renderItem.bind(this)}
                  renderSectionHeader={({ section }) => 
                  
                   <View  style={{ flex: 1,paddingTop:5,paddingBottom:5}}>
                   <Grid style={{backgroundColor:blue,padding:5,width:"97%",alignSelf:'center'}}>
                   <Row>
                   <Col style={{alignItems:'flex-start',width:'100%'}}>
                   <Text style={styles.sectionHeader}>{section.CategoryName}</Text>
                   </Col> 
                   </Row>
                   </Grid>
                   </View>
                  
               }
                  keyExtractor={(item, index) => index}
              />

       </ScrollView>
      </Overlay>


<Grid style={{alignItems:'center',alignSelf:'center',paddingTop:'2%',width:'96%'}}>

<Row>

<Text style={{fontSize:15,fontWeight:'bold',color:dark}}>
Alzamil Metal Works Factory
<Text style={{fontSize:14,color:black,}}> success is attributed to the quality of 
its manpower and highly trained technical 
staff who are certified in their respective fields.</Text>
</Text>

</Row>

<Row style={{paddingTop:'2%'}}>
<Text style={{fontSize:14}}>
In-house and external training is part of the program set for all employees 
with an aim for continues improvement as well as quality and efficiency enhancement.
</Text>
</Row>

<Row style={{paddingTop:'2%'}}>
<Text style={{fontSize:14}}>
While undertaking multiple projects of different magnitudes and skill requirements, 
AZMWF manpower accumulated enormous experience and exposure to the most complex 
jobs with the highest standards serving clients such as:
</Text>
</Row>


<Row style={{paddingTop:'2%'}}>

<Col style={{alignItems:'flex-start',width:'60%',alignSelf:'center'}}>
<Row style={{paddingTop:'1%'}}>
<Text style={styles.textlist}>
Aramco and its affiliates
</Text>
</Row>
<Row style={{paddingTop:'1%'}}>
<Text style={styles.textlist}>
Sabic and its affiliates
</Text>
</Row>
<Row style={{paddingTop:'1%'}}>
<Text style={styles.textlist}>
SEC
</Text>
</Row>
<Row style={{paddingTop:'1%'}}>
<Text style={styles.textlist}>
SWCC
</Text>
</Row>
<Row style={{paddingTop:'1%'}}>
<Text style={styles.textlist}>
Maaden
</Text>
</Row>
<Row style={{paddingTop:'1%'}}>
<Text style={styles.textlist}>
NWC
</Text>
</Row>
<Row style={{paddingTop:'1%'}}>
<Text style={styles.textlist}>
Other Private Industries
</Text>
</Row>
</Col>

</Row>

<Row style={{paddingTop:'2%'}}>
<Text style={{fontSize:15,fontWeight:'bold'}}>
AZMWF extended its technical support services to external clients and EPC contractors.
</Text>
</Row>

<Row style={{paddingTop:'2%'}}>
<Text style={{fontSize:14}}>
The following categories of manpower may be available depending on the time of inquiry.
</Text>
</Row>

<Row style={{paddingTop:'2%',paddingBottom:'3%'}}>
<Col style={{width:'30%',alignSelf:'flex-end'}}>
</Col>
<Col style={{width:'40%',alignSelf:'center'}}>
<CustomButton
                 title="Click To View Category"
                 onPress={() => this.getWorkCat()}
                 style={{ backgroundColor:dark,height:40}}
                 textStyle={{ fontSize:10}}/>
</Col>
<Col style={{width:'30%',alignSelf:'flex-end'}}>
</Col>
</Row>

<Row style={{backgroundColor:colorprimary,padding:5,width:'100%',
 alignSelf:'center',borderRadius:4}}>
  <Text style={styles.titleText}>Manpower Request & Status</Text>
</Row>

<Row style={{paddingTop:'2%',paddingBottom:'3%'}}>
  <Col style={{width:'10%',alignSelf:'center'}}>
  </Col>
  <Col style={{width:'30%',alignSelf:'center'}}>
  <TouchableOpacity activeOpacity = { .5 } onPress={() => this.gotonextpage(3)}>
           <Card  style={{borderRadius: 10,backgroundColor:colorprimary,padding:5}}> 
         
            <Image  style={styles.imagebuttonicon}
            source={require('./src/manpower.png')} />

           <Text style={{alignSelf:'center', flexWrap: 'wrap',
           fontSize:12,fontWeight:'bold',color:white}}>{'Request'}</Text>

            </Card> 
   </TouchableOpacity>
  </Col>
  <Col style={{width:'10%',alignSelf:'center'}}>
  </Col>
  <Col style={{width:'10%',alignSelf:'center'}}>
  </Col>
  <Col style={{width:'30%',alignSelf:'center'}}>
  <TouchableOpacity activeOpacity = { .5 } onPress={() => this.gotonextpage(4)}>
           <Card  style={{borderRadius: 10,backgroundColor:colorprimary,padding:5}}> 
         
            <Image  style={styles.imagebuttonicon}
            source={require('./src/req_status.png')} />

           <Text style={{alignSelf:'center', flexWrap: 'wrap',
           fontSize:12,fontWeight:'bold',color:white}}>{'Status'}</Text>

            </Card> 
   </TouchableOpacity>

  </Col>
  <Col style={{width:'10%',alignSelf:'center'}}>
  </Col>
</Row>

<Row style={{backgroundColor:colorprimary,padding:5,width:'100%',
 alignSelf:'center',borderRadius:4}}>
  <Text style={styles.titleText}>Contact us</Text>
</Row>

<Row style={{paddingTop:'2%',paddingBottom:'2%'}}>
  <Col style={{width:'70%'}}>
   <Row>
   <Text style={{fontSize:13,fontWeight:'bold',color:dark}}>{'Email :'+'\n'+'Proposal@alzamilmetal.com'+
   '\n'+'Aztracon@alzamilmetal.com'}</Text>
   </Row>
  </Col>
  <Col style={{width:'30%',alignItems:'flex-end'}}>
  <Row>
<TouchableOpacity activeOpacity = { .5 } onPress={() => this.gotonextpage(2)}>
          
            <Image  style={styles.imagebuttonweb}
            source={this.getimage('ic_web')} />
        
</TouchableOpacity>
</Row>
  </Col>
</Row>


</Grid>

</ScrollView>
</ImageBackground>
        )
      }
 };
 const styles = StyleSheet.create({
  titleText: {
    flex:1,
    flexWrap:'wrap',
    color:white,
    fontSize:14,
    fontWeight:'bold'
  },
  imagebutton: {
    width:60,
    height: 85,
    marginTop:3,
    resizeMode: 'contain' ,
   justifyContent:"center",
   alignItems:"center",
   alignSelf:'center'
  },
  imagebuttonicon:{
    width:40,
    height: 40,
    resizeMode: 'contain' ,
    justifyContent:"center",
    alignItems:"center",
    alignSelf:'center'
  },
  imagebuttonweb: {
  width:50,
  height: 50,
  resizeMode: 'contain' ,
  justifyContent:"center",
  alignItems:"center",
  alignSelf:'center'
  },
  container: {
    flex:1,
    alignItems: 'center',
  },
  welcome: {
    fontSize: 15,
    textAlign: 'center',
    margin: 10,
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
  },
  imageStyle:{
    width: screenWidth, 
    height: screenHeight, 
    justifyContent: 'center',
    alignItems: 'center'
   },
   
   tcenter: {
    flex: 1,
    justifyContent:'flex-start',
    flexDirection: 'column',
    paddingLeft:10,
  },
  image: {
    width: 40,
    height: 40,
    marginTop:5,
    marginRight:10,
  },

  //

  headerback: {
    flexDirection: 'row',
    alignItems:'center',
    backgroundColor: colorprimary,
    borderWidth: 0.5,
    borderColor:white,
    height: 40,
    width:'100%',
    borderRadius: 5,
  },

  textlist:{
  fontSize:14,
  textShadowColor: 'rgba(0, 0, 0, 0.75)',
  textShadowOffset: {width: -1, height: 1},
  textShadowRadius: 10
  },
  sectionHeader: {
    alignSelf:'flex-start',
    fontSize: 13,
    fontWeight: 'bold',
    color:'#fff',
},
itemView: {
  flex: 1,
  borderBottomWidth: 0.5,
  borderColor: '#cdcdcd',
  borderStyle: 'solid',
  paddingHorizontal: 12,
  flexDirection: 'row',
  paddingTop:2
},
textContent:{
color:white,
fontSize:12,
fontWeight:'bold'
},
titleText: {
flex:1,
flexWrap:'wrap',
color:white,
fontSize:12,
padding:5
},
  });
  
  
  
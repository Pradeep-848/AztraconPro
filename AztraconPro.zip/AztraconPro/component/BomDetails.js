import React,{ Component }  from 'react';
import {ScrollView,StyleSheet,Text,View,Dimensions,Modal,Image,TouchableOpacity,Alert} from 'react-native';
import { Col, Grid, Row } from 'react-native-easy-grid';
import { Divider } from 'react-native-elements';
import {logouttask} from './class/logout';
import axios from 'axios';
import Toast from 'react-native-whc-toast'
import { NavigationActions, StackActions } from 'react-navigation';
import strings from './res/strings'
import color from './res/colors'

const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const colorprimary=color.values.Colors.colorPrimary;
const grey=color.values.Colors.greydark;
const dark=color.values.Colors.colorPrimaryDark;
const white=color.values.Colors.white;
const black=color.values.Colors.black;
const red=color.values.Colors.red;
const lightblue=color.values.Colors.lightblue;
const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

 export default class BomDetails extends React.Component {
  static navigationOptions = ({ navigation }) => ({ 
  
    title: "Bill Of Material",
    color:white,
    headerStyle: {
      backgroundColor: colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
      handlelogin:'',
      isLoading: false, 
      dataSource:'',
      icode:'',type:'',material:'',thk:'',wid:'',len:'',dia:'',qty:'',uom:'',rstatus:'',pr:'',po:'',wh:'',qc:'',
      pid:'',UserID:'',pdesc:'',cid:'',cname:''
    };
}
login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
        this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}
getboomdetails=()=>{
  const config = {
    headers: {   
    'currentToken': tokken,
  },
    params: {
        icode:this.state.icode,
    }
    
  };

  this.setState({isLoading:true})
  axios.get(ip+'/getBomDetails', config)
  .then(response => this.setState({ dataSource:response.data},() => {if(response.status==200){

    const{Type,ItemCode,Material,Thk,Wid,Dia,Len,Qty,UOM,BStatus,PR,PO,WH,QC}=this.state.dataSource
       this.setState({
        type:Type,
        icode:ItemCode,
        material:Material,
        thk:Thk,
        wid:Wid,
        dia:Dia,
        len:Len,
        qty:Qty,
        uom:UOM,
        rstatus:BStatus,
        pr:PR,
        po:PO,
        wh:WH,
        qc:QC,
        isLoading:false    
        })
}}))
.catch(err => 
  {
    this.setState({
      isLoading:false
    },()=>{
     let error=err
     
     this.refs.toast.showBottom(error.toString())

     setTimeout(
      () => { 
        this.props.navigation.goBack();
       },
      2000
    )

    })
  }
  );
}


componentDidMount(){
   console.disableYellowBox = true;

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
  
this.setState({
    icode:this.props.navigation.getParam('ICode', ''),
    pid:this.props.navigation.getParam('PID', ''),
    cid:this.props.navigation.getParam('CusID', ''),
    pdesc:this.props.navigation.getParam('PDesc', ''),
    cname:this.props.navigation.getParam('CusName', ''),
    UserID:this.props.navigation.getParam('UserID', '')
},()=>{this.getboomdetails();})


}
  render() {
    if (this.state.isLoading) {
      return (
         <Modal
         transparent={false}
         supportedOrientations={['portrait', 'landscape']}
         visible={this.state.isLoading}
         >
          <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
           <Image
           style={{width: 300, height: 200}}
           source={require('./src/gears.gif')}  />
           </View>     
         </Modal>
      )
  }
    return (
<ScrollView style={{backgroundColor:lightblue}}>
<Grid style={{paddingTop:'2%'}}>
  <Row style={{backgroundColor:colorprimary,width:'97%',alignSelf:'center'}}>
  <Text style={styles.titleText}>
          {this.state.pid+" - "+this.state.pdesc}
  </Text>
   </Row>
   <Divider style={{ backgroundColor:white}} />
   <Divider style={{ backgroundColor:white}} />
   <Row style={{backgroundColor:colorprimary,width:'97%',alignSelf:'center'}}>
   <Text style={styles.titleText}>
          {this.state.cid.toString().trim()+" - "+this.state.cname}
  </Text>
  </Row> 
  <Divider style={{ backgroundColor:white}} />
  <Divider style={{ backgroundColor:white}} />
  <Row style={{backgroundColor:white}}>
  <Text style={{fontSize:18,fontFamily:'Bold',color:dark,paddingLeft:'2%',paddingTop:'2%'}}>
            Bom Details
     </Text>
  </Row>   
  <View style={{flexDirection: 'row',width:'98%',alignSelf:'center'}}>
     <View style={{backgroundColor: dark, height: 2, flex: 1, alignSelf: 'center'}} />
     <View style={{backgroundColor: dark, height: 2, flex: 1, alignSelf: 'center'}} />
   </View>
  </Grid>
  <Grid style={{paddingTop:'2%',width:'97%',alignSelf:'center'}}>
                <Row style={styles.rowpadd}>
                  <Col style={styles.headcol}>
                  <Text style={styles.tittle}>Type</Text>
                  </Col> 
                  <Col style={styles.detailcol}>
                  <Text style={{fontSize:15,fontWeight:'bold',color:grey}}>{this.state.type}</Text>
                  </Col> 
                </Row>
                <Row style={styles.rowpadd}>
                <Col style={styles.headcol}>
                  <Text style={styles.tittle}>Item Code</Text>
                  </Col> 
                  <Col style={styles.detailcol}>
                  <Text style={{fontSize:15,fontWeight:'bold',color:grey}}>{this.state.icode}</Text>
                  </Col> 
                </Row>
                <Row style={styles.rowpadd}>
                <Col style={styles.headcol}>
                  <Text style={styles.tittle}>Material</Text>
                  </Col> 
                  <Col style={styles.detailcol}>
                  <Text style={{fontSize:15,fontWeight:'bold',color:grey}}>{this.state.material}</Text>
                  </Col> 
                </Row>   
                <Row style={styles.rowpadd}>
                <Col style={styles.headcol}>
                   <Text style={styles.tittle}>Thk</Text>   
                  </Col>
                  <Col style={styles.detailcol}>
                    <Text style={{fontSize:15,fontWeight:'bold',color:grey}}>{this.state.thk}</Text>  
                  </Col>
                  </Row>
                  <Row style={styles.rowpadd}>
                  <Col style={styles.headcol}>
                     <Text style={styles.tittle}>Wid</Text> 
                  </Col>
                  <Col style={styles.detailcol}>
                     <Text style={{fontSize:15,fontWeight:'bold',color:grey}}>{this.state.wid}</Text> 
                  </Col>
                  </Row>
                  <Row style={styles.rowpadd}>
                  <Col style={styles.headcol}>
                     <Text style={styles.tittle}>Dia%</Text> 
                  </Col>
                  <Col style={styles.detailcol}>
                     <Text style={{fontSize:15,fontWeight:'bold',color:grey}}>{this.state.dia}</Text> 
                  </Col>
                  </Row>
                  <Row style={styles.rowpadd}>
                  <Col style={styles.headcol}>
                     <Text style={styles.tittle}>Length(mm)</Text> 
                  </Col>
                  <Col style={styles.detailcol}>
                     <Text style={{fontSize:15,fontWeight:'bold',color:grey}}>{this.state.len}</Text> 
                  </Col>
                  </Row>
                  <Row style={styles.rowpadd}>
                  <Col style={styles.headcol}>
                     <Text style={styles.tittle}>Qty</Text> 
                  </Col>
                  <Col style={styles.detailcol}>
                     <Text style={{fontSize:15,fontWeight:'bold',color:grey}}>{this.state.qty}</Text> 
                  </Col>
                  </Row>
                  <Row style={styles.rowpadd}>
                  <Col style={styles.headcol}>
                     <Text style={styles.tittle}>UOM</Text> 
                  </Col>
                  <Col style={styles.detailcol}>
                     <Text style={{fontSize:15,fontWeight:'bold',color:grey}}>{this.state.uom}</Text> 
                  </Col>
                  </Row>
                  <Row style={styles.rowpadd}>
                  <Col style={styles.headcol}>
                     <Text style={styles.tittle}>Status</Text> 
                  </Col>
                  <Col style={styles.detailcol}>
                     <Text style={{fontSize:15,fontWeight:'bold',color:grey}}>{this.state.rstatus}</Text> 
                  </Col>
                  </Row>
                  <View style={{flexDirection: 'row',width:'98%',alignSelf:'center',paddingTop:'2%'}}>
                  <View style={{backgroundColor: dark, height: 1.5, flex: 1, alignSelf: 'center'}} />
                  <View style={{backgroundColor: dark, height: 1.5, flex: 1, alignSelf: 'center'}} />
                  </View>
                  <Row style={styles.rowpadd}>
                  <Col style={{alignItems:'center'}}>
                  <Text style={styles.tittle}>PR</Text> 
                  </Col> 
                  <Col style={{alignItems:'center'}}>
                  <Text style={styles.tittle}>PO</Text>    
                  </Col> 
                  <Col style={{alignItems:'center'}}>
                  <Text style={styles.tittle}>WH</Text> 
                  </Col> 
                  <Col style={{alignItems:'center'}}>
                  <Text style={styles.tittle}>QC</Text> 
                  </Col> 
                  </Row>
                  <Row style={styles.rowpadd}>
                  <Col  style={{alignItems:'center'}}>
                     <Text style={{color:this.state.pr==='No'?red:grey,fontSize:15,fontWeight:'bold'}}>{this.state.pr}</Text> 
                  </Col>
                  <Col  style={{alignItems:'center'}}>
                     <Text style={{fontSize:15,fontWeight:'bold',color:grey}}>{this.state.po}</Text> 
                  </Col>
                  <Col  style={{alignItems:'center'}}>
                     <Text style={{fontSize:15,fontWeight:'bold',color:grey}}>{this.state.wh}</Text> 
                  </Col>
                  <Col  style={{alignItems:'center'}}>
                     <Text style={{fontSize:15,fontWeight:'bold',color:grey}}>{this.state.qc}</Text> 
                  </Col>
                  </Row>
                  <View style={{flexDirection: 'row',width:'98%',alignSelf:'center',paddingTop:'2%'}}>
                  <View style={{backgroundColor: dark, height: 1.5, flex: 1, alignSelf: 'center'}} />
                  <View style={{backgroundColor: dark, height: 1.5, flex: 1, alignSelf: 'center'}} />
                  </View>
                </Grid>
             
  <Toast ref="toast"
        />   
        
</ScrollView>
    
        )
      }
 };
 const styles = StyleSheet.create({
    textContent: {
        backgroundColor:'#fff',
        fontSize: 15,
        padding:8,
        textAlign:'center',
        color: '#36428a',
        fontFamily:'Bold',
        textShadowColor: 'rgba(0, 0, 0, 0.75)',
        textShadowOffset: {width: -1, height: 1},
        textShadowRadius: 10
      },
     tittle:{
      color:'#36428a',
      fontSize:15,
      paddingLeft:4,
      fontFamily:'Bold'
     },
     Headtittle:{
      color:'#36428a',
      fontSize:13,
      fontFamily:'Bold'
     },
     headcol:{
      alignItems:'flex-start',
      width:"40%"
     },
     detailcol:{
      alignItems:'flex-start',
      width:"60%"
     },
     titleText:{
         flex:1,
         flexWrap:'wrap',
         color:white,
         fontSize:12,
         padding:5,
         fontFamily:'Bold'
     },
     rowpadd:{
        paddingTop:3
     }
  });
  
  
  
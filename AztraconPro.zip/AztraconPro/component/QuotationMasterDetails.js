import React,{ Component }  from 'react';
import {ScrollView,StyleSheet,TouchableOpacity,Alert,Text,View,Image,FlatList,Dimensions} from 'react-native';
import { Col, Grid,Row } from 'react-native-easy-grid';
import Toast from 'react-native-whc-toast'
import {Card,CardItem} from 'native-base';
import { NavigationActions, StackActions } from 'react-navigation';
import { RFValue } from "react-native-responsive-fontsize";

//own lib
import {isPortrait} from './class/useOrientation'
import color from './res/colors';
import {logouttask} from './class/logout';


//constant values
const dark=color.values.Colors.colorPrimaryDark;
const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const greydark=color.values.Colors.greydark;
const lightblue=color.values.Colors.lightblue;

//logout
const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

//common style
const style_common = require('./class/style');

var { height, width } = Dimensions.get("window");

export default class QuotationMasterDetails extends React.Component {
   static navigationOptions = ({ navigation }) => ({ 
    title: "Quotation Master",
    headerStyle: {
      backgroundColor: colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
      fontSize:RFValue(18)
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  
  constructor(props) {
    super(props);
    this.state = {
        CusName:'',
        orientation:'',
        DeviceType:'',
        MenudataQuotation:[
          {
            "A": "Quotation Detail",
            "B": require('./src/ic_projectdetail.png'),
            "C": "QuotationDetailsActivity",
          },
          {
            "A": "Tag Items",
            "B": require('./src/ic_tagdetail.png'),
            "C": "QuotationTagListActivity",
          },
          {
            "A": "NMR Detail",
            "B": require('./src/ic_nmr.png'),
            "C": "QuotationNMRActivity",
          },
          {
            "A": "Status",
            "B": require('./src/ic_qstatus.png'),
            "C": "QuotationStatusActivity",
          },
          {
            "A": "Contact",
            "B": require('./src/ic_contact.png'),
            "C": "CustomerContactMasterActivity",
          },
          {
            "A": "Documents",
            "B": require('./src/ic_qdocument.png'),
            "C": "QuotationDocumentActivity",
          },
          {
            "A": "History",
            "B": require('./src/ic_qhistory.png'),
            "C": "QuotationHistoryActivity",
          },
          {
            "A": "Mail",
            "B":  require('./src/tm_email.png'),
            "C": "QuotationMailActivity",
          },
        ],
        UserID:'',
        QID:'',
        CusID:'',
        handlelogin:'',
    };
}

login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
        this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}


gotonextpage=(index)=>{

    const id=index

    const {C}=this.state.MenudataQuotation[id]
    
    if(C=='undefined' || C==null || C.length==0){
      this.refs.toast.showBottom("This Feature Update Soon")
    }else{
      console.log(C)
      this.props.navigation.navigate(C,{
        QID:this.state.QID,
        CusID:this.state.CusID,
        CusName:this.state.CusName,
        UserID:this.state.UserID
    });
 
  }

}



componentDidMount(){
  console.disableYellowBox = true;

  this.props.navigation.setParams({
    handlelogin: this.login.bind(this)
    });
    
    Dimensions.addEventListener('change', () => {
      this.setState({
          orientation: isPortrait() ? 'portrait' : 'landscape'
      });
    });


  this.setState({CusName:this.props.navigation.getParam('CusName', '')})
  this.setState({UserID:this.props.navigation.getParam('UserID', '')})
  this.setState({QID:this.props.navigation.getParam('QID', '')})
  this.setState({CusID:this.props.navigation.getParam('CusID', ''), 
  DeviceType:this.props.navigation.getParam('DeviceType', ''),
  orientation: isPortrait() ? 'portrait' : 'landscape',})

}

getheight(which){
  let orient=''
  let device=''

  orient = this.state.orientation
  device = this.state.DeviceType

  console.log(orient)
  if(which=='1') { //header
    if(device=='phone'){

      if(orient=='portrait'){
        return '10%'
      }else{
        //landscape
        return '25%'
      }
  
    }else{
      //tab
      if(orient=='portrait'){
        return '10%'
      }else{
         //landscape
         return '20%'
      }
  
    }
  }


  if(which=='2') { //body
    if(device=='phone'){

      if(orient=='portrait'){
        return '90%'
      }else{
        //landscape
        return '75%'
      }
  
    }else{
      //tab
      if(orient=='portrait'){
        return '90%'
      }else{
         //landscape
         return '80%'
      }
  
    }
  }

}

render() {
return (
  <View style={{flex:1,backgroundColor:lightblue}}>
  <ScrollView style={{height:this.getheight("1")}}>
  <Grid style={{paddingTop:"2%"}}>
  <Row style={{backgroundColor:colorprimary,width:'97%',alignSelf:'center',borderRadius:3}}>
  <Text style={styles.titleText}>
          {"QuotationID"+"-"+this.state.QID}
  </Text>
  </Row>
  <View style={{borderBottomColor:'#fff',borderBottomWidth: 1,paddingTop:3,}}/>
  <Row style={{backgroundColor:colorprimary,width:'97%',alignSelf:'center',borderRadius:3}}>
  <Text numberOfLines={1} style={styles.titleText}>
          {this.state.CusName+"-"+this.state.CusID}
  </Text>
  </Row>  
  </Grid>
  </ScrollView>
  <ScrollView style={{height:this.getheight("2")}}>
  <FlatList
       data={ this.state.MenudataQuotation }
       renderItem={({item,index}) =>
     
       <Grid style={{flex: 1 / 2,paddingTop:4}}>
          <Col style={{alignItems:'center',width:'100%',alignSelf:'center'}}>
          <TouchableOpacity activeOpacity = { .5 } onPress={() => this.gotonextpage(index)}>
           <Card  style={{padding: RFValue(10), margin: RFValue(10),  borderRadius: RFValue(10),borderColor:colorprimary}}> 
         
           <View
              style={{
                height: (height*12)/100,
                width:(width*20)/100,
                justifyContent: 'center',
                alignItems: 'center',
              }}
             >
            <Image  style={styles.imagebutton}
            source={item.B} />
           </View>
            </Card> 
            </TouchableOpacity>
          <Text style={{alignSelf:'center', flexWrap: 'wrap',fontSize:RFValue(12),fontFamily:'Bold'}}>{item.A}</Text>
     
          </Col> 
       </Grid>
      
      }
       numColumns={2}
       keyExtractor={(item, index) => index}
      />

        <Toast ref="toast"/>
      
  </ScrollView>
      </View>
    )
  }
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'stretch'
  },
  titleText: {
    padding:5,
    fontSize: RFValue(12),
    fontFamily:'Bold',
    color:white,
  },
  image: {
    width: 40,
    height: 40,
    marginTop:5,
    marginRight:10,
  },

  imagebutton: {
    width: '100%',
    height: '100%',
    alignSelf:'center',
    resizeMode: 'contain'    
  },
  textContent: {
    backgroundColor:colorprimary,
    fontSize: 12,
    padding:4,
    marginLeft:10,
    marginRight:10,
    color:white,
    fontWeight: 'bold'
  },
  imagetext: {
    fontSize: 12,
    color:greydark,
  },
  b: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop:10,
  },
});

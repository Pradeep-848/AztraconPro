import React,{ Component }  from 'react';
import {ScrollView,StyleSheet,Text,View,Modal,Image,TouchableOpacity,Alert,ImageBackground,Dimensions} from 'react-native';
import { Col,Grid,Row } from 'react-native-easy-grid';
import Toast from 'react-native-whc-toast'
import axios from 'axios';
import { NavigationActions, StackActions } from 'react-navigation';
import { RFValue } from "react-native-responsive-fontsize";

//own library
import {logouttask} from './class/logout';
import strings from './res/strings'
import color from './res/colors'

//constant
const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);

const loading=color.values.Colors.loading;
const white=color.values.Colors.white;
const colorprimary=color.values.Colors.colorPrimary;

var { height, width } = Dimensions.get("window");

//common style
const style_common = require('./class/style');

//logout
const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class QuotationDetails extends React.Component {
  static navigationOptions = ({ navigation }) => ({ 
    title: "Quotation Detail",
    color:white,
    headerStyle: {
      backgroundColor: colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
      fontSize:RFValue(20)
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
      isLoading:false, 
      dataSource:'',
      handlelogin:'',
      CusName:'',UserID:'',QID:'',CusID:'',qid:'',
      enquiry:'',customer:'',projectno:'',desc:'',contact:'',
      estimator:'',bid:'',payment:'',cusname:'',oqty:'',oval:'',odate:'',qrefno:'',
      layout: {
        height: height,
        width: width
    }
    };
}


_onLayout = event => {
  this.setState({
      layout: {
          height: event.nativeEvent.layout.height,
          width: event.nativeEvent.layout.width
      }
  });
};
componentDidMount(){
  console.disableYellowBox = true;

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
  
   this.setState({
       CusName:this.props.navigation.getParam('CusName', ''),
       UserID:this.props.navigation.getParam('UserID', ''),
       QID:this.props.navigation.getParam('QID', ''),
       CusID:this.props.navigation.getParam('CusID', '')
    },()=>{this.getquotationdetails();})
}

login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
        this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}


getquotationdetails=()=>{
 
    const config = {
      headers: {   
      'currentToken':tokken,
    },
      params: {
        QID:this.state.QID,
      }
      
    };
    this.setState({isLoading:true})
    axios.get(ip+'/getQuotDetails', config)
    .then(response => this.setState({dataSource:response.data},() => {if(response.status==200){
    const{qid,enquiry,customer,projectno,desc,contact,estimator,bid,payment,cusname,orqty,orval,ordate,cusqid}=this.state.dataSource
    this.setState({
    qid:qid,
    enquiry:enquiry,
    customer:customer,
    projectno:projectno,
    desc:desc,
    contact:contact,
    estimator:estimator,
    bid:bid,
    payment :payment,
    cusname:cusname,
    oqty:orqty,
    oval:orval, 
    odate:ordate,
    qrefno:cusqid,
    isLoading:false
})
    }}))
    .catch(err => 
      {
        this.setState({
          isLoading:false
        },()=>{
         let error=err
         
         this.refs.toast.showBottom(error.toString())
  
         setTimeout(
          () => { 
            this.props.navigation.goBack();
           },
          2000
        )
  
        })
      }
      );
  }
  render() {
    if (this.state.isLoading) {
      return (
        <Modal
        transparent={false}
        supportedOrientations={['portrait', 'landscape']}
        visible={this.state.isLoading}
        >
         <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
          useNativeDriver={true}
          style={style_common.load_gif}
          source={require('./src/gears.gif')}  />
          </View>     
        </Modal>
      )
  }
    return (
      
      <View
      style={{ flex: 1 }}
      onLayout={this._onLayout}
       >
      <ImageBackground 
       source={require('./src/aztracon_bg.jpg')}
       style={{
        height: this.state.layout.height,
        width: this.state.layout.width,
      }}>
       <ScrollView>
  <Grid style={{paddingTop:'2%'}}>
  <Row style={{backgroundColor:colorprimary,width:'97%',alignSelf:'center',borderRadius:3}}>
  <Text style={styles.titleText}>
          {"QuotationID"+"-"+this.state.QID}
  </Text>
   </Row>
   <View style={{borderBottomColor:'#fff',borderBottomWidth: 1,paddingTop:3}}/>
   <Row style={{backgroundColor:colorprimary,width:'97%',alignSelf:'center',borderRadius:3}}>
   <Text numberOfLines={1} style={styles.titleText}>
          {this.state.CusName+"-"+this.state.CusID}
  </Text>
  </Row>  
  </Grid>
  <Grid style={{paddingTop:6,width:'97%',alignSelf:'center'}}>
            <Row style={styles.row}>
              <Col style={styles.headcol}>
              <Text style={styles.tittle}>Quotation ID</Text>
              </Col> 
              <Col style={styles.detailcol}>
              <Text style={styles.detailtext}>{this.state.qid}</Text>
              </Col> 
            </Row>
            <Row style={styles.row}>
            <Col style={styles.headcol}>
              <Text style={styles.tittle}>Enquiry Date</Text>
              </Col> 
              <Col style={styles.detailcol}>
              <Text style={styles.detailtext}>{this.state.enquiry}</Text>
              </Col> 
            </Row>
            <Row style={styles.row}>
            <Col style={styles.headcol}>
              <Text style={styles.tittle}>Customer</Text>
              </Col>
              <Col style={styles.detailcol}>
              <Text style={styles.detailtext}>{this.state.cusname+"["+this.state.customer+"]"}</Text>
              </Col> 
            </Row>   
            <Row style={styles.row}>
            <Col style={styles.headcol}>
               <Text style={styles.tittle}>Project No</Text>   
              </Col>
              <Col style={styles.detailcol}>
                <Text style={styles.detailtext}>{this.state.projectno}</Text>  
              </Col>
              </Row>
              <Row style={styles.row}>
              <Col style={styles.headcol}>
                 <Text style={styles.tittle}>Project Desc</Text> 
              </Col>
              <Col style={styles.detailcol}>
                 <Text style={styles.detailtext}>{this.state.desc}</Text> 
              </Col>
              </Row>
            </Grid>  
      
      <Grid>   
      <Row style={styles.row}>
      <Col style={styles.headcol}>
          <Text style={styles.tittle}>Contact</Text>
          </Col>
          <Col style={styles.detailcol}>
          <Text style={styles.detailtext}>{this.state.contact}</Text>
          </Col>
      </Row>
      <Row style={styles.row}>
      <Col style={styles.headcol}>
          <Text style={styles.tittle}>Estimator</Text>
          </Col>
          <Col style={styles.detailcol}>
          <Text style={styles.detailtext}>{this.state.estimator}</Text>
          </Col>
      </Row>

      <Row style={styles.row}>
      <Col style={styles.headcol}>
          <Text style={styles.tittle}>Bid Type</Text>
          </Col>
          <Col style={styles.detailcol}>
          <Text style={styles.detailtext}>{this.state.bid}</Text>
          </Col>
      </Row>
      <Row style={styles.row}>
      <Col style={styles.headcol}>
          <Text style={styles.tittle}>Payment Terms</Text>
          </Col>
          <Col style={styles.detailcol}>
          <Text style={styles.detailtext}>{this.state.payment}</Text>
          </Col>
      </Row>
      <View style={{borderBottomColor:'#A9A9A9',borderBottomWidth: 1,height:10,width:'97%',alignSelf:'center'}}/>
      <Row style={styles.row}>
      <Col style={styles.headcol}>
          <Text style={styles.tittle}>Order Ref.No.</Text>
          </Col>
          <Col style={styles.detailcol}>
          <Text style={styles.detailtext}>{this.state.qrefno}</Text>
          </Col>
      </Row>
      <Row style={styles.row}>
      <Col style={styles.headcol}>
          <Text style={styles.tittle}>Order Date</Text>
          </Col>
          <Col style={styles.detailcol}>
          <Text style={styles.detailtext}>{this.state.odate}</Text>
          </Col>
      </Row>
      <Row style={styles.row}>
      <Col style={styles.headcol}>
          <Text style={styles.tittle}>Order Qty</Text>
          </Col>
          <Col style={styles.detailcol}>
          <Text style={styles.detailtext}>{this.state.oqty}</Text>
          </Col>
      </Row>
      <Row style={styles.row}>
      <Col style={styles.headcol}>
          <Text style={styles.tittle}>Order Value</Text>
          </Col>
          <Col style={styles.detailcol}>
          <Text style={styles.detailtext}>{this.state.oval}</Text>
          </Col>
      </Row>
      <View style={{borderBottomColor:'#A9A9A9',borderBottomWidth: 1,height:10,width:'97%',alignSelf:'center'}}/>
      </Grid>    

        <Toast ref="toast"/>       
       </ScrollView>
      </ImageBackground>
      </View>

        )
      }
 };
 const styles = StyleSheet.create({
   imageStyle:{
    width: screenWidth, 
    height: screenHeight, 
  
   },
    textContent: {
      backgroundColor:white,
      fontSize: RFValue(15),
      padding:RFValue(8),
      textAlign:'center',
      color:colorprimary,
      fontWeight: 'bold',
      textShadowColor: 'rgba(0, 0, 0, 0.75)',
      textShadowOffset: {width: -1, height: 1},
      textShadowRadius: RFValue(10)
    },
   tittle:{
    color:colorprimary,
    fontSize:RFValue(14),
    paddingRight:'4%',
    fontFamily:'Bold',
    alignSelf:'flex-end'
   },
   Headtittle:{
    color:colorprimary,
    fontSize:RFValue(13),
    fontWeight: 'bold',
   },
   headcol:{
    alignItems:'flex-start',
    width:"40%"
   },
   detailcol:{
    alignItems:'flex-start',
    width:"60%"
   },
    titleText: {
    flex:1,
    flexWrap:'wrap',
    color:white,
    fontSize:RFValue(13),
    padding:RFValue(5),
    fontFamily:'Bold'
  },
  row:{
    paddingTop:RFValue(8)
  },
  detailtext:{
    fontSize:RFValue(13),
    fontFamily:'Bold'

  }
  });
  

 
import React from "react";
import {
  ScrollView,
  Dimensions,
  Image,
  Modal,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Alert,
  KeyboardAvoidingView,
  Platform,
  FlatList,
} from "react-native";
import axios from "axios";
import { Col, Grid, Row } from "react-native-easy-grid";
import { Card, CardItem, Item, Input, Label, Form, Icon } from "native-base";
import { NavigationActions, StackActions } from "react-navigation";
import strings from "./res/strings";
import { logouttask } from "./class/logout";
import Toast from "react-native-whc-toast";
import color from "./res/colors";
import { Divider, Button, Overlay } from "react-native-elements";
import SelectDropdown from "react-native-select-dropdown";

const ip = strings.values.commonvalues.ip;
const tokken = strings.values.commonvalues.tokken;

const { width, height } = Dimensions.get("window");

const screenWidth = Math.round(Dimensions.get("window").width);
const screenHeight = Math.round(Dimensions.get("window").height);

const lightblue = color.values.Colors.lightblue;
const colorprimary = color.values.Colors.colorPrimary;
const colorprimarydark = color.values.Colors.colorprimarydark;
const white = color.values.Colors.white;
const black = color.values.Colors.black;
const darkblue = color.values.Colors.darkblue;
const red = color.values.Colors.red;
const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: "LoginActivity" })],
});

export default class ERPToDoDetail extends React.Component {
  static navigationOptions = ({ navigation }) => ({
    title: "ERP ToDo Detail",
    color: white,
    headerStyle: {
      backgroundColor: colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily: "Bold",
    },
    headerRight: (
      <TouchableOpacity
        style={{ paddingRight: 10 }}
        onPress={() => navigation.state.params.handlelogin()}
      >
        <Image
          style={{ alignSelf: "center", justifyContent: "center" }}
          source={require("./src/logout.png")}
        />
      </TouchableOpacity>
    ),
  });
  constructor(props) {
    super(props);
    this.state = {
      isLoading: true,
      data: [],
      vrm: "",
      handlelogin: "",
      AppID: "",
      ReqBy: "",
      ReqName: "",
      ReqDate: "",
      UserID: "",
      Name: "",
      sno: "",
      sid: "",
      sdate: "",
      sname: "",
      ed_comments: "",
      Sel_id: "",
      Sel_status: "",
      sdesc: "",
      spriority: "",
      sstatus: "",
      sworkto: "",
      smod: "",
      isVisibleDetail: false,
      message: "",
    };
    console.disableYellowBox = true;
  }

  login = async () => {
    Alert.alert(
      "Logout",
      "Would you like to logout?",
      [
        {
          text: "Cancel",
          onPress: () => console.log("Cancel Pressed"),
          style: "cancel",
        },
        {
          text: "OK",
          onPress: () => {
            logouttask();
            this.props.navigation.dispatch(resetAction);
          },
        },
      ],
      { cancelable: false }
    );
  };

  componentDidMount() {
    console.disableYellowBox = true;

    this.props.navigation.setParams({
      handlelogin: this.login.bind(this),
    });

    this.setState(
      {
        UserID: this.props.navigation.getParam("UserID", ""),
        Name: this.props.navigation.getParam("Name", ""),
        sno: this.props.navigation.getParam("sno", ""),
        sid: this.props.navigation.getParam("sid", ""),
        sdate: this.props.navigation.getParam("sdate", ""),
        sname: this.props.navigation.getParam("sname", ""),
        sdesc: this.props.navigation.getParam("sdesc", ""),
        spriority: this.props.navigation.getParam("spriority", ""),
        sstatus: this.props.navigation.getParam("sstatus", ""),
        sworkto: this.props.navigation.getParam("sworkto", ""),
        smod: this.props.navigation.getParam("smod", ""),
        Sel_Name:
          this.props.navigation.getParam("UserID", "") == "2927"
            ? "Mohammad Zarrar Alam"
            : "",
      },
      () => {
        this.geterpcomment();
      }
    );
  }

  geterpcomment() {
    const config = {
      headers: {
        currentToken: tokken,
      },
      params: {
        pid: this.state.sid,
      },
    };
    this.setState({ isLoading: true, data: "" });
    axios
      .get(ip + "/getERPToDoComment", config)
      .then((response) =>
        this.setState({ data: response.data }, () => {
          if (response.status == 200) {
            this.setState({ isLoading: false });
          }
        })
      )
      .catch((err) => {
        this.setState(
          {
            isLoading: false,
          },
          () => {
            let error = err;

            this.refs.toast.showBottom(error.toString());

            setTimeout(() => {
              this.props.navigation.goBack();
            }, 2000);
          }
        );
      });
  }

  getdetail(index) {
    const {
      slno,
      desc,
      unitprice,
      totweight,
      totvalue,
      vat,
      vatamount,
      netamount,
    } = this.state.data[index];

    this.setState({
      UP: unitprice,
      TW: totweight,
      TV: totvalue,
      VatPercent: vat,
      VatAmount: vatamount,
      NetAmount: netamount,
      Description: desc,
      isVisibleDetail: true,
    });
  }

  opencomment() {
    this.setState({
      isVisibleDetail: true,
      Sel_status: "",
      ed_comments: "",
      Sel_Name: this.state.UserID == "2927" ? "Mohammad Zarrar Alam" : "",
    });
  }

  cancel() {
    this.setState({ isVisibleDetail: false, Sel_status: "" });
  }

  addcomment() {
    if (this.state.Sel_status == "") {
      this.setState({
        message: "Please select Status",
      });
    } else {
      if (this.state.UserID == "2927") {
        switch (this.state.Sel_Name) {
          case "Mohammad Zarrar Alam":
            this.setState({
              Sel_id: "2927",
            });
            break;
          case "Swaminathan":
            this.setState({
              Sel_id: "1000",
            });
            break;

          case "Susindharan":
            this.setState({
              Sel_id: "1001",
            });
            break;
          case "Santhosh":
            this.setState({
              Sel_id: "1002",
            });
            break;
        }
      } else {
        this.setState({
          Sel_id: this.state.UserID,
          Sel_name: this.state.Name,
        });
      }

      this.save();
    }
  }

  save() {
    this.setState({ isLoading: true });

    axios({
      method: "post",
      url: ip + "/setERPComment",
      headers: { currentToken: tokken },
      data: {
        rid: this.state.sid,
        name: this.state.Sel_Name,
        empid: this.state.Sel_id,
        comments: this.state.ed_comments,
        status: this.state.Sel_status,
      },
    })
      .then((response) => {
        if (response.status === 200) {
          this.setState({ isLoading: false, isVisibleDetail: false }, () => {
            this.geterpcomment();
            this.refs.toast.showBottom("Submitted Successfully");
          });
        } else {
          this.refs.toast.showBottom("Failed");
        }
      })
      .catch((err) => {
        this.setState(
          {
            isLoading: false,
            isVisibleDetail: false,
          },
          () => {
            let error = err;

            this.refs.toast.showBottom(error.toString());

            setTimeout(() => {
              this.props.navigation.goBack();
            }, 2000);
          }
        );
      });
  }

  render() {
    if (this.state.isLoading) {
      return (
        <Modal
          transparent={false}
          supportedOrientations={["portrait", "landscape"]}
          visible={this.state.isLoading}
        >
          <View
            style={{ flex: 1, alignItems: "center", justifyContent: "center" }}
          >
            <Image
              style={{ width: 300, height: 200 }}
              source={require("./src/gears.gif")}
            />
          </View>
        </Modal>
      );
    }

    return (
      <View style={{ flex: 1, backgroundColor: lightblue }}>
        <ScrollView style={{ height: "30%" }}>
          <Grid style={{ paddingTop: "2%" }}>
            <Row
              style={{
                backgroundColor: colorprimary,
                padding: 5,
                width: "97%",
                alignSelf: "center",
                alignItems: "center",
                borderRadius: 2,
              }}
            >
              <Col style={{ alignItems: "flex-start", width: "100%" }}>
                <Text style={styles.titleText}>ToDo List Detail</Text>
              </Col>
            </Row>
          </Grid>

          <Card style={{ width: "97%", alignSelf: "center" }}>
            <CardItem
              style={{
                alignItems: "flex-start",
                width: "100%",
                flexWrap: "wrap",
                paddingLeft: 5,
                paddingRight: 5,
                paddingTop: 0,
                paddingBottom: 0,
              }}
            >
              <Grid>
                <Row style={{ paddingTop: 2 }}>
                  <Col style={{ alignItems: "flex-start", width: "25%" }}>
                    <Text style={styles.testHead}>Request ID - </Text>
                  </Col>
                  <Col style={{ alignItems: "flex-start", width: "25%" }}>
                    <Text
                      style={{
                        fontSize: 12,
                        color: black,
                        fontFamily: "Regular",
                      }}
                    >
                      {String(this.state.sid).trim()}
                    </Text>
                  </Col>
                  <Col style={{ alignItems: "flex-start", width: "28%" }}>
                    <Text style={styles.testHead}>Request Date - </Text>
                  </Col>
                  <Col style={{ alignItems: "flex-start", width: "22%" }}>
                    <Text
                      style={{
                        fontSize: 12,
                        color: black,
                        fontFamily: "Regular",
                      }}
                    >
                      {this.state.sdate}
                    </Text>
                  </Col>
                </Row>
                <View
                  style={{
                    borderBottomColor: "#A9A9A9",
                    borderBottomWidth: 1,
                    height: 3,
                    width: "100%",
                    alignSelf: "center",
                  }}
                />
                <Row style={{ paddingTop: 3 }}>
                  <Col style={{ alignItems: "flex-start", width: "25%" }}>
                    <Text style={styles.testHead}>Request by - </Text>
                  </Col>
                  <Col style={{ alignItems: "flex-start", width: "75%" }}>
                    <Text
                      style={{
                        fontSize: 12,
                        color: black,
                        fontFamily: "Regular",
                      }}
                    >
                      {this.state.sname}
                    </Text>
                  </Col>
                </Row>
              </Grid>
            </CardItem>
          </Card>

          <Card style={{ width: "97%", alignSelf: "center" }}>
            <CardItem
              style={{
                alignItems: "flex-start",
                width: "100%",
                flexWrap: "wrap",
                paddingLeft: 5,
                paddingRight: 5,
                paddingTop: 0,
                paddingBottom: 0,
              }}
            >
              <Grid>
                <Row style={{ paddingTop: 2, paddingBottom: 3 }}>
                  <Col style={{ alignItems: "flex-start", width: "20%" }}>
                    <Text style={styles.testHead}>Module - </Text>
                  </Col>
                  <Col style={{ alignItems: "flex-start", width: "30%" }}>
                    <Text
                      style={{
                        fontSize: 12,
                        color: black,
                        fontFamily: "Regular",
                      }}
                    >
                      {this.state.smod}
                    </Text>
                  </Col>
                  <Col style={{ alignItems: "flex-start", width: "18%" }}>
                    <Text style={styles.testHead}>Priority - </Text>
                  </Col>
                  <Col style={{ alignItems: "flex-start", width: "32%" }}>
                    <Text
                      style={{
                        fontSize: 12,
                        color: black,
                        fontFamily: "Regular",
                      }}
                    >
                      {this.state.spriority}
                    </Text>
                  </Col>
                </Row>
                <View
                  style={{
                    borderBottomColor: "#A9A9A9",
                    borderBottomWidth: 1,
                    height: 3,
                    width: "100%",
                    alignSelf: "center",
                  }}
                />
                <Row style={{ paddingTop: 3 }}>
                  <Col style={{ alignItems: "flex-start", width: "25%" }}>
                    <Text style={styles.testHead}>Assigned to - </Text>
                  </Col>
                  <Col style={{ alignItems: "flex-start", width: "42%" }}>
                    <Text
                      style={{
                        fontSize: 12,
                        color: black,
                        fontFamily: "Regular",
                      }}
                    >
                      {this.state.sworkto}
                    </Text>
                  </Col>
                  <Col style={{ alignItems: "flex-start", width: "16%" }}>
                    <Text style={styles.testHead}>Status - </Text>
                  </Col>
                  <Col style={{ alignItems: "flex-start", width: "18%" }}>
                    <Text
                      style={{
                        fontSize: 12,
                        color: black,
                        fontFamily: "Regular",
                      }}
                    >
                      {this.state.sstatus}
                    </Text>
                  </Col>
                </Row>
              </Grid>
            </CardItem>
          </Card>

          <Card style={{ width: "97%", alignSelf: "center" }}>
            <CardItem
              style={{
                alignItems: "flex-start",
                width: "100%",
                flexWrap: "wrap",
                paddingLeft: 5,
                paddingRight: 5,
                paddingTop: 0,
                paddingBottom: 0,
              }}
            >
              <Grid>
                <Row style={{ paddingTop: 2, paddingBottom: 3 }}>
                  <Col style={{ alignItems: "flex-start", width: "15%" }}>
                    <Text style={styles.testHead}>Brief - </Text>
                  </Col>
                  <Col style={{ alignItems: "flex-start", width: "85%" }}>
                    <Text
                      numberOfLines={1}
                      style={{
                        fontSize: 12,
                        color: black,
                        fontFamily: "Regular",
                      }}
                    >
                      {this.state.sdesc}
                    </Text>
                  </Col>
                </Row>
              </Grid>
            </CardItem>
          </Card>

          <View style={{ flex: 1, paddingTop: 5 }}>
            <Grid
              style={{
                backgroundColor: colorprimary,
                padding: 5,
                width: "97%",
                alignSelf: "center",
                alignItems: "center",
                borderRadius: 4,
              }}
            >
              <Row>
                <Col style={{ alignItems: "flex-start", width: "15%" }}>
                  <Text style={styles.textContent}>SNo</Text>
                </Col>
                <Col style={{ alignItems: "flex-start", width: "25%" }}>
                  <Text style={styles.textContent}>Date</Text>
                </Col>
                <Col style={{ alignItems: "flex-start", width: "30%" }}>
                  <Text style={styles.textContent}>Comment By</Text>
                </Col>
                <Col style={{ alignItems: "flex-end", width: "30%" }}>
                  <Text style={styles.textContent}>Status</Text>
                </Col>
              </Row>
            </Grid>
          </View>
        </ScrollView>

        <ScrollView style={{ height: "62%" }}>
          <FlatList
            data={this.state.data}
            renderItem={({ item, index }) => (
              <Card style={{ width: "97%", alignSelf: "center" }}>
                <CardItem style={styles.carditem}>
                  <Grid>
                    <Row style={{ paddingBottom: 3 }}>
                      <Col style={{ alignItems: "flex-start", width: "15%" }}>
                        <Text
                          style={{
                            fontSize: 11,
                            alignSelf: "flex-start",
                            fontFamily: "Regular",
                          }}
                        >
                          {item.sno}
                        </Text>
                      </Col>
                      <Col style={{ alignItems: "flex-start", width: "25%" }}>
                        <Text
                          style={{
                            fontSize: 11,
                            alignSelf: "flex-start",
                            fontFamily: "Regular",
                          }}
                        >
                          {item.date}
                        </Text>
                      </Col>
                      <Col style={{ alignItems: "flex-start", width: "30%" }}>
                        <Text
                          style={{
                            fontSize: 11,
                            alignSelf: "flex-start",
                            fontFamily: "Regular",
                          }}
                        >
                          {item.name}
                        </Text>
                      </Col>
                      <Col style={{ alignItems: "flex-end", width: "30%" }}>
                        <Text
                          style={{
                            fontSize: 11,
                            alignSelf: "flex-end",
                            fontFamily: "Regular",
                          }}
                        >
                          {item.status}
                        </Text>
                      </Col>
                    </Row>
                    <View
                      style={{
                        borderBottomColor: "#A9A9A9",
                        borderBottomWidth: 1,
                        height: 5,
                        width: "100%",
                        alignSelf: "center",
                      }}
                    />
                    <Row>
                      <Col style={{ alignItems: "flex-start", width: "100%" }}>
                        <Text
                          style={{
                            fontSize: 11,
                            alignSelf: "flex-start",
                            fontFamily: "Regular",
                          }}
                        >
                          {item.desc}
                        </Text>
                      </Col>
                    </Row>
                  </Grid>
                </CardItem>
              </Card>
            )}
            keyExtractor={(item, index) => index.toString()}
          />
        </ScrollView>

        <ScrollView style={{ height: "8%" }}>
          <Grid
            style={{
              padding: 4,
              width: "97%",
              alignSelf: "center",
              paddingBottom: 5,
            }}
          >
            <Row>
              <Col style={{ alignItems: "center", width: "100%" }}>
                <Button
                  onPress={() => this.opencomment()}
                  raised={true}
                  titleStyle={{
                    fontSize: 15,
                    textAlign: "center",
                    fontFamily: "Bold",
                  }}
                  buttonStyle={{
                    flex: 1,
                    borderRadius: 6,
                    width: 130,
                    height: 40,
                  }}
                  title=" Add Comment "
                />
              </Col>
            </Row>
          </Grid>
        </ScrollView>

        <Toast ref="toast" />

        <Modal
          animationType={"slide"}
          transparent={true}
          visible={this.state.isVisibleDetail}
          onRequestClose={() => {
            console.log("Modal has been closed.");
          }}
        >
          {/*All views of Modal*/}
          <View style={styles.modal}>
            <TouchableOpacity
              style={styles.headerback}
              activeOpacity={0.5}
              onPress={() => {
                this.setState({ isVisibleDetail: !this.state.isVisibleDetail });
              }}
            >
              <Grid>
                <Row>
                  <Col
                    style={{
                      width: "90%",
                      alignItems: "center",
                      alignSelf: "center",
                    }}
                  >
                    <Text
                      style={{
                        paddingLeft: "3%",
                        color: "#fff",
                        textDecorationStyle: "solid",
                        fontFamily: "Bold",
                        alignSelf: "flex-start",
                      }}
                    >
                      Comments
                    </Text>
                  </Col>

                  <Col
                    style={{
                      width: "10%",
                      alignItems: "center",
                      alignSelf: "center",
                    }}
                  >
                    <Image
                      source={require("./src/back.png")}
                      style={{ height: 22, width: 22 }}
                    />
                  </Col>
                </Row>
              </Grid>
            </TouchableOpacity>

            <ScrollView>
              <Grid style={{ width: "97%", alignSelf: "center" }}>
                <Row
                  style={{
                    paddingTop: 4,
                    paddingBottom: 4,
                    display: this.state.UserID == "2927" ? "flex" : "none",
                  }}
                >
                  <Text
                    style={{
                      fontSize: 14,
                      fontFamily: "Bold",
                      color: colorprimary,
                      paddingLeft: "2%",
                    }}
                  >
                    Comment By
                  </Text>
                </Row>

                <Row
                  style={{
                    paddingBottom: 4,
                    display: this.state.UserID == "2927" ? "flex" : "none",
                  }}
                >
                  <Col style={{ alignItems: "center", width: "100%" }}>
                    <Form style={{ flex: 1, alignItems: "flex-start" }}>
                    <Item style={{ marginLeft: 0, height: 45 }} picker>
                        <SelectDropdown
                          data={[
                            {
                              title: "Mohammad Zarrar Alam",
                              value: "Mohammad Zarrar Alam",
                            },
                            { title: "Swaminathan", value: "Swaminathan" },
                            { title: "Susindharan", value: "Susindharan" },
                            { title: "Santhosh", value: "Santhosh" },
                          ]}
                          onSelect={(selectedItem, index) => {
                            console.log("Selected Item:", selectedItem.value);
                            this.setState(
                              { Sel_Name: selectedItem.value },
                              () => {
                                this.state.Sel_id;
                              }
                            );
                          }}
                          renderButton={(isOpened) => {
                            const data = [
                              {
                                title: "Mohammad Zarrar Alam",
                                value: "Mohammad Zarrar Alam",
                              },
                              { title: "Swaminathan", value: "Swaminathan" },
                              { title: "Susindharan", value: "Susindharan" },
                              { title: "Santhosh", value: "Santhosh" },
                            ];

                            const buttonText = this.state.Sel_Name
                              ? data.find(
                                  (item) => item.value === this.state.Sel_Name
                                )?.title
                              : "Select Responsible";

                            return (
                              <View style={styles.dropdownButtonStyle}>
                                <Text
                                  style={{
                                    flex: 1,
                                    fontSize: 16,
                                    color: "black",
                                  }}
                                >
                                  {buttonText}
                                </Text>
                                <Icon
                                  name={
                                    isOpened ? "chevron-up" : "chevron-down"
                                  }
                                  style={{
                                    fontSize: 20,
                                    color: colorprimary,
                                  }}
                                />
                              </View>
                            );
                          }}
                          renderItem={(item, index, isSelected) => {
                            return (
                              <View
                                style={{
                                  ...styles.dropdownItemStyle,
                                  ...(isSelected && {
                                    backgroundColor: "#D2D9DF",
                                  }),
                                }}
                              >
                                <Text
                                  style={{
                                    fontSize: 16,
                                    color: "black",
                                  }}
                                >
                                  {item.title}
                                </Text>
                              </View>
                            );
                          }}
                          showsVerticalScrollIndicator={false}
                          dropdownStyle={{
                            borderRadius: 8,
                            borderWidth: 1,
                            borderColor: "#ccc",
                            backgroundColor: "#fff",
                          }}
                        />
                      </Item>
                    </Form>
                  </Col>
                </Row>

                <Row>
                  <Col style={{ width: "100%", alignItems: "flex-start" }}>
                    <Item style={{ marginLeft: 0, marginTop: 3 }} floatingLabel>
                      <Label style={styles.floatlabel}>Comments</Label>
                      <Input
                        getRef={(input) => {
                          this.ed_comments = input;
                        }}
                        returnKeyType="done"
                        maxLength={500}
                        style={styles.istyle}
                        autoCorrect={false}
                        autoCapitalize="words"
                        keyboardType={"default"}
                        value={this.state.ed_comments}
                        textDecorationStyle={{ fontFamily: "Regular" }}
                        onChangeText={(ed_comments) =>
                          this.setState({ ed_comments })
                        }
                      />
                    </Item>
                  </Col>
                </Row>

                <Row style={{ paddingBottom: 4 }}>
                  <Text
                    style={{
                      fontSize: 14,
                      fontFamily: "Bold",
                      color: colorprimary,
                      paddingLeft: "2%",
                    }}
                  >
                    Status
                  </Text>
                </Row>

                <Row style={{ paddingBottom: 4 }}>
                  <Col style={{ alignItems: "center", width: "100%" }}>
                    <Form style={{ flex: 1, alignItems: "flex-start" }}>
                    <Item style={{ marginLeft: 0, height: 45 }} picker>
                        <SelectDropdown
                          data={[
                            { title: "Open", value: "O" },
                            { title: "InProgress", value: "P" },
                            { title: "Closed", value: "C" },
                            { title: "Cancelled", value: "X" },
                          ]}
                          onSelect={(selectedItem, index) => {
                            console.log("Selected Item:", selectedItem.value);
                            this.setState(
                              { Sel_status: selectedItem.value },
                              () => {
                                this.state.Sel_status;
                              }
                            );
                          }}
                          renderButton={(isOpened) => {
                            const data = [
                              { title: "Open", value: "O" },
                              { title: "InProgress", value: "P" },
                              { title: "Closed", value: "C" },
                              { title: "Cancelled", value: "X" },
                            ];

                            const buttonText = this.state.Sel_status
                              ? data.find(
                                  (item) => item.value === this.state.Sel_status
                                )?.title
                              : "Select Status";

                            return (
                              <View style={styles.dropdownButtonStyle}>
                                <Text
                                  style={{
                                    flex: 1,
                                    fontSize: 16,
                                    color: "black",
                                  }}
                                >
                                  {buttonText}
                                </Text>
                                <Icon
                                  name={
                                    isOpened ? "chevron-up" : "chevron-down"
                                  }
                                  style={{
                                    fontSize: 20,
                                    color: colorprimary,
                                  }}
                                />
                              </View>
                            );
                          }}
                          renderItem={(item, index, isSelected) => {
                            return (
                              <View
                                style={{
                                  ...styles.dropdownItemStyle,
                                  ...(isSelected && {
                                    backgroundColor: "#D2D9DF",
                                  }),
                                }}
                              >
                                <Text
                                  style={{
                                    fontSize: 16,
                                    color: "black",
                                  }}
                                >
                                  {item.title}
                                </Text>
                              </View>
                            );
                          }}
                          showsVerticalScrollIndicator={false}
                          dropdownStyle={{
                            borderRadius: 8,
                            borderWidth: 1,
                            borderColor: "#ccc",
                            backgroundColor: "#fff",
                          }}
                        />
                      </Item>
                    </Form>
                  </Col>
                </Row>

                <Row
                  style={{
                    paddingTop: 3,
                    display: this.state.message == "" ? "none" : "flex",
                  }}
                >
                  <Col style={{ width: "100%", alignItems: "center" }}>
                    <Text
                      style={{
                        fontSize: 16,
                        fontFamily: "Bold",
                        color: red,
                        paddingTop: "1%",
                        paddingBottom: "1%",
                        textAlign: "center",
                      }}
                    >
                      {this.state.message}
                    </Text>
                  </Col>
                </Row>

                <Row style={{ paddingBottom: 4 }}>
                  <Col style={{ alignItems: "center", width: "50%" }}>
                    <Button
                      onPress={() => this.addcomment()}
                      raised={true}
                      titleStyle={{
                        fontSize: 15,
                        textAlign: "center",
                        fontFamily: "Bold",
                      }}
                      buttonStyle={{
                        flex: 1,
                        borderRadius: 6,
                        width: 120,
                        height: 45,
                      }}
                      title=" SUBMIT "
                    />
                  </Col>
                  <Col style={{ alignItems: "center", width: "50%" }}>
                    <Button
                      onPress={() => this.cancel()}
                      raised={true}
                      titleStyle={{
                        fontSize: 15,
                        textAlign: "center",
                        fontFamily: "Bold",
                      }}
                      buttonStyle={{
                        flex: 1,
                        borderRadius: 6,
                        width: 120,
                        height: 45,
                      }}
                      title=" CANCEL "
                    />
                  </Col>
                </Row>
              </Grid>
            </ScrollView>
          </View>
        </Modal>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  ButtonSection: {
    paddingTop: 3,
    width: "100%",
    justifyContent: "center",
    alignItems: "center",
    paddingBottom: 10,
  },

  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#F5FCFF",
  },
  sectionHeader: {
    fontSize: 13,
    fontWeight: "bold",
    color: "#fff",
  },
  itemView: {
    flex: 1,
    width,
    borderBottomWidth: 0.5,
    borderColor: "#cdcdcd",
    borderStyle: "solid",
    paddingHorizontal: 12,
    flexDirection: "row",
    paddingTop: 2,
  },
  textContent: {
    color: white,
    fontSize: 12,
    fontFamily: "Bold",
  },

  textTotalContent: {
    color: "#3A6705",
    fontSize: 12,
    fontFamily: "Bold",
  },

  testHead: {
    width: "100%",
    fontSize: 13,
    color: colorprimary,
    fontFamily: "Bold",
  },
  CButton: {
    paddingTop: 8,
    height: 45,
    width: 80,
    paddingBottom: 4,
  },
  imagebutton: {
    width: 30,
    height: 30,
  },
  modal: {
    flex: 1,
    backgroundColor: white,
    height: "auto",
    position: "absolute",
    bottom: 0,
    width: "100%",
  },
  headerback: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: colorprimary,
    borderWidth: 0.5,
    borderColor: white,
    height: 40,
    width: "100%",
    borderRadius: 5,
  },
  titleText: {
    flex: 1,
    flexWrap: "wrap",
    color: white,
    fontSize: 13,
    fontFamily: "Bold",
  },
  carditem: {
    alignItems: "flex-start",
    width: "100%",
    flexWrap: "wrap",
    paddingLeft: 5,
    paddingRight: 5,
    paddingTop: 6,
    paddingBottom: 6,
  },
  dropdownButtonStyle: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 10,
    paddingVertical: 12,
    backgroundColor: "#fff",
  },
  dropdownItemStyle: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 10,
    paddingHorizontal: 15,
  },
});

import React,{ Component }  from 'react';
import {ScrollView,StyleSheet,Text,View,Modal,Image,FlatList,TouchableOpacity,Alert} from 'react-native';
import { Col,Grid,Row } from 'react-native-easy-grid';
import { SearchBar } from 'react-native-elements';
import axios from 'axios';
import Toast from 'react-native-whc-toast'
import { NavigationActions, StackActions } from 'react-navigation';
import {Card,CardItem} from 'native-base';
import strings from './res/strings'
import moment from 'moment';
import color from './res/colors'
import {logouttask} from './class/logout';

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const loading=color.values.Colors.loading;
const greylight=color.values.Colors.greylight;
const skyblue=color.values.Colors.skyblue;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});
export default class ProjectMaterialList extends React.Component {

  static navigationOptions = ({ navigation }) => ({ 
    title: "Project Material",
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor:white,
    headerTitleStyle: {
      fontFamily: 'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
      USER:'',
      handlelogin:'',
      isLoading: false, 
      dataSource:[],
    };
    this.arrayholder = [];
}

getprojectmaterialdetail(index){
let id=index

const{mCode,mDesc}=this.state.dataSource[id];

this.props.navigation.navigate('ProjectMaterialDetailActivity',{UserID:this.state.USER,MCODE:mCode,Mdesc:mDesc});
}

login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
      this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}

getmaterial(){
    
    let url='/getMateriallist'

    const config = {
        headers: {   
        'currentToken':tokken,
      },  
    };   

      this.setState({isLoading:true})

      axios.get(ip+url, config)
      .then(response => this.setState({dataSource:response.data},() => {
       if(response.status==200){
          this.arrayholder = this.state.dataSource;
          this.setState({isLoading:false});
    }
  }))
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
}

filtersearch(text){
    const newData = this.arrayholder.filter(function(item){
    const itemData =item.mCode.toString()+item.mCode.toString().toUpperCase()
    const textData = text.toUpperCase()
    return itemData.indexOf(textData) > -1
}
)
this.setState({
    dataSource: newData.sort(),
    text: text
})
}

componentDidMount(){

  console.disableYellowBox = true;

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
   this.setState({USER:this.props.navigation.getParam('UserID', '')},()=>{
   this.getmaterial();
})


}
render() {
    if (this.state.isLoading) {
      return (
        <Modal
        transparent={false}
        supportedOrientations={['portrait', 'landscape']}
        visible={this.state.isLoading}
        >
         <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
          style={{width: 300, height: 200}}
          source={require('./src/gears.gif')}  />
          </View>     
        </Modal>
           )
  }
    return (
      <View style={{flex:1}}>
      <ScrollView style={{height:'10%'}}>
      <SearchBar
        placeholder="Search Material ID/Desc"
        onChangeText={(text) => this.filtersearch(text)}
        value={this.state.text}
        searchIcon={{ name: "search", size: 19, color: colorprimary }}
        clearIcon={{ name: "close-circle", size: 19 }}
        loadingProps={{ size: "small" }}
        platform={'ios'}></SearchBar>
      </ScrollView>
      <ScrollView style={{height:'6%'}}>
      <View  style={{ flex: 1,paddingTop:5,paddingBottom:5}}>
      <Grid style={{backgroundColor:'#36428a',padding:4,width:"98%",alignSelf:'center'}}>
             <Row>
             <Col style={{alignItems:'flex-start',width:'30%',paddingLeft:8}}>
             <Text style={styles.textContent}>Material ID</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'70%',paddingLeft:5}}>
             <Text style={styles.textContent}>Material Desc</Text>
             </Col> 
             </Row>
             </Grid>
      </View>
      </ScrollView>
      <ScrollView style={{height:'84%'}}>
      <FlatList
        data={this.state.dataSource}
        initialNumToRender={this.state.dataSource.length}
        renderItem={({item,index}) =>  
        <Card style={{width:'97%',alignSelf:'center'}}>
        <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
        <Grid  onPress={() => this.getprojectmaterialdetail(index)}>
        <Row> 
        <Col style={{alignItems:"flex-start",width:'30%'}}>
        <Text style={{fontSize:12}}>{item.mCode}</Text>
        </Col>
        <Col style={{alignItems:"flex-start",width:'70%'}}>
        <Text style={{fontSize:12}}>{item.mDesc}</Text> 
        </Col>
        </Row>
        </Grid>  
        </CardItem>
        </Card>
        }
        keyExtractor={(item, index) => index.toString()}
      />
      </ScrollView>
      <Toast ref="toast"/>
      </View>
        )
        
      }
 
 };
 const styles = StyleSheet.create({
    tittle:{
        color:colorprimary,
        fontSize:13
       },
       values:{
        color:greylight,
        fontSize:12
       },
    imagebutton: {
        width:30,
        height: 30,        
      },
      input: {
        maxHeight: 100,
        borderColor:skyblue, 
        borderWidth: 1, 
        padding: 10, 
        width:320,
        marginBottom: 10,
      },
      textContent:{
        color:white,
        fontSize:12
      }
  });
  

  


import React,{ Component }  from 'react';
import {ScrollView,Modal,StyleSheet,Text,View,Image,Dimensions,FlatList,ProgressBarAndroid,TouchableOpacity,Alert} from 'react-native';
import { Col, Grid, Row } from 'react-native-easy-grid';
import { Divider } from 'react-native-elements';
import Toast from 'react-native-whc-toast'
import axios from 'axios';
import { NavigationActions, StackActions } from 'react-navigation';
import {Card,CardItem} from 'native-base';
import { RFValue } from "react-native-responsive-fontsize";

//own lib
import strings from './res/strings'
import {logouttask} from './class/logout';
import color from './res/colors'

//constant
const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;
const lightblue=color.values.Colors.lightblue;
const blue=color.values.Colors.blue;
const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;


//common style
const style_common = require('./class/style');

//logout
const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class TagList extends React.Component {
  static navigationOptions = ({ navigation }) => ({ 
    title: "Tag List",
    color:"#fff",
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
      fontSize:RFValue(20)
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false, 
      handlelogin:'',
      dataSource:'',
      pid:'',
      UserID:'',
      pdesc:'',
      cid:'',
      cname:''
    };
}
login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
      this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}
gettagdetail=(index)=>{

  const id=index

  const {tagIDNo}=this.state.dataSource[id]

  this.props.navigation.navigate('TagDetailsActivity',{PID:this.state.pid,UserID:this.state.UserID,TID:tagIDNo
  ,PDesc:this.state.pdesc,CusID:this.state.cid,CusName:this.state.cname
  });

}

gettaglist=()=>{
  const config = {
    headers: {   
    'currentToken': tokken,
  },
    params: {
    pid:this.state.pid,//823
    }
    
  };

  this.setState({isLoading:true})
  axios.get(ip+'/getTagList', config)
  .then(response => this.setState({ dataSource:response.data},() => {if(response.status==200){this.setState({isLoading:false})}}))
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
}


componentDidMount(){
  console.disableYellowBox = true;

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
  
  this.setState({UserID:this.props.navigation.getParam('USER', ''),pid:this.props.navigation.getParam('PID', '')
,pdesc:this.props.navigation.getParam('PDesc', ''),
cid:this.props.navigation.getParam('CusID', ''),
cname:this.props.navigation.getParam('CusName', '')
},()=>{this.gettaglist();})
}
  render() {
    if (this.state.isLoading) {
      return (
        <Modal
        transparent={false}
        supportedOrientations={['portrait', 'landscape']}
        visible={this.state.isLoading}
        >
         <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
           useNativeDriver={true}
           style={style_common.load_gif}
           source={require('./src/gears.gif')}  />
          </View>     
        </Modal>
      )
  }
    return (
  <ScrollView style={{backgroundColor:lightblue}}>
  <Grid style={{paddingTop:'2%'}}>
  <Row style={{backgroundColor:colorprimary,width:'97%',alignSelf:'center',borderRadius:3}}>
  <Text  numberOfLines={2} style={styles.titleText}>
          {this.state.pid+" - "+this.state.pdesc}
  </Text>
   </Row>
   <Divider style={{ backgroundColor:white}} />
   <Divider style={{ backgroundColor:white}} />
   <Row style={{backgroundColor:colorprimary,width:'97%',alignSelf:'center',borderRadius:3}}>
   <Text  style={styles.titleText}>
          {this.state.cid.toString().trim()+" - "+this.state.cname}
  </Text>
  </Row>  
  </Grid>
    <View style={{ flex: 1,paddingTop:5}}>
             <Grid style={{backgroundColor:colorprimary,padding:4,width:"97%",alignSelf:'center'}}>
             <Row>
              <Col style={{alignItems:'flex-start',width:'20%'}}>
              <Text style={styles.textContent}>Tag ID</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'80%'}}>
              <Text style={styles.textContent}>Tag Code</Text>
              </Col> 
             </Row>
             </Grid>
    </View>
    <FlatList
       data={ this.state.dataSource }
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
            <CardItem style={style_common.card_item_padding}>
            <Grid  onPress={() => this.gettagdetail(index)}>
            <Row>
              <Col style={{alignItems:'flex-start',width:'20%'}}>
              <Text style={{fontSize:RFValue(12),fontFamily:'Regular'}}>{item.tagIDNo}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'80%'}}>
              <Text style={{fontSize:RFValue(12),fontFamily:'Regular'}}>{item.tagID}</Text>
              </Col> 
             </Row>
             <View style={{borderBottomColor:'#A9A9A9',borderBottomWidth: 1,height:5,width:'100%',alignSelf:'center'}}/>
            <Row>
              <Col style={{alignItems:'flex-start'}}>
              <Text style={{fontSize:RFValue(12),fontFamily:'Regular'}}>{item.tagDesc}</Text>
              </Col> 
            </Row>

            </Grid>  
             </CardItem>
           </Card>
        }

       keyExtractor={(item, index) => index.toString()}
       
      />

<Toast ref="toast"/>
          </ScrollView>
        )
      }
 };
 const styles = StyleSheet.create({
  titleText: {
    flex:1,
    flexWrap:'wrap',
    color:white,
    fontSize:RFValue(12),
    padding:RFValue(7),
    fontFamily:'Bold'
  },
  textContent:{
    color:white,
    fontSize:RFValue(12),
    fontFamily:'Bold'
  }
  });
  
  
  
import React,{ Component }  from 'react';
import {ScrollView,StyleSheet,View,Modal,TouchableOpacity,Image,Text,Alert} from 'react-native';
import { Col, Grid,Row} from 'react-native-easy-grid';
import RadioGroup from 'react-native-radio-buttons-group';
import axios from 'axios';
import { NavigationActions, StackActions } from 'react-navigation';
import Toast from 'react-native-whc-toast'
import {Card,CardItem,Item,Input} from 'native-base';
import strings from './res/strings'
import color from './res/colors'
import { Divider,Button } from 'react-native-elements';
import {logouttask} from './class/logout';

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;
const lightblue=color.values.Colors.lightblue;
const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;

let selectedButton;
let AppStatus;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

 export default class LeaveApproval extends React.Component {
  static navigationOptions = ({ navigation }) => ({ 
    title: "Leave Approval",
    color:white,
    headerStyle: {
      backgroundColor: colorprimary,
    },
    headerTintColor:white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false, 
      handlelogin:'',
      data:'',
      UserID:'',Comments:'',AppStatus:'',ReqNo:'',ReqDate:'',
      RCenter:'',Dept:'',name:'',desig:'',
      Emp:'',EmpID:'',Desig:'',Sdate:'',Edate:'',Days:'',Remarks:'',Reason:'',Balance:'',ReasonID:'',
      MaxApprovSeq:'',ApprovSeq:'',stdate:'',endate:'',Name:'',
      Comment:'',
      radiovalues: [
        {
            label: 'Approve',
            value: "Approve",
            color:'#2452b2'
        },
        {
            label: 'ReWork',
            value: 'ReWork',
            color:'#2452b2'
        },
      
    ],

    };

}
onPress = radiovalues => this.setState({ radiovalues});

login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
        this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}
getstatus(){
    this.props.navigation.navigate('LeaveApprovalStatusActivity',{UserID:this.state.UserID,LRNo:this.state.ReqNo});
}
submit(){
    switch (selectedButton) {
        case "Approve":
            AppStatus = "A";
            break;
        case "ReWork":
            AppStatus = "W";
            break;
    }
    if(AppStatus!=="A"){
      if(this.state.Comment.length === 0) {
        alert("Please Enter Comment")
        return
      }
    }
    this.Save();
}
Save(){
  this.setState({isLoading:true})
    let url=''
    if(AppStatus==='A'){
     url='/setLeaveApproval'
    }else if(AppStatus==='W'){
     url='/setLeaveRework'
    }  
    axios({
      method: 'post',
      url:ip+url,
      headers: {'currentToken':tokken}, 
      data: {
        LRNo:this.state.ReqNo,       
        UserID:this.state.UserID,  
        EmpID:this.state.EmpID,   
        comments:this.state.Comments,    
        seqno:this.state.ApprovSeq,
        maxseqno:this.state.MaxApprovSeq,     
        reason:this.state.ReasonID,   
        sdate:this.state.stdate,    
        edate:this.state.endate       
      }
    }).then(response=>{if(response.status===200){
      this.setState({isLoading:false},()=>{
        this.refs.toast.showBottom("Success")

        this.props.navigation.goBack();

      })
    }else{
      this.refs.toast.showBottom("Failed")
    }})
    .catch(err => 
      {
        this.setState({
          isLoading:false
        },()=>{
         let error=err
         
         this.refs.toast.showBottom(error.toString())
  
         setTimeout(
          () => { 
            this.props.navigation.goBack();
           },
          2000
        )
  
        })
      }
      );
}
getLeaveAppDetail=()=>{

  const config = {
    headers: {   
    'currentToken':tokken,
  },
    params: {
        LRNo:this.state.ReqNo,
        EmpID:this.state.UserID
    }
    
  };

  this.setState({isLoading:true})
  axios.get(ip+'/getLeaveAppDetail', config)
  .then(response => this.setState({ data:response.data},() => {
      if(response.status==200){
        const {J,N,F,L,B,C,I,K,E,M,D,O,P,Q,S} = this.state.data;
        console.log(this.state.data)
        this.setState({
            ReqDate:J,
            Emp:N,      
            Desig:L,
            Name:F,
            Sdate:B,
            Edate:C,
            Days:I,
            Remarks:K,
            Reason:E,
            Balance:M,
            ApprovSeq:D,
            MaxApprovSeq:O,
            ReasonID:P,
            EmpID:F,
            stdate:Q,
            endate:S,
            isLoading:false
        });
        }}))
        .catch(err => 
          {
            this.setState({
              isLoading:false
            },()=>{
             let error=err
             
             this.refs.toast.showBottom(error.toString())
      
             setTimeout(
              () => { 
                this.props.navigation.goBack();
               },
              2000
            )
      
            })
          }
          );
}

componentDidMount(){
   this.setState({
    UserID:this.props.navigation.getParam('UserID', ''),
    ReqNo:this.props.navigation.getParam('ReqNo', ''),
    RCenter:this.props.navigation.getParam('RCenter', ''),
    Dept:this.props.navigation.getParam('Department', ''),
    name:this.props.navigation.getParam('Name', ''),
    desig:this.props.navigation.getParam('Designation', '')
    },()=>{this.getLeaveAppDetail();})

    console.disableYellowBox = true;

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
}
  render() {
    selectedButton = this.state.radiovalues.find(e => e.selected == true);
    selectedButton = selectedButton ? selectedButton.value : this.state.radiovalues[0].label;   
    if (this.state.isLoading) {
      return (
        <Modal
        transparent={false}
        supportedOrientations={['portrait', 'landscape']}
        visible={this.state.isLoading}
        >
         <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
          style={{width: 300, height: 200}}
          source={require('./src/gears.gif')}  />
          </View>     
        </Modal>
      )
  }
    return (
<ScrollView style={{backgroundColor:lightblue}}>


<View  style={{ flex: 1,paddingTop:'2%'}}>
    <Grid style={{backgroundColor:colorprimary,padding:5,width:"97%",alignSelf:'center',borderRadius:4}}>
             <Row>
             <Col style={{alignItems:'flex-start',width:'100%',paddingLeft:8}}>
             <Text style={styles.textContent}>Leave Details</Text>
             </Col> 
             </Row>
             </Grid>
</View>


<Card style={{width:'97%',alignSelf:'center'}}>
  <CardItem style={{width:'100%',alignItems:'flex-start'}}>
  <Grid>
  <Row style={{paddingTop:2}}>
         <Col style={{alignItems:"flex-start",width:"20%"}}>
          <Text style={styles.tittle} >Req. No - </Text>
          </Col> 
          <Col  style={{alignItems:"flex-start",width:"25%"}}>
          <Text style={{fontSize:13,fontFamily:'Regular'}}>{this.state.ReqNo}</Text>
          </Col> 
          <Col style={{alignItems:"flex-start",width:"30%"}}>
          <Text style={styles.tittle} >Req. Date - </Text>
          </Col> 
          <Col  style={{alignItems:"flex-start",width:"25%"}}>
          <Text style={{fontSize:13,fontFamily:'Regular'}}>{this.state.ReqDate}</Text>
          </Col> 
  </Row>
  <View style={{borderBottomColor:'#A9A9A9',borderBottomWidth: 1,height:5,width:'100%',alignSelf:'center'}}/>
  <Row style={{paddingTop:5}}>
          <Col style={styles.C}>
          <Text style={styles.tittle}>Employee</Text>
          </Col> 
          <Col>
          <Text style={{fontSize:12,fontFamily:'Regular'}}>{this.state.Emp=='undefined'?'':this.state.Emp+" - "
          + this.state.Name=='undefined'?'':this.state.Name}</Text>
          </Col> 
  </Row>
  <Row style={{paddingTop:5}}>
          <Col style={styles.C}>
          <Text style={styles.tittle}>Designation</Text>
          </Col> 
          <Col>
          <Text style={{fontSize:12,fontFamily:'Regular'}}>{this.state.Desig}</Text>
          </Col> 
  </Row>
  <Row style={{paddingTop:5}}>
          <Col style={styles.C}>
          <Text style={styles.tittle}>Start Date</Text>
          </Col> 
          <Col>
          <Text style={{fontSize:12,fontFamily:'Regular'}}>{this.state.Sdate}</Text>
          </Col> 
  </Row>
  <Row style={{paddingTop:5}}>
          <Col style={styles.C}>
          <Text style={styles.tittle}>End Date</Text>
          </Col> 
          <Col>
          <Text style={{fontSize:12,fontFamily:'Regular'}}>{this.state.Edate}</Text>
          </Col> 
  </Row>
  <Row style={{paddingTop:5}}>
          <Col style={styles.C}>
          <Text style={styles.tittle}>No. of days</Text>
          </Col> 
          <Col>
          <Text style={{fontSize:12,fontFamily:'Regular'}}>{this.state.Days}</Text>
          </Col> 
  </Row>
  <Row style={{paddingTop:5}}>
           <Col style={styles.C}>
          <Text style={styles.tittle}>Balance Leave</Text>
          </Col> 
          <Col>
          <Text style={{fontSize:12,fontFamily:'Regular'}}>{this.state.Balance}</Text>
          </Col> 
  </Row>
  <Row style={{paddingTop:5}}>
          <Col style={styles.C}>
          <Text style={styles.tittle}>Reason</Text>
          </Col> 
          <Col>
          <Text style={{fontSize:12,fontFamily:'Regular'}}>{this.state.Reason}</Text>
          </Col> 
  </Row>
  <Row style={{paddingTop:5}}>
         <Col style={styles.C}>
          <Text style={styles.tittle}>Remarks</Text>
          </Col> 
          <Col>
          <Text style={{fontSize:12,fontFamily:'Regular'}}>{this.state.Remarks}</Text>
          </Col> 
  </Row>
</Grid>
  </CardItem>
</Card>
      <Card style={{width:'97%',alignSelf:"center"}}>
          <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
          <Item>
              <Input placeholder="Approval Comments"
                value={this.state.Comment}
                style={{fontFamily:'Regular'}}
                onChangeText={val => this.setState({ Comment: val })}
               />
         </Item>
          </CardItem>
        <CardItem style={{paddingLeft:50}}>       
      <RadioGroup flexDirection='row' radioButtons={this.state.radiovalues} onPress={this.onPress} />
     </CardItem>
    </Card>


<View style={{flexDirection:"row",alignItems:'center',paddingTop:20}}>
<View style={styles.button_1}>
<Button
            title="STATUS"
            containerStyle={{borderRadius:3}}
            titleStyle={{fontFamily:'Bold'}}
            onPress={this.getstatus.bind(this)}
/>
</View>
<View style={styles.button_1}>
<Button
            title="SUBMIT"
            containerStyle={{borderRadius:3}}
            titleStyle={{fontFamily:'Bold'}}
            onPress={this.submit.bind(this)}
          />
</View>
</View>
  
  <Toast ref="toast"
        />
          </ScrollView>
        )
      }
 };
 const styles = StyleSheet.create({
    container: {
      flex: 1,
      alignItems: 'stretch'
    },
    tcenter: {
      flex: 1,
      justifyContent:'flex-start',
      flexDirection: 'column',
      paddingLeft:10,
    },
    content: {
        flex:1,
        flexDirection: 'column',
      },
    image: {
      width: 50,
      height: 50,
      marginTop:5,
    },
    imagebutton: {
      width:80,
      height: 80,
      marginTop:3,
     justifyContent:"center",
     alignItems:"center"
      
    },
    textContent: {
      color:white,
      fontSize:13,
      fontFamily:'Bold'
    },
    textHead: {
        backgroundColor:'#2452b2',
        fontSize: 15,
        paddingTop:3,
        padding:4,
        textAlign:'center',
        color: '#fff',
       fontFamily:'Bold'
      },
    imagetext: {
      fontSize: 12,
      color: '#A0A0A0',
    },
    b: {
      flex: 1,
      alignItems: 'center',
      justifyContent: 'center',
      paddingTop:5,
    },
    Head: {
        flex: 1,
        paddingTop:5,
      },

   tittle:{
    color:'#36428a',
    fontSize:13,
    fontFamily:'Bold',
    paddingLeft:4
   },
   C:{
    alignItems:"flex-start",
    width:'30%'
   },

   text: {
    padding: 15,
    width:100,
    alignSelf:'center',
    color:'#fff',
    backgroundColor:"#1ca0ff"
    ,fontFamily:'Regular'
 },
 fixToText: {
  flexDirection: 'row',
  justifyContent: 'space-between',
},
button_1:{
  width:'45%',
  height:50,
  paddingLeft:'10%'
}
  });
import React, { Component } from 'react';
import {
  StyleSheet, TextInput, Text, View, Image, ImageBackground, KeyboardAvoidingView,
  Dimensions, Alert, TouchableOpacity, Modal, ScrollView
} from 'react-native';
import axios from 'axios';
import { CustomButton } from './custom-button.js';
import strings from './res/strings'
import color from './res/colors'
import { logouttask } from './class/logout';
import { NavigationActions, StackActions } from 'react-navigation';
import Toast from 'react-native-whc-toast';
import { Platform } from 'react-native';

const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);

const ip = strings.values.commonvalues.ip;
const tokken = strings.values.commonvalues.tokken;

const style_common = require('./class/style.js')

const colorprimary = color.values.Colors.colorPrimary;
const white = color.values.Colors.white;
const colorprimarydark = color.values.Colors.colorPrimaryDark;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

var { height, width } = Dimensions.get('window');

export default class ChangePassword extends React.Component {
  static navigationOptions = ({ navigation }) => ({
    title: "Change Password",
    headerStyle: {
      backgroundColor: "#2452b2"
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontFamily: 'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{ paddingRight: 10 }} onPress={() =>
        navigation.state.params.handlelogin()
      }>
        <Image
          style={{ alignSelf: 'center', justifyContent: 'center' }}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),

  });
  constructor(props) {
    super(props);
    this.state = {
      handlelogin: '',
      datasource: '',
      currentpassword: '',
      old: '',
      newpass: '',
      confirm: '',
      isLoading: false,
      UserID: '',
      User: '',
      data: '',
      From: '',
      hidePassword: true,
      hidePassword_Confirm: true,
      hidePassword_current: true,
      layout: {
        height: height,
        width: width
      }
    };

  }

  _onLayout = event => {
    this.setState({
      layout: {
        height: event.nativeEvent.layout.height,
        width: event.nativeEvent.layout.width
      }
    });
  };

  login = async () => {

    Alert.alert(
      'Logout',
      'Would you like to logout?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {
          text: 'OK', onPress: () => {
            logouttask()
            this.props.navigation.dispatch(resetAction);
          }
        },
      ],
      { cancelable: false },
    );

  }
  componentWillMount() {
    console.disableYellowBox = true;

    this.props.navigation.setParams({
      handlelogin: this.login.bind(this)
    });

    this.setState({
      UserID: this.props.navigation.getParam('UserID', ''),
      From: this.props.navigation.getParam('From', ''),
    }, () => {
      this.getcurrentpassword();
    })


  }

  getcurrentpassword() {
    let query;

    if (this.state.From == 'R') {
      query = "select Password from Login where UserID = '" + this.state.UserID.toString() + "'"
    } else {
      query = "SELECT Password FROM EmployeeMaster WHERE EmpID = " + this.state.UserID.toString()
    }
    const config = {
      headers: {
        'currentToken': tokken,
        'oldToken': '',
      },
      params: {
        sqlQuery: query
      }
    };


    this.setState({ isLoading: true })
    axios.get(ip + '/getQuery', config)
      .then(response => this.setState({ data: response.data, isLoading: false }, () => {
        if (response.status == 200) {
          console.log(this.state.data)
          this.setState({ currentpassword: this.state.data.toString() })
        }
      }))
      .catch(err => {
        this.setState({
          isLoading: false
        }, () => {
          let error = err

          this.refs.toast.showBottom(error.toString())

          setTimeout(
            () => {
              this.props.navigation.goBack();
            },
            2000
          )

        })
      }
      );

  }

  onUpdate() {
    const { old, newpass, confirm, currentpassword } = this.state;

    if (old.length == 0) {
      this.refs.toast.showBottom("Please enter current password")
    } else if (currentpassword != old) {
      this.refs.toast.showBottom("Current Password Not Match")
    } else if (newpass.length == 0) {
      this.refs.toast.showBottom("Please enter new password")
    } else if (currentpassword == newpass) {
      this.refs.toast.showBottom("New password cannot be same as old password")
    } else if (confirm.length == 0) {
      this.refs.toast.showBottom("Please enter confirm password")
    } else if (newpass !== confirm) {
      this.refs.toast.showBottom("Incorrect password")
    } else {
      const config = {
        headers: {
          'currentToken': tokken,
          'oldToken': '',
        },
        params: {
          userid: this.state.UserID.toString(),
          pass: newpass.toString(),
          from: this.state.From
        }
      };

      this.setState({ isLoading: true })
      axios.get(ip + '/setPasswordIos', config)
        .then(response => this.setState({ user: response.data, isLoading: false }, () => {
          if (response.status == 200) {
            this.setState({ isLoading: false })
            this.props.navigation.goBack();
          }
        }))
        .catch(err => {
          this.setState({
            isLoading: false
          }, () => {
            let error = err
            this.refs.toast.showBottom(error.toString())
            this.props.navigation.goBack();
          })
        }
        );
    }

  }

  managePasswordVisibility_current = () => {
    this.setState({ hidePassword_current: !this.state.hidePassword_current });
  }

  managePasswordVisibility = () => {
    this.setState({ hidePassword: !this.state.hidePassword });
  }

  managePasswordVisibility_Confirm = () => {
    this.setState({ hidePassword_Confirm: !this.state.hidePassword_Confirm });
  }

  render() {
    if (this.state.isLoading) {
      return (
        <Modal
          transparent={false}
          supportedOrientations={['portrait', 'landscape']}
          visible={this.state.isLoading}
        >
          <View onLayout={this._layout} style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
            <Image
              useNativeDriver={true}
              style={style_common.load_gif}
              source={require('./src/gears.gif')} />
          </View>
        </Modal>
      )
    }

    return (                                            

      <View
        style={styles.container}
        onLayout={this._onLayout}
      >
        <ImageBackground
          source={require('./src/bg.jpg')}
          style={{
            flex: 1,
            resizeMode: 'cover',
            width: this.state.layout.width,
            height: this.state.layout.height,
          }}
        >
          <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
            <View style={styles.contentContainer}>
              <Text style={{ fontSize: 16, color: colorprimarydark, fontFamily: 'Bold',          
                marginVertical: 10,}}>Current Password</Text>
              <View style={styles.textBoxBtnHolder}>
                <TextInput
                  underlineColorAndroid="transparent"
                  value={this.state.old}
                  onChangeText={(old) => this.setState({ old })}
                  placeholder={'Current Password'}
                  length={10}
                  keyboardType={"default"}
                  returnKeyType={"next"}
                  secureTextEntry={this.state.hidePassword_current}
                  style={styles.input}
                  ref='new'
                  onSubmitEditing={() => this.refs.pass.focus()}
                />
                <TouchableOpacity activeOpacity={0.8} style={styles.visibilityBtn} onPress={this.managePasswordVisibility_current}>
                  <Image source={(this.state.hidePassword_current) ? require('./src/hide.png') : require('./src/view.png')} style={styles.btnImage} />
                </TouchableOpacity>
              </View>

              <Text style={{ fontSize: 16, color: colorprimarydark, fontFamily: 'Bold',          
                marginVertical: 10,}}>New Password</Text>
              <View style={styles.textBoxBtnHolder}>
                <TextInput
                  underlineColorAndroid="transparent"
                  value={this.state.newpass}
                  onChangeText={(newpass) => this.setState({ newpass })}
                  placeholder={'New Password'}
                  length={10}
                  keyboardType={"default"}
                  returnKeyType={"next"}
                  secureTextEntry={this.state.hidePassword}
                  style={styles.input}
                  ref='pass'
                  onSubmitEditing={() => this.refs.passc.focus()}
                />
                <TouchableOpacity activeOpacity={0.8} style={styles.visibilityBtn} onPress={this.managePasswordVisibility}>
                  <Image source={(this.state.hidePassword) ? require('./src/hide.png') : require('./src/view.png')} style={styles.btnImage} />
                </TouchableOpacity>
              </View>

              <Text style={{ fontSize: 16, color: colorprimarydark, fontFamily: 'Bold',          
                marginVertical: 10,}}>Confirm Password</Text>
              <View style={styles.textBoxBtnHolder}>
                <TextInput
                  underlineColorAndroid="transparent"
                  value={this.state.confirm}
                  onChangeText={(confirm) => this.setState({ confirm })}
                  placeholder={'Confirm Password'}
                  length={10}
                  keyboardType={"default"}
                  returnKeyType={"done"}
                  secureTextEntry={this.state.hidePassword_Confirm}
                  style={styles.input}
                  ref='passc'
                />
                <TouchableOpacity activeOpacity={0.8} style={styles.visibilityBtn} onPress={this.managePasswordVisibility_Confirm}>
                  <Image source={(this.state.hidePassword_Confirm) ? require('./src/hide.png') : require('./src/view.png')} style={styles.btnImage} />
                </TouchableOpacity>
              </View>

              <CustomButton 
                title="UPDATE"
                onPress={this.onUpdate.bind(this)}
                style={{ backgroundColor: colorprimarydark, marginTop: '3%', marginBottom: '2%' }}
                textStyle={{ fontSize: 13, fontFamily: 'Bold' }} />
            </View>
          </ScrollView>
        </ImageBackground>
        <Toast ref='toast' />
      </View>


    )
  }
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'white',
  },
  contentContainer: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 20,
  },
  input: {
    flex: 1,
    padding: 10,
    borderWidth: 1,
    borderColor: colorprimarydark,
    fontFamily: 'Regular',
    borderRadius: 5,
    fontSize: 16,
    color: '#333',
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
  },
  label: {
    marginVertical: 10,
    fontSize: 16,
    color: '#333',
  },
  textBoxBtnHolder: {
    position: 'relative',
    justifyContent: 'center',
  },
  visibilityBtn: {
    position: 'absolute',
    right: 10,
    height: 40,
    width: 35,
    padding: 5
  },
  btnImage: {
    resizeMode: 'contain',
    height: '100%',
    width: '100%'
  }
});
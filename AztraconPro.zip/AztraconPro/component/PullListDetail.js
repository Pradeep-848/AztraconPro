import React,{ Component }  from 'react';
import {ScrollView,StyleSheet,Text,View,Modal,Image,Dimensions,FlatList,TouchableOpacity,Alert} from 'react-native';
import { Col, Grid, Row } from 'react-native-easy-grid';
import { Divider } from 'react-native-elements';
import axios from 'axios';
import {Card,CardItem} from 'native-base';
import Toast from 'react-native-whc-toast'
import { NavigationActions, StackActions } from 'react-navigation';
import { RFValue } from "react-native-responsive-fontsize";

//own lib
import strings from './res/strings'
import color from './res/colors'
import {logouttask} from './class/logout';
import {isPortrait} from './class/useOrientation'

//constant
const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const blue=color.values.Colors.blue;
const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const lightblue=color.values.Colors.lightblue;

//common style
const style_common = require('./class/style');

//logout
const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});
export default class PullListDetail extends React.Component {
  static navigationOptions = ({ navigation }) => ({ 
    title: "PullList Detail",
    color:color,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
      fontSize:RFValue(20)
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false, 
      dataSource:'',
      handlelogin:'',
      orientation:'',
      DeviceType:'',
      pid:'',UserID:'',pdesc:'',cid:'',cname:'',IssueNo:'',
    };
}

login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
        this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}


getpulllistdetail=()=>{
  const config = {
    headers: {   
    'currentToken': tokken,
  },
    params: {
        IssueNo:this.state.IssueNo,
    }
    
  };

  this.setState({isLoading:true})
  axios.get(ip+'/getPullListDetail', config)
  .then(response => this.setState({ dataSource:response.data},() => {if(response.status==200){this.setState({isLoading:false})}}))
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
}

componentDidMount(){

  console.disableYellowBox = true;

  this.props.navigation.setParams({
    handlelogin: this.login.bind(this)
    });

    Dimensions.addEventListener('change', () => {
      this.setState({
          orientation: isPortrait() ? 'portrait' : 'landscape'
      });
    });
    
  this.setState({
      IssueNo:this.props.navigation.getParam('IssueNo', ''),
      cid:this.props.navigation.getParam('CusID', ''),
      pdesc:this.props.navigation.getParam('PDesc', ''),
      cname:this.props.navigation.getParam('CusName', ''),
      UserID:this.props.navigation.getParam('UserID', ''),
      pid:this.props.navigation.getParam('PID', ''),
      orientation: isPortrait() ? 'portrait' : 'landscape',
      DeviceType:this.props.navigation.getParam('DeviceType', '')
},()=>{this.getpulllistdetail();})
}


getheight(which) {

  let orient=''
  let device=''

  orient = this.state.orientation
  device = this.state.DeviceType

  if(which=='1') { //header
    if(device=='phone'){

      if(orient=='portrait'){
        return '18%'
      }else{
        //landscape
        return '42%'
      }
  
    }else{
      //tab
      if(orient=='portrait'){
        return '15%'
      }else{
         //landscape
         return '20%'
      }
  
    }
  }


  if(which=='2') { //body
    if(device=='phone'){

      if(orient=='portrait'){
        return '82%'
      }else{
        //landscape
        return '58%'
      }
  
    }else{
      //tab
      if(orient=='portrait'){
        return '85%'
      }else{
         //landscape
         return '80%'
      }
  
    }
  }

}
  render() {
    if (this.state.isLoading){
      return (
        <Modal
        transparent={false}
        supportedOrientations={['portrait', 'landscape']}
        visible={this.state.isLoading}
        >
         <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
          useNativeDriver={true}
          style={style_common.load_gif}
          source={require('./src/gears.gif')}  />
          </View>     
        </Modal>
      )
  }
    return (
<View style={{flex:1,backgroundColor:lightblue}}>
<ScrollView style={{height:this.getheight('1')}}>
  <Grid style={{paddingTop:'2%'}}>
  <Row style={{backgroundColor:colorprimary,paddingTop:RFValue(5),width:'97%',alignSelf:'center',borderRadius:4}}>
  <Text numberOfLines={1} style={styles.titleText}>
          {this.state.pid+" - "+this.state.pdesc}
  </Text>
   </Row>
   <Divider style={{ backgroundColor:white}} />
   <Divider style={{ backgroundColor:white}} />
   <Row style={{backgroundColor:colorprimary,paddingTop:RFValue(5),width:'97%',alignSelf:'center',borderRadius:4}}>
   <Text numberOfLines={1} style={styles.titleText}>
          {this.state.cid.toString().trim()+" - "+this.state.cname}
  </Text>
  </Row>  
  </Grid>

  <Grid style={{paddingTop:'2%'}}>
  <Row style={{backgroundColor:colorprimary,width:'97%',alignSelf:'center'}}>
  <Col style={{alignItems:'flex-start',width:'30%'}}>
  <Text style={styles.titleText}>Material</Text>
  </Col>
  <Col style={{alignItems:'flex-start',width:'20%'}}>
  <Text style={styles.titleText}>Pull Qty</Text>
  </Col>
  <Col style={{alignItems:'flex-start',width:'25%'}}>
  <Text style={styles.titleText}>Issue Qty</Text>
  </Col>
  <Col style={{alignItems:'flex-start',width:'25%'}}>
  <Text style={styles.titleText}>Issued Value</Text>
  </Col>
  </Row>
  </Grid>
</ScrollView>
<ScrollView style={{height:this.getheight('2')}}>
    <FlatList
       data={ this.state.dataSource }
       initialNumToRender={this.state.dataSource.length}
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
            <CardItem style={style_common.card_item_padding}>
            <Grid>
            <Row>
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={{fontSize:RFValue(13),fontFamily:'Bold'}}>{item.Material}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'20%'}}>
              <Text style={{fontSize:RFValue(13),fontFamily:'Bold',paddingLeft:'2%'}}>{item.RequestQty}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'25%'}}>
              <Text style={{fontSize:RFValue(13),fontFamily:'Bold',paddingLeft:'8%'}}>{item.IssueQty}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'25%'}}>
              <Text style={{fontSize:RFValue(13),fontFamily:'Bold',paddingLeft:'14%'}}>{item.IssueValue}</Text>
              </Col> 
            </Row>
            <Row style={{paddingTop:RFValue(3)}}>
              <Col style={{alignItems:'center',width:'10%'}}>
              <Text style={{fontSize:RFValue(12),color:colorprimary,fontFamily:'Bold'}}>Type</Text>
              </Col> 
              <Col style={{alignItems:'center',width:'15%'}}>
              <Text style={{fontSize:RFValue(12),fontFamily:'Regular'}}>{item.Type}</Text>
              </Col> 
              <Col style={{alignItems:'center',width:'15%'}}>
              <Text style={{fontSize:RFValue(12),color:colorprimary,fontFamily:'Bold'}}>Length</Text>
              </Col> 
              <Col style={{alignItems:'center',width:'20%'}}>
              <Text style={{fontSize:RFValue(12),fontFamily:'Regular'}}>{item.Length}</Text>
              </Col> 
              <Col style={{alignItems:'center',width:'20%'}}>
              <Text style={{fontSize:RFValue(12),color:colorprimary,fontFamily:'Bold'}}>Heat No</Text>
              </Col> 
              <Col style={{alignItems:'center',width:'20%'}}>
              <Text style={{fontSize:RFValue(12),fontFamily:'Regular'}}>{item.LotNo}</Text>
              </Col> 
            </Row>
             <Row style={{paddingTop:RFValue(3)}}>
              <Col style={{alignItems:'flex-start',width:'25%'}}>
              <Text style={{fontSize:RFValue(13),color:colorprimary,fontFamily:'Bold'}}>Description:</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'75%'}}>
              <Text style={{fontSize:RFValue(12),fontFamily:'Regular'}}>{item.Description}</Text>
              </Col> 
           </Row>
          
            </Grid>  
             </CardItem>
           </Card>
        }
       keyExtractor={(item, index) => index.toString()}
       
      />
  <Toast ref="toast"/>
</ScrollView>
          </View>
        )
      }
 };
 const styles = StyleSheet.create({
  titleText: {
    flex:1,
    flexWrap:'wrap',
    color:white,
    fontSize:RFValue(13),
    padding:5,
    fontFamily:'Bold'
  },
  titleTextH: {
    flex:1,
    flexWrap:'wrap',
    color:white,
    fontSize:RFValue(12),
    padding:3,
    fontFamily:'Regular'
  },
  rowpadding:{
    paddingTop:2
  }
  });
  
  
  
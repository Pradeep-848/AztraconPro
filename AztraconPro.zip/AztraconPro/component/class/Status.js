export function getStatus(Code){

    switch (Code) {
        case "O":
            return "Open";
        case "P":
            return "InProcess";
        case "A":
            return "Approved";
        case "N":
            return "Cancelled";
        case "R":
            return "Rejected";
        case "W":
            return "Rework";
        case "T":
            return "Transfered";
        case "C":
            return "Closed";
        default:
            return "";
    }   
             
}
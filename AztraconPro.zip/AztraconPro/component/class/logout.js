import AsyncStorage from '@react-native-async-storage/async-storage';
import strings from '../res/strings'
import axios from 'axios'
import Login from '../Login';
import Home from '../Home';

const ip = strings.values.commonvalues.ip;
const tokken = strings.values.commonvalues.tokken;

export async function logouttask() {

  try {
    //new Home().dissmissNofication()

    let Uid = await AsyncStorage.getItem('UserID');
    let Aflag = await AsyncStorage.getItem('AFlag');

    if (Uid == '') {
      Uid = Login.getCurrentUser()
    }

    if (Aflag == '') {
      Aflag = Login.getAFlag()
    }

    const config = {
      headers: {
        'currentToken': tokken,
        'deviceType': 'I',
      },
      params: {
        userid: Uid,
        aflag: Aflag
      }

    };

    console.log(config)

    axios.get(ip + '/setLogout', config)
      .then(response => {
        if (response.status == 200) {
        }
      }
      )
  }

  catch (err) {
    console.log(err);
  }
}
'use strict';
import { StyleSheet } from 'react-native';
import { RFValue } from "react-native-responsive-fontsize";

//own library
import color from '../res/colors'
//color codes
const colorprimary=color.values.Colors.colorPrimary;

module.exports = StyleSheet.create({
    ios_search: {
        fontSize:RFValue(14),
        fontFamily:'Bold',
    },

    load_gif:{
        width: RFValue(300), 
        height: RFValue(200)
    },

    bold_listitem:{
        fontSize:RFValue(13),
        fontFamily:'Bold'
    },

    bold_italic_listtotal:{
        fontSize:RFValue(13),
        fontFamily:'ItalicBold'
    },

    italic_list_item:{
        fontSize:RFValue(13),
        fontFamily:'Italic'
    },

    regular_list_item:{
        fontSize:RFValue(12),
        fontFamily:'Regular'
    },

    card_item_padding:{
        alignItems:"flex-start",
        width:'100%',
        lexWrap:'wrap',
        paddingLeft:RFValue(5),
        paddingRight:RFValue(5),
        paddingTop:RFValue(5),
        paddingBottom:RFValue(5)
    },

    row_padding:{
        paddingTop:RFValue(1),
        paddingBottom:RFValue(1)
    }
});
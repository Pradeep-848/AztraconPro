export function format(amount,tag) {
    
    if(tag=='N'){
        return amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }else{
        return amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }
    
}

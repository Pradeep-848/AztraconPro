import * as React from 'react';
import { WebView } from 'react-native-webview';

let html=''

export function  getHtmlDoc(url) {

    let htmlhead = '<!DOCTYPE html><html><head><title>Document Viewer</title><meta charset="UTF-8" /></head>'
    let htmlbody = '<body> <iframe  src="'+url+'"  style="border:none;" height="2000" width="100%"></iframe></body></html>'
    
    //https://drive.google.com/file/d/1kJJeabYl-NH4nsNV8kLs-qTUYESbUfMx/preview

   //  html ='<html><a class="instructure_file_link instructure_scribd_file auto_open" title="file.pdf" href='+url+'>File Name</a></html>'
     html = htmlhead + htmlbody

    return html

}
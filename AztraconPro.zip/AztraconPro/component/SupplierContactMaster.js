import React, { Component } from 'react';
import { TouchableOpacity, TouchableWithoutFeedback, Linking, Platform, ScrollView, Alert, StyleSheet, Text, View, Image, Modal, FlatList } from 'react-native';
import { Col, Grid, Row } from 'react-native-easy-grid';
import { SearchBar, Divider } from 'react-native-elements';
import axios from 'axios';
import { NavigationActions, StackActions } from 'react-navigation';
import Toast from 'react-native-whc-toast'
import sms from 'react-native-sms-linking'
import * as Contacts from 'expo-contacts';
//import * as Permissions from 'expo-permissions';
import { Card, CardItem } from 'native-base';
import strings from './res/strings'
import { logouttask } from './class/logout';
import color from './res/colors'

const ip = strings.values.commonvalues.ip;
const tokken = strings.values.commonvalues.tokken;

const lightblue = color.values.Colors.lightblue;
const blue = color.values.Colors.blue;
const colorprimary = color.values.Colors.colorPrimary;
const white = color.values.Colors.white;
const black = color.values.Colors.black;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});


export default class SupplierContactMaster extends React.Component {
  static navigationOptions = ({ navigation }) => ({
    title: "Supplier Contact",
    color: white,
    headerStyle: {
      backgroundColor: colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily: 'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{ paddingRight: 10 }} onPress={() =>
        navigation.state.params.handlelogin()
      }>
        <Image
          style={{ alignSelf: 'center', justifyContent: 'center' }}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),

  });
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      dataSource: [],
      handlelogin: '',
      data: '',
      UserID: '', SupID: '', sname: ''
    };
    this.arrayholder = [];
  }

  login = async () => {

    Alert.alert(
      'Logout',
      'Would you like to logout?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {
          text: 'OK', onPress: () => {
            logouttask()
            this.props.navigation.dispatch(resetAction);
          }
        },
      ],
      { cancelable: false },
    );

  }

  getcontactlist() {
    const config = {
      headers: {
        'currentToken': tokken,
      },
      params: {
        supid: this.state.SupID,
      },
    };
    this.setState({ isLoading: true })
    axios.get(ip + '/getSupContactlist', config)
      .then(response => this.setState({ dataSource: response.data }, () => {
        if (response.status == 200) {
          this.arrayholder = this.state.dataSource;
          this.setState({ isLoading: false })
        }
      }))
      .catch(err => {
        this.setState({
          isLoading: false
        }, () => {
          let error = err

          this.refs.toast.showBottom(error.toString())

          setTimeout(
            () => {
              this.props.navigation.goBack();
            },
            2000
          )

        })
      }
      );

  }
  SearchFilterFunction(text) {
    const newData = this.arrayholder.filter(function (item) {
      const itemData = item.CusCode.toUpperCase() + item.CusName.toUpperCase()
      const textData = text.toUpperCase()
      return itemData.indexOf(textData) > -1
    })
    this.setState({
      dataSource: newData,
      text: text
    })
  }

  componentDidMount() {


    this.setState({
      isLoading: true
    })

    console.disableYellowBox = true;

    const { navigation } = this.props;


    this.focusListener = navigation.addListener("didFocus", () => {


      this.setState({
        SupID: this.props.navigation.getParam('SupID', ''),
        SupName: this.props.navigation.getParam('SupName', ''),
        UserID: this.props.navigation.getParam('UserID', ''),
      }, () => {
        this.props.navigation.setParams({
          handlelogin: this.login.bind(this)
        });
        this.getcontactlist()

      })

    });



  }

  call(ID) {

    let index = ID
    const { sPhone } = this.state.dataSource[index]

    if (Platform.OS === 'android') {
      Linking.openURL('tel:${' + sPhone.toString() + '}');
    }
    else {
      Linking.openURL('telprompt:${' + sPhone.toString() + '}');
    }
  }
  sms(ID) {

    let index = ID

    const { sMobile } = this.state.dataSource[index]

    sms(sMobile.toString(), 'Hi friend').catch(console.error)
  }
  email(ID) {

    let index = ID

    const { sEmail } = this.state.dataSource[index]

    console.log('mail')
    Linking.openURL('mailto:' + sEmail.toString() + '?subject=hi&body=hi')
    title = "support@example.com"
  }

  // contact(ID){

  //    let index=ID

  //    const{sMobile,sCode,sCName}=this.state.dataSource[index]


  //   const { status } =  Permissions.askAsync(Permissions.CONTACTS);

  //   if (status === 'granted') {

  //     const contact = {
  //       [Contacts.Fields.FirstName]:sCode ,
  //       [Contacts.Fields.LastName]: sCName ,
  //       [Contacts.Fields.PhoneNumbers]:sMobile
  //       }
  //       try{
  //       const contactId =  Contacts.addContactAsync(contact);
  //       console.log(contactId);
  //       if(contactId){
  //       alert("Contact Saved")
  //       }
  //       else{
  //       alert("Contact not saved.")
  //       }}
  //       catch(err){
  //       alert("Contact not saved.")
  //       }

  //   }

  // }

  contact = async (ID) => {
    let index = ID;
    const { sMobile, sCode, sCName } = this.state.dataSource[index]

    // Request permission to access contacts
    const { status } = await Contacts.requestPermissionsAsync();

    if (status === 'granted') {
      const contact = {
        [Contacts.Fields.FirstName]: sCode,
        [Contacts.Fields.LastName]: sCName,
        [Contacts.Fields.PhoneNumbers]: sMobile
      };

      try {
        const contactId = await Contacts.addContactAsync(contact);
        console.log(contactId);
        if (contactId) {
          alert("Contact Saved");
        } else {
          alert("Contact not saved.");
        }
      } catch (err) {
        alert("Contact not saved.");
      }
    } else {
      alert('Permission to access contacts was denied');
    }
  };

  render() {
    if (this.state.isLoading) {
      return (
        <Modal
          transparent={false}
          supportedOrientations={['portrait', 'landscape']}
          visible={this.state.isLoading}
        >
          <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
            <Image
              style={{ width: 300, height: 200 }}
              source={require('./src/gears.gif')} />
          </View>
        </Modal>
      )
    }
    return (
      <View style={{ flex: 1, backgroundColor: lightblue }}>
        <ScrollView style={{ height: '16%' }}>
          <Grid style={{ paddingTop: '2%' }}>
            <Row style={{ backgroundColor: colorprimary, width: '97%', alignSelf: 'center', borderRadius: 4 }}>
              <Text numberOfLines={1} style={styles.titleText}>
                {this.state.SupID.toString().trim() + " - " + this.state.SupName}
              </Text>
            </Row>
            <Divider style={{ backgroundColor: white }} />
            <Divider style={{ backgroundColor: white }} />
          </Grid>
          <SearchBar
            style={{ paddingTop: 1 }}
            placeholder="Search Supplier ID/Name"
            onChangeText={(text) => this.SearchFilterFunction(text)}
            value={this.state.text}
            searchIcon={{ name: "search", size: 19, color: colorprimary }}
            clearIcon={{ name: "close-circle", size: 19 }}
            loadingProps={{ size: "small" }}
            platform={'ios'}
          />
        </ScrollView>
        <ScrollView style={{ height: '84%' }}>
          <FlatList
            data={this.state.dataSource}
            initialNumToRender={this.state.dataSource.length}
            renderItem={({ item, index }) =>
              <Card style={{ width: '97%', alignSelf: 'center' }}>
                <CardItem style={{
                  alignItems: "flex-start", width: '100%', flexWrap: 'wrap',
                  paddingLeft: 5, paddingRight: 5, paddingTop: 10, paddingBottom: 10
                }}>
                  <Grid>

                    <Row>
                      <Col style={{ alignItems: 'flex-start', width: "100%" }}>
                        <Text style={styles.values}>{item.sConCode.toString().trim()}</Text>
                      </Col>
                    </Row>

                    <Row>
                      <Col style={{ alignItems: 'flex-start', width: "40%" }}>
                        <Text style={styles.values}>{item.sConName}</Text>
                      </Col>
                      <Col style={{ alignItems: 'flex-start', width: "20%" }}>
                        <Text style={styles.values}>{item.sPhone}</Text>
                      </Col>
                      <Col style={{ alignItems: 'flex-start', width: "10%" }}>
                        <TouchableWithoutFeedback onPress={() => this.call(index)}>
                          <Image
                            style={styles.imagebutton}
                            source={require('./src/tm_call.png')}></Image>
                        </TouchableWithoutFeedback>
                      </Col>
                      <Col style={{ alignItems: 'flex-start', width: "10%" }}>
                        <TouchableWithoutFeedback onPress={() => this.sms(index)}>
                          <Image
                            style={styles.imagebutton}
                            source={require('./src/tm_sms.png')}></Image>
                        </TouchableWithoutFeedback>
                      </Col>
                      <Col style={{ alignItems: 'flex-start', width: "10%" }}>
                        <TouchableWithoutFeedback onPress={() => this.email(index)}>
                          <Image
                            style={styles.imagebutton}
                            source={require('./src/tm_email.png')}></Image>
                        </TouchableWithoutFeedback>
                      </Col>
                      <Col style={{ alignItems: 'flex-start', width: "10%" }}>
                        <TouchableOpacity activeOpacity={.5} onPress={() => this.contact(index)}>
                          <Image
                            style={styles.imagebutton}
                            source={require('./src/tm_save_contact.png')}></Image>
                        </TouchableOpacity>
                      </Col>
                    </Row>
                    <Row>
                      <Col style={{ alignItems: 'flex-start', width: "50%" }}>
                        <Text style={styles.values}>{item.sDesig}</Text>
                      </Col>
                      <Col style={{ alignItems: 'flex-start', width: "30%" }}>
                        <Text style={styles.values}>{item.sPhone}</Text>
                      </Col>

                    </Row>
                    <Row>
                      <Col style={{ alignItems: 'flex-start', width: "50%" }}>
                        <Text style={styles.values}>{item.sEmail}</Text>
                      </Col>
                      <Col style={{ alignItems: 'flex-start', width: "50%" }}>
                        <Text style={styles.values}>{item.sMobile}</Text>
                      </Col>
                    </Row>
                  </Grid>

                </CardItem>
              </Card>
            }
            keyExtractor={(item, index) => index.toString()}
          />
        </ScrollView>
        <Toast ref="toast" />
      </View>
    )
  }
};
const styles = StyleSheet.create({
  tittle: {
    color: '#36428a',
    fontSize: 13
  },
  values: {
    color: '#708090',
    fontSize: 12,
    fontFamily: 'Regular'
  },
  imagebutton: {
    width: 30,
    height: 30,
  },
  titleText: {
    flex: 1,
    flexWrap: 'wrap',
    color: white,
    fontSize: 12,
    padding: 5,
    fontFamily: 'Bold'
  },
});



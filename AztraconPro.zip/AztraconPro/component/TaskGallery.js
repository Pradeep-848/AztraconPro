import React, { Component } from "react";
import {
  ScrollView,
  Modal,
  StyleSheet,
  Text,
  View,
  Image,
  Dimensions,
  FlatList,
  TouchableOpacity,
  Alert,
} from "react-native";
import { Col, Grid, Row } from "react-native-easy-grid";
import { Button, Divider } from "react-native-elements";
import { NavigationActions, StackActions } from "react-navigation";
import * as ImagePicker from "expo-image-picker";
import * as FileSystem from "expo-file-system";
import { Pressable } from "react-native";
import axios from "axios";
import Toast from "react-native-whc-toast";
import { Card, CardItem, Item, Form, Icon, Picker } from "native-base";
import { RFValue } from "react-native-responsive-fontsize";
import SelectDropdown from "react-native-select-dropdown";

//own lib
import { logouttask } from "./class/logout";
import strings from "./res/strings";
import color from "./res/colors";
import { TextInput } from "react-native-gesture-handler";
import base64 from "react-native-base64";
import { isPortrait } from "./class/useOrientation";
import * as Device from "expo-device";
import { DeviceType, getDeviceTypeAsync } from "expo-device";

//constant
const ip = strings.values.commonvalues.ip;
const tokken = strings.values.commonvalues.tokken;

const colorprimary = color.values.Colors.colorPrimary;
const grey = color.values.Colors.greydark;
const dark = color.values.Colors.colorPrimaryDark;
const white = color.values.Colors.white;
const black = color.values.Colors.black;
const red = color.values.Colors.red;
const lightblue = color.values.Colors.lightblue;

//common style
const style_common = require("./class/style");

//logout
const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: "LoginActivity" })],
});

export default class TaskGallery extends React.Component {
  static navigationOptions = ({ navigation }) => ({
    title: "Task Gallery",
    color: white,
    headerStyle: {
      backgroundColor: colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily: "Bold",
      fontSize: RFValue(20),
    },
    headerRight: (
      <TouchableOpacity
        style={{ paddingRight: 10 }}
        onPress={() => navigation.state.params.handlelogin()}
      >
        <Image
          style={{ alignSelf: "center", justifyContent: "center" }}
          source={require("./src/logout.png")}
        />
      </TouchableOpacity>
    ),
  });

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      isLoading1: false,
      handlelogin: "",
      dataSource: [],
      siteSource: [],
      pickerstatus: "",
      PID: "",
      USER: "",
      pdesc: "",
      cid: "",
      cname: "",
      UserID: "",
      imageUri: "",
      description: "",
      orientation: "",
      DeviceType: "",
      previewImageUri: "", // URI for image preview
      showPreviewModal: false,
    };
    this.saveImage = this.saveImage.bind(this);
    this.captureImage = this.captureImage.bind(this);
  }

  login = async () => {
    Alert.alert(
      "Logout",
      "Would you like to logout?",
      [
        {
          text: "Cancel",
          onPress: () => console.log("Cancel Pressed"),
          style: "cancel",
        },
        {
          text: "OK",
          onPress: () => {
            logouttask();
            this.props.navigation.dispatch(resetAction);
          },
        },
      ],
      { cancelable: false }
    );
  };

  getsite() {
    const config = {
      headers: {
        currentToken: tokken,
      },
      params: {
        sqlQuery:
          "SELECT TagID, TagIDNo FROM ProjectTags WHERE ProjectID = '" +
          this.state.PID +
          "'",
      },
    };

    console.log(this.state.PID);

    this.setState({ isLoading: true });
    axios
      .get(ip + "/getSpinnerData", config)
      .then(response => {
        console.log('API Response:', response.data); // Log response data
        if (response.status === 200) {
          // Map API response to required format
          const mappedData = response.data.map(item => ({
            TagID: item.sCode,      // Mapping sCode to TagID
            TagIDNo: item.sDesc     // Mapping sDesc to TagIDNo
          }));
          this.setState({ siteSource: mappedData, isLoading: false });
        } else {
          this.setState({ isLoading: false });
        }
      })
      .catch((err) => {
        this.setState(
          {
            isLoading: false,
          },
          () => {
            let error = err;

            this.refs.toast.showBottom(error.toString());

            setTimeout(() => {
              this.props.navigation.goBack();
            }, 2000);
          }
        );
      });
  }

  // pickImage = async () => {
  //     try {
  //         let result = await ImagePicker.launchImageLibraryAsync({
  //             mediaTypes: ImagePicker.MediaTypeOptions.Images,
  //             allowsEditing: true,
  //             aspect: [4, 3],
  //             quality: 1,
  //         });

  //         if (!result.canceled) {

  //             console.log('Image selected:');
  //         } else {
  //             console.log('Image selection canceled');
  //         }
  //     } catch (error) {
  //         console.error('Error picking image');
  //     }
  // };

  captureImage = async () => {
    try {
      const { status } = await ImagePicker.requestCameraPermissionsAsync();
      if (status !== "granted") {
        Alert.alert("Camera permission not granted");
        return;
      }

      let result = await ImagePicker.launchCameraAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 1,
      });

      if (!result.canceled) {
        console.log("Image captured:", result.assets[0].uri); // Update this line
        this.setState({ imageUri: result.assets[0].uri }); // Update this line
      } else {
        console.log("Image capture canceled");
      }
    } catch (error) {
      console.error("Error capturing image:", error);
    }
  };

  fetchImageUrl = async (imageID) => {
    try {
      // Fetch the image data using axios
      const response = await axios.get(`${ip}/getGalleryImage`, {
        params: {
          ProjectID: this.state.PID,
          ImageID: imageID,
        },
        responseType: "arraybuffer", // Use arraybuffer to get binary data
        headers: {
          currentToken: tokken,
        },
      });

      // Convert the response to a base64 string in chunks to avoid memory issues
      const binary = new Uint8Array(response.data);
      let base64String = "";
      for (let i = 0; i < binary.length; i += 1024) {
        base64String += String.fromCharCode.apply(
          null,
          binary.slice(i, i + 1024)
        );
      }
      const base64Image = base64.encode(base64String);
      const imageUrl = `data:image/png;base64,${base64Image}`;

      this.setState({
        previewImageUri: imageUrl,
        showPreviewModal: true,
        isLoading1: false,
      });
    } catch (error) {
      console.error("Error fetching image:", error);
      Alert.alert("Error", "Unable to fetch image.");
    }
  };

  saveImage = async () => {
    if (!this.state.imageUri) {
      //Alert.alert('No image selected', 'Please capture an image first');
      return;
    }

    if (!this.state.pickerstatus) {
      //Alert.alert('No TagID selected', 'Please select a TagID');
      return;
    }

    const base64Image = await FileSystem.readAsStringAsync(
      this.state.imageUri,
      {
        encoding: FileSystem.EncodingType.Base64,
      }
    );

    const config = {
      headers: {
        currentToken: tokken,
        "Content-Type": "application/json", // Set the content type for JSON data
      },
    };

    // const deviceModel = deviceType;

    const deviceModel = Device.modelName;

    const data = {
      image: base64Image,
      project: this.state.PID,
      tagid: this.state.pickerstatus,
      desc: this.state.description, // Send description
      empid: this.state.USER,
      itype: "I", // Update as needed
      device: deviceModel, // Update as needed
    };

    console.log(data);

    axios
      .post(ip + "/setTaskPhoto", data, config) // Changed to POST request
      .then((response) => {
        console.log(response);
        if (response.status === 200) {
          this.getTaskGallery();

          const newDataSource = [...this.state.dataSource];
          this.setState({
            dataSource: newDataSource,
            isLoading: false,
            imageUri: "", // Clear image after save
            pickerstatus: "", // Reset picker status
            description: "", // Reset description
            USER: this.state.USER,
          });
          Alert.alert("Success", "Data saved successfully");
        }
      })
      .catch((err) => {
        this.setState(
          {
            isLoading: false,
            isLoading1: false,
          },
          () => {
            let error = err;
            this.refs.toast.showBottom(error.toString());
            setTimeout(() => {
              this.props.navigation.goBack();
            }, 2000);
          }
        );
      });
  };

  getTaskGallery = () => {
    const config = {
      headers: {
        currentToken: tokken,
      },
      params: {
        pid: this.state.PID,
      },
    };

    this.setState({ isLoading: true });
    axios
      .get(ip + "/getTaskGallery", config)
      .then((response) => {
        console.log(response);
        if (response.status === 200) {
          this.setState({
            dataSource: response.data,
            isLoading: false,
          });
        }
      })
      .catch((err) => {
        this.setState(
          {
            isLoading: false,
          },
          () => {
            let error = err;
            this.refs.toast.showBottom(error.toString());
            setTimeout(() => {
              this.props.navigation.goBack();
            }, 2000);
          }
        );
      });
  };

  componentDidMount() {
    console.disableYellowBox = true;

    Dimensions.addEventListener("change", () => {
      this.setState({
        orientation: isPortrait() ? "portrait" : "landscape",
      });
    });

    this.setState(
      {
        PID: this.props.navigation.getParam("PID", ""),
        cid: this.props.navigation.getParam("CusID", ""),
        pdesc: this.props.navigation.getParam("PDesc", ""),
        cname: this.props.navigation.getParam("CusName", ""),
        USER: this.props.navigation.getParam("USER", ""),
        orientation: isPortrait() ? "portrait" : "landscape",
        DeviceType: this.props.navigation.getParam("DeviceType", ""),
      },
      () => {
        this.getTaskGallery();
        this.saveImage();
        this.getsite();
      }
    );

    this.props.navigation.setParams({
      handlelogin: this.login.bind(this),
    });
  }

  getheight(which) {
    let orient = "";
    let device = "";

    orient = this.state.orientation;
    device = this.state.DeviceType;

    if (which == "1") {
      //header
      if (device == "phone") {
        if (orient == "portrait") {
          return "12%";
        } else {
          //landscape
          return "30%";
        }
      } else {
        //tab
        if (orient == "portrait") {
          return "18%";
        } else {
          //landscape
          return "17%";
        }
      }
    }

    if (which == "2") {
      //body
      if (device == "phone") {
        if (orient == "portrait") {
          return "88%";
        } else {
          //landscape
          return "70%";
        }
      } else {
        //tab
        if (orient == "portrait") {
          return "82%";
        } else {
          //landscape
          return "83%";
        }
      }
    }
  }

  render() {
    const isSaveDisabled = !this.state.imageUri || !this.state.pickerstatus;

    //const isSaveDisabled = !this.state.imageUri;

    if (this.state.isLoading) {
      return (
        <Modal
          transparent={false}
          supportedOrientations={["portrait", "landscape"]}
          visible={this.state.isLoading}
        >
          <View
            style={{ flex: 1, alignItems: "center", justifyContent: "center" }}
          >
            <Image
              useNativeDriver={true}
              style={style_common.load_gif}
              source={require("./src/gears.gif")}
            />
          </View>
        </Modal>
      );
    } else if (this.state.isLoading1) {
      return (
        <Modal
          transparent={true}
          supportedOrientations={["portrait", "landscape"]}
          visible={this.state.isLoading1}
          onRequestClose={() => this.setState({ isLoading1: false })}
        >
          <View style={styles.modalBackground}>
            <View>
              <Image
                style={styles.loadingImage}
                source={require("./src/gears1.gif")} // Ensure the path is correct
              />
            </View>
          </View>
        </Modal>
      );
    }

    return (
      <View style={{ flex: 1, backgroundColor: lightblue }}>
        <ScrollView style={{ height: this.getheight("1") }}>
          <Grid style={{ paddingTop: "2%" }}>
            <Row
              style={{
                backgroundColor: colorprimary,
                width: "97%",
                alignSelf: "center",
                borderRadius: 3,
              }}
            >
              <Text numberOfLines={1} style={styles.titleText}>
                {this.state.PID + "-" + this.state.pdesc}
              </Text>
            </Row>
            <Divider style={{ backgroundColor: white }} />
            <Divider style={{ backgroundColor: white }} />
            <Row
              style={{
                backgroundColor: colorprimary,
                width: "97%",
                alignSelf: "center",
                borderRadius: 3,
              }}
            >
              <Text numberOfLines={1} style={styles.titleText}>
                {this.state.cid.toString().trim() + "-" + this.state.cname}
              </Text>
            </Row>
          </Grid>
        </ScrollView>

        <ScrollView style={{ height: this.getheight("2") }}>
          <Card
            style={{
              borderRadius: RFValue(4),
              width: "97%",
              alignSelf: "center",
              borderBottomColor: colorprimary,
            }}
          >
            <CardItem style={style_common.card_item_padding}>
              <Grid>
                {/* Image Display Section */}
                <Row style={{ marginTop: 20 }}>
                  <Col
                    style={{ alignItems: "center", width: "100%" }}
                    onPress={() => this.captureImage()}
                  >
                    {this.state.imageUri ? (
                      <Image
                        source={{ uri: this.state.imageUri }}
                        style={styles.capturedImage}
                      />
                    ) : (
                      <Image
                        source={require("./src/placeholder.jpg")}
                        style={styles.capturedImage}
                      />
                    )}
                  </Col>
                </Row>

                <Row>
                  <Form
                    style={{
                      flex: 1,
                      alignItems: "flex-start",
                      fontFamily: "Regular",
                    }}
                  >
                    <Item
                      style={{ marginLeft: 0, height: 45, width: "100%" }}
                      picker
                    >
                      <SelectDropdown
                        data={
                          Array.isArray(this.state.siteSource)
                            ? this.state.siteSource.map((item) => ({
                                title: item.TagIDNo + " " + item.TagID,
                                value: item.TagIDNo,
                              }))
                            : []
                        }
                        onSelect={(selectedItem, index) => {
                          console.log("Selected Item:", selectedItem.value);
                          this.setState(
                            { pickerstatus: selectedItem.value },
                            () => {
                              this.state.pickerstatus;
                            }
                          );
                        }}
                        renderButton={(isOpened) => {
                          const data = Array.isArray(this.state.siteSource)
                            ? this.state.siteSource.map((item) => ({
                                title: item.TagIDNo + " " + item.TagID,
                                value: item.TagIDNo,
                              }))
                            : [];

                          const buttonText = this.state.pickerstatus
                            ? data.find(
                                (item) => item.value === this.state.pickerstatus
                              )?.title
                            : "Select Tag ID";

                          return (
                            <View style={styles.dropdownButtonStyle}>
                              <Text
                                style={{
                                  flex: 1,
                                  fontSize: 16,
                                  color: "black",
                                }}
                              >
                                {buttonText}
                              </Text>
                              <Icon
                                name={isOpened ? "chevron-up" : "chevron-down"}
                                style={{
                                  fontSize: 20,
                                  color: colorprimary,
                                }}
                              />
                            </View>
                          );
                        }}
                        renderItem={(item, index, isSelected) => {
                          return (
                            <View
                              style={{
                                ...styles.dropdownItemStyle,
                                ...(isSelected && {
                                  backgroundColor: "#D2D9DF",
                                }),
                              }}
                            >
                              <Text
                                style={{
                                  fontSize: 16,
                                  color: "black",
                                }}
                              >
                                {item.title}
                              </Text>
                            </View>
                          );
                        }}
                        showsVerticalScrollIndicator={false}
                        dropdownStyle={{
                          borderRadius: 8,
                          borderWidth: 1,
                          borderColor: "#ccc",
                          backgroundColor: "#fff",
                        }}
                      />
                    </Item>

                    <Item style={{ marginLeft: 0, height: 45 }} picker>
                      <TextInput
                        style={{
                          height: 40,
                          borderColor: "gray",
                          borderBottomWidth: 1,
                          width: "100%",
                        }}
                        placeholder="Enter description"
                        onChangeText={(text) =>
                          this.setState({ description: text })
                        }
                        value={this.state.description}
                      />
                    </Item>
                  </Form>
                </Row>
              </Grid>
            </CardItem>
          </Card>

          <Grid
            style={{
              padding: 4,
              width: "97%",
              alignSelf: "center",
              paddingBottom: 5,
            }}
          >
            <Row>
              <Col style={{ alignItems: "center", width: "50%" }}>
                <Button
                  onPress={() => this.captureImage()}
                  raised={true}
                  titleStyle={{
                    fontSize: 15,
                    textAlign: "center",
                    fontFamily: "Bold",
                  }}
                  buttonStyle={{
                    flex: 1,
                    borderRadius: 6,
                    width: 120,
                    height: 45,
                  }}
                  title=" Camera "
                />
              </Col>
              <Col style={{ alignItems: "center", width: "50%" }}>
                <Button
                  onPress={() => {
                    this.setState({ isLoading: true }, this.saveImage);
                  }}
                  disabled={isSaveDisabled}
                  raised={true}
                  titleStyle={{
                    fontSize: 15,
                    textAlign: "center",
                    fontFamily: "Bold",
                  }}
                  buttonStyle={{
                    flex: 1,
                    borderRadius: 6,
                    width: 120,
                    height: 45,
                  }}
                  title=" Save "
                />
              </Col>
            </Row>
          </Grid>

          <Modal
            visible={this.state.showPreviewModal}
            transparent={true}
            supportedOrientations={["portrait", "landscape"]}
            animationType="slide"
            onRequestClose={() => this.setState({ showPreviewModal: false })}
          >
            <View style={styles.modalContainer}>
              <Pressable
                style={styles.closeButton}
                onPress={() => this.setState({ showPreviewModal: false })}
              >
                <Text style={styles.closeButtonText}>Close</Text>
              </Pressable>
              {this.state.isLoading1 ? (
                <Text>Loading...</Text>
              ) : this.state.previewImageUri ? (
                <Image
                  source={{ uri: this.state.previewImageUri }}
                  style={styles.previewImage}
                />
              ) : (
                <Text>No image to display</Text>
              )}
            </View>
          </Modal>

          {/* Loading Bar Issue for Background Data Component */}
          {/* <Modal
                        visible={this.state.showPreviewModal}
                        transparent={true}
                        supportedOrientations={['portrait', 'landscape']}
                        animationType="slide"
                        onRequestClose={() => this.setState({ showPreviewModal: false })}
                    >
                        <View style={styles.modalContainer}>
                            <Pressable
                                style={styles.closeButton}
                                onPress={() => this.setState({ showPreviewModal: false })}
                            >
                                <Text style={styles.closeButtonText}>Close</Text>
                            </Pressable>

                            {this.state.isLoading1 && !this.state.previewImageUri ? (
                                // Show the loading animation while isLoading1 is true or previewImageUri is not available
                                <View style={styles.modalBackground}>
                                    <View>
                                        <Image
                                            style={styles.loadingImage}
                                            source={require('./src/gears1.gif')} // Ensure the path is correct
                                        />
                                    </View>
                                </View>
                            ) : (
                                // Show the preview image when isLoading1 is false and previewImageUri is available
                                <Image source={{ uri: this.state.previewImageUri }} style={styles.previewImage} />
                            )}
                        </View>
                    </Modal> */}

          <Grid
            style={{
              backgroundColor: colorprimary,
              padding: RFValue(7),
              width: "97%",
              alignSelf: "center",
              borderRadius: 4,
            }}
          >
            <Row>
              <Col style={{ alignItems: "flex-start", width: "30%" }}>
                <Text style={styles.textContent}>ImageID</Text>
              </Col>
              <Col style={{ alignItems: "flex-start", width: "35%" }}>
                <Text style={styles.textContent}>Description</Text>
              </Col>
            </Row>
          </Grid>

          <FlatList
            data={this.state.dataSource}
            renderItem={({ item, index }) => (
              <Card style={{ width: "97%", alignSelf: "center" }}>
                <CardItem
                  style={{
                    alignItems: "flex-start",
                    width: "100%",
                    flexWrap: "wrap",
                    paddingLeft: 5,
                    paddingRight: 5,
                    paddingTop: 5,
                    paddingBottom: 5,
                  }}
                >
                  <TouchableOpacity
                    onPress={() => {
                      this.setState({ isLoading1: true }, () =>
                        this.fetchImageUrl(item.ImageID)
                      );
                    }}
                  >
                    <Grid>
                      <Row>
                        <Col
                          style={{
                            alignItems: "flex-start",
                            width: "20%",
                            marginBottom: "2%",
                            marginTop: "2%",
                          }}
                        >
                          <Text
                            style={{
                              fontSize: 13,
                              fontFamily: "Bold",
                              color: colorprimary,
                            }}
                          >
                            {item.ImageID}
                          </Text>
                        </Col>
                        <Col
                          style={{
                            alignItems: "flex-start",
                            width: "70%",
                            marginBottom: "2%",
                            marginTop: "2%",
                            marginLeft: "5%",
                          }}
                        >
                          <Text style={{ fontSize: 13, fontFamily: "Italic" }}>
                            {item.Description}
                          </Text>
                        </Col>
                      </Row>
                      <Divider />
                      <Row style={{ paddingTop: 3, paddingBottom: 3 }}>
                        <Col
                          style={{
                            alignItems: "flex-start",
                            width: "20%",
                            marginBottom: "2%",
                            marginTop: "2%",
                          }}
                        >
                          <Text
                            style={{
                              fontSize: 13,
                              fontFamily: "Bold",
                              color: colorprimary,
                            }}
                          >
                            Created By :{" "}
                          </Text>
                        </Col>
                        <Col
                          style={{
                            alignItems: "flex-start",
                            width: "80%",
                            marginBottom: "2%",
                            marginTop: "2%",
                            marginLeft: "3%",
                          }}
                        >
                          <Text
                            style={{
                              fontSize: 13,
                              fontFamily: "Italic",
                              textAlign: "left",
                            }}
                          >
                            {item.UserID}
                          </Text>
                        </Col>
                      </Row>
                      <Row style={{ paddingTop: 3, paddingBottom: 3 }}>
                        <Col style={{ alignItems: "flex-start", width: "20%" }}>
                          <Text
                            style={{
                              fontSize: 13,
                              fontFamily: "Bold",
                              color: colorprimary,
                            }}
                          >
                            Created On :{" "}
                          </Text>
                        </Col>
                        <Col
                          style={{
                            alignItems: "flex-start",
                            width: "80%",
                            marginLeft: "2%",
                          }}
                        >
                          <Text
                            style={{
                              fontSize: 13,
                              fontFamily: "Italic",
                              textAlign: "left",
                            }}
                          >
                            {item.SysDate}
                          </Text>
                        </Col>
                      </Row>
                    </Grid>
                  </TouchableOpacity>
                </CardItem>
              </Card>
            )}
            keyExtractor={(item, index) => index.toString()}
          />

          <Toast ref="toast" />
        </ScrollView>
      </View>
    );
  }
}
const styles = StyleSheet.create({
  titleText: {
    flex: 1,
    flexWrap: "wrap",
    color: white,
    fontSize: RFValue(12),
    padding: RFValue(8),
    fontFamily: "Bold",
  },
  button: {
    width: "30%",
    backgroundColor: "green",
    padding: 10,
    borderRadius: 10,
  },
  btnText: {
    color: "white",
    textAlign: "center",
  },
  buttons: {
    flexDirection: "row",
    justifyContent: "space-around",
    gap: 10,
  },
  textContent: {
    color: white,
    fontSize: 12,
    fontFamily: "Bold",
  },
  capturedImage: {
    width: 200,
    height: 150,
    resizeMode: "contain",
  },
  containerPortrait: {
    flex: 1,
    backgroundColor: white,
    padding: 10,
  },
  containerLandscape: {
    flex: 1,
    backgroundColor: white,
    padding: 10,
    flexDirection: "row",
  },
  scrollViewPortrait: {
    flex: 1,
  },
  scrollViewLandscape: {
    flex: 1,
  },
  closeButton: {
    padding: 10,
    borderRadius: 5,
    position: "absolute",
    top: 20,
    right: 20,
    backgroundColor: "red",
  },
  closeButtonText: {
    color: white,
    fontSize: RFValue(15),
    fontFamily: "Bold",
  },
  modalContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#00000080",
  },
  previewImage: {
    width: "90%",
    height: "70%",
    borderRadius: 10,
    resizeMode: "contain",
  },
  modalBackground: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#00000080",
  },
  loadingImage: {
    width: 100, // Adjust as needed
    height: 100, // Adjust as needed
  },
  dropdownButtonStyle: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 10,
    paddingVertical: 12,
    backgroundColor: "#fff",
  },
  dropdownItemStyle: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 10,
    paddingHorizontal: 15,
  },
});

import React,{ Component }  from 'react';
import {ScrollView,Modal,StyleSheet,Text,View,Image,Dimensions,FlatList,Alert,TouchableOpacity} from 'react-native';
import { Col, Grid, Row } from 'react-native-easy-grid';
import { Divider } from 'react-native-elements';
import axios from 'axios';
import {Card,CardItem} from 'native-base';
import strings from './res/strings'
import color from './res/colors'
import Toast from 'react-native-whc-toast'
import * as Font from 'expo-font'

const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const blue=color.values.Colors.blue;
const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const lightblue=color.values.Colors.lightblue;

 export default class PODetail extends React.Component {
  static navigationOptions = ({ navigation }) => ({ 
    title: "PO Detail",
    color:color,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false, 
      dataSource:'',
      handlelogin:'',
      pid:'',UserID:'',pdesc:'',cid:'',cname:'',pono:'',
    };
}

login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
      this.props.navigation.navigate('LoginActivity');} },
    ],
    {cancelable: false},
  );
 
}

getPODetail=()=>{
  const config = {
    headers: {   
    'currentToken': tokken,
  },
    params: {
        pono:this.state.pono,
    }
    
  };

  this.setState({isLoading:true})
  axios.get(ip+'/getPODetail', config)
  .then(response => this.setState({ dataSource:response.data},() => {if(response.status==200){this.setState({isLoading:false})}}))
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
}

async componentWillMount(){
  await Font.loadAsync({
    'Regular': require('./res/font/Sansation_Regular.ttf'),
    'Bold': require('./res/font/Sansation_Bold.ttf'),
    'Italic': require('./res/font/Sansation_Italic.ttf')
})
}


componentDidMount(){

  
  console.disableYellowBox = true;

  this.props.navigation.setParams({
    handlelogin: this.login.bind(this)
    });

  this.setState({
      pid:this.props.navigation.getParam('PID', ''),
      cid:this.props.navigation.getParam('CusID', ''),
      pdesc:this.props.navigation.getParam('PDesc', ''),
      cname:this.props.navigation.getParam('CusName', ''),
      UserID:this.props.navigation.getParam('UserID', ''),
      pono:this.props.navigation.getParam('PONo', '')
},()=>{this.getPODetail();})
}
  render() {
    if (this.state.isLoading){
      return (
        <Modal
        transparent={false}
        supportedOrientations={['portrait', 'landscape']}
        visible={this.state.isLoading}
        >
         <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
           useNativeDriver={true}
          style={{width: 300, height: 200}}
          source={require('./src/gears.gif')}  />
          </View>     
        </Modal>
      )
  }
    return (

<View style={{flex:1,backgroundColor:lightblue}}>
<ScrollView style={{height:'13%'}}>
  <Grid style={{paddingTop:'2%'}}>
  <Row style={{backgroundColor:colorprimary,width:'97%',alignSelf:'center',borderRadius:3}}>
  <Text numberOfLines={1} style={styles.titleText}>
          {this.state.pid+" - "+this.state.pdesc}
  </Text>
   </Row>
   <Divider style={{ backgroundColor:white}} />
   <Divider style={{ backgroundColor:white}} />
   <Row style={{backgroundColor:colorprimary,width:'97%',alignSelf:'center',borderRadius:3}}>
   <Text numberOfLines={1} style={styles.titleText}>
          {this.state.cid.toString().trim()+" - "+this.state.cname}
  </Text>
  </Row>  
  </Grid>

  <View  style={{ flex: 1,paddingTop:5,paddingBottom:5}}>
    <Grid style={{backgroundColor:colorprimary,padding:4,width:"97%",alignSelf:'center'}}>
             <Row>
             <Col style={{alignItems:'flex-start',width:'25%'}}>
             <Text style={styles.textContent}>SNo.</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'50%'}}>
             <Text style={styles.textContent}>Type</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'25%'}}>
             <Text style={styles.textContent}>Item Code</Text>
             </Col> 
             </Row>
             </Grid>
    </View>
</ScrollView>
<ScrollView style={{height:'87%'}}>
    <FlatList
       data={ this.state.dataSource }
       initialNumToRender={this.state.dataSource.length}
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
        paddingLeft:5,paddingRight:5,paddingTop:10,paddingBottom:10}}>
            <Grid>
            <Row>
              <Col style={{alignItems:'flex-start',width:'23%'}}>
              <Text style={{fontSize:13,fontFamily:'Regular'}}>{item.SlNo}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,fontFamily:'Regular'}}>{item.MaterialDesc}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'27%'}}>
              <Text style={{fontSize:13,fontFamily:'Regular'}}>{item.ItemCode}</Text>
              </Col> 
             </Row>
             <View style={{borderBottomColor:'#A9A9A9',borderBottomWidth: 1,height:5,width:'100%',alignSelf:'center'}}/>
            <Row>
              <Col style={{alignItems:'flex-start',width:'100%'}}>
              <Text style={{fontSize:13,fontFamily:'Regular'}}>{item.Description}</Text>
              </Col> 
            </Row>
            <View style={{borderBottomColor:'#A9A9A9',borderBottomWidth: 1,height:5,width:'100%',alignSelf:'center'}}/>
            <Row>
              <Col style={{alignItems:'center',width:'30%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Quantity</Text>
              </Col> 
              <Col style={{alignItems:'center',width:'30%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Total Value</Text>
              </Col> 
              <Col style={{alignItems:'center',width:'40%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Received</Text>
              </Col> 
            </Row>
           <Row>
           <Col style={{alignItems:'center',width:'30%'}}>
              <Text style={{fontSize:13,fontFamily:'Italic'}}>{item.RequiredQty}</Text>
              </Col> 
              <Col style={{alignItems:'center',width:'30%'}}>
              <Text style={{fontSize:13,fontFamily:'Italic'}}>{item.TotalValue}</Text>
              </Col> 
              <Col style={{alignItems:'center',width:'40%'}}>
              <Text style={{fontSize:13,fontFamily:'Italic'}}>{item.ReceivedQty}</Text>
              </Col> 
           </Row>
            </Grid>  
             </CardItem>
           </Card>
        }
       keyExtractor={(item, index) => index.toString()}
       
      />
     <Toast ref="toast"/>
          </ScrollView>
          </View>
        )
      }
 };
 const styles = StyleSheet.create({
  titleText: {
    flex:1,
    flexWrap:'wrap',
    color:white,
    fontSize:12,
    padding:5,
    fontFamily:'Bold'
  },
  textContent:{
    color:white,
    fontSize:12,
    fontFamily:'Bold'
  }
  });
  
  
  
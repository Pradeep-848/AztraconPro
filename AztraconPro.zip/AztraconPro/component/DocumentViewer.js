import React, { Component } from 'react';
import { Text, View, StyleSheet,YellowBox,TouchableOpacity,Image,
    Alert, 
    StatusBar} from 'react-native';
import { WebView } from 'react-native-webview';
import { Constants } from 'expo';
import {logouttask} from './class/logout';
import {getHtmlDoc} from './class/HtmlDoc'
import strings from './res/strings'
import color from './res/colors'

const blue=color.values.Colors.blue;
const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const black=color.values.Colors.black;
const colorPrimaryDark=color.values.Colors.colorPrimaryDark;
const lightgray=color.values.Colors.greydark;

export default class DocumentViewer extends Component {
  onNavigationStateChange = navState => {
    if (navState.url.indexOf('https://www.google.com') === 0) {
      const regex = /#access_token=(.+)/;
      let accessToken = navState.url.match(regex)[1];
      console.log(accessToken);
    }
  };

  static navigationOptions = ({ navigation }) => ({ 
    title: "Document Viewer",
  
    color:white,
    headerStyle: {
      color:colorprimary,
      backgroundColor:colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center',resizeMode:'contain'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });

  constructor(props) {
    super(props);
    this.state = {
        URL:'',
        isLoading: false,   
        handlelogin:'',
    };
}

login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
      this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}
  componentDidMount(){

    YellowBox.ignoreWarnings([
        'VirtualizedLists should never be nested', // TODO: Remove when fixed
      ])
      
      console.disableYellowBox = true;
    
      this.props.navigation.setParams({
        handlelogin: this.login.bind(this)
        });

  this.setState({
    URL:this.props.navigation.getParam('URL', '') })
  }

  render() {

    const html = getHtmlDoc(this.state.URL)

    return (
      <WebView
        // source={{
        //   uri: this.state.URL,
        // }}

        source={{ html: html }}
        onNavigationStateChange={this.onNavigationStateChange}
        startInLoadingState
        scalesPageToFit
        javaScriptEnabled
        style={{ flex:1, height: 600}}
      />
     );
 }
    
}

import React, { Component } from 'react';
import {
  ScrollView, Modal, StyleSheet, Text, Dimensions, View, TextInput, Image, FlatList,
  TouchableOpacity, Alert, ImageBackground
} from 'react-native';
import { Row, Col, Grid } from 'react-native-easy-grid';
import Toast from 'react-native-whc-toast'
import axios from 'axios';
import { NavigationActions, StackActions } from 'react-navigation';
import { Card, CardItem } from 'native-base';
import { logouttask } from './class/logout';
import strings from './res/strings'
import colors from './res/colors'
import { Divider } from 'react-native-elements';
import { RFPercentage, RFValue } from "react-native-responsive-fontsize";

const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);

const dark = colors.values.Colors.colorPrimaryDark;
const primary = colors.values.Colors.colorPrimary;
const colorPrimaryDark = colors.values.Colors.colorPrimaryDark;

const ip = strings.values.commonvalues.ip;
const tokken = strings.values.commonvalues.tokken;

//common style
const style_common = require('./class/style');

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

var { height, width } = Dimensions.get("window");

export default class EmployeeProfile extends React.Component {

  static navigationOptions = ({ navigation }) => ({
    title: "Profile",
    color: "#fff",
    headerStyle: {
      backgroundColor: "#2452b2",
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontFamily: 'Bold',
      fontSize: RFValue(20)
    },
    headerRight: (
      <TouchableOpacity style={{ paddingRight: 10 }} onPress={() =>
        navigation.state.params.handlelogin()
      }>
        <Image
          style={{ alignSelf: 'center', justifyContent: 'center' }}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),

  });


  constructor(props) {
    super(props);
    this.state = {
      handlelogin: '',
      username: '',
      Designation: '',
      USER: '',
      isLoading: false,
      data: '',
      dataSource: '',
      Name: '',
      desig: '',
      dept: '',
      Email: '',
      DOB: '',
      DOJ: '',
      timesche: '',
      Gender: '',
      passno: '',
      pexpdate: '',
      iqamano: '',
      iexpdate: '',
      Mobile: '',
      country: '',
      hcardno: '',
      hcarddate: '',
      medical: '',
      iban: '',
      status: '',
      layout: {
        height: height,
        width: width
      }
    };

  }

  _onLayout = event => {
    this.setState({
      layout: {
        height: event.nativeEvent.layout.height,
        width: event.nativeEvent.layout.width
      }
    });
  };

  login = async () => {

    Alert.alert(
      'Logout',
      'Would you like to logout?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {
          text: 'OK', onPress: () => {
            logouttask()
            this.props.navigation.dispatch(resetAction);
          }
        },
      ],
      { cancelable: false },
    );

  }


  getProfile = () => {

    console.log(this.state.USER)
    const config = {
      headers: {
        'currentToken': tokken,
      },
      params: {
        empid: this.state.USER,
      }

    };

    this.setState({ isLoading: true })
    axios.get(ip + '/getEmpProfile', config)
      .then(response => this.setState({ data: response.data }, () => { if (response.status == 200) { this.pendinglist() } }))
      .catch(err => {

        this.setState({
          isLoading: false
        }, () => {
          let error = err

          this.refs.toast.showBottom(error.toString())

          setTimeout(
            () => {
              this.props.navigation.goBack();
            },
            2000
          )

        })


      }
      );
  }
  pendinglist = () => {
    const config = {
      headers: {
        'currentToken': tokken,
      },
      params: {
        empid: this.state.USER,
      }

    };

    axios.get(ip + '/getPendingTS', config)
      .then(response => this.setState({ dataSource: response.data }, () => {
        if (response.status == 200) {
          const { Name, desig, dept, Email, DOB, DOJ, timesche, Gender, passno, pexpdate, iqamano, iexpdate, Mobile, country, hcardno, hcarddate, medical, iban, status } = this.state.data;
          this.setState({ Name: Name, desig: desig, dept: dept, Email: Email, DOB: DOB, DOJ: DOJ, timesche: timesche, Gender: Gender, passno: passno, pexpdate: pexpdate, iqamano: iqamano, iexpdate: iexpdate, Mobile: Mobile, country: country, hcardno: hcardno, hcarddate: hcarddate, medical: medical, iban: iban, status: status });
          this.setState({ isLoading: false });
        }
      }))
      .catch(err => {
        this.setState({
          isLoading: false
        }, () => {
          let error = err
          this.refs.toast.showBottom(error.toString())
          this.props.navigation.goBack();
        })
      }
      );

  }

  componentDidMount() {

    console.disableYellowBox = true;

    this.setState({ username: this.props.navigation.getParam('Name', ''), Designation: this.props.navigation.getParam('Designation', ''), USER: this.props.navigation.getParam('UserID', '') }, () => { this.getProfile(); })

    this.props.navigation.setParams({
      handlelogin: this.login.bind(this)
    });

  }
  render() {
    if (this.state.isLoading) {
      return (
        <Modal
          transparent={false}
          supportedOrientations={['portrait', 'landscape']}
          visible={this.state.isLoading}
        >
          <View onLayout={this._onLayout} style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
            <Image
              useNativeDriver={true}
              style={style_common.load_gif}
              source={require('./src/gears.gif')} />
          </View>
        </Modal>
      )
    }
    return (
      <View
        style={{ flex: 1 }}
        onLayout={this._onLayout}
      >
        <ImageBackground
          source={require('./src/aztracon_bg.jpg')}
          style={{
            height: this.state.layout.height,
            width: this.state.layout.width,
          }}
        >

          <ScrollView style={{ flexGrow: 1 }}>

            <Text style={styles.textContent}>
              Personal Information
            </Text>

            <View style={{ flexDirection: 'row', width: '98%', alignSelf: 'center' }}>
              <View style={{ backgroundColor: dark, height: 2, flex: 1, alignSelf: 'center' }} />
              <View style={{ backgroundColor: dark, height: 2, flex: 1, alignSelf: 'center' }} />
            </View>

            <Grid>
              <Row>

                <Col style={{ width: '15%' }}>
                  <Row>
                    <Col style={{ width: '100%' }}>
                      <Image source={require('./src/ic_prof1.png')} style={styles.image} />
                    </Col>
                  </Row>
                </Col>
                <Col style={{ width: '85%' }}>
                  <Row style={{ paddingTop: '1%', paddingBottom: '1%' }}>
                    <Col style={{ width: '100%' }}>
                      <Text adjustsFontSizeToFit numberOfLines={1} style={{ paddingLeft: 5, fontFamily: 'Bold', fontSize: RFValue(14), color: colorPrimaryDark }}>{this.state.username}</Text>
                    </Col>
                  </Row>
                  <Row style={{ paddingTop: '1%', paddingBottom: '1%' }}>
                    <Col style={{ width: '100%' }}>
                      <Text adjustsFontSizeToFit numberOfLines={1} style={{ paddingLeft: 5, fontFamily: 'Bold', fontSize: RFValue(14), color: colorPrimaryDark }}>{this.state.Designation}</Text>
                    </Col>
                  </Row>
                </Col>

              </Row>
              <Row>
                <Col>

                </Col>
              </Row>
            </Grid>

            <View style={{ borderBottomColor: '#36428a', borderBottomWidth: 1, paddingTop: '1%', width: '98%', alignSelf: 'center' }} />



            <Grid style={{ paddingTop: '1%', paddingBottom: '1%' }}>
              <Col style={{ alignItems: 'center' }}>
                <Text style={{ color: '#36428a', fontFamily: 'Bold', fontSize: RFValue(14) }}>Date of Birth</Text>
                <Text style={styles.detail}>{this.state.DOB}</Text>
              </Col>
              <Col style={{ alignItems: 'center' }}>
                <Text style={{ color: '#36428a', fontFamily: 'Bold', fontSize: RFValue(14) }}>Date of Join</Text>
                <Text style={styles.detail}>{this.state.DOJ}</Text>
              </Col>
              <Col style={{ alignItems: 'center' }}>
                <Text style={{ color: '#36428a', fontFamily: 'Bold', fontSize: RFValue(14) }}>Gender</Text>
                <Text style={styles.detail}>{this.state.Gender}</Text>
              </Col>
            </Grid>

            <View style={{ borderBottomColor: '#36428a', borderBottomWidth: 1, height: 10, width: '98%', alignSelf: 'center' }} />

            <Grid style={{ width: '97%', alignSelf: 'center', paddingTop: '1%' }}>
              <Col style={{ width: '40%' }}>
                <Text style={styles.tittle} >Department</Text>
              </Col>
              <Col style={{ width: '60%' }}>
                <Text style={styles.detail}>{this.state.dept}</Text>
              </Col>
            </Grid>

            <Grid style={{ width: '97%', alignSelf: 'center', paddingTop: '1%' }}>
              <Col style={{ width: '40%' }}>
                <Text style={styles.tittle}>Time Schedule</Text>
              </Col>
              <Col style={{ width: '60%' }}>
                <Text adjustsFontSizeToFit style={styles.detail}>{this.state.timesche}</Text>
              </Col>
            </Grid>

            <View style={{ borderBottomColor: '#36428a', borderBottomWidth: 1, height: 10, width: '98%', alignSelf: 'center' }} />

            <Grid style={{ width: '97%', alignSelf: 'center', paddingTop: '1%' }}>
              <Col style={{ width: '40%' }}>
                <Text style={styles.tittle}>Passport No</Text>
              </Col>
              <Col style={{ width: '60%' }}>
                <Text style={styles.detail}>{this.state.passno}</Text>
              </Col>
            </Grid>


            <Grid style={{ width: '97%', alignSelf: 'center', paddingTop: '1%' }}>
              <Col style={{ width: '40%' }}>
                <Text style={styles.tittle}>Expiry Date</Text>
              </Col>
              <Col style={{ width: '60%' }}>
                <Text style={styles.detail}>{this.state.pexpdate.trim()}</Text>
              </Col>
            </Grid>


            <View style={{ borderBottomColor: '#36428a', borderBottomWidth: 1, height: 10, width: '98%', alignSelf: 'center' }} />

            <Grid style={{ width: '97%', alignSelf: 'center', paddingTop: '1%' }}>
              <Col style={{ width: '40%' }}>
                <Text style={styles.tittle}>IBAN</Text>
              </Col>
              <Col style={{ width: '60%' }}>
                <Text style={styles.detail}>{this.state.iban}</Text>
              </Col>
            </Grid>

            <Grid style={{ width: '97%', alignSelf: 'center', paddingTop: '1%' }}>
              <Col style={{ width: '40%' }}>
                <Text style={styles.tittle}>IQAMA No.</Text>
              </Col>
              <Col style={{ width: '60%' }}>
                <Text style={styles.detail}>{this.state.iqamano}</Text>
              </Col>
            </Grid>

            <Grid style={{ width: '97%', alignSelf: 'center', paddingTop: '1%' }}>
              <Col style={{ width: '40%' }}>
                <Text style={styles.tittle}>Expiry Date</Text>
              </Col>
              <Col style={{ width: '40%' }}>
                <Text style={styles.detail}>{this.state.iexpdate}</Text>
              </Col>
            </Grid>

            <Grid style={{ width: '97%', alignSelf: 'center', paddingTop: '1%' }}>
              <Col style={{ width: '40%' }}>
                <Text style={styles.tittle}>Country</Text>
              </Col>
              <Col style={{ width: '40%' }}>
                <Text style={styles.detail}>{this.state.country}</Text>
              </Col>
            </Grid>

            <Grid style={{ width: '97%', alignSelf: 'center', paddingTop: '1%' }}>
              <Col style={{ width: '40%' }}>
                <Text style={styles.tittle}>HealthCard No.</Text>
              </Col>
              <Col style={{ width: '40%' }}>
                <Text style={styles.detail}>{this.state.hcardno}</Text>
              </Col>
            </Grid>

            <Grid style={{ width: '97%', alignSelf: 'center', paddingTop: '1%' }}>
              <Col style={{ width: '40%' }}>
                <Text style={styles.tittle}>HC Expiry Date</Text>
              </Col>
              <Col style={{ width: '40%' }}>
                <Text style={styles.detail}>{this.state.hcarddate}</Text>
              </Col>
            </Grid>

            <Grid style={{ width: '97%', alignSelf: 'center', paddingTop: '1%' }}>
              <Col style={{ width: '40%' }}>
                <Text style={styles.tittle}>Medical Class</Text>
              </Col>
              <Col style={{ width: '40%' }}>
                <Text style={styles.detail}>{this.state.medical}</Text>
              </Col>
            </Grid>

            <Grid style={{ width: '97%', alignSelf: 'center', paddingTop: '1%' }}>
              <Col style={{ width: '40%' }}>
                <Text style={styles.tittle}>Current Status</Text>
              </Col>
              <Col style={{ width: '40%' }}>
                <Text style={styles.detail}>{this.state.status}</Text>
              </Col>
            </Grid>

            <View style={{ borderBottomColor: '#36428a', borderBottomWidth: 1, height: 10, width: '98%', alignSelf: 'center' }} />

            <Grid style={{ width: '97%', alignSelf: 'flex-start', paddingTop: '1%', height: '15%' }}>
              <Row>
                <Col style={{ width: '100%', alignItems: 'center', alignSelf: 'center' }}>
                  <Text adjustsFontSizeToFit style={{ textAlign: 'center', fontSize: RFValue(13), paddingTop: 2, fontFamily: 'Bold' }}>{this.state.Email}</Text>
                </Col>
                <Col style={{ width: '100%', alignItems: 'center', alignSelf: 'center' }}>
                  <Text adjustsFontSizeToFit style={{ textAlign: 'center', fontSize: RFValue(13), paddingTop: 2, fontFamily: 'Bold' }}>{this.state.Mobile}</Text>
                </Col>
              </Row>
            </Grid>


            <View style={{ borderBottomColor: '#36428a', borderBottomWidth: 1, height: 10, width: '98%', alignSelf: 'center' }} />


            <View style={{ display: this.state.dataSource.length == 0 ? 'none' : 'flex' }}>


              <Text style={styles.textHead}> Pending TimeSheet</Text>

              <View style={styles.Head}>
                <Grid>
                  <Col style={{ alignItems: 'flex-start', width: '20%', backgroundColor: '#2452b2' }}>
                    <Text style={{ color: '#fff', fontSize: 13, padding: 4, paddingLeft: 20, fontFamily: 'Regular' }}>SNo</Text>
                  </Col>
                  <Col style={{ alignItems: 'flex-start', width: '50%', backgroundColor: '#2452b2' }}>
                    <Text style={{ color: '#fff', fontSize: 13, padding: 4, paddingLeft: 20, fontFamily: 'Regular' }}>Date</Text>
                  </Col>
                  <Col style={{ alignItems: 'flex-start', width: '30%', backgroundColor: '#2452b2' }}>
                    <Text style={{ color: '#fff', fontSize: 13, padding: 4, paddingLeft: 20, fontFamily: 'Regular' }}>Day</Text>
                  </Col>
                </Grid>
              </View>

              <FlatList
                data={this.state.dataSource}
                renderItem={({ item }) =>
                  <Card style={{ width: '96%', alignSelf: 'center' }}>
                    <CardItem style={{ alignItems: "flex-start", width: '100%', flexWrap: 'wrap' }}>
                      <Grid>
                        <Col style={{ alignItems: 'flex-start', width: "20%" }}>
                          <Text style={{ fontSize: RFValue(12), fontFamily: 'Regular' }}>{item.SNo}</Text>
                        </Col>
                        <Col style={{ alignItems: 'flex-start', width: '50%' }}>
                          <Text style={{ fontSize: RFValue(12), fontFamily: 'Regular' }}>{item.EntryDate}</Text>
                        </Col>
                        <Col style={{ alignItems: 'flex-start', width: '30%' }}>
                          <Text style={{ fontSize: RFValue(12), fontFamily: 'Regular' }}>{item.DayName}</Text>
                        </Col>
                      </Grid>
                    </CardItem>
                  </Card>
                }

                keyExtractor={(item, index) => index.toString()}

              />


            </View>
            <Toast ref="toast"
            />
          </ScrollView>

        </ImageBackground>
      </View>
    )
  }
};
const styles = StyleSheet.create({
  imageStyle: {
    width: screenWidth,
    height: screenHeight,

  },
  container: {
    flex: 1,
    alignItems: 'stretch'
  },
  tcenter: {
    flex: 1,
    justifyContent: 'flex-start',
    flexDirection: 'column',
    paddingLeft: 10,
  },
  content: {
    flex: 1,
    flexDirection: 'column',
  },
  image: {
    width: '100%',
    height: '100%',
    alignSelf: 'center',
    resizeMode: 'contain',
    marginTop: RFValue(2),
    marginBottom: RFValue(2)
  },
  imagebutton: {
    width: 80,
    height: 80,
    marginTop: 3,
    justifyContent: "center",
    alignItems: "center"

  },
  textContent: {
    backgroundColor: '#fff',
    fontSize: RFValue(18),
    padding: RFValue(8),
    textAlign: 'center',
    color: '#36428a',
    fontFamily: 'Bold',
    textShadowColor: 'rgba(0, 0, 0, 0.75)',
    textShadowOffset: { width: -1, height: 1 },
    textShadowRadius: 10
  },
  textHead: {
    backgroundColor: '#2452b2',
    fontSize: 15,
    paddingTop: 3,
    padding: 4,
    width: '98%',
    alignSelf: 'center',
    textAlign: 'center',
    color: '#fff',
    fontWeight: 'bold',
  },
  imagetext: {
    fontSize: 12,
    color: '#A0A0A0',
  },
  b: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: '1%',
  },
  Head: {
    width: "98%",
    flex: 1,
    paddingTop: 5,
    alignSelf: 'center'
  },

  tittle: {
    color: '#36428a',
    fontSize: RFValue(13),
    paddingLeft: 5,
    fontFamily: 'Bold'
  },
  C: {
    alignItems: "flex-start",
    width: 150
  },
  detail: {
    fontSize: RFValue(13),
    fontFamily: 'Bold'
  }
});


import React from 'react';
import {Dimensions,Image,Modal,SectionList,StyleSheet,Text,View,TouchableOpacity,AsyncStorage,Alert} from 'react-native';
import axios from 'axios';
import { Col, Grid, Row} from 'react-native-easy-grid';
import { Divider } from 'react-native-elements'
import {Card,CardItem} from 'native-base';
import { NavigationActions, StackActions } from 'react-navigation';
import { ScrollView } from 'react-native-gesture-handler';
import Toast from 'react-native-whc-toast'
import { RFValue } from "react-native-responsive-fontsize";

//own lib
import strings from './res/strings'
import color from './res/colors'
import {logouttask} from './class/logout';
import {isPortrait} from './class/useOrientation'

//constant 
const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const blue=color.values.Colors.skyblue;
const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const lightblue=color.values.Colors.lightblue;

//common style
const style_common = require('./class/style');

//logout
const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class Drawings extends React.Component{
  static navigationOptions = ({ navigation }) => ({ 
    title: "Drawings",
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor:white,
    headerTitleStyle: {
      fontFamily:'Bold',
      fontSize:RFValue(20),
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
      super(props);
      this.state = { 
        isLoading: true, 
        handlelogin:'',
        data: "",
        orientation:'',
        DeviceType:'',
        pid:'',UserID:'',pdesc:'',cid:'',cname:''
    };
      console.disableYellowBox = true;
  }
 
login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
      this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}

getheight(which){
  
  let orient=''
  let device=''

  orient = this.state.orientation
  device = this.state.DeviceType

  if(which=='1') { //header
    if(device=='phone'){

      if(orient=='portrait'){
        return '8%'
      }else{
        //landscape
        return '23%'
      }
  
    }else{
      //tab
      if(orient=='portrait'){
        return '10%'
      }else{
         //landscape
         return '18%'
      }
  
    }
  }


  if(which=='2') { //body
    if(device=='phone'){

      if(orient=='portrait') {
        return '92%'
      } else {
        //landscape
        return '77%'
      }
  
    }else{
      //tab
      if(orient=='portrait') {
        return '90%'
      } else {
         //landscape
         return '82%'
      }
  
    }
  }

}

componentDidMount() {

  console.disableYellowBox = true;

  this.props.navigation.setParams({
    handlelogin: this.login.bind(this)
    });
  
    Dimensions.addEventListener('change', () => {
      this.setState({
          orientation: isPortrait() ? 'portrait' : 'landscape'
      });
    });

   this.setState({
      pid:this.props.navigation.getParam('PID', ''),
      cid:this.props.navigation.getParam('CusID', ''),
      pdesc:this.props.navigation.getParam('PDesc', ''),
      cname:this.props.navigation.getParam('CusName', ''),
      UserID:this.props.navigation.getParam('UserID', ''),
      orientation: isPortrait() ? 'portrait' : 'landscape',
      DeviceType:this.props.navigation.getParam('DeviceType', '')
    },()=>{this.getdrawing();})
}


getdrawing(){
  console.log(this.state.pid)
    const config = {
      headers: {   
      'currentToken':tokken,
    },
      params: {
      pid:this.state.pid,
      }
    };

axios.get(ip+'/getDrawingsCatIos', config)
  .then(response => this.setState({data:response.data},() => {if(response.status==200){
   this.setState({isLoading:false});
  }
}))
.catch(err => 
  {
    this.setState({
      isLoading:false
    },()=>{
     let error=err
     
     this.refs.toast.showBottom(error.toString())

     setTimeout(
      () => { 
        this.props.navigation.goBack();
       },
      2000
    )

    })
  }
  );
}

  renderItem(item) {    
      const {DWGID,DrawingNo,RevisionNo,TagClass,FileName,Status} = item.item;
      return (
               <Card style={{width:'97%',alignSelf:'center'}}>
               <CardItem style={style_common.card_item_padding}>
               <Grid>
                 <Row>
                 <Col style={{alignItems:'flex-start',width:'20%'}}>
                 <Text style={{fontSize:RFValue(13),color:colorprimary,fontFamily:'Bold'}}>Dwg ID - </Text>
                 </Col>
                 <Col style={{alignItems:'flex-start',width:'25%'}}>
                 <Text style={{fontSize:RFValue(13),fontFamily:'Italic'}}>{DWGID}</Text>
                 </Col>
                 <Col style={{alignItems:'flex-start',width:'25%'}}>
                 <Text style={{fontSize:RFValue(13),color:colorprimary,fontFamily:'Bold'}}>Revision No - </Text>
                 </Col>
                 <Col style={{alignItems:'flex-start',width:'30%'}}>
                <Text style={{fontSize:RFValue(13),fontFamily:'Italic'}}>{RevisionNo}</Text>
                 </Col>
                 </Row>
                 <View style={{borderBottomColor:'#A9A9A9',borderBottomWidth: 1,height:5,
                  width:'100%',alignSelf:'center'}}/>
                 <Row>
                 <Col style={{alignItems:'flex-start',width:'100%'}}>
                 <Text style={{fontSize:RFValue(13),fontFamily:'Italic'}}>{FileName}</Text>
                 </Col> 
                 </Row>
                 <View style={{borderBottomColor:'#A9A9A9',borderBottomWidth: 1,height:5,
                 width:'100%',alignSelf:'center'}}/>
                 <Row>
                 <Col style={{alignItems:'flex-start',width:'35%'}}>
                 <Text style={{fontSize:RFValue(13),color:colorprimary,fontFamily:'Bold'}}>Document No.</Text>
                  </Col>
                 <Col style={{alignItems:'flex-start',width:'65%'}}>
                 <Text style={{fontSize:RFValue(13),fontFamily:'Italic'}}>{DrawingNo}</Text>
                 </Col> 
                 </Row>
                 <Row>
                 <Col style={{alignItems:'flex-start',width:'35%'}}>
               <Text style={{fontSize:RFValue(13),color:colorprimary,fontFamily:'Bold'}}>Tag Class</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'65%'}}>
               <Text style={{fontSize:RFValue(13),fontFamily:'Italic'}}>{TagClass}</Text>
               </Col> 
                 </Row>
                 <Row>
                 <Col style={{alignItems:'flex-start',width:'35%'}}>
               <Text style={{fontSize:RFValue(13),color:colorprimary,fontFamily:'Bold'}}>Status</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'65%'}}>
               <Text style={{fontSize:RFValue(13),fontFamily:'Italic'}}>{Status}</Text>
               </Col> 
                 </Row>
               </Grid>
               </CardItem>
               </Card>
      );

  }

  render() {
      if (this.state.isLoading) {
          return (
            <Modal
            transparent={false}
            supportedOrientations={['portrait', 'landscape']}
            visible={this.state.isLoading}
            >
             <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
              <Image
              useNativeDriver={true}
              style={style_common.load_gif}
              source={require('./src/gears.gif')}  />
              </View>     
            </Modal>
          )
      }

      return (
        <View style={{flex:1,backgroundColor:lightblue}}>

          <ScrollView style={{height:this.getheight('1')}}>
          <Grid style={{paddingTop:'2%'}}>
          <Row style={{backgroundColor:colorprimary,width:'97%',alignSelf:'center',borderRadius:3}}>
          <Text numberOfLines={1} style={styles.titleText}>
          {this.state.pid+" - "+this.state.pdesc}
          </Text>
          </Row>
          <Divider style={{ backgroundColor:white}} />
          <Divider style={{ backgroundColor:white}} />
          <Row style={{backgroundColor:colorprimary,width:'97%',alignSelf:'center',borderRadius:3}}>
          <Text style={styles.titleText}>
          {this.state.cid.toString().trim()+" - "+this.state.cname}
          </Text>
          </Row>  
          </Grid>
          </ScrollView>
        
          <ScrollView style={{height:this.getheight('2')}}>
              <SectionList
                  style={{paddingTop:RFValue(5)}}
                  sections={this.state.data}
                  initialNumToRender={this.state.data.length}
                  renderItem={this.renderItem.bind(this)}
                  renderSectionHeader={({ section }) =>   

                  <View  style={{ flex: 1,paddingTop:5,paddingBottom:5}}>
                   <Grid style={{backgroundColor:blue,padding:RFValue(5),width:"97%",alignSelf:'center',borderRadius:2}}>
                   <Row>
                   <Col style={{alignItems:'center',width:'100%',paddingLeft:RFValue(10)}}>
                   <Text style={styles.sectionHeader}>{section.Title}</Text>
                   </Col> 
                   </Row>
                   </Grid>
                   </View>  
                   
                  }
                  keyExtractor={(item, index) => index}
              />

<Toast ref="toast"
        />
        
          </ScrollView>

        </View>
      );
  }
}

const styles = StyleSheet.create({
  sectionHeader: {
      paddingTop: RFValue(4),
      alignItems:'center',
      fontSize: RFValue(14),
      fontFamily:'Bold',
      color:white,
      backgroundColor:blue 
  },
  titleText: {
    flex:1,
    flexWrap:'wrap',
    color:white,
    fontSize:RFValue(12),
    padding:RFValue(5),
    fontFamily:'Bold'
  },
});


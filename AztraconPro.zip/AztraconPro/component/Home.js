import React, { Component, useEffect, useState } from 'react';
import {
  TextInput, ScrollView, Modal, StyleSheet, Text, View, Image, FlatList, TouchableOpacity, YellowBox,
  Alert, Dimensions, ImageBackground, StatusBar
} from 'react-native';
import { Col, Grid, Row } from 'react-native-easy-grid';
import { Divider, Badge, Button } from 'react-native-elements';
import { NavigationActions, StackActions } from 'react-navigation';
import { RFPercentage, RFValue } from "react-native-responsive-fontsize";
import axios from 'axios';
import Toast from 'react-native-whc-toast'
import * as Notifications from 'expo-notifications';
import { Card, CardItem } from 'native-base';
import { logouttask } from './class/logout';
import { getimage } from './class/ImageGetter';
import strings from './res/strings'
import color from './res/colors'
import { isPortrait } from './class/useOrientation'
//common style
const style_common = require('./class/style');
const ip = strings.values.commonvalues.ip;
const tokken = strings.values.commonvalues.tokken;

const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);

const blue = color.values.Colors.blue;
const colorprimary = color.values.Colors.colorPrimary;
const white = color.values.Colors.white;
const black = color.values.Colors.black;
const colorPrimaryDark = color.values.Colors.colorPrimaryDark;
const lightgray = color.values.Colors.greydark;
const red = color.values.Colors.red;

var MenudataM = [];
var MenudataT = [];

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

var { height, width } = Dimensions.get("window");

export default class Home extends React.Component {

  static navigationOptions = ({ navigation }) => ({
    title: "AztraconPro",

    color: white,
    headerStyle: {
      color: colorprimary,
      backgroundColor: colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily: 'Bold',
      fontSize: RFValue(20)
    },
    headerRight: (
      <TouchableOpacity style={{ paddingRight: 10 }} onPress={() =>
        navigation.state.params.handlelogin()
      }>
        <Image
          style={{ alignSelf: 'center', justifyContent: 'center', resizeMode: 'contain' }}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),

  });
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      handlelogin: '',
      dataSource: [],
      UserID: '',
      username: '',
      Designation: '',
      RCenter: '',
      DeviceType: '',
      PenddataSource: '',
      Department: '',
      ispending: false,
      PendingMsg: '',
      orientation: '',
      layout: {
        height: height,
        width: width
      }
    };
  }

  _onLayout = event => {
    this.setState({
      layout: {
        height: event.nativeEvent.layout.height,
        width: event.nativeEvent.layout.width
      }
    });
  };

  login = async () => {

    Alert.alert(
      'Logout',
      'Would you like to logout?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {
          text: 'OK', onPress: () => {
            logouttask()
            this.props.navigation.dispatch(resetAction);
          }
        },
      ],
      { cancelable: false },
    );

  }

  changepass = () => {
    this.props.navigation.navigate('ChangePasswordActivity', { UserID: this.state.UserID });
  }
  profile = () => {
    this.props.navigation.navigate('EmployeeProfileActivity', { Name: this.state.username, Designation: this.state.Designation, UserID: this.state.UserID });
  }

  gotonextpage = (index, type) => {
    const id = index

    if (type == 'M') {

      const { C } = MenudataM[id]


      if (C == 'undefined' || C == null || C.length == 0) {
        console.log('jj')
        this.refs.toast.showBottom("This Feature Update Soon")
      } else {
        console.log(C)
        this.props.navigation.navigate(C, {
          UserID: this.state.UserID,
          RCenter: this.state.RCenter,
          Department: this.state.Department,
          Name: this.state.username,
          Designation: this.state.Designation,
          DeviceType: this.state.DeviceType
        });


      }

    } else {

      const { C } = MenudataT[id]

      if (C == 'undefined' || C == null || C.length == 0) {
        this.refs.toast.showBottom("This Feature Update Soon")
      } else {
        this.props.navigation.navigate(C, {
          UserID: this.state.UserID,
          RCenter: this.state.RCenter,
          Department: this.state.Department,
          Name: this.state.username,
          Designation: this.state.Designation,
          DeviceType: this.state.DeviceType
        });
      }

    }
  }


  async registerForPushNotificationsAsync(Message) {
    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;
  
    if (existingStatus !== 'granted') {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }
  
    if (finalStatus !== 'granted') {
      alert('Failed to get notification permission!');
      return;
    } else {
      console.log('Notification permission granted');
      this.setNotification(Message);
    }
  }
  
  setNotification = async (Msg) => {
    try {
      Notifications.setNotificationHandler({
        handleNotification: async () => ({
          shouldShowAlert: true,
        }),
      });
  
      await Notifications.presentNotificationAsync({
        title: 'Pending Approval',
        body: Msg,
      });
  
      console.log('Notification presented');
      this.setState({ isLoading: false, ispending: false, PendingMsg: Msg });
    } catch (error) {
      console.error('Error setting notification:', error);
    }
  }
  




  moveApproval() {

    this.setState({

      ispending: false

    }, () => {

      this.props.navigation.navigate('ApprovalListActivity', {
        UserID: this.state.UserID,
        RCenter: this.state.RCenter,
        Department: this.state.Department,
        Name: this.state.username,
        Designation: this.state.Designation,
        DeviceType: this.state.DeviceType
      });

    })

  }
  getPendingApproval() {

    const config = {
      headers: {
        'currentToken': tokken,
      },
      params: {
        userid: this.state.UserID,
      }

    };

    this.setState({ PenddataSource: null })
    axios.get(ip + '/getPendingApproval', config)
      .then(response => this.setState({ PenddataSource: response.data }, () => {
        if (response.status == 200) {

          let tot = 0

          let Message = ''

          for (let i = 0; i < this.state.PenddataSource.length; i++) {

            const { count } = this.state.PenddataSource[i]

            tot = tot + parseInt(count)

          }

          //Message='You Have ' + String(tot) + ' Request == ' 
          Message = '  You Have ' + String(tot) + ' Request waiting for Approval...!!' + "\n\n"

          for (let i = 0; i < this.state.PenddataSource.length; i++) {

            const { count, type } = this.state.PenddataSource[i]

            Message = Message + "   " + type + "  -  " + String(count) + "\n"

          }

          if (this.state.PenddataSource.length > 0) {
            // this.setNotifiCation(Message)
            this.registerForPushNotificationsAsync(Message)
          } else {
            this.setState({
              isLoading: false
            })
          }



        }
      }))
      .catch(err => {
        this.setState({
          isLoading: false
        }, () => {
          let error = err

          this.refs.toast.showBottom(error.toString())

          setTimeout(
            () => {
              this.props.navigation.goBack();
            },
            2000
          )

        })
      }
      );

  }

  getmenulist() {

    const config = {
      headers: {
        'currentToken': tokken,
      },
      params: {
        UserID: this.state.UserID,
      }

    };
    MenudataM = [], MenudataT = []
    this.setState({ dataSource: null, menum: null, menutt: null })
    axios.get(ip + '/getHomeIos', config)
      .then(response => this.setState({ dataSource: response.data }, () => {
        if (response.status == 200) {

          for (let i = 0; i < this.state.dataSource.length; i++) {

            if (this.state.dataSource[i].D == 'M') {
              const { A, B, C } = this.state.dataSource[i]

              var s = {
                A: A,
                B: getimage(B),
                C: C,
              }

              MenudataM.push(s)

            } else {
              const { A, B, C } = this.state.dataSource[i]

              var s = {
                A: A,
                B: getimage(B),
                C: C,
              }

              MenudataT.push(s)
            }
          }

          this.getPendingApproval()
          // this.setState({isLoading:false})

        }
      }))
      .catch(err => {
        this.setState({
          isLoading: false
        }, () => {
          let error = err

          this.refs.toast.showBottom(error.toString())

          setTimeout(
            () => {
              this.props.navigation.goBack();
            },
            2000
          )

        })
      }
      );
  }

  componentDidMount() {

    YellowBox.ignoreWarnings([
      'VirtualizedLists should never be nested', // TODO: Remove when fixed
    ])

    console.disableYellowBox = true;

    this.props.navigation.setParams({
      handlelogin: this.login.bind(this)
    });

    Dimensions.addEventListener('change', () => {
      this.setState({
        orientation: isPortrait() ? 'portrait' : 'landscape'
      });
    });

    this.setState({
      username: this.props.navigation.getParam('username', ''),
      Designation: this.props.navigation.getParam('Designation', ''),
      UserID: this.props.navigation.getParam('USER', ''),
      RCenter: this.props.navigation.getParam('RCenter', ''),
      Department: this.props.navigation.getParam('Department', ''),
      DeviceType: this.props.navigation.getParam('DT', ''),
      orientation: isPortrait() ? 'portrait' : 'landscape'
    }, () => {
      this.getmenulist();
    })

  }
  render() {
    if (this.state.isLoading) {
      return (
        <Modal
          transparent={false}
          supportedOrientations={['portrait', 'landscape']}
          visible={this.state.isLoading}
        >
          <View onLayout={this._onLayout} style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
            <Image
              useNativeDriver={true}
              style={style_common.load_gif}
              source={require('./src/gears.gif')} />
          </View>
        </Modal>
      )
    }
    return (

      <View
        style={{ flex: 1 }}
        onLayout={this._onLayout}
      >
        <ImageBackground source={require('./src/aztracon_bg.jpg')} style={{
          height: this.state.layout.height,
          width: this.state.layout.width,
        }}>
          <ScrollView>

            <Card style={{ alignSelf: 'center', width: '97%', borderColor: colorprimary, borderWidth: RFValue(5), paddingTop: RFValue(2), paddingBottom: RFValue(2) }}>
              <CardItem style={{
                alignItems: "flex-start", width: '100%', flexWrap: 'wrap',
                paddingLeft: 3, paddingRight: 3, paddingTop: 3, paddingBottom: 3
              }}>

                <Grid>
                  <Row>
                    <Col style={{ width: '70%' }}>
                      <Row style={{ paddingTop: '1%', paddingBottom: '1%' }}>
                        <Col style={{ width: '100%' }}>
                          <Text adjustsFontSizeToFit numberOfLines={1} style={{ paddingLeft: 5, fontFamily: 'Bold', fontSize: RFValue(14), color: colorPrimaryDark }}>{this.state.username}</Text>
                        </Col>
                      </Row>
                      <Row style={{ paddingTop: '1%', paddingBottom: '1%' }}>
                        <Col style={{ width: '100%' }}>
                          <Text adjustsFontSizeToFit numberOfLines={1} style={{ paddingLeft: 5, fontFamily: 'Bold', fontSize: RFValue(14), color: colorPrimaryDark }}>{this.state.Designation}</Text>
                        </Col>
                      </Row>
                    </Col>
                    <Col style={{ width: '30%' }}>
                      <Row>
                        <Col style={{ width: '50%' }}>
                          <TouchableOpacity activeOpacity={.5} onPress={this.profile}>

                            <Image source={require('./src/ic_prof1.png')} style={styles.image} />
                            {/* <Image
                          style={styles.image}
                          source={require('./src/ic_prof.png')} /> */}
                          </TouchableOpacity>
                        </Col>
                        <Col style={{ width: '50%' }}>
                          <TouchableOpacity activeOpacity={.5} onPress={this.changepass}>
                            <Image
                              style={styles.image}
                              source={require('./src/ic_change_pass1.png')} />
                          </TouchableOpacity>
                        </Col>
                      </Row>
                    </Col>
                  </Row>
                  <Row>
                    <Col>

                    </Col>
                  </Row>
                </Grid>
              </CardItem>
            </Card>

            <Grid style={{ paddingTop: '1%' }}>
              <Row style={{ backgroundColor: colorPrimaryDark, padding: RFValue(5), width: '97%', alignSelf: 'center', borderRadius: 4 }}>
                <Text style={styles.titleText}>Master</Text>
              </Row>
            </Grid>

            <ScrollView>

              <FlatList
                data={MenudataM}
                renderItem={({ item, index }) =>
                  <Grid style={{ flex: 1 / 3, paddingTop: '2%' }} >
                    <Row>
                      <Col style={{ alignItems: 'center', width: '100%', alignSelf: 'center' }}>

                        <TouchableOpacity activeOpacity={.5} onPress={() => this.gotonextpage(index, 'M')}>

                          <Card style={{ borderColor: colorprimary, padding: RFValue(8), borderRadius: RFValue(5), paddingTop: 0, paddingBottom: 0 }} >
                            <View
                              style={{
                                height: (height * 12) / 100,
                                width: (width * 15) / 100,
                                justifyContent: 'center',
                                alignItems: 'center',
                              }}
                            >
                              <Image style={styles.imagebutton} source={item.B}></Image>
                            </View>
                          </Card>

                        </TouchableOpacity>



                      </Col>
                    </Row>
                    <Row>
                      <Col style={{ alignItems: 'center', width: '100%', alignSelf: 'center' }}>
                        <Text numberOfLines={1} style={{
                          fontFamily: 'Bold', fontSize: RFValue(12),
                          alignSelf: 'center', flexWrap: 'wrap'
                        }}>
                          {item.A}
                        </Text>
                      </Col>
                    </Row>
                  </Grid>

                }
                numColumns={3}
                keyExtractor={(item, index) => index}
              />

            </ScrollView>

            <Grid style={{ paddingTop: '2%' }}>
              <Row style={{ backgroundColor: colorPrimaryDark, padding: 5, width: '97%', alignSelf: 'center', borderRadius: 4 }}>
                <Text style={styles.titleText}>Transaction</Text>
              </Row>
            </Grid>
            <ScrollView>
              <FlatList
                data={MenudataT}
                renderItem={({ item, index }) =>


                  <Grid style={{ flex: 1 / 3, paddingTop: '2%' }} >
                    <Row>
                      <Col style={{ alignItems: 'center', width: '100%', alignSelf: 'center' }}>

                        <TouchableOpacity activeOpacity={.5} onPress={() => this.gotonextpage(index, 'T')}>

                          <Card style={{ borderColor: colorprimary, padding: RFValue(8), borderRadius: 8, paddingTop: 0, paddingBottom: 0 }} >
                            <View
                              style={{
                                height: (height * 12) / 100,
                                width: (width * 15) / 100,
                                justifyContent: 'center',
                                alignItems: 'center',
                              }}
                            >
                              <Image style={styles.imagebutton} source={item.B}></Image>
                            </View>
                          </Card>

                        </TouchableOpacity>


                      </Col>
                    </Row>
                    <Row>
                      <Col style={{ alignItems: 'center', width: '100%', alignSelf: 'center' }}>
                        <Text numberOfLines={1} style={{
                          fontFamily: 'Bold', fontSize: RFValue(12),
                          alignSelf: 'center', flexWrap: 'wrap'
                        }}>
                          {item.A}
                        </Text>
                      </Col>
                    </Row>
                  </Grid>


                }
                numColumns={3}
                keyExtractor={(item, index) => index}
              />
            </ScrollView>
            <Toast ref="toast"
            />
            <StatusBar animated={true} backgroundColor={colorprimary} />





            <Modal
              animationType={"slide"}
              transparent={true}
              visible={this.state.ispending}
              onRequestClose={() => { console.log("Modal has been closed.") }}>
              {/*All views of Modal*/}
              <View style={styles.modal}>

                <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress={() => {
                  this.setState({ ispending: !this.state.ispending })
                }}>

                  <Grid>
                    <Row>
                      <Col style={{ width: '90%', alignItems: 'center', alignSelf: 'center' }}>
                        <Text style={{ paddingLeft: '3%', color: '#fff', textDecorationStyle: 'solid', fontFamily: 'Bold', alignSelf: 'flex-start' }}>
                          Pending Approval
                        </Text>
                      </Col>

                      <Col style={{ width: '10%', alignItems: 'center', alignSelf: 'center' }}>
                        <Image
                          source={require('./src/back.png')}
                          style={{ height: 22, width: 22 }}
                        />
                      </Col>
                    </Row>

                  </Grid>

                </TouchableOpacity>



                <ScrollView>

                  <Grid style={{
                    width: '100%', paddingBottom: 4,
                    borderBottomWidth: 1, borderBottomColor: colorprimary,
                    alignSelf: 'center'
                  }}>
                    <Row>
                      <Text style={{
                        fontSize: 14, fontFamily: 'ItalicBold', color: colorPrimaryDark,
                        paddingTop: "2%"
                      }}>{this.state.PendingMsg}</Text>
                    </Row>

                    <Row>
                      <Col style={{ width: '100%', alignSelf: 'center', alignItems: 'center' }}>

                        <Button onPress={() => this.moveApproval()}
                          raised={true}
                          type={'outline'}
                          titleStyle={{ fontSize: 14, textAlign: 'center', fontFamily: 'Bold', color: colorPrimaryDark }}
                          buttonStyle={{
                            flex: 1,
                            borderRadius: 6,
                            width: 140,
                            height: 40,
                            borderColor: red
                          }}


                          title=" Go to Approval " />

                      </Col>
                    </Row>

                  </Grid>

                </ScrollView>

              </View>
            </Modal>

          </ScrollView>
        </ImageBackground>
      </View>
    )
  }
};
const styles = StyleSheet.create({
  image: {
    width: '100%',
    height: '100%',
    alignSelf: 'center',
    resizeMode: 'contain'
  },
  titleText: {
    flex: 1,
    flexWrap: 'wrap',
    color: white,
    fontSize: RFValue(13),
    fontFamily: 'Bold'
  },
  imagebutton: {
    width: '100%',
    height: '100%',
    alignSelf: 'center',
    resizeMode: 'contain'
  },
  container: {
    flex: 1,
    alignItems: 'center',
  },
  welcome: {
    fontSize: 15,
    textAlign: 'center',
    margin: 10,
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
  },
  imageStyle: {
    width: screenWidth,
    height: screenHeight,
    justifyContent: 'center',
    alignItems: 'center'
  },

  tcenter: {
    flex: 1,
    justifyContent: 'flex-start',
    flexDirection: 'column',
    paddingLeft: 10,
  },
  // image: {
  //   width: 40,
  //   height: 40,
  //   marginTop:5,
  //   marginRight:10,
  // },
  modal: {
    flex: 1,
    backgroundColor: white,
    height: 'auto',
    position: 'absolute',
    bottom: 0,
    width: '98%',
    alignSelf: 'center',
    borderTopLeftRadius: 5,
    borderTopRightRadius: 5,
  },
  headerback: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colorprimary,
    borderWidth: 0.5,
    borderColor: white,
    height: 40,
    width: '100%',
    borderRadius: 5,
  },
});


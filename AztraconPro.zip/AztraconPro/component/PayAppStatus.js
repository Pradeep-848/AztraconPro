import React from 'react';
import {ScrollView,Dimensions,Image,Modal,SectionList,StyleSheet,Text,View,TouchableOpacity,Alert} from 'react-native';
import axios from 'axios';
import moment from 'moment';
import { NavigationActions, StackActions } from 'react-navigation';
import { Col, Grid, Row} from 'react-native-easy-grid';
import {Card,CardItem} from 'native-base';
import strings from './res/strings'
import Timeline from 'react-native-timeline-flatlist'
import {logouttask} from './class/logout';
import Toast from 'react-native-whc-toast'
import color from './res/colors'

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const { width, height } = Dimensions.get('window');

const lightblue=color.values.Colors.lightblue;
const blue=color.values.Colors.blue;
const black=color.values.Colors.black;
const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class PayAppStatus extends React.Component{
  static navigationOptions = ({ navigation }) => ({ 
    title: "Payment Status",
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor:white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
      super(props);
      this.state = { 
        isLoading: true, 
        isVisible:false,
        adata:"",
        PAYID:"",
        StatusData:[],
        data:[],
        handlelogin:'',
        UserID:'',
    };
      console.disableYellowBox = true;
  }

  login = async () => 
  {
  
    Alert.alert(
      'Logout',
      'Would you like to logout?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {text: 'OK', onPress: () => { logouttask()
          this.props.navigation.dispatch(resetAction);}},
      ],
      {cancelable: false},
    );
   
  }
  

componentDidMount() {
  console.disableYellowBox = true;

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
  
  this.setState({
    UserID:this.props.navigation.getParam('UserID', ''),
    
    },()=>{this.getpaymentapprovalstatus();})
}

gotoapprovalstatus(payid){
    
    console.log('here')
  this.setState({
    StatusData:[],data:[],PAYID:payid
  },()=>{
    this.gettimeline()
  })

}

display(){
  for(i=0;i< this.state.StatusData.length ;i++){
      const{E,C,D,A,F}=this.state.StatusData[i]
      let Desc,tit
      if(E!==''){
        if(D!=='' && D!=null){
          if (F=='O' || F=='P') {
            Desc=C+"\n"+"Remarks : "+E
          }else{
            Desc=C+"\n"+moment(D).format('DD-MM-YYYY').toString()+"\n"+"Remarks : "+E
          }
         
        }
        else{
          Desc=C+"\n"+"Remarks : "+E
        }
        
      }else{

        if(D!=='' && D!=null){

          if (F=='O' || F=='P') {
            Desc=C
          }else{
            Desc=C+"\n"+moment(D).format('DD-MM-YYYY').toString()
          }
       
        }else{
          Desc=C
        }
        
      }

      if(F==='A'){
          this.state.data.push({
              title:A,
              description:Desc,
              lineColor:"#15ca7d",
              icon:require('./src/ic_approved.png')
          })
      }else if(F==='P'){
          this.state.data.push({
              title:A,
              description:Desc, 
              lineColor:"#f4b825",
              icon:require('./src/ic_pending.png')
          })
      }else if(F==='R'){
          this.state.data.push({
              title:A,
              description:Desc,
              lineColor:"#f6634b",
              icon:require('./src/ic_rejected.png')
          })
      }else if(F==='O'){
          this.state.data.push({
              title:A,
              description:Desc,
              lineColor:"#2d353a",
              icon:require('./src/ic_opened.png')
          })
      }else if(F=='W'){
          this.state.data.push({
              title:A,
              description:Desc,
              lineColor:"#2d353a",
              icon:require('./src/ic_opened.png')
          })
      }
  
    }
    this.setState({isLoading:false,isVisible:true})
}



/* display(){
    for(let i=0;i< this.state.StatusData.length ;i++){
        const{E,C}=this.state.StatusData[i]
        let Desc
        if(E!==''){
          Desc=C+"\n"+"Remarks : "+E
        }else{
            Desc=C
        }
        const{D,A,F}=this.state.StatusData[i]

        if(F==='A'){
          let head
          if(moment(D).format('DD-MM-YYYY')=='Invalid date'){
            head=A
          }else{
            head=moment(D).format('DD-MM-YYYY')+"\n"+A
          }

            this.state.data.push({
                time:moment(D).format('DD-MM-YYYY'),
                title:head,
                description:Desc,
                lineColor:"#15ca7d",
                icon:require('./src/ic_approved.png')
            })
        }else if(F==='P'){

          let head
          if(moment(D).format('DD-MM-YYYY')=='Invalid date'){
            head=A
          }else{
            head=moment(D).format('DD-MM-YYYY')+"\n"+A
          }

            this.state.data.push({
                time:moment(D).format('DD-MM-YYYY'),
                title:head,
                description:Desc,
                lineColor:"#f4b825",
                icon:require('./src/ic_pending.png')
            })
        }else if(F==='R'){
          let head
          if(moment(D).format('DD-MM-YYYY')=='Invalid date'){
            head=A
          }else{
            head=moment(D).format('DD-MM-YYYY')+"\n"+A
          }
            this.state.data.push({
                time:moment(D).format('DD-MM-YYYY'),
                title:head,
                description:Desc,
                lineColor:"#f6634b",
                icon:moment(D).format('DD-MM-YYYY'),
            })
        }else if(F==='O'){

          let head
          if(moment(D).format('DD-MM-YYYY')=='Invalid date'){
            head=A
          }else{
            head=moment(D).format('DD-MM-YYYY')+"\n"+A
          }

            this.state.data.push({
                time:moment(D).format('DD-MM-YYYY'),
                title:head,
                description:Desc,
                lineColor:"#2d353a",
                icon:require('./src/ic_opened.png')
            })
        }else if(F=='W'){

          let head
          if(moment(D).format('DD-MM-YYYY')=='Invalid date'){
            head=A
          }else{
            head=moment(D).format('DD-MM-YYYY')+"\n"+A
          }

            this.state.data.push({
                time:moment(D).format('DD-MM-YYYY'),
                title:head,
                description:Desc,
                lineColor:"#2d353a",
                icon:require('./src/ic_opened.png')
            })
        }
    
      }
      console.log(this.state.data)
      this.setState({isLoading:false,isVisible:true})
 }

 */
gettimeline(){

    console.log('ho')
    this.setState({isLoading:true})
     const config = {
         headers: {   
         'currentToken':tokken,
       },
         params: {
          payid:this.state.PAYID,
         }
         
       };
  
   axios.get(ip+'/getPayStatus', config)
     .then(response => this.setState({StatusData:response.data},() => {if(response.status==200){
         console.log(this.state.StatusData)
     this.display()
     }}))
     .catch(err => 
       {
         this.setState({
           isLoading:false
         },()=>{
          let error=err
          
          this.refs.toast.showBottom(error.toString())
   
          setTimeout(
           () => { 
             this.props.navigation.goBack();
            },
           2000
         )
   
         })
       }
       );
  
  }

  
getpaymentapprovalstatus(){
    const config = {
      headers: {   
      'currentToken':tokken,
    },
      params: {
        UserID:this.state.UserID,
      }
    };
    this.setState({isLoading:true});
    axios.get(ip+'/getPayStatusListIOS', config)
  .then(response => this.setState({adata:response.data},() => {if(response.status==200){
      console.log(this.state.adata)
      this.setState({isLoading:false});
    }
}))
.catch(err => 
  {
    this.setState({
      isLoading:false
    },()=>{
     let error=err
     
     this.refs.toast.showBottom(error.toString())

     setTimeout(
      () => { 
        this.props.navigation.goBack();
       },
      2000
    )

    })
  }
  );
  
}

format(x) {
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}


  renderItem(item) {    

    const {payid,pdate,amt} = item.item;
      return (
            <Card style={{width:'97%',alignSelf:'center'}}>
               <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
                  paddingLeft:5,paddingRight:5,paddingTop:5,paddingBottom:5}}>
               <Grid onPress={this.gotoapprovalstatus.bind(this,payid)}>
               <Row>
               <Col style={{alignItems:'flex-start',width:'25%'}}>
               <Text style={{fontSize:12,color:black,fontFamily:'Regular'}}>{payid}</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'25%'}}>
               <Text style={{fontSize:12,color:black,fontFamily:'Regular'}}>{pdate}</Text>
               </Col>
               <Col style={{alignItems:'flex-end',width:'50%'}}>
               <Text style={{fontSize:12,color:black,fontFamily:'Regular'}}>{this.format((Math.round(amt * 100) / 100).toFixed(2))}</Text>
               </Col>
               </Row>
               </Grid>   
               </CardItem>
               </Card>
      );

  }

  render() {
      if (this.state.isLoading) {
          return (
            <Modal
            transparent={false}
            supportedOrientations={['portrait', 'landscape']}
            visible={this.state.isLoading}
            >
             <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
              <Image
              style={{width: 300, height: 200}}
              source={require('./src/gears.gif')}  />
              </View>     
            </Modal>
          )
      }

    return (
    <View style={{flex:1,backgroundColor:lightblue}}>
    <ScrollView style={{height:"6%"}}>
    <View  style={{ flex: 1,paddingTop:'2%'}}>
    <Grid style={{backgroundColor:colorprimary,padding:5,width:"97%",alignSelf:'center',borderRadius:4}}>
             <Row>
             <Col style={{alignItems:'flex-start',width:'25%',paddingLeft:8}}>
             <Text style={styles.textContent}>Payment ID</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'25%',paddingLeft:5}}>
             <Text style={styles.textContent}>Date</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'50%',paddingRight:5}}>
             <Text style={styles.textContent}>Amount</Text>
             </Col> 
             </Row>
             </Grid>
    </View>
    </ScrollView>
    <ScrollView style={{height:"94%"}}>

    <Modal            
          animationType = {"slide"}  
          transparent = {true}  
          visible = {this.state.isVisible}  
          onRequestClose = {() =>{ console.log("Modal has been closed.") } }>  
          {/*All views of Modal*/}  
          <View style = {styles.modal}>  
          <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress = {() =>
           {  
            this.setState({ isVisible:!this.state.isVisible})
           }}>
       
       <Grid>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontFamily:'Bold',alignSelf:'flex-start'}}>
             Approve Timeline
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('./src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
       </Grid>
        
         </TouchableOpacity>


         <Timeline 
          style={styles.list}
          data={this.state.data}
          circleSize={25}
          showTime={false}
          circleColor='rgba(0,0,0,0)'
          lineColor='rgb(45,156,219)'
          descriptionStyle={{color:'gray',fontFamily:'Regular'}}
          innerCircle={'icon'}
        />


          </View>
          </Modal>
              <SectionList
                  sections={this.state.adata}
                  style={{paddingTop:2}}
                  initialNumToRender={this.state.adata.length}
                  renderItem={this.renderItem.bind(this)}
                  renderSectionHeader={({ section }) => 
                  
                   <View  style={{ flex: 1,paddingTop:2}}>
                   <Grid style={{backgroundColor:'#3498db',padding:5,width:"97%",alignSelf:'center',borderRadius:4}}>
                   <Row>
                   <Col style={{alignItems:'flex-start',width:'100%'}}>
                   <Text style={styles.sectionHeader}>{section.Title}</Text>
                   </Col> 
                   </Row>
                   </Grid>
                   </View>
                  
               }
                  keyExtractor={(item, index) => index}
              />
                <Toast ref="toast"/>
          </ScrollView>
          </View>
      );
  }
}

const styles = StyleSheet.create({
  container: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: '#F5FCFF',
  },
  sectionHeader: {
      alignSelf:'flex-start',
      fontSize: 13,
      fontFamily: 'Bold',
      color:'#fff',
  },
  itemView: {
    flex: 1,
    width,
    borderBottomWidth: 0.5,
    borderColor: '#cdcdcd',
    borderStyle: 'solid',
    paddingHorizontal: 12,
    flexDirection: 'row',
    paddingTop:2
},
textContent:{
  color:white,
  fontSize:12,
  fontFamily:'Bold'
},
list: {
    flex: 1,
    marginTop:10,
  },
modal: {  
    flex:1,
    backgroundColor:white,
    height:'auto',
    position: 'absolute',
    bottom: 0,
    width:'100%'
     },
     headerback: {
        flexDirection: 'row',
        alignItems:'center',
        backgroundColor: colorprimary,
        borderWidth: 0.5,
        borderColor:white,
        height: 40,
        width:'100%',
        borderRadius: 5,
      },
});


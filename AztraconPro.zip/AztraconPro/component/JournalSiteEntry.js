import React,{ Component }  from 'react';
import {Dimensions,TouchableWithoutFeedback,View,FlatList,Keyboard,TouchableOpacity,StyleSheet,Text,Image,ScrollView,Alert,KeyboardAvoidingView,Platform,Modal} from 'react-native';
import { Col, Grid,Row } from 'react-native-easy-grid';
import { Card,CardItem,Item,Input,Form,Label } from 'native-base';
import DateTimePicker from "react-native-modal-datetime-picker";
import { NavigationActions, StackActions } from 'react-navigation';
import {Button,SearchBar} from 'react-native-elements'
import {TextInput} from 'react-native-paper'
import Toast from 'react-native-whc-toast'
import moment, { parseTwoDigitYear } from 'moment';
import axios from 'axios';
import {logouttask} from './class/logout';
import color from './res/colors'
import strings from './res/strings'

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const colorprimarydark=color.values.Colors.colorPrimaryDark;

const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);
const moverheight=screenHeight/8

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

 export default class JournalSiteEntry extends React.Component {
   static navigationOptions = ({ navigation }) => ({ 
    title: "Journal Entry",
    headerStyle: {
      backgroundColor: colorprimary
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
  });
  
  constructor(props) {
    super(props);
    this.state = {
         isDateTimePickerVisible:false,Dept:'',iscostwake:false,isemployeewake:false,issitewake:false,isprojectwake:false,issupplierwake:false,name:''
         ,UserID:"",handlelogin:'',ed_vocdate:moment(new Date()).format("DD/MMM/YYYY"),ed_debit_amt:'',glcodesource:'',isglcode:false,
         Spn_gl_code:'',Spn_GL:'',ed_glcode:'',ed_narration:'',spn_site:'',sitesource:'',issite:'',
         Spn_site_code:'',Spn_project_code:'',Spn_Project:'',isproject:false,projectsource:'',employeesource:''
         ,isemployee:false,Spn_employee_code:'',spn_employee:'',spn_Supplier:'',suppliersource:'',issupplier:false,
         Spn_supplier_code:'',costsource:'',iscost:false,Spn_cost_code:'',Spn_cost:'',ed_invoiceno:'',ed_invoicedate:''
    };
    this.arrayholder = [];
}

 
goback(){
  this.props.navigation.replace('JournalSiteActivity',{
    UserID:this.state.UserID,Department:this.state.Dept,Name:this.state.name
  })
}

onsave(){

  const{ed_vocdate,ed_debit_amt,Spn_employee_code,ed_invoiceno,ed_invoicedate
  }=this.state

  if(ed_invoicedate==null || ed_invoicedate==''){
     this.setState({
      ed_invoicedate:" "
     })
  }

  if(ed_vocdate==null || ed_vocdate==''){
    this.refs.toast.showCenter('Please enter Voucher Date',500);
  }else if(ed_debit_amt==null || ed_debit_amt==''){
   this.refs.toast.showCenter('Please enter Debit Amount',500);
  }else if(Spn_employee_code==null || Spn_employee_code==''){
    this.refs.toast.showCenter('Please Select Employee',500);
  }else if(ed_invoiceno==null || ed_invoiceno==''){
    this.refs.toast.showCenter('Please enter Invoice No',500);
  }else{
    this.setState({isLoading:true})

  let u="/addJournalSite"

  axios({
    method: 'post',
    url:ip+u,
    headers: {'currentToken':tokken}, 

    data:{
      VocDate:moment(this.state.ed_vocdate,'DD/MMM/YYYY').format('MM/DD/YYYY'), 
      GLCode:this.state.Spn_gl_code,
      Narration:this.state.ed_narration,    
      Debit:this.state.ed_debit_amt,
      Division:'AZ',
      Department:this.state.Dept,    
      PID:this.state.Spn_project_code,
      EmpID:this.state.Spn_employee_code,
      INo:this.state.ed_invoiceno,    
      SID:this.state.Spn_supplier_code,
      UserID:this.state.UserID,
      SiteID:this.state.Spn_site_code,    
      CCode:this.state.Spn_cost_code,
      InvDate:moment(this.state.ed_invoicedate,'DD/MMM/YYYY').format('MM/DD/YYYY'),
    },


  }).then(response=>{if(response.status===200){
        this.setState({isLoading:false},()=>{ 
          this.refs.toast.showBottom('Save Successful');
          this.goback()
        })
  }else{
    this.refs.toast.showBottom('Save Failed');
  }})
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())
  
       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )
  
      })
    }
    );
  } 
}
oncancel(){
  this.props.navigation.goBack();
}

filtersearch(text){
  const newData = this.arrayholder.filter(function(item){
  const itemData =item.sBcode.toString()+item.sBdesc.toString().toUpperCase()
  const textData = text.toUpperCase()
  return itemData.indexOf(textData) > -1
}
)
this.setState({
  glcodesource: newData.sort(),
  text: text
})
}

getglcode(){
  
    const config = {
        headers: {   
        'currentToken': tokken,
      },   
      };

      this.setState({isLoading:true})
      axios.get(ip+'/getSpnGlcode', config)
      .then(response => this.setState({glcodesource:response.data},() => {if(response.status==200){
           this.arrayholder = this.state.glcodesource;
          this.setState({isLoading:false,isglcode:true});
        }}))
        .catch(err => 
          {
            this.setState({
              isLoading:false
            },()=>{
             let error=err
             
             this.refs.toast.showBottom(error.toString())
        
             setTimeout(
              () => { 
                this.props.navigation.goBack();
               },
              2000
            )
        
            })
          }
          );
  
}

getemployee(){
  
  const config = {
      headers: {   
      'currentToken': tokken,
    },   
    params:{
      'SiteID':this.state.Spn_site_code
    }
    };

    this.setState({isLoading:true})
    axios.get(ip+'/getSpnEmp', config)
    .then(response => this.setState({employeesource:response.data},() => {if(response.status==200){

        this.setState({isLoading:false,isemployee:true});
      }}))
      .catch(err => 
        {
          this.setState({
            isLoading:false
          },()=>{
           let error=err
           
           this.refs.toast.showBottom(error.toString())
      
           setTimeout(
            () => { 
              this.props.navigation.goBack();
             },
            2000
          )
      
          })
        }
        );

}
getemployeeitems (code,desc) {

  this.setState({
    Spn_employee_code:code,
    spn_employee:code+"--"+desc,
    isemployee:!this.state.isemployee,
    issupplierwake:true
  })

}

getsupplier(){
  
  const config = {
      headers: {   
      'currentToken': tokken,
    },   
    };

    this.setState({isLoading:true})
    axios.get(ip+'/getSpnSupplierJ', config)
    .then(response => this.setState({suppliersource:response.data},() => {if(response.status==200){

        this.setState({isLoading:false,issupplier:true});
      }}))
      .catch(err => 
        {
          this.setState({
            isLoading:false
          },()=>{
           let error=err
           
           this.refs.toast.showBottom(error.toString())
      
           setTimeout(
            () => { 
              this.props.navigation.goBack();
             },
            2000
          )
      
          })
        }
        );

}

getsupplieritem (code,desc) {

  this.setState({
    Spn_supplier_code:code,
    spn_Supplier:code+"--"+desc,
    issupplier:!this.state.issupplier,
  })

}

getsite(){
  
    const config = {
        headers: {   
        'currentToken': tokken,
      },   
      params: {
        sqlQuery:"SELECT LocCode,LocName FROM CompanyWareHouse WHERE LocCode IN (SELECT LocCode FROM CompanyWareHouseProjects WHERE Con_Admin = '"+this.state.UserID+"') "
      } 
      };

      this.setState({isLoading:true})
      axios.get(ip+'/getSpinnerData', config)
      .then(response => this.setState({sitesource:response.data},() => {if(response.status==200){
  
          this.setState({isLoading:false});
        }}))
        .catch(err => 
          {
            this.setState({
              isLoading:false
            },()=>{
             let error=err
             
             this.refs.toast.showBottom(error.toString())
        
             setTimeout(
              () => { 
                this.props.navigation.goBack();
               },
              2000
            )
        
            })
          }
          );
  
}

getproject(){
  
  const config = {
      headers: {   
      'currentToken': tokken,
    },   
    params: {
      sqlQuery:"SELECT ProjectID,ProjectDesc FROM ProjectMaster WHERE CurrentStatus ='O' and ProjectID <> '100' and ProjectID in (SELECT ProjectID FROM CompanyWareHouseProjects WHERE LocCode = '" + this.state.Spn_site_code + "' AND Con_Admin = '" + this.state.UserID +"')"
    } 
    };

    this.setState({isLoading:true})
    axios.get(ip+'/getSpinnerData', config)
    .then(response => this.setState({projectsource:response.data},() => {if(response.status==200){

        this.setState({isLoading:false,isproject:true});
      }}))
      .catch(err => 
        {
          this.setState({
            isLoading:false
          },()=>{
           let error=err
           
           this.refs.toast.showBottom(error.toString())
      
           setTimeout(
            () => { 
              this.props.navigation.goBack();
             },
            2000
          )
      
          })
        }
        );

}

getprojectitems (code,desc) {

  this.setState({
    Spn_project_code:code,
    Spn_Project:code+"--"+desc,
    isproject:!this.state.isproject,
    isemployeewake:true
  })

}

getsiteitems (code,desc) {

    this.setState({
      Spn_site_code:code,
      spn_site:code+"--"+desc,
      issite:!this.state.issite,
      isprojectwake:true
    })
  
  }
getglcodeitem (code,desc) {

  this.setState({
    Spn_gl_code:code,
    Spn_GL:code+" "+desc,
    ed_narration:desc,
    isglcode:!this.state.isglcode,
    iscostwake:true
  })

}


getcostitems (code,desc) {

  this.setState({
    Spn_cost_code:code,
    Spn_cost:code+" "+desc,
    iscost:!this.state.iscost
  })

}

getcostcode(){
  
  const config = {
      headers: {   
      'currentToken': tokken,
    },   
    params: {
      sqlQuery:"SELECT MaterialAbrev,MaterialDesc FROM MaterialCategory WHERE CostGLCode ="+this.state.Spn_gl_code+"OR LinkGlCode ="+this.state.Spn_gl_code+"OR "+"'"+this.state.Spn_gl_code+"'"+" like '20107%'"
    } 
    };

    this.setState({isLoading:true})
    axios.get(ip+'/getSpinnerData', config)
    .then(response => this.setState({costsource:response.data},() => {if(response.status==200){

        this.setState({isLoading:false,iscost:true});
      }}))
      .catch(err => 
        {
          this.setState({
            isLoading:false
          },()=>{
           let error=err
           
           this.refs.toast.showBottom(error.toString())
      
           setTimeout(
            () => { 
              this.props.navigation.goBack();
             },
            2000
          )
      
          })
        }
        );

}

  
  
  handleDatePicked = date => {
    const NewDate =moment(date).format('DD/MMM/YYYY')
    this.setState({ed_invoicedate:NewDate})
    this.hideDateTimePicker();
  };
  
  hideDateTimePicker = () => {
    this.setState({ isDateTimePickerVisible: false });
  }
  
  showDateTimePicker = () => {
    Keyboard.dismiss
    this.setState({ isDateTimePickerVisible: true });
  }
  
  
login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
      this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}


componentDidMount(){

  console.disableYellowBox = true;

  this.props.navigation.setParams({
    handlelogin: this.login.bind(this)
    });

  this.setState({
    Dept:this.props.navigation.getParam('Department', ''),
    UserID:this.props.navigation.getParam('UserID', ''),
    name:this.props.navigation.getParam('Name', ''),
},()=>{
  this.getsite()
})
  
}

onlayoutcost(){
  if(this.state.iscostwake==true){
   this.getcostcode()
  }else{
    this.refs.toast.showBottom("Please Select GL Code")
  }
}

onlayoutsite(){
this.setState({
  issite:true
})
}
onlayoutproject(){
  if(this.state.isprojectwake==true){
    this.getproject()
  }else{
    this.refs.toast.showBottom("Please Select Site")
  }
}

onlayoutemployee(){

  if(this.state.isemployeewake==true){
    this.getemployee()
  }else{
    this.refs.toast.showBottom("Please Select Project")
  }
}

onlayoutsupplier(){

  if(this.state.issupplierwake==true){
    this.getsupplier()
  }else{
    this.refs.toast.showBottom("Please Select Employee")
  }

}

render() {

  if (this.state.isLoading) {
    return (
      <Modal
      transparent={false}
      supportedOrientations={['portrait', 'landscape']}
      visible={this.state.isLoading}
      >
       <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
        <Image
        style={{width: 300, height: 200}}
        source={require('./src/gears.gif')}  />
        </View>     
      </Modal>
    )
  }
return (
<ScrollView>
       <Grid>
       <Form>
           <Row style={styles.rowstyle}>
           <Col style={{width:'50%',alignItems:"flex-start"}}>
           <Item floatingLabel>
              <Label style={styles.floatlabel}>Voucher Date</Label>
              <Input 
                editable={false}
                getRef={(input) => { this.vocdate = input; }}
                returnKeyType='next'
                style={styles.istyle}
                value={this.state.ed_vocdate}
                onChangeText={(ed_vocdate) => this.setState({ ed_vocdate })}
                focus={false}
              />
            </Item>
            </Col>

            <Col style={{width:'50%',alignItems:"flex-start"}}>

            <Item floatingLabel>
              <Label style={styles.floatlabel}>Debit Amount</Label>
              
               <Input 
                getRef={(input) => { this.debitamount = input; }}
                returnKeyType='next'
                autoCorrect={false}
                maxLength={10}
                style={styles.istyle}
                keyboardType={'numeric'}
                value={this.state.ed_debit_amt}
                onChangeText={(ed_debit_amt) => this.setState({ ed_debit_amt })}
                onSubmitEditing={() => { this.narration._root.focus(); }}
              /> 
            </Item>
            </Col>

           </Row>

           <Row style={styles.rowstyle}>
           <Col style={{width:'100%',alignItems:'flex-start'}}>
           <Item  floatingLabel   onPress={this.getglcode.bind(this)}>
           <Label style={styles.floatlabel}>GL Code</Label>
           <Input 
           editable={false}
           style={styles.istyle}
           multiline={true}
           value={this.state.Spn_GL}/>
           </Item>
           </Col>
           </Row> 
      
          <Row style={styles.rowstyle}>
           <Col style={{width:'100%',alignItems:"flex-start"}}>
           <Item  floatingLabel>
              <Label style={styles.floatlabel}>Narration</Label>
              <Input 
                getRef={(input) => { this.narration = input; }}
                returnKeyType='next'
                maxLength={100}
                style={styles.istyle}
                autoCorrect={false}
                autoCapitalize='words'
                keyboardType={'default'}
                value={this.state.ed_narration}
                onChangeText={(ed_narration) => this.setState({ ed_narration })}
                onSubmitEditing={() => { this.invoiceno._root.focus(); }}
              />
            </Item>
            </Col>
           </Row>

           <Row style={styles.rowstyle}>
           <Col style={{width:'100%',alignItems:'flex-start'}}>
           <Item floatingLabel onPress={this.onlayoutsite.bind(this)}>
           <Label style={styles.floatlabel}>Site</Label>
           <Input 
           editable={false}
           style={styles.istyle}
           multiline={true}
           value={this.state.spn_site}/>
           </Item>
           </Col>
           </Row> 

           <Row style={styles.rowstyle}>
           <Col style={{width:'100%',alignItems:'flex-start'}}>
           <Item  floatingLabel onPress={this.onlayoutproject.bind(this)}>
           <Label style={styles.floatlabel}>Project</Label>
           <Input 
           editable={false}
           multiline={true}
           style={{ fontSize: 12 }}
           value={this.state.Spn_Project}/>
           </Item>
           </Col>
           </Row> 
      
           <Row style={styles.rowstyle}>
           <Col style={{width:'100%',alignItems:'flex-start'}}>
           <Item  floatingLabel onPress={this.onlayoutcost.bind(this)}>
           <Label style={styles.floatlabel}>Cost Code</Label>
           <Input 
           editable={false}
           multiline={true}
           style={styles.istyle}
           value={this.state.Spn_cost}/>
           </Item>
           </Col>
           </Row> 


           <Row style={styles.rowstyle}>
           <Col style={{width:'100%',alignItems:'flex-start'}}>
           <Item floatingLabel onPress={this.onlayoutemployee.bind(this)}>
           <Label style={styles.floatlabel}>Employee</Label>
           <Input 
           editable={false}
           style={styles.istyle}
           multiline={true}
           value={this.state.spn_employee}/>
           </Item>
           </Col>
           </Row> 

           <Row style={styles.rowstyle}>
           <Col style={{width:'100%',alignItems:'flex-start'}}>
           <Item floatingLabel onPress={this.onlayoutsupplier.bind(this)}>
           <Label style={styles.floatlabel}>Supplier</Label>
           <Input 
           editable={false}
           multiline={true}
           style={styles.istyle}
           value={this.state.spn_Supplier}/>
           </Item>
           </Col>
           </Row> 


          <Row style={styles.rowstyle}>
           <Col style={{width:'60%',alignItems:"flex-start"}}>
           <Item floatingLabel>
              <Label style={styles.floatlabel}>Invoice No.</Label>
              <Input 
                getRef={(input) => { this.invoiceno = input; }}
                returnKeyType='done'
                autoCorrect={false}
                style={styles.istyle}
                maxLength={30}
                autoCapitalize='words'
                keyboardType={'default'}
                value={this.state.ed_invoiceno}
                onChangeText={(ed_invoiceno) => this.setState({ ed_invoiceno })}
              />
            </Item>
           </Col> 
           <Col style={{width:'40%',alignItems:"flex-start"}}>
          
           <DateTimePicker
            isVisible={this.state.isDateTimePickerVisible}
            onConfirm={this.handleDatePicked}
            onCancel={this.hideDateTimePicker}/>   

           <Item  floatingLabel   onPress={this.showDateTimePicker.bind(this)}>
           <Label style={styles.floatlabel}>Invoice Date</Label>
           <Input 
           editable={false}
           style={styles.istyle}
           value={this.state.ed_invoicedate}/>
           </Item>

           </Col> 
           </Row>
       
          </Form>
       </Grid>
       
       <View style={{flexDirection:"row",alignItems:'center',paddingTop:20}}>
       <View style={styles.TButton}>
       <Button
            title="SUBMIT"
            buttonStyle={{
              backgroundColor:colorprimary
            }}
            onPress={this.onsave.bind(this)}/>
       </View>
       <View style={styles.TButton}>
       <Button
       title="CANCEL"
       buttonStyle={{
              backgroundColor:colorprimary
            }}
            onPress={this.oncancel.bind(this)}/>
       </View>
       </View>



       <Modal            
          animationType = {"slide"}  
          transparent = {true}  
          visible = {this.state.isglcode}  
          onRequestClose = {() =>{ console.log("Modal has been closed.") } }>  
          {/*All views of Modal*/}  
          <View style = {styles.modal}>  
          <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress = {() =>
           {  
            this.setState({ isglcode:!this.state.isglcode})
           }}>
        
        <Grid>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontWeight:'bold',alignSelf:'flex-start'}}>
             GL List
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('./src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
       </Grid>
  

         </TouchableOpacity>
         
         <SearchBar
         placeholder="Search GL Code"
         onChangeText={(text) => this.filtersearch(text)}
         value={this.state.text}
         platform={'ios'}
         searchIcon={{ name: "search", size: 19, color: colorprimary }}
         clearIcon={{ name: "close-circle", size: 19 }}
         loadingProps={{ size: "small" }}>
         </SearchBar>

         <FlatList
         data={ this.state.glcodesource}
         initialNumToRender={this.state.glcodesource.length}
         renderItem={({item}) => 
         <Card style={{width:'97%',alignSelf:'center'}}>
           <CardItem style={{alignItems:'flex-start',width:'100%',flexWrap:'wrap'}}>
           <Grid onPress={this.getglcodeitem.bind(this, item.sBcode,item.sBdesc)}>
           <Row>
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={{fontSize:13}}>{item.sBcode}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'70%'}}>
              <Text style={{fontSize:13}}>{item.sBdesc}</Text>
              </Col> 
              <Col>
             </Col>  
           </Row>
         </Grid>
           </CardItem>
         </Card>
    
        }
       keyExtractor={(item, index) => index.toString()}
      />

          </View>  
        </Modal>


        <Modal            
          animationType = {"slide"}  
          transparent = {true}  
          visible = {this.state.issite}  
          onRequestClose = {() =>{ console.log("Modal has been closed.") } }>  
          {/*All views of Modal*/}  
          <View style = {styles.modal}>  
          <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress = {() =>
           {  
            this.setState({ issite:!this.state.issite})
           }}>

        <Grid>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontWeight:'bold',alignSelf:'flex-start'}}>
             Site List
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('./src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
       </Grid>
       
      
         </TouchableOpacity>
         
         <FlatList
         data={ this.state.sitesource}
         initialNumToRender={this.state.sitesource.length}
         renderItem={({item}) => 
         <Card style={{width:'97%',alignSelf:'center'}}>
           <CardItem style={{alignItems:'flex-start',width:'100%',flexWrap:'wrap'}}>
           <Grid onPress={this.getsiteitems.bind(this, item.sCode,item.sDesc)}>
           <Row>
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={{fontSize:13}}>{item.sCode}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'70%'}}>
              <Text style={{fontSize:13}}>{item.sDesc}</Text>
              </Col> 
              <Col>
             </Col>  
           </Row>
         </Grid>
           </CardItem>
         </Card>
    
        }
       keyExtractor={(item, index) => index.toString()}
      />

          </View>  
        </Modal>


        <Modal            
          animationType = {"slide"}  
          transparent = {true}  
          visible = {this.state.isproject}  
          onRequestClose = {() =>{ console.log("Modal has been closed.") } }>  
          {/*All views of Modal*/}  
          <View style = {styles.modal}>  
          <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress = {() =>
           {  
            this.setState({ isproject:!this.state.isproject})
           }}>
       

       <Grid>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontWeight:'bold',alignSelf:'flex-start'}}>
             Project List
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('./src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
       </Grid>
        

         </TouchableOpacity>
         
         <FlatList
         data={ this.state.projectsource}
         initialNumToRender={this.state.projectsource.length}
         renderItem={({item}) => 
         <Card style={{width:'97%',alignSelf:'center'}}>
           <CardItem style={{alignItems:'flex-start',width:'100%',flexWrap:'wrap'}}>
           <Grid onPress={this.getprojectitems.bind(this, item.sCode,item.sDesc)}>
           <Row>
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={{fontSize:13}}>{item.sCode}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'70%'}}>
              <Text style={{fontSize:13}}>{item.sDesc}</Text>
              </Col> 
              <Col>
             </Col>  
           </Row>
         </Grid>
           </CardItem>
         </Card>
    
        }
       keyExtractor={(item, index) => index.toString()}
      />

          </View>  
        </Modal>

        <Modal            
          animationType = {"slide"}  
          transparent = {true}  
          visible = {this.state.isemployee}  
          onRequestClose = {() =>{ console.log("Modal has been closed.") } }>  
          {/*All views of Modal*/}  
          <View style = {styles.modal}>  
          <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress = {() =>
           {  
            this.setState({ isemployee:!this.state.isemployee})
           }}>
        
        <Grid>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontWeight:'bold',alignSelf:'flex-start'}}>
             Employee List
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('./src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
       </Grid>

      

         </TouchableOpacity>
         
         <FlatList
         data={ this.state.employeesource}
         initialNumToRender={this.state.employeesource.length}
         renderItem={({item}) => 
         <Card style={{width:'97%',alignSelf:'center'}}>
           <CardItem style={{alignItems:'flex-start',width:'100%',flexWrap:'wrap'}}>
           <Grid onPress={this.getemployeeitems.bind(this, item.sBcode,item.sBdesc)}>
           <Row>
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={{fontSize:13}}>{item.sBcode}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'70%'}}>
              <Text style={{fontSize:13}}>{item.sBdesc}</Text>
              </Col> 
              <Col>
             </Col>  
           </Row>
         </Grid>
           </CardItem>
         </Card>
    
        }
       keyExtractor={(item, index) => index.toString()}
      />

          </View>  
        </Modal>

        <Modal            
          animationType = {"slide"}  
          transparent = {true}  
          visible = {this.state.issupplier}  
          onRequestClose = {() =>{ console.log("Modal has been closed.") } }>  
          {/*All views of Modal*/}  
          <View style = {styles.modal}>  
          <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress = {() =>
           {  
            this.setState({ issupplier:!this.state.issupplier})
           }}>
        

        <Grid>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontWeight:'bold',alignSelf:'flex-start'}}>
             Supplier List
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('./src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
       </Grid>

         
         </TouchableOpacity>
         
         <FlatList
         data={ this.state.suppliersource}
         initialNumToRender={this.state.suppliersource.length}
         renderItem={({item}) => 
         <Card style={{width:'97%',alignSelf:'center'}}>
           <CardItem style={{alignItems:'flex-start',width:'100%',flexWrap:'wrap'}}>
           <Grid onPress={this.getsupplieritem.bind(this, item.sSCode,item.sSName)}>
           <Row>
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={{fontSize:13}}>{item.sSCode}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'70%'}}>
              <Row>
              <Col style={{alignItems:'flex-start',width:'100%'}}>
              <Text style={{fontSize:13}}>{item.sSName}</Text>
              </Col>
              </Row>
              <Row>
              <Col style={{alignItems:'flex-start',width:'100%'}}>
              <Text style={{fontSize:13}}>{item.sCountry}</Text>
              </Col>
              </Row>
              </Col> 
              <Col>
             </Col>  
           </Row>
         </Grid>
           </CardItem>
         </Card>
    
        }
       keyExtractor={(item, index) => index.toString()}
      />

          </View>  
        </Modal>


        <Modal            
          animationType = {"slide"}  
          transparent = {true}  
          visible = {this.state.iscost}  
          onRequestClose = {() =>{ console.log("Modal has been closed.") } }>  
          {/*All views of Modal*/}  
          <View style = {styles.modal}>  
          <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress = {() =>
           {  
            this.setState({ iscost:!this.state.iscost})
           }}>
         
         <Grid>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontWeight:'bold',alignSelf:'flex-start'}}>
             Cost List
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('./src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
       </Grid>
         

         </TouchableOpacity>
         
         <FlatList
         data={ this.state.costsource}
         initialNumToRender={this.state.costsource.length}
         renderItem={({item}) => 
         <Card style={{width:'97%',alignSelf:'center'}}>
           <CardItem style={{alignItems:'flex-start',width:'100%',flexWrap:'wrap'}}>
           <Grid onPress={this.getcostitems.bind(this, item.sCode,item.sDesc)}>
           <Row>
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={{fontSize:13}}>{item.sCode}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'70%'}}>
              <Text style={{fontSize:13}}>{item.sDesc}</Text>
              </Col> 
              <Col>
             </Col>  
           </Row>
         </Grid>
           </CardItem>
         </Card>
    
        }
       keyExtractor={(item, index) => index.toString()}
      />

          </View>  
        </Modal>


      <Toast ref="toast" />
</ScrollView>  
)
}
}

const styles = StyleSheet.create({
image:{
    width:40,
    height:40
},
textContent: {
    backgroundColor:colorprimary,
    fontSize: 12,
    padding:4,
    width:'97%',
    alignSelf:'center',
    color:white,
    fontWeight: 'bold'
  },
  imagebutton: {
    width:80,
    height: 80,
    alignSelf:'center'
  },
  imagetext:{
      color:colorprimary,
      fontSize:12,
      alignSelf:'center'
  },
  i: {
    paddingTop:10,
  },
  floatlabel:{
  color:colorprimarydark,
  fontSize:15
  },
  TButton:{
    width:'45%',
    height:50,
    paddingLeft:'10%'
  },
  headerback: {
    flexDirection: 'row',
    alignItems:'center',
    backgroundColor: colorprimary,
    borderWidth: 0.5,
    borderColor:white,
    height: 40,
    width:'100%',
    borderRadius: 5,
  },
  modal: {  
    flex: 1,
    backgroundColor:white,
    height:'70%', 
    position: 'absolute',
    bottom: 0,
    width:'100%'
     },
  container: {
    backgroundColor:white,
    flex: 1,
    height: '100%',
    justifyContent: 'space-around',
    left: 0,
    position: 'absolute',
    top: 0,
    width: '100%'
  },
  rowstyle:{
    paddingTop:6,
  },
  istyle:{
   fontSize: 13 
  }
});

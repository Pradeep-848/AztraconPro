import React, { Component } from 'react';
import {StyleSheet,TouchableOpacity,Alert,View,Modal,Image,ScrollView,Text} from 'react-native';
import Timeline from 'react-native-timeline-flatlist'
import axios from 'axios';
import { NavigationActions, StackActions } from 'react-navigation';
import { Col,Grid,Row } from 'react-native-easy-grid';
import {logouttask} from './class/logout';
import strings from './res/strings'
import color from './res/colors'
import moment from 'moment';
import Toast from 'react-native-whc-toast'
const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class LeaveApprovalStatus extends Component {
    static navigationOptions = ({ navigation }) => ({ 
        title: "Approvals Status",
        color:white,
        headerStyle: {
          backgroundColor:colorprimary,
        },
        headerTintColor:white,
        headerTitleStyle: {
         fontFamily:'Bold',
        },
        headerRight: (
          <TouchableOpacity style={{paddingRight:10}} onPress={() => 
          navigation.state.params.handlelogin()
          }>
          <Image
              style={{alignSelf:'center',justifyContent:'center'}}
              source={require('./src/logout.png')} />
          </TouchableOpacity>
        ),
        
      });
      constructor(props) {
        super(props);
        this.state = {
          USER:'',
          isLoading: false, 
          handlelogin:'',
          data:[],
          dataSource:[],
          LRNo:'',UserID:''
        };
    }
    componentDidMount(){
      console.disableYellowBox = true;

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
        this.setState({
            UserID:this.props.navigation.getParam('UserID', ''),
            LRNo:this.props.navigation.getParam('LRNo', '')},()=>{this.gettimeline();})
     }
     login = async () => 
     {
     
       Alert.alert(
         'Logout',
         'Would you like to logout?',
         [
           {
             text: 'Cancel',
             onPress: () => console.log('Cancel Pressed'),
             style: 'cancel',
           },
           {text: 'OK', onPress: () => { logouttask()
            this.props.navigation.dispatch(resetAction);} },
         ],
         {cancelable: false},
       );
      
     }
     gettimeline(){
        const config = {
            headers: {   
            'currentToken':tokken,
          },
            params: {
                LRNo:this.state.LRNo,
            }
            
          };
    
      this.setState({isLoading:true})
      axios.get(ip+'/getLeaveStatus', config)
        .then(response => this.setState({dataSource:response.data},() => {if(response.status==200){
        this.display()
        }}))
        .catch(err => 
          {
            this.setState({
              isLoading:false
            },()=>{
             let error=err
             
             this.refs.toast.showBottom(error.toString())
      
             setTimeout(
              () => { 
                this.props.navigation.goBack();
               },
              2000
            )
      
            })
          }
          );
           
     }
     display(){
      for(i=0;i< this.state.dataSource.length ;i++){
          const{E,C,D,A,F}=this.state.dataSource[i]
          let Desc,tit
          if(E!==''){
            if(D!=='' && D!=null){
              if (F=='O' || F=='P') {
                Desc=C+"\n"+"Remarks : "+E
              }else{
                Desc=C+"\n"+moment(D).format('DD-MM-YYYY').toString()+"\n"+"Remarks : "+E
              }
             
            }
            else{
              Desc=C+"\n"+"Remarks : "+E
            }
            
          }else{

            if(D!=='' && D!=null){

              if (F=='O' || F=='P') {
                Desc=C
              }else{
                Desc=C+"\n"+moment(D).format('DD-MM-YYYY').toString()
              }
           
            }else{
              Desc=C
            }
            
          }
    
          if(F==='A'){
              this.state.data.push({
                  title:A,
                  description:Desc,
                  lineColor:"#15ca7d",
                  icon:require('./src/ic_approved.png')
              })
          }else if(F==='P'){
              this.state.data.push({
                  title:A,
                  description:Desc, 
                  lineColor:"#f4b825",
                  icon:require('./src/ic_pending.png')
              })
          }else if(F==='R'){
              this.state.data.push({
                  title:A,
                  description:Desc,
                  lineColor:"#f6634b",
                  icon:require('./src/ic_rejected.png')
              })
          }else if(F==='O'){
              this.state.data.push({
                  title:A,
                  description:Desc,
                  lineColor:"#2d353a",
                  icon:require('./src/ic_opened.png')
              })
          }else if(F=='W'){
              this.state.data.push({
                  title:A,
                  description:Desc,
                  lineColor:"#2d353a",
                  icon:require('./src/ic_opened.png')
              })
          }
      
        }
        this.setState({isLoading:false})
   }
  
  render() {
    if (this.state.isLoading) {
        return (
          <Modal
          transparent={false}
          supportedOrientations={['portrait', 'landscape']}
          visible={this.state.isLoading}
          >
           <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
            <Image
            style={{width: 300, height: 200}}
            source={require('./src/gears.gif')}  />
            </View>     
          </Modal>
        )
    }
    //'rgb(45,156,219)'
    return (
      <View style={{flex:1}}>


      <ScrollView style={{height:'10%',paddingTop:'4%'}}>
                   <Grid style={{backgroundColor:colorprimary,padding:5,borderRadius:4,width:'97%',alignSelf:'center'}}>
                   <Row>
                    <Col style={{alignItems:'flex-start',width:"100%",paddingLeft:8}}>
                    <Text style={styles.textContent}>Approvals Timeline</Text>
                    </Col> 
                   </Row>
                   </Grid>
      </ScrollView>

      <ScrollView style={{height:'90%',paddingTop:'4%',width:'90%',alignSelf:'center'}}>
        <Timeline 
          style={styles.list}
          data={this.state.data}
          circleSize={25}
          showTime={false}
          circleColor='rgba(0,0,0,0)'
          lineColor='rgb(45,156,219)'
          descriptionStyle={{color:'gray',fontFamily:'Regular'}}
          innerCircle={'icon'}
        />
          <Toast ref="toast"/>
          </ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
	paddingTop:30,
    backgroundColor:'white'
  },
  list: {
    flex: 1,
    marginTop:10,
  },
  textContent: {
    fontSize: 13,
    color: '#fff',
   fontFamily:'Bold'
  },
});
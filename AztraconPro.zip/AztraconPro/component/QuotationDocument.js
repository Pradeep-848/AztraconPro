import React,{ Component }  from 'react';
import {ScrollView,StyleSheet,Text,View,Dimensions,Modal,Image,
  FlatList,TouchableOpacity,Alert,Linking} from 'react-native';
import { Col, Grid, Row } from 'react-native-easy-grid';
import { Divider } from 'react-native-elements';
import { NavigationActions, StackActions } from 'react-navigation';
import axios from 'axios';
import Toast from 'react-native-whc-toast'
import {Card,CardItem} from 'native-base';
import { RFValue } from "react-native-responsive-fontsize";

//own lib 
import {logouttask} from './class/logout';
import strings from './res/strings'
import color from './res/colors'

//constant
const fileip=strings.values.commonvalues.fileip;
const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const loading=color.values.Colors.loading;
const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const lightblue=color.values.Colors.lightblue;

//common style
const style_common = require('./class/style');

//logout
const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class QuotationDocument extends React.Component {
  static navigationOptions = ({ navigation }) => ({ 
    title: "Quotation Document",
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
      fontSize:RFValue(20)
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false, 
      dataSource:'',
      handlelogin:'',
      CusName:'',UserID:'',QID:'',CusID:''
    };
}

getquotationdocument=()=>{
  const config = {
    headers: {   
    'currentToken': tokken,
  },
    params: {
    QID:this.state.QID,
    }
  };

  this.setState({isLoading:true})
  axios.get(ip+'/getQuotDocument', config)
  .then(response => this.setState({ dataSource:response.data},() => {if(response.status==200){this.setState({isLoading:false})}}))
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
}

login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
        this.props.navigation.dispatch(resetAction);
      } },
    ],
    {cancelable: false},
  );
 
}
qutDownload(index){

  const{Attachdate,Document,Attachfile}=this.state.dataSource


  Linking.openURL(fileip+"/QuotDownload/file?FileName="+Attachfile+"&QID="+this.state.QID) 

}


componentDidMount(){
  
console.disableYellowBox = true;

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
  
  this.setState({
      CusName:this.props.navigation.getParam('CusName', ''),
      UserID:this.props.navigation.getParam('UserID', ''),
      QID:this.props.navigation.getParam('QID', ''),
      CusID:this.props.navigation.getParam('CusID', ''),
},()=>{this.getquotationdocument();})
}
  render() {
    if (this.state.isLoading) {
      return (
        <Modal
        transparent={false}
        visible={this.state.isLoading}
        supportedOrientations={['portrait', 'landscape']}
        >
         <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
          useNativeDriver={true}
          style={style_common.load_gif}
          source={require('./src/gears.gif')}  />
          </View>     
        </Modal>
      )
  }
    return (
    <ScrollView style={{backgroundColor:lightblue}}>
     <Grid style={{paddingTop:'2%'}}>
     <Row style={{backgroundColor:colorprimary,width:'97%',alignSelf:'center',borderRadius:3}}>
     <Text style={styles.titleText}>
          {"QuotationID"+"-"+this.state.QID}
     </Text>
     </Row>

     <View style={{borderBottomColor:white,borderBottomWidth: 1,paddingTop:RFValue(5)}}/>

     <Row style={{backgroundColor:colorprimary,width:'97%',alignSelf:'center',borderRadius:3}}>
     <Text numberOfLines={1} style={styles.titleText}>
          {this.state.CusName+"-"+this.state.CusID}
     </Text>

     </Row>  
     </Grid>
  
    <View style={{ flex: 1,paddingTop:RFValue(8),display:this.state.dataSource.length==0?'none':'flex'}}>
             <Grid style={{backgroundColor:colorprimary,padding:RFValue(6),width:"97%",alignSelf:'center'}}>
             <Row>
              <Col style={{alignItems:'flex-start',width:'25%'}}>
              <Text style={styles.textContent}>Attach Date</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'75%'}}>
              <Text style={styles.textContent}>Document Name</Text>
              </Col> 
             </Row>
    </Grid>
    </View>
    <FlatList
       data={ this.state.dataSource }
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
            <CardItem style={style_common.card_item_padding}>
            <Grid onPress={() => this.qutDownload(index)}>           
            <Row>
              <Col style={{alignItems:'flex-start',width:'25%'}}>
              <Text style={{fontSize:RFValue(12),fontFamily:'Regular'}}>{item.Attachdate}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'75%'}}>
              <Text style={{fontSize:RFValue(12),fontFamily:'Regular'}}>{item.Document}</Text>
              </Col> 
             </Row>     
              <Row>
              <Col style={{alignItems:'flex-start',width:'20%'}}>
              <Text style={{fontSize:RFValue(12),color:colorprimary,fontFamily:'Bold'}}>Attach File</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'80%'}}>
              <Text style={{fontSize:RFValue(12),fontFamily:'Regular'}}>{item.Attachfile}</Text>
              </Col> 
            </Row>
            </Grid>  
             </CardItem>
           </Card>
        }

       keyExtractor={(item, index) => index.toString()}
       
      />

<Toast ref="toast"/>

          </ScrollView>
        )
      }
 };
 const styles = StyleSheet.create({
  titleText: {
    flex:1,
    flexWrap:'wrap',
    color:white,
    fontSize:RFValue(12),
    padding:RFValue(8),
    fontFamily:'Bold'
  },
  textContent:{
    color:white,
    fontSize:RFValue(12),
    fontFamily:'Bold'
  }
  });
  
  
  
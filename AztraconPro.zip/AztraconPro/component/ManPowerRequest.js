import React,{ Component }  from 'react';
import {Dimensions,View,FlatList,Keyboard,TouchableOpacity,StyleSheet,Text,Image,ScrollView,Alert,KeyboardAvoidingView,Platform,Modal} from 'react-native';
import { Col, Grid,Row } from 'react-native-easy-grid';
import { Card,CardItem,Item,Input,Form,Label } from 'native-base';
import { NavigationActions, StackActions } from 'react-navigation';
import DateTimePicker from "react-native-modal-datetime-picker";
import {Button,SearchBar} from 'react-native-elements'
import Toast from 'react-native-whc-toast'
import moment, { parseTwoDigitYear } from 'moment';
import axios from 'axios';
import {logouttask} from './class/logout';
import color from './res/colors'
import strings from './res/strings'

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const colorprimarydark=color.values.Colors.colorPrimaryDark;

const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);
const moverheight=screenHeight/8

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});
 export default class ManPowerRequest extends React.Component {
   static navigationOptions = ({ navigation }) => ({ 
    title: "ManPower Request",
    headerStyle: {
      backgroundColor: colorprimary
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
  });
  
  constructor(props) {
    super(props);
    this.state = {
         isworkcatwake:false,isjopwake:false,spn_workcat:'',isjoptypewake:false,Spn_WorkCat_code:'',spn_WorkCat_desc:'',workcatsource:''
         ,jopsource:'',ed_narration:'',ed_name:'',ed_man_count:'',UserID:"",handlelogin:'',ed_reqdate:moment(new Date()).format("DD/MMM/YYYY"),  
    };
    this.arrayholder = [];
}

 

onsave(){

  const{Spn_WorkCat_code,Spn_jop_code,ed_man_count}=this.state

  if(Spn_WorkCat_code==null || Spn_WorkCat_code==''){
    this.refs.toast.showBottom('Please Select Work Category',500);
  }else if(Spn_jop_code==null || Spn_jop_code==''){
    this.refs.toast.showBottom('Please Select Jop Type',500);
  }else if(ed_man_count==null || ed_man_count=='')
  {
    this.refs.toast.showBottom('Please Enter No of Man Power',500);
  }else{
    this.setState({isLoading:true})

    let u="/addManPowerRequest"
  
    axios({
      method: 'post',
      url:ip+u,
      headers: {'currentToken':tokken}, 
  
      data:{
        UserID:this.state.UserID,
        GroupCode:this.state.Spn_WorkCat_code,    
        Code:this.state.Spn_jop_code,
        ReqCont:this.state.ed_man_count,
        Remark:this.state.ed_narration,
      },
  
  
    }).then(response=>{if(response.status===200){
          this.setState({isLoading:false},()=>{ 
             this.refs.toast.showBottom('Save Successful');
             this.props.navigation.goBack();
          })
    }else{
      this.refs.toast.showBottom('Save Failed');
    }})
    .catch(err => 
      {
        this.setState({
          isLoading:false
        },()=>{
         let error=err
         
         this.refs.toast.showBottom(error.toString())
    
         setTimeout(
          () => { 
            this.props.navigation.goBack();
           },
          2000
        )
    
        })
      }
      );
  }
 
}
oncancel(){
  this.props.navigation.goBack();
}


getworkcategory(){
  console.log("a")
  const config = {
      headers: {   
      'currentToken': tokken,
    }};

    this.setState({isLoading:true})
    axios.get(ip+'/getWorkCategory', config)
    .then(response => this.setState({workcatsource:response.data},() => {if(response.status==200){

        this.setState({isLoading:false});
      }}))
      .catch(err => 
        {
          this.setState({
            isLoading:false
          },()=>{
           let error=err
           
           this.refs.toast.showBottom(error.toString())
      
           setTimeout(
            () => { 
              this.props.navigation.goBack();
             },
            2000
          )
      
          })
        }
        );

}
getworkcategoryitem (code,desc) {

  this.setState({
    Spn_WorkCat_code:code,
    spn_WorkCat_desc:code+"--"+desc,
    isworkcatwake:false,
    isjopwake:true,
    spn_jop_desc:null
  },()=>{
      this.getjoptype();
  })

}


getjoptype(){
  
  const config = {
      headers: {   
      'currentToken': tokken,
    },   
    params:{
        'WorkCat':this.state.Spn_WorkCat_code
      }
    };

    this.setState({isLoading:true})
    axios.get(ip+'/getJopType', config)
    .then(response => this.setState({jopsource:response.data},() => {if(response.status==200){

        this.setState({isLoading:false});
      }}))
      .catch(err => 
        {
          this.setState({
            isLoading:false
          },()=>{
           let error=err
           
           this.refs.toast.showBottom(error.toString())
      
           setTimeout(
            () => { 
              this.props.navigation.goBack();
             },
            2000
          )
      
          })
        }
        );

}

getjopttypeitem (code,desc) {

  this.setState({
    Spn_jop_code:code,
    spn_jop_desc:desc,
    isjoptypewake:!this.state.isjoptypewake,
  })

}


login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
      this.props.navigation.dispatch(resetAction);
    }},
    ],
    {cancelable: false},
  );
 
}


componentDidMount(){

  console.disableYellowBox = true;

  this.props.navigation.setParams({
    handlelogin: this.login.bind(this)
    });

  this.setState({
    Dept:this.props.navigation.getParam('Department', ''),
    UserID:this.props.navigation.getParam('UserID', ''),
    ed_name:this.props.navigation.getParam('Name', ''),
},()=>{
  this.getworkcategory()
})
  
}


onlayoutjoptype(){

  if(this.state.isjopwake==true){
    this.setState({
        isjoptypewake:!this.state.isjoptypewake,
    })
  }else{
    this.refs.toast.showBottom("Please Select Work Category")
  }

}

onlayoutworkcat(){
    this.setState({
        isworkcatwake:!this.state.isworkcatwake
    })
}

render() {

  if (this.state.isLoading) {
    return (
      <Modal
      useNativeDriver={true}
      transparent={false}
      supportedOrientations={['portrait', 'landscape']}
      visible={this.state.isLoading}
      >
       <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
        <Image
        style={{width: 300, height: 200}}
        source={require('./src/gears.gif')}  />
        </View>     
      </Modal>
    )
  }
return (
<ScrollView>
       <Grid>
       <Form>


           <Row style={styles.rowstyle}>
           <Col style={{width:'100%',alignItems:'flex-start'}}>
           <Item  floatingLabel>
           <Label style={styles.floatlabel}>Name</Label>
           <Input 
           editable={false}
           style={styles.istyle}
           multiline={true}
           value={this.state.ed_name}/>
           </Item>
           </Col>
           </Row> 

           <Row style={styles.rowstyle}>
           <Col style={{width:'100%',alignItems:'flex-start'}}>
           <Item  floatingLabel>
           <Label style={styles.floatlabel}>Email</Label>
           <Input 
           editable={false}
           style={styles.istyle}
           multiline={true}
           value={this.state.UserID}/>
           </Item>
           </Col>
           </Row> 

           <Row style={styles.rowstyle}>
           <Col style={{width:'100%',alignItems:'flex-start'}}>
           <Item floatingLabel>
              <Label style={styles.floatlabel}>Req Date</Label>
              <Input 
                editable={false}
                getRef={(input) => { this.vocdate = input; }}
                returnKeyType='next'
                style={styles.istyle}
                value={this.state.ed_reqdate}
                onChangeText={(ed_reqdate) => this.setState({ ed_reqdate })}
                focus={false}
              />
            </Item>
           </Col>
           </Row>

           <Row style={styles.rowstyle}>
           <Col style={{width:'100%',alignItems:'flex-start'}}>
           <Item  floatingLabel onPress={this.onlayoutworkcat.bind(this)}>
           <Label style={styles.floatlabel}>Work Category</Label>
           <Input 
           editable={false}
           style={styles.istyle}
           multiline={true}
           value={this.state.spn_WorkCat_desc}/>
           </Item>
           </Col>
           </Row> 

           <Row style={styles.rowstyle}>
           <Col style={{width:'100%',alignItems:'flex-start'}}>
           <Item  floatingLabel onPress={this.onlayoutjoptype.bind(this)}>
           <Label style={styles.floatlabel}>Jop Category</Label>
           <Input 
           editable={false}
           multiline={true}
           style={styles.istyle}
           value={this.state.spn_jop_desc}/>
           </Item>
           </Col>
           </Row> 

           <Row style={styles.rowstyle}>
           <Col style={{width:'100%',alignItems:"flex-start"}}>
           <Item  floatingLabel>
              <Label style={styles.floatlabel}>Narration</Label>
              <Input 
                getRef={(input) => { this.narration = input; }}
                returnKeyType='next'
                maxLength={100}
                style={styles.istyle}
                autoCorrect={false}
                autoCapitalize='words'
                keyboardType={'default'}
                value={this.state.ed_narration}
                onChangeText={(ed_narration) => this.setState({ ed_narration })}
                onSubmitEditing={() => { this.mancount._root.focus(); }}
              />
            </Item>
            </Col>
           </Row>


           <Row style={styles.rowstyle}>

            <Col style={{width:'100%',alignItems:"flex-start"}}>

            <Item floatingLabel>
              <Label style={styles.floatlabel}>ManPower Count</Label>
              
               <Input 
                getRef={(input) => { this.mancount = input; }}
                returnKeyType='done'
                autoCorrect={false}
                maxLength={4}
                style={styles.istyle}
                keyboardType={'numeric'}
                value={this.state.ed_man_count}
                onChangeText={(ed_man_count) => this.setState({ ed_man_count })}
              /> 
            </Item>
            </Col>

           </Row>

        
          </Form>
       </Grid>
       
       <View style={{flexDirection:"row",alignItems:'center',paddingTop:20}}>
       <View style={styles.TButton}>
       <Button
            title="SUBMIT"
            buttonStyle={{
              backgroundColor:colorprimary
            }}
            onPress={this.onsave.bind(this)}/>
       </View>
       <View style={styles.TButton}>
       <Button
       title="CANCEL"
       buttonStyle={{
              backgroundColor:colorprimary
            }}
            onPress={this.oncancel.bind(this)}/>
       </View>
       </View>



        <Modal            
          animationType = {"slide"}  
          transparent = {true}  
          visible = {this.state.isworkcatwake}  
          onRequestClose = {() =>{ console.log("Modal has been closed.") } }>  
          {/*All views of Modal*/}  
          <View style = {styles.modal}>  
          <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress = {() =>
           {  
            this.setState({ isworkcatwake:!this.state.isworkcatwake})
           }}>
        
        <Grid>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontWeight:'bold',alignSelf:'flex-start'}}>
             Work Category
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('./src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
       </Grid>

         </TouchableOpacity>
         
         <FlatList
         data={ this.state.workcatsource}
         initialNumToRender={this.state.workcatsource.length}
         renderItem={({item}) => 
         <Card style={{width:'97%',alignSelf:'center'}}>
           <CardItem style={{alignItems:'flex-start',width:'100%',flexWrap:'wrap'}}>
           <Grid onPress={this.getworkcategoryitem.bind(this, item.Code,item.Description)}>
           <Row>
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={{fontSize:13}}>{item.Code}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'70%'}}>
              <Text style={{fontSize:13}}>{item.Description}</Text>
              </Col> 
              <Col>
             </Col>  
           </Row>
         </Grid>
           </CardItem>
         </Card>
    
        }
       keyExtractor={(item, index) => index.toString()}
      />

          </View>  
        </Modal>

        <Modal            
          animationType = {"slide"}  
          transparent = {true}  
          visible = {this.state.isjoptypewake}  
          onRequestClose = {() =>{ console.log("Modal has been closed.") } }>  
          {/*All views of Modal*/}  
          <View style = {styles.modal}>  
          <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress = {() =>
           {  
            this.setState({ isjoptypewake:!this.state.isjoptypewake})
           }}>
        
        <Grid>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontWeight:'bold',alignSelf:'flex-start'}}>
             Jop Type
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('./src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
       </Grid>
         
         </TouchableOpacity>
         
         <FlatList
         data={ this.state.jopsource}
         initialNumToRender={this.state.jopsource.length}
         renderItem={({item}) => 
         <Card style={{width:'97%',alignSelf:'center'}}>
           <CardItem style={{alignItems:'flex-start',width:'100%',flexWrap:'wrap'}}>
           <Grid onPress={this.getjopttypeitem.bind(this, item.Code,item.Description)}>
           <Row>
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={{fontSize:13}}>{item.SNo}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'70%'}}>
              <Text style={{fontSize:13}}>{item.Description}</Text>
              </Col> 
              <Col>
             </Col>  
           </Row>
         </Grid>
           </CardItem>
         </Card>
    
        }
       keyExtractor={(item, index) => index.toString()}
      />

          </View>  
        </Modal>

      <Toast ref="toast" />
</ScrollView>  
)
}
}

const styles = StyleSheet.create({
image:{
    width:40,
    height:40
},
textContent: {
    backgroundColor:colorprimary,
    fontSize: 12,
    padding:4,
    width:'97%',
    alignSelf:'center',
    color:white,
    fontWeight: 'bold'
  },
  imagebutton: {
    width:80,
    height: 80,
    alignSelf:'center'
  },
  imagetext:{
      color:colorprimary,
      fontSize:12,
      alignSelf:'center'
  },
  i: {
    paddingTop:10,
  },
  floatlabel:{
  color:colorprimarydark,
  fontSize:15
  },
  TButton:{
    width:'45%',
    height:50,
    paddingLeft:'10%'
  },
  headerback: {
    flexDirection: 'row',
    alignItems:'center',
    backgroundColor: colorprimary,
    borderWidth: 0.5,
    borderColor:white,
    height: 40,
    width:'100%',
    borderRadius: 5,
  },
  modal: {  
    flex: 1,
    backgroundColor:white,
    height:'70%', 
    position: 'absolute',
    bottom: 0,
    width:'100%'
     },
  container: {
    backgroundColor:white,
    flex: 1,
    height: '100%',
    justifyContent: 'space-around',
    left: 0,
    position: 'absolute',
    top: 0,
    width: '100%'
  },
  rowstyle:{
    paddingTop:6,
  },
  istyle:{
   fontSize: 13 
  }
});

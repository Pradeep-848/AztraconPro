import React, { Component, useState } from "react";
import {
  ScrollView,
  Modal,
  StyleSheet,
  Text,
  Dimensions,
  View,
  Image,
  FlatList,
  TouchableOpacity,
  Alert,
  RefreshControl,
  Button,
} from "react-native";
import { Row, Col, Grid } from "react-native-easy-grid";
import axios from "axios";
import { NavigationActions, StackActions } from "react-navigation";
import colors from "./res/colors";
import strings from "./res/strings";
import { RFValue } from "react-native-responsive-fontsize";
import { refresh } from "@react-native-community/netinfo";
import Collapsible from "react-native-collapsible";

//common style
const style_common = require("./class/style");

var { height, width } = Dimensions.get("window");

const colorprimary = colors.values.Colors.colorPrimary;
const white = colors.values.Colors.white;
const dark = colors.values.Colors.colorPrimaryDark;
const primary = colors.values.Colors.colorPrimary;
const colorPrimaryDark = colors.values.Colors.colorPrimaryDark;

const ip = strings.values.commonvalues.ip;
const tokken = strings.values.commonvalues.tokken;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: "LoginActivity" })],
});

export default class ManPowerDistribution extends React.Component {
  static navigationOptions = ({ navigation }) => ({
    title: "ManPowerDistribution",
    color: white,
    headerStyle: {
      backgroundColor: primary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily: "Bold",
      fontSize: RFValue(20),
    },
    headerRight: (
      <View style={{ flexDirection: "row", width: width * 0.3 }}>
        <TouchableOpacity
          style={{
            flex: 1,
            alignItems: "flex-end",
            paddingLeft: 10,
            marginLeft: "2%",
          }}
          onPress={() => navigation.state.params.handleRefresh()}
        >
          <Image
            style={{ width: 20, height: 20 }}
            source={require("./src/refresh.png")}
          />
        </TouchableOpacity>
        <TouchableOpacity
          style={{ flex: 1, alignItems: "flex-end", paddingRight: 10 }}
          onPress={() => navigation.state.params.handlelogin()}
        >
          <Image
            style={{ width: 20, height: 20 }}
            source={require("./src/logout.png")}
          />
        </TouchableOpacity>
      </View>
    ),
  });

  constructor(props) {
    super(props);
    this.state = {
      handlelogin: "",
      data: "",
      USER: "",
      Revenue_YTD: "",
      Unbilled_Revenue: "",
      Billing_YTD: "",
      MenudataProjectA: [],
      MenudataProjectB: [],
      isLoading: true,
      refreshing: false,
      layout: {
        height: height,
        width: width,
      },
    };
  }

  _onLayout = (event) => {
    this.setState({
      layout: {
        height: event.nativeEvent.layout.height,
        width: event.nativeEvent.layout.width,
      },
    });
  };

  login = async () => {
    Alert.alert(
      "Logout",
      "Would you like to logout?",
      [
        {
          text: "Cancel",
          onPress: () => console.log("Cancel Pressed"),
          style: "cancel",
        },
        {
          text: "OK",
          onPress: () => {
            this.props.navigation.dispatch(resetAction);
          },
        },
      ],
      { cancelable: false }
    );
  };

  format(x) {
    if (isNaN(x) || x === null || x === undefined) {
      return "-"; // Return an empty string if x is not a valid number
    }
    return Math.round(x)
      .toString()
      .replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  }

  getDashBoard = () => {
    const config = {
      headers: {
        currentToken: tokken,
      },
      params: {
        userid: this.state.USER,
      },
    };

    this.setState({ isLoading: !this.state.refreshing });

    axios
      .get(ip + "/getFinDashBoard", config)
      .then((response) => {
        console.log("Response:", response);
        if (response.status === 200) {
          const data = response.data;
          console.log("Response:", response.data);

          this.setState({
            dataSource: data,
            Revenue_YTD: data.A,
            Unbilled_Revenue: data.B,
            Billing_YTD: data.C,
            YetToBeInvoice: data.D,
            Collection_YTD: data.E,
            YetToBeInvoiceNet_Receivables: data.F,
            Bank_Debt_YTD: data.G,
            Bank_Loan_YTD: data.H,
            LC_Exposure_YTD: data.I,
            Fin_Cost_YTD: data.J,
            Net_Receivables: data.K,
            Net_Payables: data.L,
            Billing_MTD: data.M,
            Collection_MTD: data.N,
            CashOnHand: data.O,
            Bank_Debt_NR_MTD: data.P,
            BS_Exposure: data.Q,
            Bank_Debt_MTD: data.R,
            LC_Exposure: data.S,
            BG_Exposure: data.T,
            Net_Receivables_MTD: data.U,
            Net_Payables_MTD: data.V,
            Net_Inventory: data.W,
            Net_Payables_MTDNet_Inventory: data.X,
            MenudataProjectA: [
              { A: "Revenue", B: data.A },
              { A: "Pending Revenue", B: data.B },
              { A: "Billing", B: data.C },
              { A: "Pending Billing", B: data.D },
              { A: "Collection", B: data.E },
              { A: "Pending Collection", B: data.F },
              { A: "Bank Debt", B: data.G },
              { A: "Bank Loan", B: data.H },
              { A: "LC Availability", B: data.I },
              { A: "Financial Cost", B: data.J },
              { A: "Accounts Receivable", B: data.K },
              { A: "Accounts Payable", B: data.L },
            ],
            MenudataProjectB: [
              { A: "Billing", B: data.M },
              { A: "Collection", B: data.N },
              { A: "Cash at Bank", B: data.O },
              { A: "Bank Debt Loan", B: data.P },
              { A: "Bank Debt Loan + 1", B: data.Q },
              { A: "Bank Debt", B: data.R },
              { A: "LC Payments", B: data.S },
              { A: "STL Financable", B: data.T },
              { A: "Accounts Receivable", B: data.U },
              { A: "Accounts Payable without LC", B: data.V },
              { A: "LC Exports", B: data.W },
              { A: "Accounts Payables", B: data.X },
            ],
            Current_Date_Time: data.Y,
            isLoading: false,
            refreshing: false,
          });
        }
      })
      .catch((err) => {
        console.error("Error:", err);
        this.setState(
          {
            isLoading: false,
            refreshing: false,
          },
          () => {
            setTimeout(() => {
              this.props.navigation.goBack();
            }, 2000);
          }
        );
      });
  };

  componentDidMount() {
    this.setState(
      { USER: this.props.navigation.getParam("UserID", "") },
      () => {
        this.getDashBoard();
      }
    );

    this.props.navigation.setParams({
      handlelogin: this.login.bind(this),
      handleRefresh: this.onRefresh.bind(this),
    });
  }

  onRefresh = () => {
    this.setState({ refreshing: true }, () => {
      this.getDashBoard();
    });
  };

  getheight(which) {
    let orient = this.state.orientation;
    let device = this.state.DeviceType;

    if (which == "1") {
      //header
      if (device == "phone") {
        if (orient == "portrait") {
          return "10%";
        } else {
          //landscape
          return "25%";
        }
      } else {
        //tab
        if (orient == "portrait") {
          return "10%";
        } else {
          //landscape
          return "13%";
        }
      }
    }

    if (which == "2") {
      //body
      if (device == "phone") {
        if (orient == "portrait") {
          return "90%";
        } else {
          //landscape
          return "75%";
        }
      } else {
        //tab
        if (orient == "portrait") {
          return "90%";
        } else {
          //landscape
          return "87%";
        }
      }
    }
  }

  render() {
    if (this.state.isLoading) {
      return (
        <Modal
          transparent={false}
          supportedOrientations={["portrait", "landscape"]}
          visible={this.state.isLoading}
        >
          <View
            onLayout={this._onLayout}
            style={{ flex: 1, alignItems: "center", justifyContent: "center" }}
          >
            <Image
              useNativeDriver={true}
              style={style_common.load_gif}
              source={require("./src/gears.gif")}
            />
          </View>
        </Modal>
      );
    }
    return (
      <View style={{ flex: 1 }}>
        {/* <ScrollView refreshControl={
                    <RefreshControl
                        tintColor={primary}
                        refreshing={this.state.refreshing}
                        onRefresh={this.onRefresh}
                    />
                }> */}
        <ScrollView style={{ height: this.getheight("2") }}>
        <Grid
            style={{
              backgroundColor: colorprimary,
              padding: RFValue(7),
              width: "97%",
              alignSelf: "center",
              borderRadius: 4,
            }}
          >
            <Row>
              <Col style={{ alignItems: "flex-start", width: "20%" }}>
                <Text style={styles.textContent}>Active</Text>
              </Col>
              <Col style={{ alignItems: "flex-start", width: "25%" }}>
                <Text style={styles.textContent}>Vacation</Text>
              </Col>
              <Col style={{ alignItems: "flex-start", width: "20%" }}>
                <Text style={styles.textContent}>AZ Count</Text>
              </Col>
              <Col style={{ alignItems: "flex-end", width: "35%" }}>
                <Text style={styles.textContent}>MPS [AZ + MPS]</Text>
              </Col>
            </Row>
          </Grid>

          <Collapsible >
          <Text>Heloo</Text>
          </Collapsible>

          <FlatList
            data={this.state.MenudataProjectA}
            scrollEnabled={false}
            renderItem={({ item }) => {
              const textColor = item.A === "Bank Loan" ? "red" : "grey";

              return (
                <Grid style={{ flex: 1 / 3 }}>
                  <Row>
                    <Col
                      style={{
                        alignItems: "center",
                        width: "100%",
                        alignSelf: "center",
                      }}
                    >
                      <Text
                        style={{
                          alignSelf: "center",
                          flexWrap: "wrap",
                          fontSize: RFValue(12),
                          fontFamily: "Bold",
                          color: colorprimary,
                          textAlign: "center",
                        }}
                      >
                        {item.A}
                      </Text>

                      <View
                        style={{
                          height: (height * 8) / 100,
                          width: (width * 20) / 100,
                          justifyContent: "center",
                          alignItems: "center",
                        }}
                      >
                        <Text
                          style={{
                            color: textColor,
                            fontSize: RFValue(11),
                            fontFamily: "Bold",
                          }}
                        >
                          {this.format(item.B)}
                        </Text>
                      </View>
                    </Col>
                  </Row>
                </Grid>
              );
            }}
            numColumns={3}
            keyExtractor={(item, index) => index.toString()}
          />

          <Row
            style={{
              backgroundColor: colorPrimaryDark,
              padding: RFValue(5),
              width: "97%",
              alignSelf: "center",
              borderRadius: 4,
              marginTop: "2%",
              marginBottom: "2%",
            }}
          >
            <Text style={styles.titleText}>Grand Total:</Text>
          </Row>
        </ScrollView>

        {/* </ScrollView> */}
      </View>
    );
  }
}

const styles = StyleSheet.create({
  titleText: {
    fontSize: RFValue(13),
    fontFamily: "Bold",
    color: white,
    alignSelf: "center",
    justifyContent: "center",
    textAlign: "justify",
  },
  detail: {
    fontSize: RFValue(13),
    fontFamily: "Bold",
  },
  tittle: {
    color: "#36428a",
    fontSize: RFValue(13),
    paddingLeft: 5,
    fontFamily: "Bold",
  },
  textContent: {
    color: white,
    fontSize: RFValue(12),
    fontFamily: "Bold",
  },
});

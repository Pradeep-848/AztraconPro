import React from 'react';
import {ScrollView,Dimensions,Image,Modal,SectionList,StyleSheet,Text,View,TouchableOpacity,Alert} from 'react-native';
import axios from 'axios';
import { Col, Grid, Row} from 'react-native-easy-grid';
import { NavigationActions, StackActions } from 'react-navigation';
import {Card,CardItem} from 'native-base';
import { SearchBar } from 'react-native-elements';
import strings from './res/strings'
import {logouttask} from './class/logout';
import Toast from 'react-native-whc-toast'
import color from './res/colors'

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const { width, height } = Dimensions.get('window');

const blue=color.values.Colors.blue;
const black=color.values.Colors.black;
const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const lightblue=color.values.Colors.lightblue;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class PayAppPending extends React.Component{
  static navigationOptions = ({ navigation }) => ({ 
    title: "Payment Approval",
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor:white,
    headerTitleStyle: {
     fontFamily:'Bold'
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
      super(props);
      this.state = { 
        isLoading: true, 
        data: "",
        handlelogin:'',
        UserID:'',
        text:''
    };
      this.arrayholder = [] ;
      console.disableYellowBox = true;
  }

  login = async () => 
  {
  
    Alert.alert(
      'Logout',
      'Would you like to logout?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {text: 'OK', onPress: () => { logouttask()
          this.props.navigation.dispatch(resetAction);} },
      ],
      {cancelable: false},
    );
   
  }
  

componentDidMount() {

  this.setState({
    isLoading:true
  })

  console.disableYellowBox = true;

 const { navigation } = this.props;


 this.focusListener = navigation.addListener("didFocus", () => {


  this.setState({
    UserID:this.props.navigation.getParam('UserID', ''),
  },()=>{
    this.props.navigation.setParams({
      handlelogin: this.login.bind(this),
     
      });
      this.getpaymentapproval();
  })


});

}

gotoapproval(rdate,payto,pid,pname,payid,newid,amt,cb,bal,doc,file,rem,reqby,ptype,pdate,seqno,ver,aprAmt){

  console.log(pid)
  
  console.log(ptype)

        this.props.navigation.navigate('PayApprovalActivity',{
            rdate:rdate,
            payto:payto,
            pid:pid,
            pname:pname,
            payid:payid,
            newid:newid,
            amt:amt,
            cb:cb,
            bal:bal,
            doc:doc,
            file:file,
            rem:rem,
            reqby:reqby,
            ptype:ptype,
            pdate:pdate,
            seqno:seqno,
            ver:ver,
            aprAmt:aprAmt,
            UserID:this.state.UserID,
        });
  
    

}

getGrandTotal(){

  var total=0.0

  this.state.data.map((item) => {
  
      item.data.map((Item) => {
        let newamt =  Item.amt
        total=total+parseFloat(newamt)
       
      })
    
})

var retureVal=this.format((Math.round(total * 100) / 100).toFixed(2));

return retureVal

}

getSubTotal(secHead){

  var total=0.0

  this.state.data.map((item) => {
  
    var title = item.Title;

    if(secHead==title){
  
      item.data.map((Item) => {
        let newamt =  Item.amt
        total=total+parseFloat(newamt)
       
      })

    }
})

var retureVal=this.format((Math.round(total * 100) / 100).toFixed(2));

 return retureVal

}

SearchFilterFunction(searchquery){

  if( searchquery == undefined || searchquery == '') {
    this.setState({
      data: this.arrayholder,
      text:''
    })
    return;
  }

  if (searchquery.trim().length > 0) {
      var temp = []

      this.arrayholder.map((item) => {
            var dataItem = {};

            var title = item.Title;

            var brandData = [];

            item.data.map((searchItem) => {
              let newid =  searchItem.newid
                if (newid.match(searchquery)) {
                  brandData.push(searchItem);
                }
            })
            // if (brandData.length > 0) {
            // } else {
            //  return null;
            // }
            dataItem.Title = title;
            dataItem.data = brandData;
            temp.push(dataItem);

            if(temp.length > 0){

              this.setState({
                data: temp,
              })
              
            }else{
              this.setState({
                data: [],
              })
            }
         

      })


      this.setState({
        text:searchquery
      })
}

}

getpaymentapproval(){
    const config = {
      headers: {   
      'currentToken':tokken,
    },
      params: {
        UserID:this.state.UserID,
      }
    };
    this.setState({isLoading:true});
    axios.get(ip+'/getPayApprovalListIOSV2', config)
  .then(response => this.setState({data:response.data},() => {if(response.status==200){
      this.arrayholder = this.state.data ;  
      this.setState({isLoading:false});
    }
}))
.catch(err => 
  {
    this.setState({
      isLoading:false
    },()=>{
     let error=err
     
     this.refs.toast.showBottom(error.toString())

     setTimeout(
      () => { 
        this.props.navigation.goBack();
       },
      2000
    )

    })
  }
  );
  
}

format(x) {
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}


  renderItem(item) {    

    const {payid,pdate,amt,rdate,payto,pid,pname,newid,cb,bal,doc,file,rem,reqby,ptype,seqno,ver,apramt} = item.item;
      return (
            <Card style={{width:'97%',alignSelf:'center'}}>
               <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
                  paddingLeft:5,paddingRight:5,paddingTop:6,paddingBottom:6}}>
               <Grid onPress={this.gotoapproval.bind(this,
               rdate,payto,pid,pname,payid,newid,amt,cb,bal,doc,file,rem,reqby,ptype,pdate,seqno,ver,apramt
               )}>
               <Row>
               <Col style={{alignItems:'flex-start',width:'30%'}}>
               <Text style={{fontSize:12,color:black,fontFamily:'Regular'}}>{newid}</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'30%'}}>
               <Text style={{fontSize:12,color:black,fontFamily:'Regular'}}>{pdate}</Text>
               </Col>
               <Col style={{alignItems:'flex-end',width:'40%'}}>
               <Text style={{fontSize:12,color:black,fontFamily:'Regular'}}>{this.format((Math.round(amt * 100) / 100).toFixed(2))}</Text>
               </Col>
               </Row>
               </Grid>   
               </CardItem>
               </Card>
      );

  }

  render() {
      if (this.state.isLoading) {
          return (
            <Modal
            transparent={false}
            supportedOrientations={['portrait', 'landscape']}
            visible={this.state.isLoading}
            >
             <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
              <Image
              style={{width: 300, height: 200}}
              source={require('./src/gears.gif')}  />
              </View>     
            </Modal>
          )
      }

    return (
    <View style={{flex:1,backgroundColor:lightblue}}>
         <ScrollView style={{height:'10%'}}>
      <SearchBar
        placeholder="Search"
        keyboardType='numeric'
        onChangeText={(text) => this.SearchFilterFunction(text)}
        value={this.state.text}
        searchIcon={{ name: "search", size: 19, color: colorprimary }}        
        clearIcon={{ name: "close-circle", size: 19 }}
        platform={'ios'}
      />
        </ScrollView>
    <ScrollView style={{height:"5%"}}>
    <View  style={{ flex: 1,paddingTop:'2%',width:"97%",alignSelf:'center'}}>
    <Grid style={{backgroundColor:colorprimary,padding:5,borderRadius:4}}>
             <Row>
             <Col style={{alignItems:'flex-start',width:'30%'}}>
             <Text style={styles.textContent}>Payment ID</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'30%'}}>
             <Text style={styles.textContent}>Date</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'40%'}}>
             <Text style={styles.textContent}>Amount</Text>
             </Col> 
             </Row>
             </Grid>
    </View>
    </ScrollView>
    <ScrollView style={{height:"85%"}}>
              <SectionList
                  sections={this.state.data}
                  extraData={this.state.data}
                  style={{paddingTop:2}}
                  initialNumToRender={this.state.data.length}
                  renderItem={this.renderItem.bind(this)}
                  renderSectionHeader={({ section }) => 
                  
                   <View  style={{ flex: 1,paddingTop:4}}>
                   <Grid style={{backgroundColor:'#3498db',padding:4,width:"97%",alignSelf:'center',borderRadius:3}}>
                   <Row>
                   <Col style={{alignItems:'flex-start',width:'40%'}}>
                   <Text style={styles.sectionHeader}>{section.Title}</Text>
                   </Col> 
                   <Col style={{alignItems:'flex-end',width:'60%'}}>
                   <Text style={{  alignSelf:'flex-end',fontSize: 13,fontFamily:'Bold',color:'#fff',}}>
                     {this.getSubTotal(section.Title)}
                     </Text>
                   </Col> 
                   </Row>
                   </Grid>
                   </View>
                  
               }
                  keyExtractor={(item, index) => index}
              />
                <Toast ref="toast"/>
    </ScrollView>

    <ScrollView style={{height:'8%'}}>
   <Card style={{alignSelf:'center',width:'97%',height:40}}>
   <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
        paddingLeft:5,paddingRight:5,paddingTop:10,paddingBottom:10}}>
  <Row>
  <Col style={{alignItems:'flex-start',width:'40%'}}>
  <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Grand Total :</Text>
  </Col>
  <Col style={{alignItems:'flex-end',width:'60%'}}>
  <Text style={{fontSize:13,fontFamily:'Bold'}}>{this.getGrandTotal()}</Text>
  </Col>
  </Row>
  </CardItem>
</Card>
      </ScrollView>
          </View>
      );
  }
}

const styles = StyleSheet.create({
  container: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: '#F5FCFF',
  },
  sectionHeader: {
      alignSelf:'flex-start',
      fontSize: 13,
     fontFamily:'Bold',
      color:'#fff',
  },
  itemView: {
    flex: 1,
    width,
    borderBottomWidth: 0.5,
    borderColor: '#cdcdcd',
    borderStyle: 'solid',
    paddingHorizontal: 12,
    flexDirection: 'row',
    paddingTop:2
},
textContent:{
  color:white,
  fontSize:12,
  fontFamily:'Bold'
}

});


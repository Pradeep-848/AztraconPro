import React,{ Component }  from 'react';
import {ScrollView,StyleSheet,Text,View,Image,FlatList,Modal,TouchableOpacity,Alert} from 'react-native';
import { Col,Grid,Row } from 'react-native-easy-grid';
import { NavigationActions, StackActions } from 'react-navigation';
import { SearchBar } from 'react-native-elements';
import axios from 'axios';
import {Card,CardItem} from 'native-base';
import strings from './res/strings'
import color from './res/colors';
import {logouttask} from './class/logout';
import Toast from 'react-native-whc-toast'

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const blue=color.values.Colors.blue;
const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const lightblue=color.values.Colors.lightblue;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class CustomerProjectMaster extends React.Component {

  static navigationOptions = ({ navigation }) => ({ 
    title: "Projects",
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor:white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
      UserID:'',
      handlelogin:'',
      CusID:'',
      cname:'',
      isLoading: false, 
      dataSource:[],
      value:'',
      filter:''
    };
    this.arrayholder = [];
}

login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
        this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}

goprojectmasterdetail(index){
let id=index

const{PID,PDesc,CusID,CusName}=this.state.dataSource[id];

this.props.navigation.navigate('ProjectMasterDetailsActivity',{
    PID:PID,
    UserID:this.state.UserID,
    PDesc:PDesc,
    CusID:CusID,
    CusName:CusName});
}

getcustomerproject(){
  console.log(this.state.CusID)
    const config = {
        headers: {   
        'currentToken':tokken,
      }, 
      params: {
        Cuscode:this.state.CusID,
    }   
     
      };   
      this.setState({isLoading:true})

      axios.get(ip+'/getCustomerProjectMaster', config)
      .then(response => this.setState({dataSource:response.data},() => {
       if(response.status==200){
          this.arrayholder = this.state.dataSource;
          this.setState({isLoading:false});
    }

  }))
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );  
}

filtersearch(text){
    const newData = this.arrayholder.filter(function(item){
    const itemData =item.PID.toString()+item.CusID.toString().toUpperCase()
    const textData = text.toUpperCase()
    return itemData.indexOf(textData) > -1
}
)
this.setState({
    dataSource: newData.sort(),
    text: text
})
}

componentDidMount(){
  console.disableYellowBox = true;

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
  
   this.setState({
       UserID:this.props.navigation.getParam('UserID', ''),
       CusID:this.props.navigation.getParam('CusID', ''),
       cname:this.props.navigation.getParam('CusName', '')
    },()=>{
   this.getcustomerproject();
})


}
render() {
    if (this.state.isLoading) {
      return (
        <Modal
        transparent={false}
        supportedOrientations={['portrait', 'landscape']}
        visible={this.state.isLoading}
        >
         <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
            useNativeDriver={true}
          style={{width: 300, height: 200}}
          source={require('./src/gears.gif')}  />
          </View>     
        </Modal>
           )
  }
    return (
      <ScrollView style={{backgroundColor:lightblue}}>
      <View>
      <Grid style={{paddingTop:'2%',width:'97%',alignSelf:'center'}}>
      <Row style={{backgroundColor:colorprimary,alignSelf:'center', borderRadius:4}}>
      <Text numberOfLines={1} style={styles.titleText}>
          {this.state.CusID.toString().trim()+" - "+this.state.cname}
      </Text>
      </Row>
      </Grid>
      <SearchBar
        style={{width:'97%',alignSelf:"center"}}
        placeholder="Search ProjectMaster"
        onChangeText={(text) => this.filtersearch(text)}
        value={this.state.text}
        searchIcon={{ name: "search", size: 19, color: colorprimary }}
        clearIcon={{ name: "close-circle", size: 19 }}
        loadingProps={{ size: "small" }}
        platform={'ios'}
      />
      </View>
      <ScrollView>
        <FlatList
        data={this.state.dataSource}
        initialNumToRender={this.state.dataSource.length}
        renderItem={({item,index}) =>  
        <Card style={{alignSelf:'center',width:'97%'}}>
        <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
        <Grid  onPress={() => this.goprojectmasterdetail(index)}>
        <Row> 
        <Col style={{alignItems:"flex-start",width:'20%'}}>
        <Text style={{fontSize:13,fontFamily:'Normal'}}>{item.PID}</Text>
        </Col>
        <Col style={{alignItems:"flex-start",width:'80%'}}>
        <Text style={{fontSize:13,alignSelf:'flex-end',fontFamily:'Normal'}}>{item.SDesc}</Text> 
        </Col>
        </Row>
        <View style={{borderBottomColor:'#A9A9A9',borderBottomWidth: 1,height:5,
        width:'100%',alignSelf:'center'}}/>
        <Row>
        <Col style={{width:'100%',alignItems:'flex-start'}}>
        <Text style={{fontSize:13,fontFamily:'Normal'}}>{item.PDesc}</Text>
        </Col>
        </Row>
        </Grid>  
        </CardItem>
        </Card>
        }
        keyExtractor={(item, index) => index.toString()}
      />
        </ScrollView> 
        <Toast ref="toast"
        />
  </ScrollView> 
        )
        
      }
 
 };
 const styles = StyleSheet.create({
    tittle:{
        color:'#36428a',
        fontSize:13
       },
       values:{
        color:'#708090',
        fontSize:12
       },
      imagebutton: {
        width:30,
        height: 30,        
      },
      input: {
        maxHeight: 100,
        borderColor: "#1ca0ff", 
        borderWidth: 1, 
        padding: 10, 
        width:320,
        marginBottom: 10,
      },
      titleText: {
      width:'96%',
      flex:1,
      flexWrap:'wrap',
      color:white,
      fontSize:12,
      padding:5,
      fontFamily:'Bold'
  },
  });
  

  


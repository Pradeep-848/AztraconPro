import React,{ Component }  from 'react';
import {ScrollView,StyleSheet,Text,View,Dimensions,Modal,FlatList,TouchableOpacity,Image,Alert,ActivityIndicator} from 'react-native';
import { Col,Grid,Row } from 'react-native-easy-grid';
import { Overlay,Button,SearchBar } from 'react-native-elements';
import axios from 'axios';
import { NavigationActions, StackActions } from 'react-navigation';
import Toast from 'react-native-whc-toast'
import {Card,CardItem} from 'native-base';
import Spinner from 'react-native-loading-spinner-overlay';
import strings from './res/strings'
import color from './res/colors'
import {logouttask} from './class/logout';
import BigList from "react-native-big-list";
import { List, Subheading } from "react-native-paper";

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const lightblue=color.values.Colors.lightblue;
const colorprimary=color.values.Colors.colorPrimary;
const primarylite=color.values.Colors.primarylite
const white=color.values.Colors.white;


const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});


export default class SupplierMaster extends React.Component {

  static navigationOptions = ({ navigation }) => ({ 
    title: "Supplier Master",
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor:white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
        UserID:'',
        isLoading: false, 
        dataSource:[],
        agecode:'',
        value:'',
        filter:'',
        ClickedSupID:'',
        ClickedSupName:'',
        handlelogin:'',
        isVisible:false,
        alphadata:[{"key": "A"},{"key": "B"},{"key": "C"},{"key": "D"},{"key": "E"},{"key": "F"},{"key": "G"},{"key": "H"},{"key": "I"},{"key": "J"},{"key": "K"},{"key": "L"},{"key": "M"}
        ,{"key": "N"},{"key": "O"},{"key": "P"},{"key": "Q"},{"key": "R"},{"key": "S"},{"key": "T"},{"key": "U"},{"key": "V"},{"key": "W"}
        ,{"key": "X"},{"key": "Y"},{"key": "Z"}],
        loading:false,
        tag:"all"
    };
    this.arrayholder = [];
    this.alphaholder=[];
}
Profile = ()=>{

    this.setState({isVisible:false},()=>{
      this.props.navigation.navigate('SupplierProfileActivity',{SupID:this.state.SupID,UserID:this.state.UserID,SupName:this.state.SupName});
    })
 
}


login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
        this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}



PurchaseOrder = ()=>{
     this.setState({isVisible:false},()=>{
      this.props.navigation.navigate('SupplierPOActivity',{SupID:this.state.SupID,UserID:this.state.UserID,SupName:this.state.SupName});
    })
}
Contact =()=>{
      this.setState({isVisible:false},()=>{
      this.props.navigation.navigate('SupplierContactMasterActivity',{SupID:this.state.SupID,UserID:this.state.UserID,SupName:this.state.SupName});
    })
}
Ledger =()=>{
        this.setState({isVisible:false},()=>{
      this.props.navigation.navigate('SupplierLedgerActivity',{SupID:this.state.SupID,UserID:this.state.UserID,SupName:this.state.SupName});
    })
}
PayableAgeing =()=>{
  this.getagecode();    

}





getagecode(){
  
  console.log("clicked"+this.state.CusID)

  const config = {
    headers: {   
     'currentToken':tokken,
  },   
    params:{
      sqlQuery:"SELECT ISNULL(Age,0) FROM Invoice_Ageing WHERE InvType = 'V' and Party ='"+this.state.SupID.toString()+"'"
    }   
  };   
  this.setState({isLoading:true})

  axios.get(ip+'/getQuery', config)
  .then(response => this.setState({agecode:response.data},() => {
    console.log(response.data)
   if(response.status==200){
      this.setState({isLoading:false,isVisible:false},()=>{
        console.log("agecode"+this.state.agecode)
        this.props.navigation.navigate('SupplierFinanceDetailActivity',
        {
          SupID:this.state.SupID,
          UserID:this.state.UserID,
          SupName:this.state.SupName,
          AgeCode:this.state.agecode
        });
      });
}

}))
.catch(err => 
{
  this.setState({
    isLoading:false
  },()=>{
   let error=err
   
   this.refs.toast.showBottom(error.toString())

   setTimeout(
    () => { 
      this.props.navigation.goBack();
     },
    2000
  )

  })
}
);
}

opendialog(index){
 let id=index
     
const{sID,sName}=this.state.dataSource[id];

this.setState({
    UserID:this.state.UserID,
    SupID:sID,
    SupName:sName,
    isVisible:true
})
}

getsupplier(){
    const config = {
        headers: {   
        'currentToken':tokken,
      },      
      };   
      this.setState({isLoading:true,dataSource:''})

      axios.get(ip+'/getSupplierlist', config)
      .then(response => this.setState({dataSource:response.data},() => {
       if(response.status==200){
          this.arrayholder = this.state.dataSource;
          this.setState({isLoading:false});
    }

  }))
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
    
}
hidemodel(){
  this.setState({isVisible:false})
}

filtersearch(text){
      const newData = this.arrayholder.filter(function(item){
      const itemData =item.sID.toString().toUpperCase()+item.sName.toString().trim().toUpperCase()
      const textData =text.toUpperCase()
      return itemData.indexOf(textData) > -1
  }
  )
  this.setState({
    dataSource: newData.sort(),
    text: text,
    loading:false
})

}
filterclick= (value) => {  
  this.getfiltervalue(value)
}

getfiltervalue = (value) => {  
  
  const config = {
    headers: {   
    'currentToken':tokken,
  },      
  params: {
    Filter:value.toString(),
    }
  };   
  this.setState({isLoading:true,dataSource:''})

  axios.get(ip+'/getSupplierlistfilterios', config)
  .then(response => this.setState({dataSource:response.data},() => {
   if(response.status==200){
      this.arrayholder = this.state.dataSource;
      if(this.state.dataSource.length===0 || this.state.dataSource===undefined){
         // alert("No Record Found")
      }
      this.setState({isLoading:false});
}

}))
.catch(err => 
{
  this.setState({
    isLoading:false
  },()=>{
   let error=err
   
   this.refs.toast.showBottom(error.toString())

   setTimeout(
    () => { 
      this.props.navigation.goBack();
     },
    2000
  )

  })
}
);

}

getListViewItem = (value) => {  
    this.alphaholder=this.arrayholder
    const newData = this.alphaholder.filter(function(item){
    const itemData = item.sName.toString().trim().toUpperCase()
    const textData = value.toUpperCase()
    if(textData.toString()===itemData.toString().trim().charAt(0))
    {
      return itemData.indexOf(textData) > -1
    }
})

this.alphaholder = newData;

this.setState({
  dataSource: newData.sort(),
},()=>{
  this.loadersetter()
})

} 

loadersetter(){

  setTimeout(
    () => { 
      this.setState({
        loading: !this.state.loading,
      })
     },
    2000
  )

}

refershclick=()=>{
  this.setState({
    text:'',
    loading: !this.state.loading,
    tag:"all"
  },()=>{
    setTimeout(
      () => { 
        this.filtersearch("")
       },
      2000
    )
  });
}


componentDidMount(){
  
console.disableYellowBox = true;

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
  
   this.setState({UserID:this.props.navigation.getParam('UserID', '')},()=>{
   this.getsupplier();
  // this.getfiltervalue("A");
})

}


render() {


 
  const renderItem = ({ item,index }) => {
    return (
      <Card style={{width:'97%',alignSelf:'center',}} >
        <CardItem  style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
        paddingLeft:5,paddingRight:5,paddingTop:10,paddingBottom:10}}>

        <Grid style={{height:screenHeight*5/100}}>

        <Grid onPress={() => this.opendialog(index)}>

        <Col style={{alignItems:"flex-start",width:'20%'}}>
        <Text style={{fontSize:13,fontFamily:'Bold'}}>{item.sID}</Text>
        </Col>

        <Col style={{alignItems:"flex-start",width:'80%'}}>
          <Grid>

            <Col style={{alignItems:"flex-start",width:'100%'}}>
            <Text numberOfLines={1} style={{fontSize:13,fontFamily:'Bold'}}>{item.sName}</Text>
            </Col>

          </Grid>
          <Grid>
            <Col style={{alignItems:"flex-start",width:'70%'}}>
            <Text style={{fontSize:13,fontFamily:'Italic'}}>{item.sCountry}</Text>
            </Col>
            <Col style={{alignItems:"flex-end",width:'30%'}}>
            <Text style={{fontSize:13,fontFamily:'Italic'}}>{item.sBalance=='0'?'':item.sBalance}</Text>
            </Col>
          </Grid>
        </Col>
       
        </Grid>

        </Grid>


        </CardItem>
      </Card>
     
    
    );
  };
 
 if (this.state.isLoading) {
      return (
         <Modal
         transparent={false}
        >
         <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
          style={{width: 300, height: 200}}
          source={require('./src/gears.gif')}  />
          </View>     
        </Modal>
           )
  }
    return (
      <View style={{flex:1,backgroundColor:lightblue}}>
      <ScrollView style={{height:'10%'}}>      
      <Grid>
      <Row>
        <Col style={{width:'100%',alignSelf:'center'}}>
        <SearchBar
        style={{width:'100%',alignSelf:'center'}}
        placeholder="Search Supplier"
        onChangeText={(text) => this.filtersearch(text)}
        value={this.state.text}
        searchIcon={{ name: "search", size: 19, color: colorprimary }}
        clearIcon={{ name: "close-circle", size: 19 }}
        loadingProps={{ size: "small" }}
        lightTheme 
        round
      />
        </Col>
        {/* <Col style={{width:'10%',alignSelf:'center'}}>
        <TouchableOpacity activeOpacity = { .5 } onPress={ this.refershclick }>
        <Image
          style={{width:30,height:30}}
          source={require('./src/reloads.png')}/>
        </TouchableOpacity>
        </Col> */}
      </Row>
      </Grid>  

      </ScrollView>
      <View style={{height:'90%'}}>

      <Spinner
          color={colorprimary}
          visible={this.state.loading}
          textContent={'Loading...'}
          textStyle={styles.spinnerTextStyle}
        />

      <Overlay
       overlayStyle={{height:'40%',width:'88%',backgroundColor:primarylite,borderRadius:15}}
       animationType='slide'
       isVisible={this.state.isVisible}
       onBackdropPress={() => this.setState({ isVisible: false })}>
       <ScrollView>

       <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress = {() =>
           {  
            this.setState({ isVisible:!this.state.isVisible})
           }}>
        
        <Grid>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontFamily:'Bold',alignSelf:'flex-start'}}>
              Supplier
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('./src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
       </Grid>
        

       </TouchableOpacity>

        <Grid>
        <Row style={styles.i}>
        <Col style={{alignItems:'center'}}>
          <TouchableOpacity activeOpacity = { .5 } onPress={ this.Profile }>
          <Image style={styles.imagebutton}
          source={require('./src/ic_customer.png')} />
          </TouchableOpacity>
          <Text style={{color:white,fontFamily:'Bold'}}>Profile</Text>
          </Col> 
          <Col style={{alignItems:'center'}}>
          <TouchableOpacity activeOpacity = { .5 } onPress={ this.PurchaseOrder }>
          <Image  style={styles.imagebutton}
          source={require('./src/ic_po.png')} />
          <Text style={{color:white,fontFamily:'Bold'}}>Purchase Order</Text>
          </TouchableOpacity>
          </Col> 
          <Col style={{alignItems:'center'}}>
          <TouchableOpacity activeOpacity = { .5 } onPress={ this.Contact }>
          <Image  style={styles.imagebutton}
          source={require('./src/ic_contact.png')} />
          <Text style={{color:white,fontFamily:'Bold'}}>Contact List</Text>
          </TouchableOpacity>
          </Col> 
        </Row> 
          <Row style={styles.i}>
          <Col style={{alignItems:'center'}}>
          <TouchableOpacity activeOpacity = { .5 } onPress={ this.Ledger }>
          <Image style={styles.imagebutton}
          source={require('./src/ic_ledger.png')} />
          </TouchableOpacity>
          <Text style={{color:white,fontFamily:'Bold'}}>Ledger</Text>
          </Col> 
          <Col style={{alignItems:'center'}}>
          <TouchableOpacity activeOpacity = { .5 } onPress={ this.PayableAgeing }>
          <Image  style={styles.imagebutton}
          source={require('./src/ic_pay_age.png')} />
          <Text style={{color:white,fontFamily:'Bold'}}>Payable Ageing</Text>
          </TouchableOpacity>
          </Col> 
          </Row> 
        </Grid>
       </ScrollView>

      </Overlay>

      <BigList
          placeholder={true}
          removeClippedSubviews={true}
          data={this.state.dataSource}
          itemHeight={screenHeight*9/100}
          renderItem={renderItem}
        />

    
        {/* <FlatList
        data={this.state.dataSource}
        initialNumToRender={this.state.dataSource.length}
        removeClippedSubviews={false}
        renderItem={({item,index}) =>  
        <Card style={{width:'97%',alignSelf:'center'}}>
        <CardItem  style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
        paddingLeft:5,paddingRight:5,paddingTop:10,paddingBottom:10}}>
        <Grid  onPress={() => this.opendialog(index)}>
        <Row> 
        <Col style={{alignItems:"flex-start",width:'20%'}}>
        <Text style={{fontSize:13,fontFamily:'Bold'}}>{item.sID}</Text>
        </Col>
        <Col style={{alignItems:"flex-start",width:'80%'}}>
            <Grid>
            <Row>
            <Col style={{alignItems:"flex-start",width:'100%'}}>
            <Text style={{fontSize:13,fontFamily:'Bold'}}>{item.sName}</Text>
            </Col>
            </Row>
            <Row>
            <Col style={{alignItems:"flex-start",width:'70%'}}>
            <Text style={{fontSize:13,fontFamily:'Italic'}}>{item.sCountry}</Text>
            </Col>
            <Col style={{alignItems:"flex-end",width:'30%'}}>
            <Text style={{fontSize:13,fontFamily:'Italic'}}>{item.sBalance=='0'?'':item.sBalance}</Text>
            </Col>
            </Row>
            </Grid>
        </Col>
        </Row>
        </Grid>  
        </CardItem>
        </Card>
        }
        keyExtractor={(item, index) => index.toString()}
      />   */}
      </View>


      <Toast ref="toast"/>
    

       {/*  <FlatList
        horizontal
        style={{height:'10%',alignSelf:'center'}}
        data={this.state.alphadata}
        renderItem={({ item: rowData }) => {
          return (

            <Text style={{fontSize:20,paddingLeft:12,alignSelf:'center',color:colorprimary,fontFamily: "Bold"}}
            onPress={this.filterclick.bind(this, rowData.key)}
            >
                {rowData.key}
            </Text>
  
          );
        }}
        keyExtractor={(item, index) => index}
      /> */}

      </View>
        )
        
      }
 
 };
 const styles = StyleSheet.create({
    tittle:{
        color:'#36428a',
        fontSize:13
       },
       values:{
        color:'#708090',
        fontSize:12
       },
    imagebutton: {
    width:80,
    height: 80,
    marginTop:3,
   justifyContent:"center",
   alignItems:"center" 
      },
      input: {
        maxHeight: 100,
        borderColor: "#1ca0ff", 
        borderWidth: 1, 
        padding: 10, 
        width:320,
        marginBottom: 10,
      },
       i: {
    paddingTop:10,
  },
  spinnerTextStyle: {
    color:colorprimary,
  },
  headerback: {
    flexDirection: 'row',
    alignItems:'center',
    backgroundColor: colorprimary,
    borderWidth: 0.5,
    borderColor:white,
    height: 35,
    width:'100%',
    borderRadius: 5,
  },
  });
  

  


import React,{ Component }  from 'react';
import {StyleSheet,Image,Dimensions,View,TouchableOpacity,Alert} from 'react-native';
import { NavigationActions, StackActions } from 'react-navigation';
import {logouttask} from './class/logout';
import color from './res/colors'
const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

 export default class AboutUs extends React.Component {
  static navigationOptions  = ({ navigation }) => ({ 
    title: "About Us",
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  
  constructor(props) {
    super(props);
     this.state = {
         UserID:'',
         handlelogin:'',
    };
}
login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
        this.props.navigation.dispatch(resetAction);
      } },
    ],
    {cancelable: false},
  );

 }
componentDidMount(){
    this.setState({
        UserID:this.props.navigation.getParam('UserID', '')
    })

  console.disableYellowBox = true;
  this.props.navigation.setParams({
           handlelogin: this.login.bind(this)
  });
  
}

render() {
  const {width, height} = Dimensions.get("window")
return (
  <View>
  <Image source={require('./src/aboutus.png')}
    resizeMode='contain'
    style={{
      maxHeight: height,
      maxWidth: width
      }} />
</View>
       )
      }
 };
 const styles = StyleSheet.create({
 
});

  
  
  
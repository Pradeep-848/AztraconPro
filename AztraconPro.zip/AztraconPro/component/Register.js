import React,{ Component }  from 'react';
import {Dimensions,View,ImageBackground,StyleSheet,Image,Text,Modal,TextInput,TouchableOpacity} from 'react-native';
import { CustomButton } from './custom-button.js';
import Toast from 'react-native-whc-toast'
import axios from 'axios';
import color from './res/colors'
import strings from './res/strings'


const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const colorprimarydark=color.values.Colors.colorPrimaryDark;

const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);
const moverheight=screenHeight/8

 export default class Register extends React.Component {
   static navigationOptions = ({ navigation }) => ({ 
    title: "Register",
    headerStyle: {
      backgroundColor: colorprimary
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
    }
  });
  
  constructor(props) {
    super(props);
    this.state = {
        hidePassword: true,
        hidePassword_Confirm: true,
        email:"",
        name:"",
        password:"",
        passwordc:""
    };
}

managePasswordVisibility = () =>
{
  this.setState({ hidePassword: !this.state.hidePassword });
}

managePasswordVisibility_Confirm = () =>
{
  this.setState({ hidePassword_Confirm: !this.state.hidePassword_Confirm });
}

goback(){
    this.props.navigation.goBack();
}

onsave(){
 
  const { email,name,password,passwordc } = this.state;

   if(email==null || email==''){
      this.refs.toast.showCenter('Please enter Email',500);
    }else if(name==null || name==''){
     this.refs.toast.showCenter('Please enter Name',500);
    }else if(password==null || password==''){
      this.refs.toast.showCenter('Please enter Password',500);
    }else if(passwordc==null || passwordc==''){
      this.refs.toast.showCenter('Please enter Confirm Password',500);
    }else if(password!=passwordc){
      this.refs.toast.showCenter('Password Not Match',500);
    }else{
      this.setState({isLoading:true})

      let u="/addCustomerRegister"
    
      axios({
        method: 'post',
        url:ip+u,
        headers: {'currentToken':tokken}, 
    
        data:{
          Email:this.state.email,
          Name:this.state.name,    
          Pwd:this.state.password,
        },
    
    
      }).then(response=>{ this.setState({
        res:response.data
      },()=>{

        if(response.status===200){
          this.setState({isLoading:false,},()=>{ 
            console.log(this.state.res)
            if(this.state.res=='s'){
              this.refs.toast.showBottom('Save Successful');
              setTimeout(
                  () => { 
                    this.goback()
                   },
                  500
                )
            }else if(this.state.res=='a'){
              this.refs.toast.showBottom('Email Already Exist');
            }else{
              this.refs.toast.showBottom('Register Failed');
            }
        
          })
    }else{
      this.refs.toast.showBottom('Save Failed');
    }
    
      })})
      .catch(err => 
        {
          this.setState({
            isLoading:false
          },()=>{
           let error=err
           
           this.refs.toast.showBottom(error.toString())
      
           setTimeout(
            () => { 
              this.props.navigation.goBack();
             },
            2000
          )
      
          })
        }
        );
    }

      

}

componentDidMount(){

  console.disableYellowBox = true;

}


render() {
    if (this.state.isLoading) {
        return (
          <Modal
          transparent={false}
          visible={this.state.isLoading}
          >
           <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
            <Image
            useNativeDriver={true}
            style={{width: 300, height: 200}}
            source={require('./src/gears.gif')}  />
            </View>     
          </Modal>
        )
    }
  
  return (
   
    <View style={styles.container}>
  
      <ImageBackground 
        source={require('./src/aztracon_bg.jpg')}
        style = {styles.imageStyle} >

       <Image
          style={styles.image}
          source={require('./src/ic_aztracon.png')} />

     <View style={styles.tcenter}>
    
      <Text style={{fontSize:16,fontFamily:'Bold',color:colorprimarydark,
                    paddingTop:"2%",paddingBottom:"2%"}}>Email</Text>

      <TextInput
        value={this.state.email}
        onChangeText={(email) => this.setState({ email })}
        placeholder={'Email'}
        length={50}
        style={styles.input}
        keyboardType={"email-address"}
        returnKeyType = {"next"}
        ref='email'
        autoCapitalize={"none"}
        onSubmitEditing={(event) => { 
              this.refs.name.focus(); 
            }}
      />

   <Text style={{fontSize:16,fontFamily:'Bold',color:colorprimarydark,
                    paddingTop:"2%",paddingBottom:"2%"}}>Customer Name</Text>

      <TextInput
        value={this.state.name}
        onChangeText={(name) => this.setState({ name })}
        placeholder={'Customer Name'}
        length={50}
        keyboardType={"default"}
        style={styles.input}
        returnKeyType = {"next"}
        ref='name'
        onSubmitEditing={(event) => { 
              this.refs.pass.focus(); 
            }}
      />


      <Text style={{fontSize:16,fontFamily:'Bold',color:colorprimarydark,
                    paddingTop:"2%",paddingBottom:"2%"}}>Password</Text>

     <View style = { styles.textBoxBtnHolder }>

          <TextInput 
          underlineColorAndroid = "transparent" 
          value={this.state.password}
          onChangeText={(password) => this.setState({ password })}
          placeholder={'Password'}
          length={10}
          keyboardType={"default"}
          returnKeyType = {"next"}
          secureTextEntry = { this.state.hidePassword } 
          style = { styles.input }
          ref='pass'
           onSubmitEditing={(event) => { 
              this.refs.cpass.focus(); 
            }}
          />

          <TouchableOpacity activeOpacity = { 0.8 } style = { styles.visibilityBtn } onPress = { this.managePasswordVisibility }>
            <Image source = { ( this.state.hidePassword ) ? require('./src/hide.png') : require('./src/view.png') } style = { styles.btnImage } />
          </TouchableOpacity>

      </View>
     
     
     <Text style={{fontSize:16,fontFamily:'Bold',color:colorprimarydark,
                    paddingTop:"2%",paddingBottom:"2%"}}>Confirm Password</Text>
                    
                    
     <View style = { styles.textBoxBtnHolder }>
     
     <TextInput 
     underlineColorAndroid = "transparent" 
     value={this.state.passwordc}
     onChangeText={(passwordc) => this.setState({ passwordc })}
     placeholder={'Confirm Password'}
     length={10}
     keyboardType={"default"}
     returnKeyType = {"next"}
     secureTextEntry = { this.state.hidePassword_Confirm } 
     style = { styles.input }
     ref='cpass'
     onSubmitEditing={(event) => { 
     this.refs.cpass.focus(); 
     }}
     />
     <TouchableOpacity activeOpacity = { 0.8 } style = { styles.visibilityBtn } onPress = { this.managePasswordVisibility_Confirm }>
     <Image source = { ( this.state.hidePassword_Confirm ) ? require('./src/hide.png') : require('./src/view.png') } style = { styles.btnImage } />
     </TouchableOpacity>
     </View>
   

           <CustomButton
           title="Register"
           onPress={() => this.onsave()}
           style={{ backgroundColor:colorprimarydark}}
           textStyle={{ fontSize:13,fontFamily:'Bold' }}/>


    </View>
  
      </ImageBackground>
      <Toast ref="toast"/>
     

    </View>
   
  )
}
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center'
      },
      image: {
        marginTop: 5,
        width: 100,
        height: 100,
        resizeMode: 'stretch',
        justifyContent: 'center'
      },
     
      tcenter: {
        flex: 1,
        //justifyContent: 'center',
        marginTop: 50,
        //alignItems: 'center'
      },
      tbutton: {
        height:50
      },
    
      input: {
        maxHeight: 100,
        borderColor: colorprimarydark, 
        borderWidth: 1, 
        padding: 10, 
        width:320,
        marginBottom: 10,
        alignSelf: 'stretch',
        borderRadius: 5,
        fontFamily:'Regular'
      },
      imageStyle:{
        width: screenWidth, 
        height: screenHeight, 
        justifyContent: 'center',
        alignItems: 'center'
       },

       textBoxBtnHolder:
       {
         position: 'relative',
         alignSelf: 'stretch',
         justifyContent: 'center'
       },
     
       textBox:
       {
         fontSize: 18,
         alignSelf: 'stretch',
         height: 50,
         paddingRight: 45,
         paddingLeft: 8,
         borderWidth: 1,
         paddingVertical: 0,
         borderColor: colorprimarydark,
         borderRadius: 5
       },
     
       visibilityBtn:
       {
         position: 'absolute',
         right: 3,
         height: 40,
         width: 35,
         padding: 5
       },
     
       btnImage:
       {
         resizeMode: 'contain',
         height: '100%',
         width: '100%'
       }
});

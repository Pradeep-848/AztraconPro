import React,{ Component }  from 'react';
import {TouchableHighlight,TouchableOpacity,StyleSheet, Text,View,TextInput,Button,Image,ImageBackground,Dimensions,AsyncStorage,NetInfo,StatusBar,ActivityIndicator,Alert,Modal,FlatList} from 'react-native';
import {createStackNavigator, createAppContainer,StackNavigator} from 'react-navigation';
import {Spinner,Item,Label,Input} from 'native-base'
import Toast from 'react-native-whc-toast'
import { Col, Grid, Row } from 'react-native-easy-grid';
import { ScrollView } from 'react-native-gesture-handler';
import axios from 'axios';
import DateTimePicker from "react-native-modal-datetime-picker";
import moment from 'moment';

const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);

const screen = Math.round(Dimensions.get('window').width)/3;
const mheight=Math.round(Dimensions.get('window').height)/2;

const sheight=(mheight/2)+mheight;


import strings from './res/strings'

const ip=strings.values.commonvalues.ip;

const tokken=strings.values.commonvalues.tokken;

 export default class ConstructionTimeSheetAdd extends React.Component {
   static navigationOptions = {
    title: "Construction TimeSheet",
    headerStyle: {
      backgroundColor: "#2452b2"
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontFamily:'Bold',
    },
  }; 
  
  constructor(props) {
    super(props);
    this.state = {
      USER:'',
      isDateTimePickerVisible:false,
      TaskDate:'Task Date',
      teammember:'Team Member',
      TagDetail:'Tag Details',
      TaskDetail:'Task Details',
      TimeSchedule:'TimeSchedule',
      dataTeamMember:'',
      isVisible:false,
      isVisibleTag:false,
      isLoading:false,
      isSpinner:false,
      projectDetail:'Project Detail',
      EmpID:'',
      EmpName:'',
      EmpDetail:'',
      tageddetail:'',
      TagDataSource:'',
      ProjectID:'',
      TagID:'',
      TagCode:'',
      RSCName:'',
      isVisibleTask:false,
      isVisibleTimeSchedule:false,
      TaskDataSource:'',
      TimeSheduleDataSource:'',
      TaskID:'',
      TaskDesc:'',
      TaskDescription:'',
      SICODE:'',
      Complete:'',
      Regular:'',
      Over:'',
      pdate:''
    };
}
onSave(){
if(this.state.EmpID===''){
  alert('Please Select Employee')
}else if(this.state.TaskDescription===''){
  alert('Please Enter Description')
}else{
  this.onInsert()
}
}
onInsert(){
  this.setState({isLoading:true})

  console.log('PID'+this.state.ProjectID)
  console.log('TagID'+this.state.TagID)
  console.log('RSCName'+this.state.RSCName)
  console.log('TaskID'+this.state.TaskID)
  console.log('TaskDescription'+this.state.TaskDescription)
  console.log('Regtime'+this.state.Regular)
  console.log('Over'+this.state.Over)
  console.log('Percent'+this.state.Complete)
  console.log('TS'+this.state.SICODE)
  console.log('ActivityDate'+this.state.pdate)

  axios({
    method: 'post',
    url:ip+'/addSupervisorTSAdd',
    headers: {'currentToken':tokken}, 
    data:{
      EmpID:this.state.EmpID,
      PID:this.state.ProjectID,
      TagID:this.state.TagID, 
      ResCen:this.state.RSCName,
      TaskID:this.state.TaskID,
      TaskDesc:this.state.TaskDescription,
      AppBy:this.state.USER, 
      RegTime:this.state.Regular,
      OverTime:this.state.Over,
      Percent:this.state.Percent,
      Weld:' ',
      TS:this.state.SICODE,
      MacID:' ',
      ActivityDate:this.state.pdate
    }
  }).then(response=>{if(response.status===200){
    this.setState({isLoading:false},()=>{alert('Success')})
  }else{
      alert('Failed')
  }});
}
showDateTimePicker = () => {
    this.setState({ isDateTimePickerVisible: true });
}

hideDateTimePicker = () => {
    this.setState({ isDateTimePickerVisible: false });
}
  handleDatePicked = date => {

    this.setState({pdate:date})
    const NewDate =moment(date).format('DD-MM-YYYY')
    this.setState({TaskDate:NewDate})

    this.hideDateTimePicker();
  };
  getTeamMemberItem (empid,empname) {
   console.log(empid,empname)
   this.setState({ isVisible:!this.state.isVisible,EmpID:empid,EmpName:empname})
    this.setState({teammember:empid+'  '+empname})
  }
  getTagItems (tagid,tagcode) {
    console.log(tagid,tagcode)
    this.setState({ isVisibleTag:!this.state.isVisibleTag,TagID:tagid,TagCode:tagcode})
     this.setState({TagDetail:tagid+'  '+tagcode})
   }
   getTaskitems (taskid,taskcode) {
     console.log(taskid,taskcode)
     this.setState({isVisibleTask:!this.state.isVisibleTask,TaskID:taskid,TaskCode:taskcode})
     this.setState({TaskDetail:taskid+'  '+taskcode})
   }
   gettimesheduleitem(sIcode,sDesc) {
    console.log(sIcode+'  '+sDesc) 
    this.setState({isVisibleTimeSchedule:!this.state.isVisibleTimeSchedule,SICODE:sIcode})
    this.setState({TimeSchedule:sIcode+'  '+sDesc})
   }
gettimeshedule(){
  const config = {
      headers: {
      'currentToken':tokken,
    },
      params: {
        pid:this.state.ProjectID
      }
    };
    this.setState({isVisibleTimeSchedule:true,isLoading:true})
    axios.get(ip+'/getSpnTS', config)
    .then(response => this.setState({TimeSheduleDataSource:response.data},() => {if(response.status==200){this.setState({isLoading:false})}}))
    .catch(err => console.log(err));  
}
componentDidMount() {
this.setState({USER:this.props.navigation.getParam('USER', '')})
}
getteammember(){
    const config = {
        headers: {   
        'currentToken':tokken,
      },
        params: {
            sqlQuery:'SELECT EmpID,EmpName FROM EmployeeMaster_Hire WHERE LocCode IN (SELECT LocCode FROM CompanyWarehouse WHERE Supervisor='+'2927'+')' //this.state.USER
        }
      };
      this.setState({isSpinner:true,isVisible:true})
      axios.get(ip+'/getSpinnerData', config)
      .then(response => this.setState({dataTeamMember:response.data},() => {if(response.status==200){this.setState({isSpinner:false})}}))
      .catch(err => console.log(err));  
}
call(){
    this.getteammember()
}
gettaskdetail(){
    this.setState({RSCName:this.state.RSCName})
    const config = {
        headers: {
        'currentToken':tokken,
      },
        params: {
            sqlQuery:'SELECT TaskID,TaskDesc FROM ProjectTagTasks WHERE TagIDNo ='+this.state.TagID//+' '+'AND TaskGroup='+this.state.RSCName
        }
      };
      this.setState({isVisibleTask:true,isLoading:true})
      axios.get(ip+'/getSpinnerData', config)
      .then(response => this.setState({TaskDataSource:response.data},() => {if(response.status==200){this.setState({isLoading:false})}}))
      .catch(err => console.log(err));  
}
gettagdetail(){
    const config = {
        headers: {   
        'currentToken':tokken,
      },
        params: {
            sqlQuery:'select TagIDNo,TagID from ProjectTags where ProjectID='+this.state.ProjectID
        }
        
      };

      this.setState({isVisibleTag:true,isLoading:true})
      axios.get(ip+'/getSpinnerData', config)
      .then(response => this.setState({TagDataSource:response.data},() => {if(response.status==200){this.setState({isLoading:false})}}))
      .catch(err => console.log(err));  
}
getprojectdetail(){
    const config = {
        headers: {   
        'currentToken':tokken,
      },
        params: {
            empid:this.state.EmpID,
        }
      };
      this.setState({isLoading:true})
      axios.get(ip+'/getEmpDetail',config)
      .then(response => this.setState({ EmpDetail:response.data},() =>{if(response.status==200){
          const{A,B,C}=this.state.EmpDetail
          this.setState({isLoading:false,projectDetail:A+' '+B,ProjectID:A,RSCName:C})
        }
    }))
      .catch(err => console.log(err));  
}
render() {
     if (this.state.isLoading) {
        return (
            <View style={{ flex: 1,
              justifyContent: 'center',
              flexDirection: 'column' }}>
                <ActivityIndicator size="large" color="#0000ff" />
            </View>
        )
    }

  return (
<ScrollView style={styles.container}>
<Text style={styles.spinner}  onPress={this.showDateTimePicker.bind(this)}  >
        {this.state.TaskDate}
</Text>
<DateTimePicker
          isVisible={this.state.isDateTimePickerVisible}
          onConfirm={this.handleDatePicked}
          onCancel={this.hideDateTimePicker}/>   
<Text style={styles.textContent}>
         Team Member
</Text>     
<Text style={styles.spinners}  onPress = {() => {this.call()}}  >
        {this.state.teammember}
</Text>     
      <Modal    
          animationType = {"fade"}  
          transparent = {true}  
          visible = {this.state.isVisible}  
          onRequestClose = {() =>{ console.log("Modal has been closed.") } }>  
          {/*All views of Modal*/}  
          
      <View style = {styles.modal}>  

  <TouchableOpacity style={styles.FacebookStyle} activeOpacity={0.5} onPress = {() => {  
                  this.setState({ isVisible:!this.state.isVisible})}}>

        <Grid>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontFamily:'Bold',alignSelf:'flex-start'}}>
             Team Member
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('./src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
       </Grid>
   

</TouchableOpacity>
      <FlatList
       data={ this.state.dataTeamMember }
       initialNumToRender={this.state.dataTeamMember.length}
        renderItem={({item}) => 
        <Grid onPress={this.getTeamMemberItem.bind(this,item.sCode,item.sDesc)}>
              <Col style={{alignItems:'flex-start',width:'20%'}}>
              <Text style={{fontSize:13,fontFamily:'Regular'}}>{item.sCode}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'80%'}}>
              <Text style={{fontSize:13,fontFamily:'Regular'}}>{item.sDesc}</Text>
              </Col> 
        </Grid>
        }
       keyExtractor={(item, index) => index.toString()}
      />

          </View>  
      </Modal>  

        <Text style={styles.textContent}>
         Project Details
        </Text>     
<Text style={{padding:10}} onPress = {() => {this.getprojectdetail()}}>{this.state.projectDetail}</Text>

<Text style={styles.textContent}>
        Tag Details
</Text>     
<Text style={styles.spinners}  onPress = {() => {this.gettagdetail()}}  >
        {this.state.TagDetail}
</Text>     
    <Modal            
          animationType = {"fade"}  
          transparent = {true}  
          visible = {this.state.isVisibleTag}  
          onRequestClose = {() =>{ console.log("Modal has been closed.") } }>  
          {/*All views of Modal*/}  
          
      <View style = {styles.modal}>  

  <TouchableOpacity style={styles.FacebookStyle} activeOpacity={0.5} onPress = {() => {  
                  this.setState({ isVisibleTag:!this.state.isVisibleTag})}}>
   
   <Grid>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontFamily:'Bold',alignSelf:'flex-start'}}>
             Tag Details
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('./src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
       </Grid>
    
</TouchableOpacity>
      <FlatList
       data={ this.state.TagDataSource }
       initialNumToRender={this.state.TagDataSource.length}
        renderItem={({item}) => 
        <Grid onPress={this.getTagItems.bind(this,item.sCode,item.sDesc)}
        >
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={{fontSize:13}}>{item.sCode}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'70%'}}>
              <Text style={{fontSize:13}}>{item.sDesc}</Text>
              </Col> 
        </Grid>
        }
  
       keyExtractor={(item, index) => index.toString()}
      />
          </View>  
    </Modal> 
<Text style={styles.textContent}>
        Task Details
</Text>    
<Text style={styles.spinners}  onPress = {() => {this.gettaskdetail()}}  >
        {this.state.TaskDetail}
</Text>   
   <Modal            
          animationType = {"fade"}  
          transparent = {true}  
          visible = {this.state.isVisibleTask}  
          onRequestClose = {() =>{ console.log("Modal has been closed.") } }>  
          {    }
      <View style = {styles.modal}>  

  <TouchableOpacity style={styles.FacebookStyle} activeOpacity={0.5} onPress = {() => {  
                  this.setState({ isVisibleTask:!this.state.isVisibleTask})}}>
   
   <Grid>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontFamily:'Bold',alignSelf:'flex-start'}}>
             Task Detail
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('./src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
       </Grid>
    
    
</TouchableOpacity>
      <FlatList
       data={ this.state.TaskDataSource }
       initialNumToRender={this.state.TaskDataSource.length}
        renderItem={({item}) => 
        <Grid onPress={this.getTaskitems.bind(this,item.sCode,item.sDesc)}
        >
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={{fontSize:13,fontFamily:'Regular'}}>{item.sCode}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'70%'}}>
              <Text style={{fontSize:13,fontFamily:'Regular'}}>{item.sDesc}</Text>
              </Col> 
        </Grid>
        }
  
       keyExtractor={(item, index) => index.toString()}
      />
          </View>  
        </Modal> 
        <Item floatingLabel>
              <Label style={{color:'#2452b2',fontSize:13}}>Task Description</Label>
              <Input  value={this.state.TaskDescription}
              style={{fontFamily:'Regular'}}
          onChangeText={(TaskDescription) => this.setState({ TaskDescription })} />
    </Item>
<Text style={styles.textContent}>
Time Schedule
</Text>    
<Text style={styles.spinners}  onPress = {() => {this.gettimeshedule()}}  >
        {this.state.TimeSchedule}
</Text>  
 <Modal            
          animationType = {"fade"}  
          transparent = {true}  
          visible = {this.state.isVisibleTimeSchedule}  
          onRequestClose = {() =>{ console.log("Modal has been closed.") } }>  
          {
          }       
      <View style = {styles.modal}>  

  <TouchableOpacity style={styles.FacebookStyle} activeOpacity={0.5} onPress = {() => {  
                  this.setState({ isVisibleTimeSchedule:!this.state.isVisibleTimeSchedule})}}>
 
       <Grid>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontFamily:'Bold',alignSelf:'flex-start'}}>
             Time Shedule
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('./src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
       </Grid>
   
</TouchableOpacity>
      <FlatList
       data={ this.state.TimeSheduleDataSource}
       initialNumToRender={this.state.TimeSheduleDataSource.length}
        renderItem={({item}) => 
        <Grid onPress={this.gettimesheduleitem.bind(this,item.A,item.B)}
        >
        <Row>
        <Col style={{alignItems:'flex-start',width:'30%'}}>
        <Text style={{fontSize:13,fontFamily:'Regular'}}>{item.A}</Text>
        </Col> 
        <Col style={{alignItems:'flex-start',width:'70%'}}>
        <Text style={{fontSize:13,fontFamily:'Regular'}}>{item.B}</Text>
        </Col> 
        </Row> 
        <Row>
        <Col style={{alignItems:'flex-start',width:'25%'}}>
        <Text style={{fontSize:12,color:'#2452b2',fontFamily:'Regular'}}>Start Time</Text>
        </Col> 
        <Col style={{alignItems:'flex-start',width:'25%'}}>
        <Text style={{fontSize:12,color:'#2452b2',fontFamily:'Regular'}}>End Time</Text>
        </Col> 
        <Col style={{alignItems:'flex-start',width:'25%'}}>
        <Text style={{fontSize:12,color:'#2452b2',fontFamily:'Regular'}}>Reg. hours</Text>
        </Col>
        <Col style={{alignItems:'flex-start',width:'25%'}}>
        <Text style={{fontSize:12,color:'#2452b2',fontFamily:'Regular'}}>Lunch Min</Text>
        </Col> 
        </Row>
        <Row>
        <Col style={{alignItems:'flex-start',width:'25%'}}>
        <Text style={{fontSize:12,fontFamily:'Regular'}}>{item.B}</Text>
        </Col> 
        <Col style={{alignItems:'flex-start',width:'25%'}}>
        <Text style={{fontSize:12,fontFamily:'Regular'}}>{item.C}</Text>
        </Col> 
        <Col style={{alignItems:'flex-start',width:'25%'}}>
        <Text style={{fontSize:12,fontFamily:'Regular'}}>{item.D}</Text>
        </Col> 
        <Col style={{alignItems:'flex-start',width:'25%'}}>
        <Text style={{fontSize:12,fontFamily:'Regular'}}>{item.E}</Text>
        </Col> 
        </Row>
        </Grid>
        }
  
       keyExtractor={(item, index) => index.toString()}
      />
          </View>  
        </Modal> 
        <View style={styles.b}>
            <Grid>
              <Col style={{alignItems:'flex-start',width:screen}}>
              <Item floatingLabel>
              <Label style={{color:'#2452b2',fontSize:13}}>%Complete</Label>
              <Input  keyboardType={'numeric'}
               value={this.state.Complete}
               style={{fontFamily:'Regular'}}
          onChangeText={(Complete) => this.setState({ Complete })}
               />
              </Item>
              </Col> 
              <Col style={{alignItems:'flex-start',width:screen}}>
              <Item floatingLabel>
              <Label style={{color:'#2452b2',fontSize:13}}>Regular Time</Label>
              <Input  keyboardType={'numeric'} 
              style={{fontFamily:'Regular'}}
          value={this.state.Regular}
          onChangeText={(Regular) => this.setState({ Regular })}
              />
              </Item>
              </Col> 
              <Col style={{alignItems:'flex-start',width:screen}}>
              <Item floatingLabel>
              <Label style={{color:'#2452b2',fontSize:13}}>Over Time</Label>
              <Input  keyboardType={'numeric'}
               value={this.state.Over}
               style={{fontFamily:'Regular'}}
              onChangeText={(Over) => this.setState({ Over })}
               />
              </Item>
              </Col> 
            </Grid>  
          </View>
          <View style={[{ width: "35%", margin: 20,alignSelf:'center'}]}>
          <Button
            onPress={this.onSave.bind(this)}
            title="Save"         
          />
</View> 
</ScrollView>
  )
}

 
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'white',
      },
      spinner: {
        fontSize: 15,
        padding:10,
        height:40,
        flexWrap: 'wrap',
        color: 'grey',
      },
      textContent: {
        backgroundColor:'#2452b2',
        fontSize: 12,
        padding:4,
        color: '#fff',
        fontFamily:'Bold'
      },
      spinners: {
        fontSize: 13,
        padding:10,
        height:50,
        flexWrap: 'wrap',
        color: 'grey',
      },
      modal: {  
        flex: 1,
        backgroundColor: '#fff',
        height: sheight, 
        position: 'absolute',
        bottom: 0,
        width:'100%'
         },  
      FacebookStyle: {
            flexDirection: 'row',
            alignItems:'center',
            backgroundColor: '#1ca0ff',
            borderWidth: 0.5,
            borderColor: '#fff',
            height: 40,
            width: screenWidth,
            borderRadius: 5,
            fontFamily:'Regular'
    },
});

 
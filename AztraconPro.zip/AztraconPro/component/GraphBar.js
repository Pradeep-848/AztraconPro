import React,{ Component }  from 'react';
import {ScrollView,StyleSheet,ActivityIndicator,View,AppRegistry,processColor,Text} from 'react-native';
import { VictoryBar, VictoryChart, VictoryTheme,VictoryLabel } from "victory-native";

import axios from 'axios';
import strings from './res/strings'
import color from './res/colors'

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const black=color.values.Colors.black;

let data = [];

 export default class GraphBar extends React.Component {
  static navigationOptions = {
    title: "Bar Chart",
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
  };
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false, 
      dataSource:'',
      agecode:'',
    };
}

getbardata=()=>{
  console.log(this.state.agecode)
  const config = {
    headers: {   
    'currentToken': tokken,
  },
    params: {
        AgeCode:this.state.agecode,
    }
    
  };

  this.setState({isLoading:true})
  axios.get(ip+'/getSupplierListBar', config)
  .then(response => this.setState({ dataSource:response.data},() => {if(response.status==200){

      for (let i=0;i<this.state.dataSource.length;i++){
          const{Party,Percent,Amount}=this.state.dataSource[i]
          
          var s={
            Party:Party,
            Percent:parseInt(Percent),
            Amount:Amount,
            fill:this.randomColor()
            }
            data.push(s)
      }

      this.setState({
          isLoading:false
        })}}))
  .catch(err => console.log(err));  
}

componentDidMount(){
 this.setState({
    agecode:this.props.navigation.getParam('Agecode', '')
},()=>{this.getbardata();})
}
randomColor = () => ('#' + (Math.random() * 0xFFFFFF << 0).toString(16) + '000000').slice(0, 7)
  render() {
    if (this.state.isLoading) {
      return (
          <View style={{ flex: 1,
            justifyContent: 'center',
            flexDirection: 'column' }}>
              <ActivityIndicator size="large" color="#0000ff" />
          </View>
      )
  }
    return (
  <View style={styles.container}>
  <ScrollView>
  <VictoryChart 
           height={700}
           theme={VictoryTheme.material}> 
        <VictoryBar 
          barWidth={10}
          style={{
         data: {
          fill: ({ datum }) => datum.fill,
              }
          }}
          minDomain={{ x: 1 }}
          horizontal     
          data={data}
          x="Party" 
          y="Percent" />
      </VictoryChart>
  </ScrollView>
      </View>  
        )
      }
 };
 const styles = StyleSheet.create({
  container: {
    flex: 1,
 //   justifyContent: "center",
  //  alignItems: "center",
    backgroundColor: "#f5fcff"
  }
  });
  
  
  
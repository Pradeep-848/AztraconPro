import React,{ Component }  from 'react';
import {ScrollView,Modal,StyleSheet,Text,View,Image,TouchableOpacity,Alert,ImageBackground,Dimensions} from 'react-native';
import { Col,Grid,Row } from 'react-native-easy-grid';
import { NavigationActions, StackActions } from 'react-navigation';
import axios from 'axios';
import Toast from 'react-native-whc-toast'
import { RFValue } from "react-native-responsive-fontsize";

//own lib
import color from './res/colors'
import {logouttask} from './class/logout';
import strings from './res/strings'

//constant
const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);
const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const blue=color.values.Colors.blue;
const white=color.values.Colors.white;
const primary=color.values.Colors.colorPrimary;
const loading=color.values.Colors.loading;

var { height, width } = Dimensions.get("window");

//common style
const style_common = require('./class/style');

//logout
const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});
 export default class ProjectDetails extends React.Component {
  static navigationOptions = ({ navigation }) => ({ 
    title: "Project Details",
    color:white,
    headerStyle: {
      backgroundColor: primary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
      fontSize:RFValue(20)
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
      isLoading:false, 
      dataSource:'',
      handlelogin:'',
      USER:'',
      pid:'',
      qid:'',
      ptype:'',
      pname:'',
      cproject:'',
      customer:'',
      location:'',
      ono:'',
      ovalue:'',
      oqty:'',
      odate:'',
      currency:'',
      duedate:'',
      pengineer:'',
      pmanager:'',
      cstatus:'',
      layout: {
        height: height,
        width: width
    }
    };
}


_onLayout = event => {
  this.setState({
      layout: {
          height: event.nativeEvent.layout.height,
          width: event.nativeEvent.layout.width
      }
  });
};


componentDidMount() {
  console.disableYellowBox = true;

  this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
  
   this.setState({ 
    USER:this.props.navigation.getParam('USER', ''),
    pid:this.props.navigation.getParam('PID', '')
  },()=>{this.getprojectdetails();})
}



login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
        this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}


getprojectdetails=()=>{
 
    const config = {
      headers: {   
      'currentToken':tokken,
    },
      params: {
        pid:this.state.pid,
      }
      
    };
    this.setState({isLoading:true})
    axios.get(ip+'/getProjDetails', config)
    .then(response => this.setState({dataSource:response.data},() => {if(response.status==200){
     const{pid,qid,ptype,pname,cproject,customer,location,ono,ovalue,oqty,odate,currency,duedate,pengineer,pmanager,cstatus}=this.state.dataSource
    this.setState({
    pid:pid,
    qid:qid,
    ptype:ptype,
    pname:pname,
    cproject:cproject,
    customer:customer,
    location:location,
    ono:ono,
    ovalue :ovalue,
    oqty:oqty,
    odate:odate,
    currency:currency, 
    duedate:duedate,
    pengineer:pengineer,
    pmanager:pmanager,
    cstatus:cstatus,
    isLoading:false
})
    }}))
    .catch(err => 
      {
        this.setState({
          isLoading:false
        },()=>{
         let error=err
         
         this.refs.toast.showBottom(error.toString())
  
         setTimeout(
          () => { 
            this.props.navigation.goBack();
           },
          2000
        )
  
        })
      }
      );
  }
  render() {
    if (this.state.isLoading) {
      return (
        <Modal
        transparent={false}
        supportedOrientations={['portrait', 'landscape']}
        visible={this.state.isLoading}
        >
          <View  onLayout={this._onLayout} style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
          useNativeDriver={true}
          style={style_common.load_gif}
          source={require('./src/gears.gif')}  />
          </View>      
        </Modal>
      )
  }
    return (
    <View
    style={{ flex: 1 }}
    onLayout={this._onLayout}
       >
    <ImageBackground 
          source={require('./src/aztracon_bg.jpg')}
          style = {styles.imageStyle} >
         
    <ScrollView>
    <Grid style={{paddingTop:'3%'}}>
            <Row style={styles.rowpadd}>
              <Col style={styles.headcol}>
              <Text style={styles.tittle}>Project ID</Text>
              </Col> 
              <Col style={styles.detailcol}>
              <Text style={styles.detailtext}>{this.state.pid}</Text>
              </Col> 
            </Row>
            <Row style={styles.rowpadd}>
            <Col style={styles.headcol}>
              <Text style={styles.tittle}>Q ID</Text>
              </Col> 
              <Col style={styles.detailcol}>
              <Text  style={styles.detailtext}>{this.state.qid}</Text>
              </Col> 
            </Row>
            <Row style={styles.rowpadd}>
            <Col style={styles.headcol}>
              <Text style={styles.tittle}>Project type</Text>
              </Col> 
              <Col style={styles.detailcol}>
              <Text  style={styles.detailtext}>{this.state.ptype}</Text>
              </Col> 
            </Row>   
            <Row style={styles.rowpadd}>
            <Col style={styles.headcol}>
               <Text style={styles.tittle}>Project Name</Text>   
              </Col>
              <Col style={styles.detailcol}>
                <Text  style={styles.detailtext}>{this.state.pname}</Text>  
              </Col>
              </Row>
              <Row style={styles.rowpadd}>
              <Col style={styles.headcol}>
                 <Text style={styles.tittle}>Client project</Text> 
              </Col>
              <Col style={styles.detailcol}>
                 <Text  style={styles.detailtext}>{this.state.cproject}</Text> 
              </Col>
              </Row>
            </Grid>  
      
      <Grid>   
      <Row style={styles.rowpadd}>
      <Col style={styles.headcol}>
          <Text style={styles.tittle}>Customer</Text>
          </Col>
          <Col style={styles.detailcol}>
          <Text  style={styles.detailtext}>{this.state.customer}</Text>
          </Col>
      </Row>
      <Row style={styles.rowpadd}>
      <Col style={styles.headcol}>
          <Text style={styles.tittle}>Location</Text>
          </Col>
          <Col style={styles.detailcol}>
          <Text  style={styles.detailtext}>{this.state.location}</Text>
          </Col>
      </Row>
      <Row style={styles.rowpadd}>
      <Col style={styles.headcol}>
          <Text style={styles.tittle}>Order No.</Text>
          </Col>
          <Col style={styles.detailcol}>
          <Text  style={styles.detailtext}>{this.state.ono}</Text>
          </Col>
      </Row>
      <Row style={styles.rowpadd}>
      <Col style={styles.headcol}>
          <Text style={styles.tittle}>Order value</Text>
          </Col>
          <Col style={styles.detailcol}>
          <Text  style={styles.detailtext}>{this.state.ovalue}</Text>
          </Col>
      </Row>
      <Row style={styles.rowpadd}>
      <Col style={styles.headcol}>
          <Text style={styles.tittle}>Order quantity</Text>
          </Col>
          <Col style={styles.detailcol}>
          <Text  style={styles.detailtext}>{this.state.oqty}</Text>
          </Col>
      </Row>
      <Row style={styles.rowpadd}>
      <Col style={styles.headcol}>
          <Text style={styles.tittle}>Order date</Text>
          </Col>
          <Col style={styles.detailcol}>
          <Text  style={styles.detailtext}>{this.state.odate}</Text>
          </Col>
      </Row>
      <Row style={styles.rowpadd}>
      <Col style={styles.headcol}>
          <Text style={styles.tittle}>Currency</Text>
          </Col>
          <Col style={styles.detailcol}>
          <Text  style={styles.detailtext}>{this.state.currency}</Text>
          </Col>
      </Row>
      <Row style={styles.rowpadd}>
      <Col style={styles.headcol}>
          <Text style={styles.tittle}>Due date</Text>
          </Col>
          <Col style={styles.detailcol}>
          <Text  style={styles.detailtext}>{this.state.duedate}</Text>
          </Col>
      </Row>
      <Row style={styles.rowpadd}>
      <Col style={styles.headcol}>
          <Text style={styles.tittle}>Project engineer</Text>
          </Col>
          <Col style={styles.detailcol}>
          <Text  style={styles.detailtext}>{this.state.pengineer}</Text>
          </Col>
      </Row>
      <Row style={styles.rowpadd}>
      <Col style={styles.headcol}>
          <Text style={styles.tittle}>Project manager</Text>
          </Col>
          <Col style={styles.detailcol}>
          <Text  style={styles.detailtext}>{this.state.pmanager}</Text>
          </Col>
      </Row>
      <Row style={styles.rowpadd}>
      <Col style={styles.headcol}>
          <Text style={styles.tittle}>Current status</Text>
          </Col>
          <Col style={styles.detailcol}>
          <Text  style={styles.detailtext}>{this.state.cstatus}</Text>
          </Col>
      </Row>
      </Grid>  
      
  <Toast ref="toast"/>         
    </ScrollView>

    </ImageBackground>

    </View>
        )
      }
 };
 const styles = StyleSheet.create({
    textContent: {
      backgroundColor:white,
      fontSize: RFValue(15),
      padding:RFValue(8),
      textAlign:'center',
      color:primary,
      fontWeight: 'bold',
      textShadowColor: 'rgba(0, 0, 0, 0.75)',
      textShadowOffset: {width: -1, height: 1},
      textShadowRadius: 10
    },
   tittle:{
    color:primary,
    fontSize: RFValue(14),
    paddingLeft:RFValue(6),
    fontFamily:'Bold'
   },
   Headtittle:{
    color:primary,
    fontSize: RFValue(13),
    fontWeight:'bold',
   },
   headcol:{
    alignItems:'flex-start',
    width:"40%"
   },
   detailcol:{
    alignItems:'flex-start',
    width:"60%"
   },
   rowpadd:{
    paddingTop:RFValue(7)
   },
   detailtext:{
     fontSize: RFValue(13),
     fontFamily:'Bold'
   },
   imageStyle:{
    width: screenWidth, 
    height: screenHeight, 
   },
  });
  

 
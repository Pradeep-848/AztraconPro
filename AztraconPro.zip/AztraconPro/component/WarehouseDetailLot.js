import React,{ Component }  from 'react';
import {ScrollView,Modal,StyleSheet, Text,View,Image,Dimensions,FlatList,TouchableOpacity,Alert} from 'react-native';
import { Col, Grid, Row } from 'react-native-easy-grid';
import { Divider } from 'react-native-elements';
import Toast from 'react-native-whc-toast'
import axios from 'axios';
import { NavigationActions, StackActions } from 'react-navigation';
import {Card,CardItem} from 'native-base';
import {logouttask} from './class/logout';
import strings from './res/strings'
import color from './res/colors'


const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const blue=color.values.Colors.blue;
const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const lightblue=color.values.Colors.lightblue;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class WarehouseDetailLot extends React.Component {
  static navigationOptions = ({ navigation }) => ({ 
    title: "Warehouse Detail",
    color:color,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false, 
      dataSource:'',
      handlelogin:'',
      pid:'',UserID:'',pdesc:'',cid:'',cname:'',whrno:'',whsno:'',
    };
}
login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
        this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}
getWHLotDetail=()=>{
  const config = {
    headers: {   
    'currentToken': tokken,
  },
    params: {
        whrno:this.state.whrno,
        whsno:this.state.whsno
    }
    
  };

  this.setState({isLoading:true})
  axios.get(ip+'/getWHDetailLot', config)
  .then(response => this.setState({ dataSource:response.data},() => {if(response.status==200){this.setState({isLoading:false})}}))
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
}



componentDidMount(){
  console.disableYellowBox = true;

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
  
  this.setState({
      pid:this.props.navigation.getParam('PID', ''),
      cid:this.props.navigation.getParam('CusID', ''),
      pdesc:this.props.navigation.getParam('PDesc', ''),
      cname:this.props.navigation.getParam('CusName', ''),
      UserID:this.props.navigation.getParam('UserID', ''),
      whrno:this.props.navigation.getParam('WHRNo', ''),
      whsno:this.props.navigation.getParam('WHSNo', '')
},()=>{this.getWHLotDetail();})
}
  render() {
    if (this.state.isLoading){
      return (
        <Modal
        transparent={false}
        supportedOrientations={['portrait', 'landscape']}
        visible={this.state.isLoading}
        >
         <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
          style={{width: 300, height: 200}}
          source={require('./src/gears.gif')}  />
          </View>     
        </Modal>
      )
  }
    return (
<View style={{flex:1,backgroundColor:lightblue}}>

<ScrollView style={{height:'15%'}}>
  <Grid style={{paddingTop:'2%'}}>
  <Row style={{backgroundColor:colorprimary,width:'97%',alignSelf:'center'}}>
  <Text style={styles.titleText}>
          {this.state.pid+" - "+this.state.pdesc}
  </Text>
   </Row>
   <Divider style={{ backgroundColor:white}} />
   <Divider style={{ backgroundColor:white}} />
   <Row style={{backgroundColor:colorprimary,width:'97%',alignSelf:'center'}}>
   <Text style={styles.titleText}>
          {this.state.cid.toString().trim()+" - "+this.state.cname}
  </Text>
  </Row>  
  </Grid>
  <View  style={{ flex: 1,paddingTop:5,paddingBottom:5}}>
    <Grid style={{backgroundColor:colorprimary,padding:5,width:"97%",alignSelf:'center',borderRadius:4}}>
             <Row>
             <Col style={{alignItems:'flex-start',width:'20%',paddingLeft:8}}>
             <Text style={styles.textContent}>LotID</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'25%',paddingLeft:5}}>
             <Text style={styles.textContent}>Heat No</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'25%',paddingRight:5}}>
             <Text style={styles.textContent}>QC Date</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'30%',paddingRight:5}}>
             <Text style={styles.textContent}>QC Stats</Text>
             </Col> 
             </Row>
             </Grid>
    </View>
    </ScrollView>
    <ScrollView style={{height:'85%'}}>
    <FlatList
       data={ this.state.dataSource }
       initialNumToRender={this.state.dataSource.length}
       renderItem={({item,index}) =>  
       <Card>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
            <Grid>
            <Row>
              <Col style={{alignItems:'flex-start',width:'20%'}}>
              <Text style={{fontSize:13,fontFamily:'Normal'}}>{item.LotID}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'25%'}}>
              <Text style={{fontSize:13,fontFamily:'Normal'}}>{item.HeatNo}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'25%'}}>
              <Text style={{fontSize:13,fontFamily:'Normal'}}>{item.QcDate}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={{fontSize:13,fontFamily:'Normal'}}>{item.InspStatusDesc}</Text>
              </Col> 
            </Row>
            <View style={{borderBottomColor:'#A9A9A9',borderBottomWidth: 1,height:5,width:'100%',alignSelf:'center'}}/>
            <Row>
              <Col style={{alignItems:'center',width:'30%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Accepted Qty</Text>
              </Col> 
              <Col style={{alignItems:'center',width:'40%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Rejected Qty</Text>
              </Col> 
              <Col style={{alignItems:'center',width:'30%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Hold Qty</Text>
              </Col> 
            </Row>
           <Row>
              <Col style={{alignItems:'center',width:'30%'}}>
              <Text style={{fontSize:13,fontFamily:'Normal'}}>{item.AcceptedQty}</Text>
              </Col> 
              <Col style={{alignItems:'center',width:'40%'}}>
              <Text style={{fontSize:13,fontFamily:'Normal'}}>{item.RejectedQty}</Text>
              </Col> 
              <Col style={{alignItems:'center',width:'30%'}}>
              <Text style={{fontSize:13,fontFamily:'Normal'}}>{item.HoldQty}</Text>
              </Col> 
           </Row>
           <View style={{borderBottomColor:'#A9A9A9',borderBottomWidth: 1,height:10,width:'100%',alignSelf:'center'}}/>
           <Row>
           <Col style={{alignItems:'center',width:'35%'}}>
           <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Attach File Name</Text>
           </Col> 
           <Col style={{alignItems:'center',width:'55%'}}>
           <Text style={{fontSize:13,fontFamily:'Normal'}}>{item.AttachFileName}</Text>
           </Col> 
           </Row>
           <Row>
           <Col style={{alignItems:'center',width:'35%'}}>
           <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>QC Remarks</Text>
           </Col> 
           <Col style={{alignItems:'center',width:'55%'}}>
           <Text style={{fontSize:13,fontFamily:'Normal'}}>{item.QcRemarks}</Text>
           </Col> 
           </Row>
            </Grid>  
             </CardItem>
           </Card>
        }
       keyExtractor={(item, index) => index.toString()}
       
      />
  <Toast ref="toast"/>
          </ScrollView>
          </View>
        )
      }
 };
 const styles = StyleSheet.create({
  titleText: {
    flex:1,
    flexWrap:'wrap',
    color:white,
    fontSize:12,
    padding:5,
    fontFamily:'Bold'
  },
  textContent:{
    color:white,
    fontSize:13,
    fontFamily:'Bold'
  }
  });
  
  
  
import React,{ Component }  from 'react';
import {ScrollView,StyleSheet,Text,View,Dimensions,Modal,Image,FlatList,TouchableOpacity,Alert,
Linking} from 'react-native';
import { Col, Grid, Row } from 'react-native-easy-grid';
import { Divider,SearchBar } from 'react-native-elements';
import axios from 'axios';
import { NavigationActions, StackActions } from 'react-navigation';
import {Card,CardItem} from 'native-base';
import Toast from 'react-native-whc-toast'
import {logouttask} from './class/logout';
import strings from './res/strings'
import color from './res/colors'

const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);

const ip=strings.values.commonvalues.ip;
const fileip = strings.values.commonvalues.fileip;
const tokken=strings.values.commonvalues.tokken;

const black=color.values.Colors.black;
const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const lightblue=color.values.Colors.lightblue;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});
export default class ProjectMail extends React.Component {
  static navigationOptions = ({ navigation }) => ({ 
    title: "Project Mail",
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false, 
      dataSource:'',
      MsgdataSource:[],
      AttachdataSource:[],
      handlelogin:'',
      isMail:false,
      text:'',
      CusName:'',UserID:'',PID:'',CusID:'',
      From:'',To:'',Subject:'',Date:'',Body:''
    };
    this.arrayholder = [];
}
login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
      this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}
getprojectmail=()=>{
  const config = {
    headers: {   
    'currentToken': tokken,
  },
    params: {
        UserID:this.state.UserID,
        PID:this.state.PID,
    }
    
  };

  this.setState({isLoading:true})
  axios.get(ip+'/getProjectMailIOS', config)
  .then(response => this.setState({ dataSource:response.data},() => {if(response.status==200){
    this.arrayholder = this.state.dataSource;
    console.log(this.state.dataSource)
    this.setState({isLoading:false})
  }}))
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
}

DownloadFile= async (Path,Name) =>{

console.log('here')

 let url=''
  
 url=fileip+"/DocumentDownloadIOS?FPath="+Path+"&FileName="+Name 

 const supported = await Linking.canOpenURL(url);

 if (supported) {
  await Linking.openURL(url);
} else {
  Alert.alert(`Don't know how to open this URL: ${url}`);
} 

}


getMsgFile(i){
  let FName;
  const {FilePath,Task,Desc,IsValid} = this.state.dataSource[i]

  console.log(IsValid)
  FName = Desc+'.msg'
if(IsValid==true){

    if(Task!='OT-1001'){

        const config = {
          headers: {   
          'currentToken': tokken,
        },
          params: {
            FPath:FilePath,
            FileName:FName
          }
          
        };
      
        this.setState({isLoading:true})
        axios.get(ip+'/MailDocumentDownloadIOS', config)
        .then(response => this.setState({ MsgdataSource:response.data},() => {if(response.status==200){
          console.log(this.state.MsgdataSource)
          const{Attachments,from,to,subject,date,body}=this.state.MsgdataSource[0]
          this.setState({
            From:from,
            To:to,
            Subject:subject,
            Date:date,
            Body:body,
            AttachdataSource:Attachments,
            isLoading:false,
            isMail:true})
    
        }}))
        .catch(err => 
          {
            this.setState({
              isLoading:false
            },()=>{
             let error=err
             
             this.refs.toast.showBottom(error.toString())
      
             setTimeout(
              () => { 
                this.props.navigation.goBack();
               },
              2000
            )
      
            })

          }
          );
    
      }else{
      this.refs.toast.showBottom('Internal Mail..,Not allowed to Open.. !')
      }

}else{
    console.log('here')
     this.refs.toast.showBottom('You are not allowed to open Communication')
}



}

filtersearch(text){
  const newData = this.arrayholder.filter(function(item){
  const itemData =item.From.toString().toUpperCase()+item.To.toString().toUpperCase()
  const textData =text.toUpperCase()
  return itemData.indexOf(textData) > -1
}
)
this.setState({
dataSource: newData.sort(),
text: text,
})

}

componentDidMount() {

  console.disableYellowBox = true;

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
  this.setState({
      CusName:this.props.navigation.getParam('CusName', ''),
      UserID:this.props.navigation.getParam('USER', ''),
      PID:this.props.navigation.getParam('PID', ''),
      CusID:this.props.navigation.getParam('CusID', ''),
},()=>{this.getprojectmail();})
}
  render() {
    if (this.state.isLoading) {
      return (
        <Modal
        transparent={false}
        supportedOrientations={['portrait', 'landscape']}
        visible={this.state.isLoading}
        >
         <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
          useNativeDriver={true}
          style={{width: 300, height: 200}}
          source={require('./src/gears.gif')}  />
          </View>     
        </Modal>
      )
  }
    return (
    <ScrollView style={{backgroundColor:lightblue}}>
     <Grid style={{paddingTop:'2%'}}>
     <Row style={{backgroundColor:colorprimary,width:'97%',alignSelf:'center',borderRadius:3}}>
     <Text style={styles.titleText}>
          {"Project ID"+"-"+this.state.PID}
     </Text>
     </Row>
     <Divider style={{ backgroundColor:white}} />
     <Divider style={{ backgroundColor:white}} />
     <Row style={{backgroundColor:colorprimary,width:'97%',alignSelf:'center',borderRadius:3}}>
     <Text numberOfLines={1} style={styles.titleText}>
          {this.state.CusName+"-"+this.state.CusID}
     </Text>
     </Row> 

       <Row>
        <Col style={{width:'100%',alignSelf:'center'}}>
        <SearchBar
        style={{width:'100%',alignSelf:'center'}}
        placeholder="Search From / To"
        onChangeText={(text) => this.filtersearch(text)}
        value={this.state.text}
        searchIcon={{ name: "search", size: 19, color: colorprimary }}
        clearIcon={{ name: "close-circle", size: 19 }}
        loadingProps={{ size: "small" }}
        lightTheme 
        round
      />
      </Col>
      </Row>

     </Grid>
  

    <FlatList
       data={ this.state.dataSource }
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
             paddingLeft:5,paddingRight:5,paddingTop:10,paddingBottom:10}}>
            <Grid  onPress={() => this.getMsgFile(index)}>      
              <Row>
              <Col style={{alignItems:'flex-start',width:'20%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:"Bold"}}>Trans No - </Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={{fontSize:13,fontFamily:'Italic'}}>{item.TNo}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'20%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:"Bold"}}>Mail Date - </Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={{fontSize:13,fontFamily:'Italic'}}>{item.MailDate}</Text>
              </Col> 
              </Row>
              <View style={{borderBottomColor:'#A9A9A9',borderBottomWidth: 1,height:5,width:'100%',alignSelf:'center'}}/>
              <Row style={{paddingTop:3}}>
              <Col style={{alignItems:'flex-start',width:'20%'}}>
              <Text style={{fontSize:12,color:colorprimary,fontFamily:"Bold",alignSelf:'flex-end'}}>From - </Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'80%'}}>
              <Text style={{fontSize:12,fontFamily:'Regular'}}>{item.From}</Text>
              </Col> 
              </Row>
               <Row  style={{paddingTop:3}}>
              <Col style={{alignItems:'flex-start',width:'20%'}}>
              <Text style={{fontSize:12,color:colorprimary,fontFamily:"Bold",alignSelf:'flex-end'}}>To - </Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'80%'}}>
              <Text style={{fontSize:12,fontFamily:'Regular'}}>{item.To}</Text>
              </Col> 
              </Row>
              <Row  style={{paddingTop:3}}>
              <Col style={{alignItems:'flex-start',width:'20%'}}>
              <Text style={{fontSize:12,color:colorprimary,fontFamily:"Bold",alignSelf:'flex-end'}}>Subject - </Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'80%'}}>
              <Text style={{fontSize:12,fontFamily:'Regular'}}>{item.Desc}</Text>
              </Col> 
              </Row>
            </Grid>  
             </CardItem>
           </Card>
        }

       keyExtractor={(item, index) => index.toString()}
       
      />

       {/*Mail View Modal*/} 

         <Modal            
          animationType = {"slide"}  
          transparent = {true}  
          visible = {this.state.isMail}  
          onRequestClose = {() =>{ console.log("Modal has been closed.") } }>  
          {/*All views of Modal*/}  
          <View style = {styles.modal}>  
          <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress = {() =>
           {  
            this.setState({ isMail:!this.state.isMail})
           }}>
        
          <Grid>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontFamily:'Bold',alignSelf:'flex-start'}}>
             Mail Detail
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('./src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
       </Grid>

         </TouchableOpacity>

         <Grid style={{width:'97%',alignSelf:'center'}}>
             <Row style={styles.row}>
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={styles.htitle}>From</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'70%'}}>
              <Text style={styles.tvalue}>{this.state.From}</Text>
              </Col> 
             </Row>
             <Row style={styles.row}>
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={styles.htitle}>To</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'70%'}}>
              <Text style={styles.tvalue}>{this.state.To}</Text>
              </Col> 
             </Row>
             <Row style={styles.row}>
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={styles.htitle}>Date</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'70%'}}>
              <Text style={styles.tvalue}>{this.state.Date}</Text>
              </Col> 
             </Row>
             <Row style={styles.row}>
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={styles.htitle}>Subject</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'70%'}}>
              <Text style={styles.tvalue}>{this.state.Subject}</Text>
              </Col> 
             </Row>
             <Row style={styles.row}>
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={styles.htitle}>Body</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'70%'}}>
              <Text style={styles.tvalue}>{this.state.Body}</Text>
              </Col> 
             </Row>


             <Divider style={{ backgroundColor:colorprimary}} />
             <Divider style={{ backgroundColor:colorprimary}} />

         </Grid>

     <Grid style={{paddingTop:'2%'}}>

     <Row style={{backgroundColor:colorprimary,width:'97%',alignSelf:'center',borderRadius:3}}>
     <Text style={styles.titleText}>
      Attachments
     </Text>
     </Row>  

     </Grid>

         <FlatList
       data={ this.state.AttachdataSource }
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
             paddingLeft:5,paddingRight:5,paddingTop:10,paddingBottom:10}}>

            <Grid  onPress={() => this.DownloadFile(item.FilePath,item.FileName)}>      
              <Row>
              <Col style={{alignItems:'flex-start',width:'100%'}}>
              <Text style={{fontSize:13,fontFamily:'Italic'}}>{item.FileName}</Text>
              </Col> 
              </Row>
            </Grid>  
             </CardItem>
           </Card>
        }

       keyExtractor={(item, index) => index.toString()}
       
      />

        </View>
  </Modal>

<Toast ref="toast"/>

          </ScrollView>
        )
      }
 };
 const styles = StyleSheet.create({
  titleText: {
    flex:1,
    flexWrap:'wrap',
    color:white,
    fontSize:12,
    padding:5,
    fontFamily:'Bold'
  },
  textContent:{
    color:white,
    fontSize:12
  }
  , modal: {  
    flex:1,
    backgroundColor:white,
    height:'auto',
    position: 'absolute',
    bottom: 0,
    width:'100%',
     },
     headerback: {
      flexDirection: 'row',
      alignItems:'center',
      backgroundColor: colorprimary,
      borderWidth: 0.5,
      borderColor:white,
      height: 40,
      width:'100%',
      borderRadius: 5,
    },
    htitle:{
      color:'#36428a',
      fontSize:15,
      alignSelf:'flex-start',
      fontFamily:'Bold'
     },
     tvalue:{
      alignSelf:'flex-start',
      fontSize:14,
      color:black,
      fontFamily:'Italic'
     },
     row:{
       paddingTop:3,
       paddingBottom:3
     }
  });
  
  
  

 
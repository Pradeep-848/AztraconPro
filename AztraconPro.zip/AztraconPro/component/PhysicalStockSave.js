import React,{ Component }  from 'react';
import {ScrollView,StyleSheet,Text,View,Modal,Image,TouchableOpacity,Alert} from 'react-native';
import { Col, Grid, Row } from 'react-native-easy-grid';
import { NavigationActions, StackActions } from 'react-navigation';
import { Divider } from 'react-native-elements';
import { Card,CardItem } from 'native-base';
import {logouttask} from './class/logout';
import Toast from 'react-native-whc-toast'
import color from './res/colors'

const colorprimary=color.values.Colors.colorPrimary;
const colorprimarydark=color.values.Colors.colorPrimaryDark;
const white=color.values.Colors.white;
const black=color.values.Colors.black;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});
export default class PhysicalStockSave extends React.Component {
  static navigationOptions = ({ navigation }) => ({ 
  
    title: "Physical Stock Save",
    color:white,
    headerStyle: {
      backgroundColor: colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
      handlelogin:'',
      isLoading: false, 
      pid:'',
      itemCode:'',
      entryCode:'',
      qty:'',
      mdesc:'',
      seqno:'',
      materialdesc:'',
      mcode:'',
      slno:'',
      source:'',
      userid:'',
      heatno:'',
      length:'',
      uom:'',
      itemvalue:'',
      location:'',
      grade:'',
      verification:'',
    };
}
login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
      this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}


componentDidMount(){

console.disableYellowBox = true;

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
  
this.setState({
    pid:this.props.navigation.getParam('PID', ''),
    itemCode:this.props.navigation.getParam('ItemCode', ''),
    entryCode:this.props.navigation.getParam('EntryCode', ''),
    qty:this.props.navigation.getParam('QTY', ''),
    mdesc:this.props.navigation.getParam('MDESC', ''),
    seqno:this.props.navigation.getParam('SNo', ''),
    materialdesc:this.props.navigation.getParam('mdesc', ''),
    mcode:this.props.navigation.getParam('MCODE', ''),
    slno:this.props.navigation.getParam('SlNo', ''),
    source:this.props.navigation.getParam('Source', ''),
    userid:this.props.navigation.getParam('UserID', ''),
    heatno:this.props.navigation.getParam('HeatNo', ''),
    length:this.props.navigation.getParam('Length', ''),
    uom:this.props.navigation.getParam('UOM', ''),
    itemvalue:this.props.navigation.getParam('ItemValue', ''),
    location:this.props.navigation.getParam('Location', ''),
    grade:this.props.navigation.getParam('Grade', ''),
    verification:this.props.navigation.getParam('Verify', '')
})

}
  render() {
    if (this.state.isLoading) {
      return (
         <Modal
         transparent={false}
         supportedOrientations={['portrait', 'landscape']}
         visible={this.state.isLoading}
         >
          <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
           <Image
           style={{width: 300, height: 200}}
           source={require('./src/gears.gif')}  />
           </View>     
         </Modal>
      )
  }
    return (
<ScrollView>
<Grid style={{paddingTop:4}}>
  <Row style={{width:'98%',alignSelf:'center',paddingBottom:3}}>
  <Col style={{width:'100%',alignSelf:'center',alignItems:'center'}}>
  <Text style={{color:colorprimarydark,alignSelf:'center',fontSize:20,
           textShadowColor: colorprimary,
           fontWeight:'bold',
           justifyContent:'center',
           textShadowRadius: 5
  }}>
         Physical Stock
  </Text>
  </Col>
   </Row>


   <Divider style={{ backgroundColor:colorprimarydark,width:'97%',alignSelf:'center'}} />
   <Divider style={{ backgroundColor:colorprimarydark,width:'97%',alignSelf:'center'}} />
   <Divider style={{ backgroundColor:colorprimarydark,width:'97%',alignSelf:'center'}} />

   <Row style={{width:'98%',alignSelf:'center',paddingTop:4,paddingBottom:4}}>
   <Col style={{width:'100%',alignSelf:'center',alignItems:'center'}}>
    <Text style={{color:black,fontSize:15,alignSelf:'center'}}>
          {this.state.mcode+"-"+this.state.materialdesc}
    </Text>
    </Col>
   </Row> 

  <Divider style={{ backgroundColor:colorprimary,width:'97%',alignSelf:"center"}} />
  <Divider style={{ backgroundColor:colorprimary,width:'97%',alignSelf:"center"}} />
  </Grid>

  <Card style={{width:"97%",alignSelf:"center",paddingTop:5}}>
      <CardItem style={{width:'100%',alignSelf:"center"}}>
      <Grid style={{paddingTop:5}}>
                <Row style={styles.rowpadd}>
                  <Col style={styles.headcol}>
                  <Text style={styles.tittle}>Project</Text>
                  </Col> 
                  <Col style={styles.detailcol}>
                  <Text style={{fontSize:12}}>{this.state.pid}</Text>
                  </Col> 
                </Row>
                <Row style={styles.rowpadd}>
                <Col style={styles.headcol}>
                  <Text style={styles.tittle}>Entry No</Text>
                  </Col> 
                  <Col style={styles.detailcol}>
                  <Text style={{fontSize:12}}>{this.state.entryCode}</Text>
                  </Col> 
                </Row>
                <Row style={styles.rowpadd}>
                <Col style={styles.headcol}>
                  <Text style={styles.tittle}>Item Code</Text>
                  </Col> 
                  <Col style={styles.detailcol}>
                  <Text style={{fontSize:12}}>{this.state.itemCode}</Text>
                  </Col> 
                </Row>   
                <Row style={styles.rowpadd}>
                <Col style={styles.headcol}>
                   <Text style={styles.tittle}>Item Desc</Text>   
                  </Col>
                  <Col style={styles.detailcol}>
                    <Text style={{fontSize:12}}>{this.state.materialdesc}</Text>  
                  </Col>
                  </Row>
                  <Row style={styles.rowpadd}>
                  <Col style={styles.headcol}>
                     <Text style={styles.tittle}>Heat No</Text> 
                  </Col>
                  <Col style={styles.detailcol}>
                     <Text style={{fontSize:12}}>{this.state.heatno}</Text> 
                  </Col>
                  </Row>
                  <Row style={styles.rowpadd}>
                  <Col style={styles.headcol}>
                     <Text style={styles.tittle}>Length</Text> 
                  </Col>
                  <Col style={styles.detailcol}>
                     <Text style={{fontSize:12}}>{this.state.length}</Text> 
                  </Col>
                  </Row>
                  <Row style={styles.rowpadd}>
                  <Col style={styles.headcol}>
                     <Text style={styles.tittle}>UOM</Text> 
                  </Col>
                  <Col style={styles.detailcol}>
                     <Text style={{fontSize:12}}>{this.state.uom}</Text> 
                  </Col>
                  </Row>
                  <Row style={styles.rowpadd}>
                  <Col style={styles.headcol}>
                     <Text style={styles.tittle}>Item Value</Text> 
                  </Col>
                  <Col style={styles.detailcol}>
                     <Text style={{fontSize:12}}>{this.state.itemvalue}</Text> 
                  </Col>
                  </Row>
                  <Row style={styles.rowpadd}>
                  <Col style={styles.headcol}>
                     <Text style={styles.tittle}>Location</Text> 
                  </Col>
                  <Col style={styles.detailcol}>
                     <Text style={{fontSize:12}}>{this.state.location}</Text> 
                  </Col>
                  </Row>
                  <Row style={styles.rowpadd}>
                  <Col style={styles.headcol}>
                     <Text style={styles.tittle}>Quantity</Text> 
                  </Col>
                  <Col style={styles.detailcol}>
                     <Text style={{fontSize:12}}>{this.state.qty}</Text> 
                  </Col>
                  </Row>
                  <Row style={styles.rowpadd}>
                  <Col style={styles.headcol}>
                     <Text style={styles.tittle}>Grade</Text> 
                  </Col>
                  <Col style={styles.detailcol}>
                     <Text style={{fontSize:12}}>{this.state.grade}</Text> 
                  </Col>
                  </Row>
                
                </Grid>
      </CardItem>

  </Card>
           
  <Toast ref="toast"
        />   
        
</ScrollView>
    
        )
      }
 };
 const styles = StyleSheet.create({
    textContent: {
        backgroundColor:'#fff',
        fontSize: 15,
        padding:8,
        textAlign:'center',
        color: '#36428a',
        fontWeight: 'bold',
        textShadowColor: 'rgba(0, 0, 0, 0.75)',
        textShadowOffset: {width: -1, height: 1},
        textShadowRadius: 10
      },
     tittle:{
      color:'#36428a',
      fontWeight: 'bold',
      fontSize:14,
      paddingLeft:4
     },
     Headtittle:{
      color:'#36428a',
      fontSize:13,
      fontWeight: 'bold',
     },
     headcol:{
      alignItems:'flex-start',
      width:"40%"
     },
     detailcol:{
      alignItems:'flex-start',
      width:"60%"
     },
     titleText:{
         flex:1,
         flexWrap:'wrap',
         color:white,
         fontSize:15,
         padding:5
     },
     rowpadd:{
        paddingTop:10
     }
  });
  
  
  
import React,{ Component }  from 'react';
import {ScrollView,Modal,StyleSheet,Text,View,Image,Dimensions,FlatList,TouchableOpacity,Alert} from 'react-native';
import { Col, Grid, Row } from 'react-native-easy-grid';
import { Divider } from 'react-native-elements';
import axios from 'axios';
import { NavigationActions, StackActions } from 'react-navigation';
import {Card,CardItem} from 'native-base';
import { RFValue } from "react-native-responsive-fontsize";
import Toast from 'react-native-whc-toast'

//own lib
import strings from './res/strings'
import color from './res/colors'
import {logouttask} from './class/logout';


//constant
const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const lightblue=color.values.Colors.lightblue;
const blue=color.values.Colors.blue;
const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;

//common style
const style_common = require('./class/style');

//logout
const resetAction = StackActions.reset({  
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});
 export default class NMRHistory extends React.Component {
  static navigationOptions = ({ navigation }) => ({ 
    title: "NMR History",
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
      fontSize:RFValue(18)
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false, 
      dataSource:'',
      handlelogin:'',
      pid:'',UserID:'',pdesc:'',cid:'',cname:'',nmrid:''
    };
}
login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
        this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}

getnmrhistory=()=>{
  const config = {
    headers: {   
    'currentToken': tokken,
  },
    params: {
        nmrid:this.state.nmrid,//823
    }
    
  };

  this.setState({isLoading:true})
  axios.get(ip+'/getNMRHistory', config)
  .then(response => this.setState({ dataSource:response.data},() => {if(response.status==200){this.setState({isLoading:false})}}))
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
    
}



componentDidMount(){
  console.disableYellowBox = true;

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
  
  this.setState({
      pid:this.props.navigation.getParam('PID', ''),
      cid:this.props.navigation.getParam('CusID', ''),
      pdesc:this.props.navigation.getParam('PDesc', ''),
      cname:this.props.navigation.getParam('CusName', ''),
      UserID:this.props.navigation.getParam('UserID', ''),
      nmrid:this.props.navigation.getParam('NMRid', '')
},()=>{this.getnmrhistory();})
}
  render() {
    if (this.state.isLoading) {
      return (
        <Modal
        transparent={false}
        supportedOrientations={['portrait', 'landscape']}
        visible={this.state.isLoading}
        >
         <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
           useNativeDriver={true}
           style={style_common.load_gif}
           source={require('./src/gears.gif')}  />
          </View>     
        </Modal>
      )
  }
    return (
  <ScrollView style={{backgroundColor:lightblue}}>
  <Grid style={{paddingTop:'2%'}}>
  <Row style={{backgroundColor:colorprimary,width:'97%',alignSelf:'center',borderRadius:3}}>
  <Text numberOfLines={1} style={styles.titleText}>
          {this.state.pid+" - "+this.state.pdesc}
  </Text>
   </Row>
   <Divider style={{ backgroundColor:white}} />
   <Divider style={{ backgroundColor:white}} />
   <Row style={{backgroundColor:colorprimary,width:'97%',alignSelf:'center',borderRadius:3}}>
   <Text numberOfLines={1} style={styles.titleText}>
          {this.state.cid.toString().trim()+" - "+this.state.cname}
  </Text>
  </Row>  
  </Grid>

    <FlatList
       data={ this.state.dataSource }
       initialNumToRender={this.state.dataSource.length}
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
            <Grid>
            <Row>
              <Col style={{alignItems:'flex-start',width:'20%'}}>
              <Text style={{fontSize:RFValue(13),color:colorprimary,fontFamily:'Bold'}}>Trans ID - </Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={{fontSize:RFValue(13),fontFamily:'Regular'}}>{item.TransID}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'20%'}}>
              <Text style={{fontSize:RFValue(13),color:colorprimary,fontFamily:'Bold'}}>Doc ID - </Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={{fontSize:RFValue(13),fontFamily:'Regular'}}>{item.DocumentID}</Text>
              </Col> 
             </Row>
             <View style={{borderBottomColor:'#A9A9A9',borderBottomWidth: 1,height:5,
             width:'100%',alignSelf:'center'}}/>
            <Row>
              <Col style={{alignItems:'flex-start'}}>
              <Text style={{fontSize:RFValue(13),fontFamily:'Regular'}}>{item.DocumentName}</Text>
              </Col> 
            </Row>
            <View style={{borderBottomColor:'#A9A9A9',borderBottomWidth: 1,height:5,
             width:'100%',alignSelf:'center'}}/>
            <Row>
              <Col style={{alignItems:'flex-start',width:'20%'}}>
              <Text style={{fontSize:RFValue(13),color:colorprimary,fontFamily:'Bold'}}>Sheets-</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={{fontSize:RFValue(13),fontFamily:'Regular'}}>{item.Sheets}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'20%'}}>
              <Text style={{fontSize:RFValue(13),color:colorprimary,fontFamily:'Bold'}}>Copies-</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={{fontSize:RFValue(13),fontFamily:'Regular'}}>{item.Copies}</Text>
              </Col> 
             </Row>
             <Row>
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={{fontSize:RFValue(13),color:colorprimary,fontFamily:'Bold'}}>Date - </Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'70%'}}>
              <Text style={{fontSize:RFValue(13),fontFamily:'Regular'}}>{item.SentDate}</Text>
              </Col> 
             </Row>
             <Row>
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={{fontSize:RFValue(13),color:colorprimary,fontFamily:'Bold'}}>Ack Status - </Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'70%'}}>
              <Text style={{fontSize:RFValue(13),fontFamily:'Regular'}}>{item.DocRtnStatus}</Text>
              </Col> 
             </Row>
            </Grid>  
             </CardItem>
           </Card>
        }

       keyExtractor={(item, index) => index.toString()}
       
      />
  <Toast ref="toast"/>
          </ScrollView>
        )
      }
 };
 const styles = StyleSheet.create({
  titleText: {
    flex:1,
    flexWrap:'wrap',
    color:white,
    fontSize:RFValue(12),
    padding:RFValue(5),
    fontFamily:'Bold'
  },
  });
  
  
  
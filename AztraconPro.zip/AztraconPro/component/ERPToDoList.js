import React, { Component } from "react";
import {
  ScrollView,
  StyleSheet,
  Text,
  View,
  Modal,
  Image,
  FlatList,
  TouchableOpacity,
  Alert,
  Dimensions,
} from "react-native";
import { Col, Grid, Row } from "react-native-easy-grid";
import { SearchBar } from "react-native-elements";
import { NavigationActions, StackActions } from "react-navigation";
import axios from "axios";
import Toast from "react-native-whc-toast";
import { Card, CardItem, Item, Input, Form, Label, Icon } from "native-base";
import strings from "./res/strings";
import SelectDropdown from "react-native-select-dropdown";

import moment from "moment";
import color from "./res/colors";
import { logouttask } from "./class/logout";

const screenWidth = Math.round(Dimensions.get("window").width);
const screenHeight = Math.round(Dimensions.get("window").height);

const ip = strings.values.commonvalues.ip;
const tokken = strings.values.commonvalues.tokken;

const lightblue = color.values.Colors.lightblue;
const colorprimary = color.values.Colors.colorPrimary;
const white = color.values.Colors.white;
const dark = color.values.Colors.colorPrimaryDark;
const loading = color.values.Colors.loading;
const greylight = color.values.Colors.greylight;
const skyblue = color.values.Colors.skyblue;
const darkblue = color.values.Colors.darkblue;
const green = color.values.Colors.darkgreen;
const orange = color.values.Colors.orange;
const red = color.values.Colors.red;
const gray = color.values.Colors.gray;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: "LoginActivity" })],
});

export default class ERPToDoList extends React.Component {
  static navigationOptions = ({ navigation }) => ({
    title: "ERP ToDo List",
    color: white,
    headerStyle: {
      backgroundColor: colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily: "Bold",
    },
    headerRight: (
      <TouchableOpacity
        style={{ paddingRight: 10 }}
        onPress={() => navigation.state.params.handlelogin()}
      >
        <Image
          style={{ alignSelf: "center", justifyContent: "center" }}
          source={require("./src/logout.png")}
        />
      </TouchableOpacity>
    ),
  });
  constructor(props) {
    super(props);
    this.state = {
      UserID: "",
      Department: "",
      handlelogin: "",
      pickerstatus: "",
      pickerresponse: "",
      txt_title: "",
      txt_c: "0",
      txt_p: "0",
      txt_o: "0",
      isLoading: false,
      dataSource: [],
      listData: [],
      value: "",
      valueres: "",
      filter: "",
      txt_title: "",
    };
    this.arrayholder = [];
  }

  goerpdetail(index) {
    let id = index;

    const { sNo, sID, sDate, sName, sDesc, sPriority, sStatus, sWorkto, sMod } =
      this.state.listData[id];

    this.props.navigation.navigate("ERPToDoDetailActivity", {
      UserID: this.state.UserID,
      Name: this.state.Name,
      sno: sNo,
      sid: sID,
      sdate: sDate,
      sname: sName,
      sdesc: sDesc,
      spriority: sPriority,
      sstatus: sStatus,
      sworkto: sWorkto,
      smod: sMod,
    });
  }

  login = async () => {
    Alert.alert(
      "Logout",
      "Would you like to logout?",
      [
        {
          text: "Cancel",
          onPress: () => console.log("Cancel Pressed"),
          style: "cancel",
        },
        {
          text: "OK",
          onPress: () => {
            logouttask();
            this.props.navigation.dispatch(resetAction);
          },
        },
      ],
      { cancelable: false }
    );
  };

  getResList(value) {
    if (value != null) {
      let url = "/getERPToDoListAllRes";

      const config = {
        headers: {
          currentToken: tokken,
        },
        params: {
          userid: this.state.UserID,
          Status: this.state.pickerstatus,
          resid: value,
        },
      };
      this.setState({
        isLoading: true,
        txt_title: "",
        txt_c: "0",
        txt_p: "0",
        txt_o: "0",
      });

      axios
        .get(ip + url, config)
        .then((response) =>
          this.setState({ dataSource: response.data }, () => {
            if (this.state.dataSource.length != 0) {
              if (response.status == 200) {
                const { head, detail } = this.state.dataSource[0];

                const { S1, S2, S3, S4 } = head;

                let Name = "";

                console.log(value);

                switch (value) {
                  case "2927":
                    Name = "Mohammad Zarrar";
                    break;
                  case "1000":
                    Name = "Swaminathan";
                    break;
                  case "1001":
                    Name = "Susindharan";
                    break;
                  case "1002":
                    Name = "Santhosh";
                    break;
                  default:
                    break;
                }
                let s_1 = "",
                  s_2 = "",
                  s_3 = "";

                s_1 = S1 == undefined ? "0" : S1;
                s_2 = S2 == undefined ? "0" : S2;
                s_3 = S3 == undefined ? "0" : S3;

                this.setState(
                  {
                    listData: detail,
                    pickerresponse: value,
                    txt_title: "Overall ( " + Name + " )",
                    txt_c: s_1,
                    txt_p: s_2,
                    txt_o: s_3,
                  },
                  () => {
                    setTimeout(() => {
                      this.setState({
                        isLoading: false,
                      });
                    }, 2000);
                  }
                );
              }
            } else {
              this.setState({
                isLoading: false,
              });
            }
          })
        )
        .catch((err) => {
          this.setState(
            {
              isLoading: false,
            },
            () => {
              let error = err;

              this.refs.toast.showBottom(error.toString());

              setTimeout(() => {
                this.props.navigation.goBack();
              }, 2000);
            }
          );
        });
    }
  }

  getErpList(value) {
    if (value != null) {
      let url = "/getERPToDoListAllV1";

      const config = {
        headers: {
          currentToken: tokken,
        },
        params: {
          userid: this.state.UserID,
          Status: value,
        },
      };
      this.setState({
        isLoading: true,
        pickerresponse: "",
        txt_title: "",
        txt_c: "0",
        txt_p: "0",
        txt_o: "0",
      });

      axios
        .get(ip + url, config)
        .then((response) =>
          this.setState({ dataSource: response.data }, () => {
            if (this.state.dataSource.length != 0) {
              if (response.status == 200) {
                const { head, detail } = this.state.dataSource[0];

                const { S1, S2, S3, S4 } = head;

                let s_1 = "",
                  s_2 = "",
                  s_3 = "";

                s_1 = S1 == undefined ? "0" : S1;
                s_2 = S2 == undefined ? "0" : S2;
                s_3 = S3 == undefined ? "0" : S3;

                this.setState(
                  {
                    listData: detail,
                    pickerstatus: value,
                    txt_title: "Overall",
                    txt_c: s_1,
                    txt_p: s_2,
                    txt_o: s_3,
                  },
                  () => {
                    setTimeout(() => {
                      this.setState({
                        isLoading: false,
                      });
                    }, 2000);
                  }
                );
              }
            } else {
              console.log("here");
              this.setState({
                isLoading: false,
              });
            }
          })
        )
        .catch((err) => {
          this.setState(
            {
              isLoading: false,
            },
            () => {
              let error = err;

              this.refs.toast.showBottom(error.toString());

              setTimeout(() => {
                this.props.navigation.goBack();
              }, 2000);
            }
          );
        });
    }
  }

  /* filtersearch(text){
    const newData = this.arrayholder.filter(function(item){
    const itemData =item.sID.toString()+item.sDesc.toString().toUpperCase()
    const textData = text.toUpperCase()
    return itemData.indexOf(textData) > -1
}
)
this.setState({
    dataSource: newData.sort(),
    text: text
})
} */

  componentDidMount() {
    console.disableYellowBox = true;

    this.props.navigation.setParams({
      handlelogin: this.login.bind(this),
    });

    this.setState({ value: moment().format() });

    this.setState(
      {
        UserID: this.props.navigation.getParam("UserID", ""),
        Name: this.props.navigation.getParam("Name", ""),
        Department: this.props.navigation.getParam("Dept", ""),
        pickerstatus: "P",
      },
      () => {
        this.getErpList("P");
      }
    );
  }

  render() {
    if (this.state.isLoading) {
      return (
        <Modal
          transparent={false}
          supportedOrientations={["portrait", "landscape"]}
          visible={this.state.isLoading}
        >
          <View
            style={{ flex: 1, alignItems: "center", justifyContent: "center" }}
          >
            <Image
              animationType={"slide"}
              useNativeDriver={true}
              style={{ width: 300, height: 200 }}
              source={require("./src/gears.gif")}
            />
          </View>
        </Modal>
      );
    }
    return (
      <View style={{ flex: 1, backgroundColor: lightblue }}>
        <ScrollView style={{ height: "26%" }}>
          <Card
            style={{
              borderRadius: 4,
              width: "97%",
              alignSelf: "center",
              borderBottomColor: colorprimary,
            }}
          >
            <CardItem
              style={{
                alignItems: "flex-start",
                width: "100%",
                flexWrap: "wrap",
                paddingLeft: 1,
                paddingRight: 1,
                paddingTop: 0,
                paddingBottom: 0,
              }}
            >
              <Grid>
                <Row>
                  <Col
                    style={{
                      alignItems: "flex-start",
                      width: "43%",
                      alignSelf: "center",
                    }}
                  >
                    <Text
                      style={{
                        fontSize: 16,
                        fontFamily: "Bold",
                        color: dark,
                        paddingLeft: "4%",
                      }}
                    >
                      Status
                    </Text>
                  </Col>

                  <Col
                    style={{
                      alignItems: "flex-start",
                      width: "57%",
                      alignSelf: "center",
                    }}
                  >
                    <Text
                      style={{
                        fontSize: 16,
                        fontFamily: "Bold",
                        color: dark,
                        paddingLeft: "4%",
                      }}
                    >
                      Responsible
                    </Text>
                  </Col>
                </Row>
                <Row>
                  <Col
                    style={{
                      alignItems: "flex-start",
                      width: "43%",
                      alignSelf: "center",
                    }}
                  >
                    <Form style={{ flex: 1, alignItems: "flex-start" }}>
                      <Item style={{ marginLeft: 0, height: 45 }} picker>
                        <SelectDropdown
                          data={[
                            { title: "Open", value: "O" },
                            { title: "InProgress", value: "P" },
                            { title: "Closed", value: "C" },
                            { title: "Cancelled", value: "X" },
                          ]}
                          onSelect={(selectedItem, index) => {
                            console.log("Selected Item:", selectedItem.value);
                            this.setState(
                              { pickerstatus: selectedItem.value },
                              () => {
                                this.getErpList(selectedItem.value);
                              }
                            );
                          }}
                          renderButton={(isOpened) => {
                            const data = [
                              { title: "Open", value: "O" },
                              { title: "InProgress", value: "P" },
                              { title: "Closed", value: "C" },
                              { title: "Cancelled", value: "X" },
                            ];

                            const buttonText = this.state.pickerstatus
                              ? data.find(
                                  (item) =>
                                    item.value === this.state.pickerstatus
                                )?.title
                              : "Select Status";

                            return (
                              <View style={styles.dropdownButtonStyle}>
                                <Text
                                  style={{
                                    flex: 1,
                                    fontSize: 16,
                                    color: "black",
                                  }}
                                >
                                  {buttonText}
                                </Text>
                                <Icon
                                  name={
                                    isOpened ? "chevron-up" : "chevron-down"
                                  }
                                  style={{
                                    fontSize: 20,
                                    color: colorprimary,
                                  }}
                                />
                              </View>
                            );
                          }}
                          renderItem={(item, index, isSelected) => {
                            return (
                              <View
                                style={{
                                  ...styles.dropdownItemStyle,
                                  ...(isSelected && {
                                    backgroundColor: "#D2D9DF",
                                  }),
                                }}
                              >
                                <Text
                                  style={{
                                    fontSize: 16,
                                    color: "black",
                                  }}
                                >
                                  {item.title}
                                </Text>
                              </View>
                            );
                          }}
                          showsVerticalScrollIndicator={false}
                          dropdownStyle={{
                            borderRadius: 8,
                            borderWidth: 1,
                            borderColor: "#ccc",
                            backgroundColor: "#fff",
                          }}
                        />
                      </Item>
                    </Form>
                  </Col>

                  <Col style={{ alignItems: "flex-start", width: "57%" }}>
                    <Form style={{ flex: 1, alignItems: "flex-start" }}>
                      <Item style={{ marginLeft: 0, height: 45 }} picker>
                        <SelectDropdown
                          data={[
                            { title: "Mohammad Zarrar", value: "2927" },
                            { title: "Swaminathan", value: "1000" },
                            { title: "Susindharan", value: "1001" },
                            { title: "Santhosh", value: "1002" },
                          ]}
                          onSelect={(selectedItem, index) => {
                            console.log("Selected Item:", selectedItem.value);
                            this.setState(
                              { pickerresponse: selectedItem.value },
                              () => {
                                this.getResList(selectedItem.value);
                              }
                            );
                          }}
                          renderButton={(isOpened) => {
                            const data = [
                              { title: "Mohammad Zarrar", value: "2927" },
                              { title: "Swaminathan", value: "1000" },
                              { title: "Susindharan", value: "1001" },
                              { title: "Santhosh", value: "1002" },
                            ];

                            const buttonText = this.state.pickerresponse
                              ? data.find(
                                  (item) =>
                                    item.value === this.state.pickerresponse
                                )?.title
                              : "Select Responsible";

                            return (
                              <View style={styles.dropdownButtonStyle}>
                                <Text
                                  style={{
                                    flex: 1,
                                    fontSize: 16,
                                    color: "black",
                                  }}
                                >
                                  {buttonText}
                                </Text>
                                <Icon
                                  name={
                                    isOpened ? "chevron-up" : "chevron-down"
                                  }
                                  style={{
                                    fontSize: 20,
                                    color: colorprimary,
                                  }}
                                />
                              </View>
                            );
                          }}
                          renderItem={(item, index, isSelected) => {
                            return (
                              <View
                                style={{
                                  ...styles.dropdownItemStyle,
                                  ...(isSelected && {
                                    backgroundColor: "#D2D9DF",
                                  }),
                                }}
                              >
                                <Text
                                  style={{
                                    fontSize: 16,
                                    color: "black",
                                  }}
                                >
                                  {item.title}
                                </Text>
                              </View>
                            );
                          }}
                          showsVerticalScrollIndicator={false}
                          dropdownStyle={{
                            borderRadius: 8,
                            borderWidth: 1,
                            borderColor: "#ccc",
                            backgroundColor: "#fff",
                          }}
                        />
                      </Item>
                    </Form>
                  </Col>
                </Row>
              </Grid>
            </CardItem>
          </Card>

          {/* <SearchBar
                 inputContainerStyle={{height:25}}
                 inputStyle={{fontSize:14}}
                 containerStyle={{width:'97%',alignSelf:'center',height:50}}
                 placeholder="Search by Description"
                 onChangeText={(text) => this.filtersearch(text)}
                 value={this.state.text}
                 platform={'ios'}>
                </SearchBar>*/}

          <Card
            style={{
              width: "97%",
              alignSelf: "center",
              borderColor: colorprimary,
              borderWidth: 4,
            }}
          >
            <CardItem
              style={{
                alignItems: "flex-start",
                width: "100%",
                flexWrap: "wrap",
                paddingLeft: 1,
                paddingRight: 1,
                paddingTop: 0,
                paddingBottom: 0,
              }}
            >
              <Grid style={{ padding: 4, width: "100%", alignSelf: "center" }}>
                <Row
                  style={{
                    backgroundColor: colorprimary,
                    borderRadius: 2,
                    padding: 5,
                  }}
                >
                  <Col style={{ alignItems: "flex-start", width: "100%" }}>
                    <Text style={styles.textContent}>
                      {this.state.txt_title}{" "}
                    </Text>
                  </Col>
                </Row>

                <Row style={{ paddingTop: 3 }}>
                  <Col style={{ alignItems: "flex-start", width: "33%" }}>
                    <Row>
                      <Col style={{ alignItems: "center", width: "100%" }}>
                        <Text
                          style={{
                            fontFamily: "Bold",
                            fontSize: 13,
                            color: green,
                          }}
                        >
                          {this.state.txt_c}{" "}
                        </Text>
                      </Col>
                    </Row>

                    <Row style={{ paddingTop: 3 }}>
                      <Col style={{ alignItems: "center", width: "100%" }}>
                        <Text style={styles.textHeadContent}>Completed</Text>
                      </Col>
                    </Row>
                  </Col>

                  <Col style={{ alignItems: "flex-start", width: "34%" }}>
                    <Row>
                      <Col style={{ alignItems: "center", width: "100%" }}>
                        <Text
                          style={{
                            fontFamily: "Bold",
                            fontSize: 13,
                            color: orange,
                          }}
                        >
                          {this.state.txt_p}{" "}
                        </Text>
                      </Col>
                    </Row>
                    <Row style={{ paddingTop: 3 }}>
                      <Col style={{ alignItems: "center", width: "100%" }}>
                        <Text style={styles.textHeadContent}>In Progress</Text>
                      </Col>
                    </Row>
                  </Col>

                  <Col style={{ alignItems: "flex-start", width: "33%" }}>
                    <Row>
                      <Col style={{ alignItems: "center", width: "100%" }}>
                        <Text
                          style={{
                            fontFamily: "Bold",
                            fontSize: 13,
                            color: red,
                          }}
                        >
                          {this.state.txt_o}{" "}
                        </Text>
                      </Col>
                    </Row>
                    <Row style={{ paddingTop: 3 }}>
                      <Col style={{ alignItems: "center", width: "100%" }}>
                        <Text style={styles.textHeadContent}>Opened</Text>
                      </Col>
                    </Row>
                  </Col>
                </Row>
              </Grid>
            </CardItem>
          </Card>
          <Grid
            style={{
              backgroundColor: colorprimary,
              padding: 4,
              width: "97%",
              alignSelf: "center",
              borderRadius: 4,
            }}
          >
            <Row>
              <Col style={{ alignItems: "flex-start", width: "10%" }}>
                <Text style={styles.textContent}>SNo.</Text>
              </Col>
              <Col style={{ alignItems: "flex-start", width: "60%" }}>
                <Text style={styles.textContent}>Request By</Text>
              </Col>
              <Col style={{ alignItems: "flex-end", width: "30%" }}>
                <Text style={styles.textContent}>Date</Text>
              </Col>
            </Row>
          </Grid>
        </ScrollView>
        <ScrollView style={{ height: "74%" }}>
          <FlatList
            data={this.state.listData}
            initialNumToRender={this.state.listData.length}
            renderItem={({ item, index }) => (
              <Card style={{ width: "97%", alignSelf: "center" }}>
                <CardItem
                  style={{
                    alignItems: "flex-start",
                    width: "100%",
                    flexWrap: "wrap",
                    paddingLeft: 5,
                    paddingRight: 5,
                    paddingTop: 10,
                    paddingBottom: 10,
                  }}
                >
                  <Grid onPress={() => this.goerpdetail(index)}>
                    <Row>
                      <Col style={{ alignItems: "flex-start", width: "10%" }}>
                        <Text style={{ fontSize: 13, fontFamily: "Regular" }}>
                          {item.sNo}
                        </Text>
                      </Col>
                      <Col style={{ alignItems: "flex-start", width: "60%" }}>
                        <Text style={{ fontSize: 13, fontFamily: "Regular" }}>
                          {item.sName}
                        </Text>
                      </Col>
                      <Col style={{ alignItems: "flex-end", width: "30%" }}>
                        <Text style={{ fontSize: 13, fontFamily: "Regular" }}>
                          {item.sDate}
                        </Text>
                      </Col>
                    </Row>
                    <View
                      style={{
                        borderBottomColor: "#A9A9A9",
                        borderBottomWidth: 1,
                        height: 5,
                        width: "100%",
                        alignSelf: "center",
                      }}
                    />
                    <Row>
                      <Col>
                        <Text
                          style={{
                            fontSize: 12,
                            fontFamily: "Regular",
                            width: "100%",
                          }}
                        >
                          {item.sDesc}
                        </Text>
                      </Col>
                    </Row>
                  </Grid>
                </CardItem>
              </Card>
            )}
            keyExtractor={(item, index) => index.toString()}
          />
        </ScrollView>
        <Toast ref="toast" />
      </View>
    );
  }
}
const styles = StyleSheet.create({
  textContent: {
    color: white,
    fontSize: 12,
    fontFamily: "Bold",
  },
  textHeadContent: {
    color: gray,
    fontSize: 13,
    fontFamily: "Regular",
  },
  tittle: {
    color: colorprimary,
    fontSize: 13,
  },
  values: {
    color: greylight,
    fontSize: 12,
  },
  imagebutton: {
    width: 30,
    height: 30,
  },
  input: {
    maxHeight: 100,
    borderColor: skyblue,
    borderWidth: 1,
    padding: 10,
    width: 320,
    marginBottom: 10,
  },
  dropdownButtonStyle: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 10,
    paddingVertical: 12,
    backgroundColor: "#fff",
  },
  dropdownItemStyle: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 10,
    paddingHorizontal: 15,
  },
});

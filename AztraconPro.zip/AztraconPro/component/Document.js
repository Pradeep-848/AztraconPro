import React,{ Component }  from 'react';
import {ScrollView,Modal,StyleSheet,Text,View,Image,FlatList,TouchableOpacity,
  Alert,Linking} from 'react-native';
import { Col, Grid, Row } from 'react-native-easy-grid';
import { NavigationActions, StackActions } from 'react-navigation';
import axios from 'axios';
import Toast from 'react-native-whc-toast'
import {Card,CardItem} from 'native-base';
import {logouttask} from './class/logout';
import strings from './res/strings'
import color from './res/colors'

const fileip=strings.values.commonvalues.fileip;
const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const lightblue=color.values.Colors.lightblue;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

 export default class Document extends React.Component {
  static navigationOptions = ({ navigation }) => ({ 
    title: "Document List",
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,   
      handlelogin:'',
      dataSource:'',
      UserID:'',DocType:'',Param1:'',Param2:''
    };
}
login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
        this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}
moveDoc= async (index) =>{

  const id=index

  const {SlNo,DocumentName,AttachFileName,FilePath}=this.state.dataSource[id]

 let url=''
  
 url=fileip+"/DocumentDownloadIOS?FPath="+FilePath+"&FileName="+AttachFileName 

 const supported = await Linking.canOpenURL(url);

 if (supported) {
  await Linking.openURL(url);
} else {
  Alert.alert(`Don't know how to open this URL: ${url}`);
} 

}

getDocumentList=()=>{
  const config = {
    headers: {   
    'currentToken': tokken,
  },
    params: {
        doctype:this.state.DocType,
        param1:this.state.Param1,
        param2:this.state.Param2,
    }
    
  };

  this.setState({isLoading:true})
  axios.get(ip+'/getDocumentListIOS', config)
  .then(response => this.setState({ dataSource:response.data},() => {if(response.status==200){this.setState({isLoading:false})}}))
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
}

componentDidMount(){

  console.disableYellowBox = true;

  this.props.navigation.setParams({
    handlelogin: this.login.bind(this)
    });
    
 this.setState({
    UserID:this.props.navigation.getParam('UserID', ''),
    DocType:this.props.navigation.getParam('DocType', ''),
    Param1:this.props.navigation.getParam('Param1', ''),
    Param2:this.props.navigation.getParam('Param2', ''),
},()=>{this.getDocumentList();})

}
  render() {
    if (this.state.isLoading) {
      return (
        <Modal
        transparent={false}
        supportedOrientations={['portrait', 'landscape']}
        visible={this.state.isLoading}
        >
         <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
           useNativeDriver={true}
          style={{width: 300, height: 200}}
          source={require('./src/gears.gif')}  />
          </View>     
        </Modal>
      )
  }
    return (
  <View style={{flex:1,backgroundColor:lightblue}}>

    <ScrollView style={{height:'6%'}}>

    <View  style={{ flex: 1,paddingTop:5,paddingBottom:5}}>
    <Grid style={{backgroundColor:'#2452b2',borderRadius:4,padding:5,width:'97%',alignSelf:'center'}}>
              <Row>
              <Col style={{alignItems:'center',width:'13%'}}>
              <Text style={{color:'#fff',fontSize:13,fontFamily:'Bold'}}>SNo</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'87%'}}>
              <Text style={{color:'#fff',fontSize:13,fontFamily:'Bold'}}>Document Name</Text>
              </Col> 
              </Row>
            </Grid>  
    </View>

    </ScrollView>


    <ScrollView style={{height:'94%'}}>

    <FlatList
       data={ this.state.dataSource}
       initialNumToRender={this.state.dataSource.length}
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
                  paddingLeft:5,paddingRight:5,paddingTop:8,paddingBottom:8}}>
            <Grid  onPress={() => this.moveDoc(index)}>
              <Row>
              <Col style={{alignItems:'flex-start',width:'13%'}}>
              <Text style={{fontSize:12,alignSelf:'center',fontFamily:'Regular'}}>{item.SlNo}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'87%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-start',fontFamily:'Regular'}}>{item.DocumentName}</Text>
              </Col> 
             </Row>
            </Grid>  
             </CardItem>
           </Card>
        }

       keyExtractor={(item, index) => index.toString()}
       
      />

    </ScrollView>
  

<Toast ref="toast"
        />
        
          </View>
        )
      }
 };
 const styles = StyleSheet.create({
  titleText: {
    flex:1,
    flexWrap:'wrap',
    color:white,
    fontSize:12,
    padding:5,
    fontFamily:'Bold'
  },
  });
  
  
  

















 

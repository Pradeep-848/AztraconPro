import React, { Component } from "react";
import {
  ScrollView,
  StyleSheet,
  Text,
  View,
  Modal,
  Image,
  FlatList,
  TouchableOpacity,
  Alert,
  Dimensions,
} from "react-native";
import { Col, Grid, Row } from "react-native-easy-grid";
import { SearchBar } from "react-native-elements";
import { NavigationActions, StackActions } from "react-navigation";
import axios from "axios";
import Toast from "react-native-whc-toast";
import { Card, CardItem, Item, Form, Icon } from "native-base";
import moment from "moment";
import { RFValue } from "react-native-responsive-fontsize";

//own lib
import color from "./res/colors";
import { logouttask } from "./class/logout";
import strings from "./res/strings";
import { isPortrait } from "./class/useOrientation";
import SelectDropdown from "react-native-select-dropdown";

//constant
const ip = strings.values.commonvalues.ip;
const tokken = strings.values.commonvalues.tokken;

const lightblue = color.values.Colors.lightblue;
const colorprimary = color.values.Colors.colorPrimary;
const white = color.values.Colors.white;
const dark = color.values.Colors.colorPrimaryDark;
const loading = color.values.Colors.loading;
const greylight = color.values.Colors.greylight;
const skyblue = color.values.Colors.skyblue;

const screenWidth = Math.round(Dimensions.get("window").width);
const screenHeight = Math.round(Dimensions.get("window").height);

//common style
const style_common = require("./class/style");

//logout
const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: "LoginActivity" })],
});

export default class ProjectMaster extends React.Component {
  static navigationOptions = ({ navigation }) => ({
    title: "Project List",
    color: white,
    headerStyle: {
      backgroundColor: colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily: "Bold",
      fontSize: RFValue(18),
    },
    headerRight: (
      <TouchableOpacity
        style={{ paddingRight: 10 }}
        onPress={() => navigation.state.params.handlelogin()}
      >
        <Image
          style={{ alignSelf: "center", justifyContent: "center" }}
          source={require("./src/logout.png")}
        />
      </TouchableOpacity>
    ),
  });
  constructor(props) {
    super(props);
    this.state = {
      USER: "",
      DEPT: "",
      handlelogin: "",
      pickerstatus: "",
      isLoading: false,
      dataSource: [],
      value: "",
      filter: "",
      orientation: "",
      DeviceType: "",
    };
    this.arrayholder = [];
  }

  goprojectmasterdetail(index) {
    let id = index;
    const { sID, sDesc, sCid, sName } = this.state.dataSource[id];

    this.props.navigation.navigate("ProjectMasterDetailsActivity", {
      USER: this.state.USER,
      PID: sID,
      PDesc: sDesc,
      CusID: sCid,
      CusName: sName,
      DeviceType: this.state.DeviceType,
    });
  }

  login = async () => {
    Alert.alert(
      "Logout",
      "Would you like to logout?",
      [
        {
          text: "Cancel",
          onPress: () => console.log("Cancel Pressed"),
          style: "cancel",
        },
        {
          text: "OK",
          onPress: () => {
            logouttask();
            this.props.navigation.dispatch(resetAction);
          },
        },
      ],
      { cancelable: false }
    );
  };

  getproject(value) {
    if (value != null) {
      let url = "";

      if (
        this.state.DEPT === "MGT" ||
        this.state.DEPT === "FIN" ||
        this.state.DEPT === "ICT"
      ) {
        url = "/getProjectlistV1";
      } else {
        url = "/getProjectlistOwnV1";
      }

      const config = {
        headers: {
          currentToken: tokken,
        },
        params: {
          userid: this.state.USER,
          Status: value,
        },
      };
      this.setState({ isLoading: true });

      axios
        .get(ip + url, config)
        .then((response) =>
          this.setState({ dataSource: response.data }, () => {
            if (response.status == 200) {
              this.arrayholder = this.state.dataSource;
              this.setState({ pickerstatus: value }, () => {
                setTimeout(() => {
                  this.setState({
                    isLoading: false,
                  });
                }, 2000);
              });
            }
          })
        )
        .catch((err) => {
          this.setState(
            {
              isLoading: false,
            },
            () => {
              let error = err;

              this.refs.toast.showBottom(error.toString());

              setTimeout(() => {
                this.props.navigation.goBack();
              }, 2000);
            }
          );
        });
    }
  }

  filtersearch(text) {
    const newData = this.arrayholder.filter(function (item) {
      const itemData = item.sID.toString() + item.sCid.toString().toUpperCase();
      const textData = text.toUpperCase();
      return itemData.indexOf(textData) > -1;
    });
    this.setState({
      dataSource: newData.sort(),
      text: text,
    });
  }

  componentDidMount() {
    console.disableYellowBox = true;

    Dimensions.addEventListener("change", () => {
      this.setState({
        orientation: isPortrait() ? "portrait" : "landscape",
      });
    });

    this.props.navigation.setParams({
      handlelogin: this.login.bind(this),
    });

    this.setState({ value: moment().format() });
    this.setState(
      {
        USER: this.props.navigation.getParam("UserID", ""),
        DEPT: this.props.navigation.getParam("Department", ""),
        orientation: isPortrait() ? "portrait" : "landscape",
        DeviceType: this.props.navigation.getParam("DeviceType", ""),
        pickerstatus: "Ongoing",
      },
      () => {
        this.getproject("Ongoing");
      }
    );
  }

  getheight(which) {
    let orient = "";
    let device = "";

    orient = this.state.orientation;
    device = this.state.DeviceType;

    if (which == "1") {
      //header
      if (device == "phone") {
        if (orient == "portrait") {
          return "25%";
        } else {
          //landscape
          return "35%";
        }
      } else {
        //tab
        if (orient == "portrait") {
          return "18%";
        } else {
          //landscape
          return "17%";
        }
      }
    }

    if (which == "2") {
      //body
      if (device == "phone") {
        if (orient == "portrait") {
          return "75%";
        } else {
          //landscape
          return "65%";
        }
      } else {
        //tab
        if (orient == "portrait") {
          return "82%";
        } else {
          //landscape
          return "83%";
        }
      }
    }
  }

  render() {
    if (this.state.isLoading) {
      return (
        <Modal
          transparent={false}
          supportedOrientations={["portrait", "landscape"]}
          visible={this.state.isLoading}
        >
          <View
            style={{ flex: 1, alignItems: "center", justifyContent: "center" }}
          >
            <Image
              useNativeDriver={true}
              style={style_common.load_gif}
              source={require("./src/gears.gif")}
            />
          </View>
        </Modal>
      );
    }
    return (
      <View style={{ flex: 1, backgroundColor: lightblue }}>
        <ScrollView
          style={{
            height: this.getheight("1"),
            display: this.state.orientation == "portrait" ? "flex" : "none",
          }}
        >
          <Text
            style={{
              fontSize: RFValue(16),
              fontFamily: "Bold",
              color: dark,
              paddingLeft: "2%",
            }}
          >
            Status
          </Text>

          <Card
            style={{
              borderRadius: RFValue(4),
              width: "97%",
              alignSelf: "center",
              borderBottomColor: colorprimary,
            }}
          >
            <CardItem style={style_common.card_item_padding}>
              <Grid>
                <Row>
                  <Form
                    style={{
                      flex: 1,
                      alignItems: "flex-start",
                      fontFamily: "Regular",
                    }}
                  >
                    <Item style={{ marginLeft: 0, height: 45 }} picker>
                      <SelectDropdown
                        data={[
                          { title: "Cancelled", value: "Cancelled" },
                          { title: "Completed", value: "Completed" },
                          { title: "Delivered", value: "Delivered" },
                          { title: "On Hold", value: "On Hold" },
                          { title: "Ongoing", value: "Ongoing" },
                        ]}
                        onSelect={(selectedItem, index) => {
                          console.log("Selected Item:", selectedItem.value);
                          this.setState(
                            { pickerstatus: selectedItem.value },
                            () => {
                              this.getproject(selectedItem.value);
                            }
                          );
                        }}
                        renderButton={(isOpened) => {
                          const data = [
                            { title: "Cancelled", value: "Cancelled" },
                            { title: "Completed", value: "Completed" },
                            { title: "Delivered", value: "Delivered" },
                            { title: "On Hold", value: "On Hold" },
                            { title: "Ongoing", value: "Ongoing" },
                          ];

                          const buttonText = this.state.pickerstatus
                            ? data.find(
                                (item) => item.value === this.state.pickerstatus
                              )?.title
                            : "Select Project Status";

                          return (
                            <View style={styles.dropdownButtonStyle}>
                              <Text
                                style={{
                                  flex: 1,
                                  fontSize: 16,
                                  color: "black",
                                }}
                              >
                                {buttonText}
                              </Text>
                              <Icon
                                name={isOpened ? "chevron-up" : "chevron-down"}
                                style={{
                                  fontSize: 20,
                                  color: colorprimary,
                                }}
                              />
                            </View>
                          );
                        }}
                        renderItem={(item, index, isSelected) => {
                          return (
                            <View
                              style={{
                                ...styles.dropdownItemStyle,
                                ...(isSelected && {
                                  backgroundColor: "#D2D9DF",
                                }),
                              }}
                            >
                              <Text
                                style={{
                                  fontSize: 16,
                                  color: "black",
                                }}
                              >
                                {item.title}
                              </Text>
                            </View>
                          );
                        }}
                        showsVerticalScrollIndicator={false}
                        dropdownStyle={{
                          borderRadius: 8,
                          borderWidth: 1,
                          borderColor: "#ccc",
                          backgroundColor: "#fff",
                        }}
                      />
                    </Item>
                  </Form>
                </Row>
              </Grid>
            </CardItem>
          </Card>

          <SearchBar
            inputContainerStyle={{ height: 25 }}
            inputStyle={{ fontSize: RFValue(14) }}
            containerStyle={{ width: "97%", alignSelf: "center", height: 50 }}
            placeholder="Search Project Master"
            onChangeText={(text) => this.filtersearch(text)}
            searchIcon={{ name: "search", size: 19, color: colorprimary }}
            clearIcon={{ name: "close-circle", size: 19 }}
            loadingProps={{ size: "small" }}
            value={this.state.text}
            platform={"ios"}
          ></SearchBar>

          <Grid
            style={{
              backgroundColor: colorprimary,
              padding: RFValue(7),
              width: "97%",
              alignSelf: "center",
              borderRadius: 4,
            }}
          >
            <Row>
              <Col style={{ alignItems: "flex-start", width: "30%" }}>
                <Text style={styles.textContent}>Project ID</Text>
              </Col>
              <Col style={{ alignItems: "flex-start", width: "35%" }}>
                <Text style={styles.textContent}>Customer Code</Text>
              </Col>
              <Col style={{ alignItems: "flex-end", width: "35%" }}>
                <Text style={styles.textContent}>Location</Text>
              </Col>
            </Row>
          </Grid>
        </ScrollView>
        {/* landscape */}
        <ScrollView
          style={{
            height: this.getheight("1"),
            display: this.state.orientation != "portrait" ? "flex" : "none",
          }}
        >
          <Grid>
            <Row>
              <Col
                style={{
                  width: "100%",
                  alignItems: "center",
                  alignSelf: "center",
                }}
              >
                <Row>
                  <Col
                    style={{
                      width: "10%",
                      alignItems: "center",
                      alignSelf: "center",
                    }}
                  >
                    <Text
                      style={{
                        fontSize: RFValue(16),
                        fontFamily: "Bold",
                        color: dark,
                        paddingLeft: "2%",
                      }}
                    >
                      Status
                    </Text>
                  </Col>
                  <Col
                    style={{
                      width: "40%",
                      alignItems: "center",
                      alignSelf: "center",
                    }}
                  >
                    <Card
                      style={{
                        borderRadius: RFValue(4),
                        width: "97%",
                        alignSelf: "center",
                        borderBottomColor: colorprimary,
                      }}
                    >
                      <CardItem style={style_common.card_item_padding}>
                        <Grid>
                          <Row>
                            <Form
                              style={{
                                flex: 1,
                                alignItems: "flex-start",
                                fontFamily: "Regular",
                              }}
                            >
                              <Item
                                style={{ marginLeft: 0, height: 45 }}
                                picker
                              >
                                <SelectDropdown
                                  data={[
                                    { title: "Cancelled", value: "Cancelled" },
                                    { title: "Completed", value: "Completed" },
                                    { title: "Delivered", value: "Delivered" },
                                    { title: "On Hold", value: "On Hold" },
                                    { title: "Ongoing", value: "Ongoing" },
                                  ]}
                                  onSelect={(selectedItem, index) => {
                                    console.log(
                                      "Selected Item:",
                                      selectedItem.value
                                    );
                                    this.setState(
                                      { pickerstatus: selectedItem.value },
                                      () => {
                                        this.getproject(selectedItem.value);
                                      }
                                    );
                                  }}
                                  renderButton={(isOpened) => {
                                    const data = [
                                      {
                                        title: "Cancelled",
                                        value: "Cancelled",
                                      },
                                      {
                                        title: "Completed",
                                        value: "Completed",
                                      },
                                      {
                                        title: "Delivered",
                                        value: "Delivered",
                                      },
                                      { title: "On Hold", value: "On Hold" },
                                      { title: "Ongoing", value: "Ongoing" },
                                    ];

                                    const buttonText = this.state.pickerstatus
                                      ? data.find(
                                          (item) =>
                                            item.value ===
                                            this.state.pickerstatus
                                        )?.title
                                      : "Select Project Status";

                                    return (
                                      <View style={styles.dropdownButtonStyle}>
                                        <Text
                                          style={{
                                            flex: 1,
                                            fontSize: 16,
                                            color: "black",
                                          }}
                                        >
                                          {buttonText}
                                        </Text>
                                        <Icon
                                          name={
                                            isOpened
                                              ? "chevron-up"
                                              : "chevron-down"
                                          }
                                          style={{
                                            fontSize: 20,
                                            color: colorprimary,
                                          }}
                                        />
                                      </View>
                                    );
                                  }}
                                  renderItem={(item, index, isSelected) => {
                                    return (
                                      <View
                                        style={{
                                          ...styles.dropdownItemStyle,
                                          ...(isSelected && {
                                            backgroundColor: "#D2D9DF",
                                          }),
                                        }}
                                      >
                                        <Text
                                          style={{
                                            fontSize: 16,
                                            color: "black",
                                          }}
                                        >
                                          {item.title}
                                        </Text>
                                      </View>
                                    );
                                  }}
                                  showsVerticalScrollIndicator={false}
                                  dropdownStyle={{
                                    borderRadius: 8,
                                    borderWidth: 1,
                                    borderColor: "#ccc",
                                    backgroundColor: "#fff",
                                  }}
                                />
                              </Item>
                            </Form>
                          </Row>
                        </Grid>
                      </CardItem>
                    </Card>
                  </Col>
                  <Col
                    style={{
                      width: "50%",
                      alignItems: "center",
                      alignSelf: "center",
                    }}
                  >
                    <SearchBar
                      inputContainerStyle={{ height: 25 }}
                      inputStyle={{ fontSize: RFValue(14) }}
                      containerStyle={{
                        width: "97%",
                        alignSelf: "center",
                        height: 50,
                      }}
                      placeholder="Search Project Master"
                      onChangeText={(text) => this.filtersearch(text)}
                      value={this.state.text}
                      searchIcon={{
                        name: "search",
                        size: 19,
                        color: colorprimary,
                      }}
                      clearIcon={{ name: "close-circle", size: 19 }}
                      loadingProps={{ size: "small" }}
                      platform={"ios"}
                    ></SearchBar>
                  </Col>
                </Row>
                <Row></Row>
              </Col>
            </Row>
          </Grid>

          <Grid
            style={{
              backgroundColor: colorprimary,
              padding: RFValue(7),
              width: "97%",
              alignSelf: "center",
              borderRadius: 4,
            }}
          >
            <Row>
              <Col style={{ alignItems: "flex-start", width: "30%" }}>
                <Text style={styles.textContent}>Project ID</Text>
              </Col>
              <Col style={{ alignItems: "flex-start", width: "35%" }}>
                <Text style={styles.textContent}>Customer Code</Text>
              </Col>
              <Col style={{ alignItems: "flex-end", width: "35%" }}>
                <Text style={styles.textContent}>Location</Text>
              </Col>
            </Row>
          </Grid>
        </ScrollView>

        <ScrollView style={{ height: this.getheight("2") }}>
          <FlatList
            data={this.state.dataSource}
            initialNumToRender={this.state.dataSource.length}
            renderItem={({ item, index }) => (
              <Card style={{ width: "97%", alignSelf: "center" }}>
                <CardItem style={style_common.card_item_padding}>
                  <Grid onPress={() => this.goprojectmasterdetail(index)}>
                    <Row>
                      <Col style={{ alignItems: "flex-start", width: "30%" }}>
                        <Text
                          style={{
                            fontSize: RFValue(13),
                            fontFamily: "Regular",
                          }}
                        >
                          {item.sID}
                        </Text>
                      </Col>
                      <Col style={{ alignItems: "flex-start", width: "35%" }}>
                        <Text
                          style={{
                            fontSize: RFValue(13),
                            fontFamily: "Regular",
                          }}
                        >
                          {item.sCid}
                        </Text>
                      </Col>
                      <Col style={{ alignItems: "flex-end", width: "35%" }}>
                        <Text
                          style={{
                            fontSize: RFValue(13),
                            fontFamily: "Regular",
                          }}
                        >
                          {item.sStatus}
                        </Text>
                      </Col>
                    </Row>
                    <View
                      style={{
                        borderBottomColor: "#A9A9A9",
                        borderBottomWidth: 1,
                        height: 5,
                        width: "100%",
                        alignSelf: "center",
                      }}
                    />
                    <Row>
                      <Col>
                        <Text
                          style={{
                            fontSize: RFValue(12),
                            width: "100%",
                            fontFamily: "Regular",
                          }}
                        >
                          {item.sDesc}
                        </Text>
                      </Col>
                    </Row>
                  </Grid>
                </CardItem>
              </Card>
            )}
            keyExtractor={(item, index) => index.toString()}
          />
        </ScrollView>
        <Toast ref="toast" />
      </View>
    );
  }
}
const styles = StyleSheet.create({
  textContent: {
    color: white,
    fontSize: RFValue(12),
    fontFamily: "Bold",
  },
  tittle: {
    color: colorprimary,
    fontSize: RFValue(13),
  },
  values: {
    color: greylight,
    fontSize: RFValue(12),
  },
  imagebutton: {
    width: 30,
    height: 30,
  },
  input: {
    maxHeight: 100,
    borderColor: skyblue,
    borderWidth: 1,
    padding: 10,
    width: 320,
    marginBottom: 10,
  },
  dropdownButtonStyle: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 10,
    paddingVertical: 12,
    backgroundColor: "#fff",
  },
  dropdownItemStyle: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 10,
    paddingHorizontal: 15,
  },
});

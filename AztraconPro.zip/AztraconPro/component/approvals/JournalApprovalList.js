import React,{ Component }  from 'react';
import {ScrollView,Modal,StyleSheet,Text,View,Image,FlatList,TouchableOpacity,Alert,Dimensions} from 'react-native';
import { Col, Grid, Row } from 'react-native-easy-grid';
import Toast from 'react-native-whc-toast'
import axios from 'axios';
import { NavigationActions, StackActions   } from 'react-navigation';
import {Card,CardItem} from 'native-base';
import { RFValue } from "react-native-responsive-fontsize";

//own library
import strings from '../res/strings'
import {logouttask} from '../class/logout';
import color from '../res/colors'
import {isPortrait} from '../class/useOrientation'

//constant
const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const lightblue=color.values.Colors.lightblue;
const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;

//common style
const style_common = require('../class/style');

//logout function
const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class JournalApprovalList extends React.Component {
  
  static navigationOptions = ({ navigation }) => ({ 
    
    title: "Journal List",
    color:"#fff",
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
      fontSize:RFValue(18)
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('../src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false, 
      Dept:'',
      handlelogin:'',
      dataSource:'',
      UserID:'',
      AppType:'',
      orientation:'',
      DeviceType:'',
    };
}



login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
      this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}

getJournalDetail=(data)=>{

  const {vocType,vocNo,vocDate,vocAmt,narration,paymentId,seq,ver,eflag}=data

  this.props.navigation.navigate('JournalApprovalActivity',
  {
      UserID:this.state.UserID,
      Dept:this.state.Dept,
      AppType:this.state.AppType,
      VocType:vocType,
      VocNo:vocNo,
      VocDate:vocDate,
      VocAmt:vocAmt,
      PaymentID:paymentId,
      Narration:narration,
      ver:ver,
      seqno:seq,
      eflag:eflag,
  });
  
}

getJournalList=()=>{
  const config = {
    headers: {   
    'currentToken': tokken,
  },
    params: {
        approver:this.state.UserID,
    }
    
  };
  this.setState({  isLoading:true })
  axios.get(ip+'/getJournalApprovalList', config)
  .then(response => this.setState({ dataSource:response.data},() => {if(response.status==200){this.setState({isLoading:false})}}))
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
}

format(x) {
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}


amountformatter(amount) {

  let FV
  FV=parseFloat(amount).toFixed(2)
  return this.format(FV).toString()

}


componentDidMount(){

  this.setState({
    isLoading:true
  })
  

  Dimensions.addEventListener('change', () => {
    this.setState({
        orientation: isPortrait() ? 'portrait' : 'landscape'
    });
  });

  console.disableYellowBox = true;

  const { navigation } = this.props;


  this.focusListener = navigation.addListener("didFocus", () => {
    this.setState({
      UserID:this.props.navigation.getParam('UserID', ''),
      AppType:this.props.navigation.getParam('Type', ''),
      Dept:this.props.navigation.getParam('Department', ''),
      orientation: isPortrait() ? 'portrait' : 'landscape',
      DeviceType:this.props.navigation.getParam('DeviceType', '')
  },()=>{
    this.getJournalList()
  })
  
  });

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
  


}

getheight(which){
  let orient=''
  let device=''

  orient = this.state.orientation
  device = this.state.DeviceType

console.log('here'+orient+device)
  if(which=='1') { //header
    if(device=='phone'){

      if(orient=='portrait'){
        return '5%'
      }else{
        //landscape
        return '12%'
      }
  
    }else{
      //tab
      if(orient=='portrait'){
        return '5%'
      }else{
         //landscape
         return '10%'
      }
  
    }
  }


  if(which=='2') { //body
    if(device=='phone'){

      if(orient=='portrait'){
        return '95%'
      }else{
        //landscape
        return '88%'
      }
  
    }else{
      //tab
      if(orient=='portrait'){
        return '95%'
      }else{
         //landscape
         return '90%'
      }
  
    }
  }

}


  render() {
    if (this.state.isLoading) {
      return (
        <Modal
        transparent={false}
        visible={this.state.isLoading}
        >
         <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
           useNativeDriver={true}
           supportedOrientations={['portrait', 'landscape']}
           style={style_common.load_gif}
           source={require('../src/gears.gif')}  />
          </View>     
        </Modal>
      )
  }
    return (
        <View style={{flex:1,backgroundColor:lightblue}}>
    
        <ScrollView style={{height:this.getheight("1")}}>

        <View  style={{ flex: 1,paddingTop:RFValue(5)}}>

        <View style={{borderBottomColor:'#fff',borderBottomWidth: RFValue(1),paddingTop:RFValue(3)}}/>

        <Grid style={{backgroundColor:colorprimary,padding:RFValue(4),width:"97%",alignSelf:'center',borderRadius:RFValue(4)}}>
                 <Row>
                 <Col style={{alignItems:'flex-start',width:'15%'}}>
                 <Text style={styles.textContent}>Type</Text>
                 </Col> 
                 <Col style={{alignItems:'flex-start',width:'25%'}}>
                 <Text style={styles.textContent}>Voc No</Text>
                 </Col> 
                 <Col style={{alignItems:'flex-start',width:'30%'}}>
                 <Text style={styles.textContent}>Voc Date</Text>
                 </Col> 
                 <Col style={{alignItems:'flex-end',width:'30%'}}>
                 <Text style={{  color:white,fontSize:RFValue(12),fontFamily:'Bold',alignSelf:'flex-end'}}>Voc Amt</Text>
                 </Col> 
                 </Row>
                 </Grid>
        </View>
        </ScrollView>

        <ScrollView style={{height:this.getheight("2")}}>
       <FlatList
       data={ this.state.dataSource }
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
       <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
        paddingLeft:RFValue(5),paddingRight:RFValue(5),paddingTop:RFValue(5),paddingBottom:RFValue(5)}}>
       <Grid onPress={this.getJournalDetail.bind(this,item)}>
       <Row>
       <Col style={{alignItems:'flex-start',width:'15%'}}>
       <Text style={style_common.italic_list_item}>{item.vocType}</Text>
       </Col>
       <Col style={{alignItems:'flex-start',width:'25%'}}>
       <Text style={style_common.italic_list_item}>{item.vocNo}</Text>
       </Col>
       <Col style={{alignItems:'flex-start',width:'30%'}}>
       <Text style={style_common.italic_list_item}>{item.vocDate}</Text>
       </Col>
       <Col style={{alignItems:'flex-end',width:'30%'}}>
       <Text style={{fontSize:RFValue(13),fontFamily:'Italic',alignSelf:'flex-end'}}>{this.amountformatter(item.vocAmt)}</Text>
       </Col>
       </Row>
      
       </Grid>   
       </CardItem>
       </Card>
        }

       keyExtractor={(item, index) => index.toString()}
       
      />

<Toast ref="toast"/>
        </ScrollView>

        </View>   
        )
      }
 };
 const styles = StyleSheet.create({
  titleText: {
    flex:1,
    flexWrap:'wrap',
    color:white,
    fontSize:RFValue(12),
    padding:RFValue(5),
    fontFamily:'Bold'
  },
  textContent:{
    color:white,
    fontSize:RFValue(12),
    fontFamily:'Bold'
  }
  });
  
  
  
import React, { Component } from 'react';
import { ScrollView, Modal, StyleSheet, Text, View, Image, Dimensions, FlatList, TouchableOpacity, Alert } from 'react-native';
import { Col, Grid, Row } from 'react-native-easy-grid';
import Toast from 'react-native-whc-toast';
import axios from 'axios';
import { NavigationActions, StackActions } from 'react-navigation';
import { Card, CardItem } from 'native-base';
import { Divider } from 'react-native-elements';

//own lib
import strings from '../res/strings';
import color from '../res/colors';
import { logouttask } from '../class/logout';
import { isPortrait } from '../class/useOrientation';


//constant
const ip = strings.values.commonvalues.ip;
const tokken = strings.values.commonvalues.tokken;

//colors
const lightblue = color.values.Colors.lightblue;
const colorprimary = color.values.Colors.colorPrimary;
const white = color.values.Colors.white;

//common style
const style_common = require('../class/style');

//logout
const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class ProjectDrawingApprovalList extends React.Component {
  static navigationOptions = ({ navigation }) => ({
    title: "Drawing List",
    color: "#fff",
    headerStyle: {
      backgroundColor: colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily: 'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{ paddingRight: 10 }} onPress={() => navigation.state.params.handlelogin()}>
        <Image style={{ alignSelf: 'center', justifyContent: 'center' }} source={require('../src/logout.png')} />
      </TouchableOpacity>
    ),
  });

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      handlelogin: '',
      dataSource: [],
      UserID: '',
      orientation: '',
      DeviceType: '',
    };
  }

  login = async () => {
    Alert.alert(
      'Logout',
      'Would you like to logout?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {
          text: 'OK', onPress: () => {
            logouttask();
            this.props.navigation.dispatch(resetAction);
          }
        },
      ],
      { cancelable: false },
    );
  }

  getDrawingDetail = (data) => {
    const { appid, seq, ver, apptype, pid, reqby, reqname, appdate, tclass, category, typedesc, ecrno, remark, reqdate } = data;

    this.props.navigation.navigate('ProjectDrawingApprovalActivity', {
      UserID: this.state.UserID,
      AppID: appid,
      Seq: seq,
      Ver: ver,
      appType: apptype,
      pid: pid,
      reqBy: reqby,
      reqName: reqname,
      appDate: appdate,
      tClass: tclass,
      category: category,
      typeDesc: typedesc,
      ecrNo: ecrno,
      Remark: remark,
      reqDate: reqdate,
    });
  }

  getSOSDetail = (data) => {
    const { appid, seq, ver, apptype, pid, reqby, reqname, appdate, tclass, category, typedesc, ecrno, remark, reqdate } = data;

    this.props.navigation.navigate('ProjectDrawingSOSApprovalActivity', {
      UserID: this.state.UserID,
      AppID: appid,
      Seq: seq,
      Ver: ver,
      appType: apptype,
      pid: pid,
      reqBy: reqby,
      reqName: reqname,
      appDate: appdate,
      tClass: tclass,
      category: category,
      typeDesc: typedesc,
      ecrNo: ecrno,
      Remark: remark,
      reqDate: reqdate,
    });
  }

  getDrawingList = () => {
    const config = {
      headers: {
        'currentToken': tokken,
      },
      params: {
        approver: this.state.UserID,
      }
    };
    this.setState({ isLoading: true });
    axios.get(ip + '/getProjectDrawingApprovalListV1', config)
      .then(response => {
        if (response.status === 200) {
          const updatedData = response.data.map(item => {
            console.log(item); // For debugging purposes
            return {
              ...item,
              navigateTo: item.apptype === 'SOS' ? 'getSOSDetail' : 'getDrawingDetail'
            };
          });
          this.setState({ dataSource: updatedData, isLoading: false });
        }
      })
      .catch(err => {
        this.setState({ isLoading: false }, () => {
          let error = err;
          this.refs.toast.showBottom(error.toString());
          setTimeout(() => {
            this.props.navigation.goBack();
          }, 2000);
        });
      });
  }


  componentDidMount() {
    this.setState({ isLoading: true });
    console.disableYellowBox = true;

    const { navigation } = this.props;

    Dimensions.addEventListener('change', () => {
      this.setState({
        orientation: isPortrait() ? 'portrait' : 'landscape'
      });
    });

    this.focusListener = navigation.addListener("didFocus", () => {
      this.setState({ UserID: this.props.navigation.getParam('UserID', '') }, () => {
        this.getDrawingList();
      });
    });

    this.props.navigation.setParams({
      handlelogin: this.login.bind(this),
    });
  }

  getheight(which) {

    let orient = ''
    let device = ''

    orient = this.state.orientation
    device = this.state.DeviceType

    if (which == '1') { //header
      if (device == 'phone') {

        if (orient == 'portrait') {
          return '3%'
        } else {
          //landscape
          return '15%'
        }

      } else {
        //tab
        if (orient == 'portrait') {
          return '5%'
        } else {
          //landscape
          return '8%'
        }

      }
    }


    if (which == '2') { //body
      if (device == 'phone') {

        if (orient == 'portrait') {
          return '97%'
        } else {
          //landscape
          return '85%'
        }

      } else {
        //tab
        if (orient == 'portrait') {
          return '95%'
        } else {
          //landscape
          return '92%'
        }

      }
    }

  }

  renderItem = ({ item }) => (
    <TouchableOpacity onPress={() => this[item.navigateTo](item)}>
      <Card style={{ width: '97%', alignSelf: 'center' }}>
        <CardItem style={{ alignItems: "flex-start", width: '100%', flexWrap: 'wrap', paddingLeft: 5, paddingRight: 5, paddingTop: 5, paddingBottom: 5 }}>
          <Grid>
            <Row style={{ paddingBottom: 3 }}>
              <Col style={{ alignItems: 'flex-start', width: '10%' }}>
                <Text style={{ fontSize: 13, fontFamily: 'Italic' }}>{item.pid}</Text>
              </Col>
              <Col style={{ alignItems: 'flex-start', width: '25%' }}>
                <Text style={{ fontSize: 13, fontFamily: 'Italic' }}>{item.category === 'I' ? 'For Internal' : 'For Client'}</Text>
              </Col>
              <Col style={{ alignItems: 'flex-start', width: '37%' }}>
                <Text style={{ fontSize: 13, fontFamily: 'Italic' }}>{item.tclass}</Text>
              </Col>
              <Col style={{ alignItems: 'flex-start', width: '28%' }}>
                <Text style={{ fontSize: 13, fontFamily: 'Italic' }}>{item.reqdate}</Text>
              </Col>
            </Row>
            <Divider />
            <Row style={{ paddingTop: 3, paddingBottom: 3 }}>
              <Col style={{ alignItems: 'flex-start', width: '25%' }}>
                <Text style={{ fontSize: 13, fontFamily: 'Bold', color: colorprimary }}>Dwg. Type :</Text>
              </Col>
              <Col style={{ alignItems: 'flex-start', width: '75%' }}>
                <Text style={{ fontSize: 13, fontFamily: 'Italic' }}>{item.typedesc}</Text>
              </Col>
            </Row>
          </Grid>
        </CardItem>
      </Card>
    </TouchableOpacity>
  );

  render() {
    if (this.state.isLoading) {
      return (
        <Modal
          transparent={false}
          supportedOrientations={['portrait', 'landscape']}
          visible={this.state.isLoading}
        >
          <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
            <Image useNativeDriver={true} style={{ width: 300, height: 200 }} source={require('../src/gears.gif')} />
          </View>
        </Modal>
      );
    }

    return (
      <View style={{ flex: 1, backgroundColor: lightblue }}>
        <ScrollView style={{ height: this.getheight('1') }}>
          <View style={{ flex: 1, paddingTop: 5 }}>
            <View style={{ borderBottomColor: '#fff', borderBottomWidth: 1, paddingTop: 3 }} />
            <Grid style={{ backgroundColor: colorprimary, padding: 4, width: "97%", alignSelf: 'center', borderRadius: 4 }}>
              <Row>
                <Col style={{ alignItems: 'flex-start', width: '10%' }}>
                  <Text style={styles.textContent}>PID</Text>
                </Col>
                <Col style={{ alignItems: 'flex-start', width: '25%' }}>
                  <Text style={styles.textContent}>Purpose</Text>
                </Col>
                <Col style={{ alignItems: 'flex-start', width: '37%' }}>
                  <Text style={styles.textContent}>Design Group</Text>
                </Col>
                <Col style={{ alignItems: 'flex-start', width: '28%' }}>
                  <Text style={styles.textContent}>Req Date</Text>
                </Col>
              </Row>
            </Grid>
          </View>
        </ScrollView>
        <ScrollView style={{ height: this.getheight('2') }}>
          <FlatList
            data={this.state.dataSource}
            renderItem={this.renderItem}
            keyExtractor={(item, index) => index.toString()}
          />
          <Toast ref="toast" />
        </ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  titleText: {
    flex: 1,
    flexWrap: 'wrap',
    color: white,
    fontSize: 12,
    padding: 5,
    fontFamily: 'Bold',
  },
  textContent: {
    color: white,
    fontSize: 12,
    fontFamily: 'Bold',
  },
});

import React from 'react';
import {ScrollView,Dimensions,Image,Modal,StyleSheet,Text,View,TouchableOpacity,
  Alert,KeyboardAvoidingView,Platform,FlatList,Linking} from 'react-native';
import axios from 'axios';
import { Col, Grid, Row} from 'react-native-easy-grid';
import {Card,CardItem,Item,Input,Spinner} from 'native-base';
import RadioGroup from 'react-native-radio-buttons-group';
import { NavigationActions, StackActions } from 'react-navigation';
import strings from '../res/strings'
import {logouttask} from '../class/logout';
import Toast from 'react-native-whc-toast'
import color from '../res/colors'
import { Divider,Button,Overlay } from 'react-native-elements';
import Timeline from 'react-native-timeline-flatlist'
import moment from 'moment';
import { CustomButton } from '../custom-button.js';
import * as Font from 'expo-font'

const ip=strings.values.commonvalues.ip;
const fileip=strings.values.commonvalues.fileip;
const tokken=strings.values.commonvalues.tokken;

const { width, height } = Dimensions.get('window');

const lightblue=color.values.Colors.lightblue;
const blue=color.values.Colors.blue;
const colorprimary=color.values.Colors.colorPrimary;
const colorprimarydark=color.values.Colors.colorprimarydark;
const white=color.values.Colors.white;
const black=color.values.Colors.black;
const gray=color.values.Colors.gray;

let selectedButton;
let AppStatus;
let passdata=[];
let datacg=[];
let dataga =[];

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});


export default class PayRollApproval extends React.Component{
  static navigationOptions = ({ navigation }) => ({ 
    title: "HR Approval",
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor:white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('../src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
      super(props);
      this.state = { 
        isLoading: true, 
        isVisibleGA:false,
        isAttachment:false,
        isStatus:false,
        tot_cog_cnt_s:0,tot_cog_gross_s:0,tot_cog_earn_s:0,tot_cog_net_s:0,
        tot_ga_cnt_s:0,tot_ga_gross_s:0,tot_ga_earn_s:0,tot_ga_net_s:0,tot_net_s:0,
        data:[],DocDataSource:[],Statusdata:[],DisStatusData:[],vrm:"",handlelogin:'',UserID:'',SalDate:'',AppID:'',dept:'',Comments:'',
        AppStatus:'',Seq:'',Ver:'',cnt:'',Remark:'',SDate:'',AppType:'',
        Basic:'',Hallowance:'',Transpot:'',Food:'',Allowance:'',Oallowance:'',
        Bonus:'',OT:'',Earn:'',Dedu:'',NetPay:'',Gross:'',Comment:'',
        DN:'',CNT:'',BA:'',AL:'',HA:'',FA:'',TA:'',OA:'',GR:'',BO:'',OTM:'',EA:'',
        DE:'',NP:'',
        radiovalues: [
            {
                label: 'Approve',
                value: "Approve",
                color:'#2452b2'
            },
            {
                label: 'Reject',
                value: "Reject",
                color:'#2452b2'
            },
            {
                label: 'ReWork',
                value: 'ReWork',
                color:'#2452b2'
            },
          
        ],
    };
      console.disableYellowBox = true;
      this.arrayholder = [] ;
  }

  login = async () => 
  {
  
    Alert.alert(
      'Logout',
      'Would you like to logout?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {text: 'OK', onPress: () => { logouttask()
          this.props.navigation.dispatch(resetAction);} },
      ],
      {cancelable: false},
    );
   
  }
  

componentDidMount() {
  console.disableYellowBox = true;

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
 
  this.setState({
    UserID:this.props.navigation.getParam('UserID', ''),
    AppID:this.props.navigation.getParam('AppID', ''),
    AppType:this.props.navigation.getParam('AppType', ''),
    Seq:this.props.navigation.getParam('Seq', ''),
    Ver:this.props.navigation.getParam('Ver', ''),
    Remark:this.props.navigation.getParam('Remark', ''),
    },()=>{this.getPayRollData();})
}

format(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

getPayRollData(){
  

    const config = {
      headers: {   
      'currentToken':tokken,
    },
      params: {
        appid:this.state.AppID,
      }
    };
    this.setState({isLoading:true});
    axios.get(ip+'/getPayRollData', config)
  .then(response => this.setState({data:response.data},() => {if(response.status==200){
    

    datacg=[]
    dataga=[]

    let sal_date='',s_date='',
    tot_cog_gross= 0.0,tot_cog_earn= 0.0,tot_cog_net= 0.0,tot_cog_cnt= 0.0,
    tot_ga_gross= 0.0,tot_ga_earn= 0.0,tot_ga_net= 0.0,tot_ga_cnt= 0.0,tot_net= 0.0;

        for(let i=0;i<this.state.data.length;i++){
            const{sdate,cgroup,dept,deptname,cnt,ba,all,ha,ta,fa,
                oa,gross,bonus,ot,earn,dedu,net,late,saldate}=this.state.data[i]
                
                if(cgroup=='COG'){
        
                    let data_cg=({
                        Dept:dept,
                        DeptName:deptname,
                        Cnt:cnt,
                        Ba:ba,
                        All:all,
                        Ha:ha,
                        Ta:ta,
                        Fa:fa,
                        Oa:oa,
                        Gross:gross,
                        Bonus:bonus,
                        Ot:ot,
                        Earn:earn,
                        Dedu:dedu,
                        Net:net,
                        Late:late,
                      })

                      datacg.push(data_cg)

                    tot_cog_cnt=parseFloat(tot_cog_cnt)+parseFloat(cnt)
                    tot_cog_gross = parseFloat(tot_cog_gross)+parseFloat(gross);
                    tot_cog_earn = parseFloat(tot_cog_earn)+parseFloat(earn);
                    tot_cog_net = parseFloat(tot_cog_net)+parseFloat(net);
                }

                if(cgroup=='G&A'){
                
                    let data_ga=({
                        Dept:dept,
                        DeptName:deptname,
                        Cnt:cnt,
                        Ba:ba,
                        All:all,
                        Ha:ha,
                        Ta:ta,
                        Fa:fa,
                        Oa:oa,
                        Gross:gross,
                        Bonus:bonus,
                        Ot:ot,
                        Earn:earn,
                        Dedu:dedu,
                        Net:net,
                        Late:late,
                      })
                  
                      dataga.push(data_ga)

                    tot_ga_cnt=parseFloat(tot_ga_cnt)+parseFloat(cnt)
                    tot_ga_gross = parseFloat(tot_ga_gross)+parseFloat(gross);
                    tot_ga_earn = parseFloat(tot_ga_earn)+parseFloat(earn);
                    tot_ga_net = parseFloat(tot_ga_net)+parseFloat(net);
                }


                s_date=sdate;
                sal_date=saldate;
        }

        tot_net = tot_ga_net + tot_cog_net;


      

    this.setState({
        SalDate:sal_date,
        SDate:s_date,
        tot_cog_cnt_s:tot_cog_cnt,tot_cog_gross_s:tot_cog_gross,
        tot_cog_earn_s:tot_cog_earn,tot_cog_net_s:tot_cog_net,
        tot_ga_cnt_s:tot_ga_cnt,tot_ga_gross_s:tot_ga_gross,
        tot_ga_earn_s:tot_ga_earn,tot_ga_net_s:tot_ga_net,tot_net_s:tot_net,
        isLoading:false},()=>{
         this.getDoclist()
        });
    }
}))
.catch(err => 
  {
    this.setState({
      isLoading:false
    },()=>{
     let error=err
     
     this.refs.toast.showBottom(error.toString())

     setTimeout(
      () => { 
        this.props.navigation.goBack();
       },
      2000
    )

    })
  }
  );
  
}


/* getDoclist(){
  const config = {
    headers: {   
    'currentToken': tokken,
  },
    params: {
      appid:this.state.AppID,
      apptype:this.state.AppType,
    }
    
  };

  this.setState({isLoading:true})
  axios.get(ip+'/getHRAppDocs', config)
  .then(response => this.setState({ DocDataSource:response.data},() => {if(response.status==200){
    this.setState({
      isAttachment:response.data.length==0?false:true,
      isLoading:false
    })}}))
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
} */

amountformatter(amount){

  let FV
  FV=this.format(Math.round(amount).toString())
  return FV;
}
getcgdetail(index){

  const{Dept,DeptName,Cnt,Ba,All,Ha,Ta,Fa,Oa,Gross,Bonus,Ot,Earn,Dedu,Net,Late}=datacg[index]

  this.setState({
    DN:DeptName,CNT:Cnt+" Employees",BA:this.amountformatter(Ba),AL:this.amountformatter(All),
    FA:this.amountformatter(Fa),TA:this.amountformatter(Ta),OA:this.amountformatter(Oa),
    GR:this.amountformatter(Gross),BO:this.amountformatter(Bonus),OTM:this.amountformatter(Ot),
    EA:this.amountformatter(Earn),
    DE:this.amountformatter(Dedu),NP:this.amountformatter(Net),HA:this.amountformatter(Ha),
    isVisibleGA:true
  })

}
getgadetail(index){

  const{Dept,DeptName,Cnt,Ba,All,Ha,Ta,Fa,Oa,Gross,Bonus,Ot,Earn,Dedu,Net,Late}=dataga[index]

  this.setState({
    DN:DeptName,CNT:Cnt+" Employees",BA:this.amountformatter(Ba),AL:this.amountformatter(All),
    FA:this.amountformatter(Fa),TA:this.amountformatter(Ta),OA:this.amountformatter(Oa),
    GR:this.amountformatter(Gross),BO:this.amountformatter(Bonus),OTM:this.amountformatter(Ot),
    EA:this.amountformatter(Earn),
    DE:this.amountformatter(Dedu),NP:this.amountformatter(Net),HA:this.amountformatter(Ha),
    isVisibleGA:true
  })
 
}

getStatus(){

  this.setState({isLoading:true, StatusData:[],DisStatusData:[]})

   const config = {
       headers: {   
       'currentToken':tokken,
     },
       params: {
        appid:this.state.AppID,
        ver:this.state.Ver,
       }
       
     };

 axios.get(ip+'/getPayRollStatus', config)
   .then(response => this.setState({StatusData:response.data},() => {if(response.status==200){
   this.display()
   }}))
   .catch(err => 
     {
       this.setState({
         isLoading:false
       },()=>{
        let error=err
        
        this.refs.toast.showBottom(error.toString())
 
        setTimeout(
         () => { 
           this.props.navigation.goBack();
          },
         2000
       )
 
       })
     }
     );

}


display(){
  for(i=0;i< this.state.StatusData.length ;i++){
      const{E,C,D,A,F}=this.state.StatusData[i]
      let Desc,tit
      if(E!==''){
        if(D!=='' && D!=null){
          if (F=='O' || F=='P') {
            Desc=C+"\n"+"Remarks : "+E
          }else{
            Desc=C+"\n"+moment(D).format('DD-MM-YYYY').toString()+"\n"+"Remarks : "+E
          }
         
        }
        else{
          Desc=C+"\n"+"Remarks : "+E
        }
        
      }else{

        if(D!=='' && D!=null){

          if (F=='O' || F=='P') {
            Desc=C
          }else{
            Desc=C+"\n"+moment(D).format('DD-MM-YYYY').toString()
          }
       
        }else{
          Desc=C
        }
        
      }

      if(F==='A'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#15ca7d",
              icon:require('../src/ic_approved.png')
          })
      }else if(F==='P'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc, 
              lineColor:"#f4b825",
              icon:require('../src/ic_pending.png')
          })
      }else if(F==='R'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#f6634b",
              icon:require('../src/ic_rejected.png')
          })
      }else if(F==='O'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#2d353a",
              icon:require('../src/ic_opened.png')
          })
      }else if(F=='W'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#2d353a",
              icon:require('../src/ic_opened.png')
          })
      }
  
    }
    this.setState({isLoading:false,isStatus:true})
}


submit(){
  switch (selectedButton) {
      case "Approve":
          AppStatus = "A";
          break;
      case "Reject":
            AppStatus = "R";
            break;
      case "ReWork":
          AppStatus = "W";
          break;      
  }
  if(AppStatus!=="A"){
    if(this.state.Comment.length === 0) {
      alert("Please Enter Comment")
      return
    }
  }
  this.Save();
}

Save(){
this.setState({isLoading:true})
  let url=''
  if(AppStatus==='A'){
   url='/setPayRollApp'
  }else if(AppStatus=='R'){
    url='/setPayRollRej'
  }else if(AppStatus==='W'){
   url='/setPayRollRew'
  }  

  axios({
    method: 'post',
    url:ip+url,
    headers: {'currentToken':tokken}, 
    data: {
      appid:this.state.AppID,       
      userid:this.state.UserID,  
      comments:this.state.Comment,   
      status:this.state.AppStatus,    
      seqno:this.state.Seq,
      saldate:this.state.SalDate,     
      ver:this.state.Ver,       
    }
  }).then(response=>{if(response.status===200){
    this.setState({isLoading:false},()=>{
      this.refs.toast.showBottom("Submitted Successfully")


       this.props.navigation.goBack();

    })
  }else{
    this.refs.toast.showBottom("Failed")
  }})
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
}



getDoclist(){
  const config = {
    headers: {   
    'currentToken': tokken,
  },
    params: {
      doctype:this.state.AppType,
      param1:this.state.AppID,
      param2:0
    }
    
  };

  this.setState({isLoading:true})
  axios.get(ip+'/getDocumentListIOS', config)
  .then(response => this.setState({ DocDataSource:response.data},() => {if(response.status==200){
    this.setState({
      isAttachment:response.data.length==0?false:true,
      isLoading:false
    })}}))
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
}




DownloadDoc(data){

 const{SlNo,DocumentName,AttachFileName,FilePath}=data

 Linking.openURL(fileip+"/DocumentDownloadIOS?FPath="+FilePath+"&FileName="+AttachFileName) 

}



onPress = radiovalues => this.setState({ radiovalues});

render() {
    selectedButton = this.state.radiovalues.find(e => e.selected == true);
    selectedButton = selectedButton ? selectedButton.value : this.state.radiovalues[0].label;   
      if (this.state.isLoading) {
          return (
            <Modal
            transparent={false}
            supportedOrientations={['portrait', 'landscape']}
            visible={this.state.isLoading}
            >
             <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
              <Image
              style={{width: 300, height: 200}}
              source={require('../src/gears.gif')}  />
              </View>     
            </Modal>
          )
      }

      return (
    <View style={{flex:1,backgroundColor:lightblue}}> 
    <KeyboardAvoidingView 
        behavior='padding'
        keyboardVerticalOffset={
        Platform.select({
           ios: () => 0,
           android: () => 60
        })()
        }>
  <ScrollView style={{height:"100%"}}>

  <Modal            
          animationType = {"slide"}  
          transparent = {true}  
          visible = {this.state.isStatus}  
          onRequestClose = {() =>{ console.log("Modal has been closed.") } }>  
          {/*All views of Modal*/}  
          <View style = {styles.modal}>  
          <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress = {() =>
           {  
            this.setState({ isStatus:!this.state.isStatus})
           }}>
        
        <Grid>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontFamily:'Bold',alignSelf:'flex-start'}}>
             Approval Timeline
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('../src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
       </Grid>

         </TouchableOpacity>


         <Timeline 
          style={styles.list}
          data={this.state.DisStatusData}
          circleSize={25}
          showTime={false}
          circleColor='rgba(0,0,0,0)'
          lineColor='rgb(45,156,219)'
          descriptionStyle={{color:'gray',fontFamily:'Regular'}}
          innerCircle={'icon'}
        />

          </View>
   </Modal>

  <Overlay
  width="90%"
  height="60%"
  animationType='slide'
  isVisible={this.state.isVisibleGA}
  onBackdropPress={() => this.setState({ isVisibleGA: false })}> 
          {/*All views of Modal*/}  

          <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress = {() =>
           {  
            this.setState({ isVisibleGA:!this.state.isVisibleGA})
           }}>

        <Grid>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontFamily:'Bold',alignSelf:'flex-start'}}>
             Payroll Detail
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('../src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
       </Grid>

     

         </TouchableOpacity>
            
             <View  style={{ flex: 1,paddingTop:5}}>
             
             <Grid style={{width:'97%',alignSelf:'center'}}>

             <Row> 
               <Col style={{alignItems:'center',width:'100%'}}>
               <Text style={{fontSize:13,color:gray,fontFamily:'Bold'}}>{this.state.DN}</Text>
               </Col>
               </Row>
               <Row>
               <Col style={{alignItems:'center',width:'100%'}}>
               <Text style={{fontSize:12,color:gray,fontFamily:'Italic'}}>{this.state.CNT}</Text>
               </Col>
               </Row>

               <Divider></Divider>
               <Divider></Divider>
               <Divider></Divider>

              <Row>
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Basic</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'50%'}}>
              <Text style={{fontSize:13,color:gray,fontFamily:'Bold'}}>{this.state.BA}</Text>
              </Col> 
              </Row>
              
              <Row>
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Allowance</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'50%'}}>
              <Text style={{fontSize:13,color:gray,fontFamily:'Bold'}}>{this.state.AL}</Text>
              </Col> 
              </Row>
              <Row>
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>House Allowance</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'50%'}}>
              <Text style={{fontSize:13,color:gray,fontFamily:'Bold'}}>{this.state.HA}</Text>
              </Col> 
              </Row>
              <Row>
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Food Allowance</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'50%'}}>
              <Text style={{fontSize:13,color:gray,fontFamily:'Bold'}}>{this.state.FA}</Text>
              </Col> 
              </Row>
              <Row>
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Transport Allowance</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'50%'}}>
              <Text style={{fontSize:13,color:gray,fontFamily:'Bold'}}>{this.state.TA}</Text>
              </Col> 
              </Row>
              <Row>
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Other Allowance</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'50%'}}>
              <Text style={{fontSize:13,color:gray,fontFamily:'Bold'}}>{this.state.OA}</Text>
              </Col> 
              </Row>
              <Divider></Divider>
              <Divider></Divider>
              <Divider></Divider>

              <Row>
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Gross</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'50%'}}>
              <Text style={{fontSize:13,color:black,fontFamily:'Bold'}}>{this.state.GR}</Text>
              </Col> 
              </Row>

              <Row>
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Bonus</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'50%'}}>
              <Text style={{fontSize:13,color:gray,fontFamily:'Bold'}}>{this.state.BO}</Text>
              </Col> 
              </Row>

              <Row>
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Overtime</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'50%'}}>
              <Text style={{fontSize:13,color:gray,fontFamily:'Bold'}}>{this.state.OTM}</Text>
              </Col> 
              </Row>

              <Divider></Divider>
              <Divider></Divider>
              <Divider></Divider>

              <Row>
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Earnings</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'50%'}}>
              <Text style={{fontSize:13,color:black,fontFamily:'Bold'}}>{this.state.EA}</Text>
              </Col> 
              </Row>

              <Row>
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Deduction</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'50%'}}>
              <Text style={{fontSize:13,color:black,fontFamily:'Bold'}}>{this.state.DE}</Text>
              </Col> 
              </Row>

              <Divider></Divider>
              <Divider></Divider>

              <Row>
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Net Pay</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'50%'}}>
              <Text style={{fontSize:13,color:black,fontFamily:'Bold'}}>{this.state.NP}</Text>
              </Col> 
              </Row>


             </Grid>


             </View>
    </Overlay>



    <View  style={{ flex: 1,paddingTop:2,paddingBottom:2}}>
    <Grid style={{paddingTop:'2%'}}>
    <Row style={{backgroundColor:colorprimary,padding:5,width:'97%',alignSelf:'center'
    ,alignItems:'center',borderRadius:2}}>
    <Col style={{alignItems:'center',width:'100%'}}>
    <Text style={styles.titleText}>PayRoll Approval</Text>
    </Col>
     </Row>
     </Grid>
    </View>

    <Card style={{width:'97%',alignSelf:'center'}}>
               <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
                  paddingLeft:5,paddingRight:5,paddingTop:5,paddingBottom:5}}>
               <Grid>
               <Row style={{paddingTop:2,paddingBottom:3,}}>
               <Col style={{alignItems:'flex-start',width:'30%'}}>
               <Text style={styles.testHead}>Salary Month : </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'70%'}}>
               <Text style={{fontSize:12,color:black,fontFamily:'Regular'}}>{this.state.SDate}</Text>
               </Col>
               </Row>         
               <Row style={{paddingTop:3,paddingBottom:3}}>
               <Col style={{alignItems:'flex-start',width:'30%'}}>
               <Text style={styles.testHead}>Net Amount : </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'70%'}}>
               <Text style={{fontSize:12,color:black,fontFamily:'Regular'}}>{this.format(this.state.tot_net_s.toString())}</Text>
               </Col>
               </Row>       
               <Row style={{paddingTop:3,paddingBottom:3}}>
               <Col style={{alignItems:'flex-start',width:'30%'}}>
               <Text style={styles.testHead}>Remarks : </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'70%'}}>
               <Text style={{fontSize:12,color:black,fontFamily:'Regular'}}>{this.state.Remark}</Text>
               </Col>
               </Row>          
               </Grid>   
               </CardItem>
   </Card>


    {/* GA */}

    <View  style={{ flex: 1,paddingTop:5}}>
    <Grid style={{backgroundColor:colorprimary,padding:5,width:'97%',alignSelf:'center',
    alignItems:'center',borderRadius:2}}>
             <Row>
             <Col style={{alignItems:'flex-start',width:'40%'}}>
             <Text style={styles.textContent}>G and A</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'10%'}}>
             <Text style={styles.textContent}>Cnt</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'17%'}}>
             <Text style={styles.textContent}>Gross</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'17%'}}>
             <Text style={styles.textContent}>Earnings</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'16%'}}>
             <Text style={styles.textContent}>Net</Text>
             </Col> 
             </Row>
             </Grid>
    </View>
    <FlatList
       data={ dataga }
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
            <CardItem style={styles.carditem}>
            <Grid  onPress={() => this.getgadetail(index)}>
            <Row>
              <Col style={{alignItems:'flex-start',width:'40%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-start'}}>{item.DeptName}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'10%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-start'}}>{item.Cnt}</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'17%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-end'}}>{this.format(Math.round(item.Gross).toString())}</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'17%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-end'}}>{this.format(Math.round(item.Earn).toString())}</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'16%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-end'}}>{this.format(Math.round(item.Net).toString())}</Text>
              </Col> 
             </Row>
            </Grid>  
             </CardItem>
           </Card>
        }

       keyExtractor={(item, index) => index.toString()}
       
      />
       <View  style={{ flex: 1,paddingTop:5}}>
       <Grid style={{backgroundColor:'#D7EFFA',padding:4,width:"97%",alignSelf:'center',borderRadius:2}}>
             <Row>
             <Col style={{alignItems:'flex-start',width:'40%'}}>
             <Text style={styles.textTotalContent}>G and A Total :</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'10%'}}>
             <Text style={styles.textTotalContent}>{this.format(Math.round(this.state.tot_ga_cnt_s).toString())}</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'17%'}}>
              </Col>
             <Col style={{alignItems:'flex-end',width:'17%'}}>
             <Text style={styles.textTotalContent}>{this.format(Math.round(this.state.tot_ga_earn_s).toString())}</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'16%'}}>
             </Col>
             </Row>
             <Row>
             <Col style={{alignItems:'flex-start',width:'40%'}}>
              </Col>
              <Col style={{alignItems:'flex-start',width:'10%'}}>
                </Col>
             <Col style={{alignItems:'flex-end',width:'17%'}}>
             <Text style={styles.textTotalContent}>{this.format(Math.round(this.state.tot_ga_gross_s).toString())}</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'17%'}}>
               </Col>
             <Col style={{alignItems:'flex-end',width:'16%'}}>
             <Text style={styles.textTotalContent}>{this.format(Math.round(this.state.tot_ga_net_s).toString())}</Text>
             </Col> 
             </Row>
             </Grid>
      </View>

{/* COG */}

      <View  style={{ flex: 1,paddingTop:5}}>
    <Grid style={{backgroundColor:colorprimary,padding:5,width:'97%',borderRadius:2,alignSelf:'center',alignItems:'center'}}>
             <Row>
             <Col style={{alignItems:'flex-start',width:'40%'}}>
             <Text style={styles.textContent}>COG</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'10%'}}>
             <Text style={styles.textContent}>Cnt</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'17%'}}>
             <Text style={styles.textContent}>Gross</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'17%'}}>
             <Text style={styles.textContent}>Earnings</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'16%'}}>
             <Text style={styles.textContent}>Net</Text>
             </Col> 
             </Row>
             </Grid>
    </View>
    <FlatList
       data={ datacg }
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
            <CardItem style={styles.carditem}>
            <Grid  onPress={() => this.getcgdetail(index)}>
            <Row>
              <Col style={{alignItems:'flex-start',width:'40%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-start',fontFamily:'Regular'}}>{item.DeptName}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'10%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-start',fontFamily:'Regular'}}>{item.Cnt}</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'17%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-end',fontFamily:'Regular'}}>{this.format(Math.round(item.Gross).toString())}</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'17%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-end',fontFamily:'Regular'}}>{this.format(Math.round(item.Earn).toString())}</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'16%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-end',fontFamily:'Regular'}}>{this.format(Math.round(item.Net).toString())}</Text>
              </Col> 
             </Row>
            </Grid>  
             </CardItem>
           </Card>
        }

       keyExtractor={(item, index) => index.toString()}
       
      />
       <View  style={{ flex: 1,paddingTop:5}}>
       <Grid style={{backgroundColor:'#D7EFFA',padding:4,borderRadius:2,width:"97%",alignSelf:'center'}}>
             <Row>
             <Col style={{alignItems:'flex-start',width:'40%'}}>
             <Text style={styles.textTotalContent}>COG Total :</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'10%'}}>
             <Text style={styles.textTotalContent}>{this.state.tot_cog_cnt_s}</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'17%'}}>
             </Col>
             <Col style={{alignItems:'flex-end',width:'17%'}}>
             <Text style={styles.textTotalContent}>{this.format(Math.round(this.state.tot_cog_earn_s).toString())}</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'16%'}}>
             </Col>
             </Row>
             <Row>
             <Col style={{alignItems:'flex-start',width:'50%'}}>
               </Col>
             <Col style={{alignItems:'flex-end',width:'17%'}}>
             <Text style={styles.textTotalContent}>{this.format(Math.round(this.state.tot_cog_gross_s).toString())}</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'17%'}}>
               </Col>
             <Col style={{alignItems:'flex-end',width:'16%'}}>
             <Text style={styles.textTotalContent}>{this.format(Math.round(this.state.tot_cog_net_s).toString())}</Text>
             </Col> 
             </Row>
             </Grid>
      </View>

{/* Doc List
 */}

{/* <View  style={{display:this.state.isAttachment==true?'flex':'none',flex: 1,paddingTop:5}}>
            <Grid style={{backgroundColor:colorprimary,padding:5,width:'97%',alignSelf:'center',alignItems:'center'}}>
              <Row>
              <Col style={{alignItems:'center',width:'100%'}}>
              <Text style={{color:white,fontSize:13,fontFamily:'Bold'}}>Attachments</Text>
              </Col>
              </Row>
            </Grid>

            <FlatList
       data={ this.state.DocDataSource}
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
            <Grid>
              <Row>
              <Col style={{alignItems:'flex-start',width:'10%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-start',fontFamily:'Regular'}}>{item.A}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'90%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-start',fontFamily:'Regular'}}>{item.C}</Text>
              </Col> 
              </Row>
            </Grid>  
             </CardItem>
           </Card>
        }

       keyExtractor={(item, index) => index.toString()}
       
      />
</View>
      */}


<View  style={{display:this.state.isAttachment==true?'flex':'none',flex: 1,paddingTop:5}}>
            <Grid style={{backgroundColor:colorprimary,padding:5,width:'97%',
            alignSelf:'center',alignItems:'center',borderRadius:2}}>
              <Row>
              <Col style={{alignItems:'center',width:'100%'}}>
              <Text style={{color:white,fontSize:13,fontFamily:'Bold'}}>Attachments</Text>
              </Col>
              </Row>
            </Grid>

            <FlatList
       data={ this.state.DocDataSource}
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
            <Grid onPress={this.DownloadDoc.bind(this,item)}>
              <Row>
              <Col style={{alignItems:'flex-start',width:'10%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-start',fontFamily:'Regular'}}>{item.SlNo}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'90%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-start',fontFamily:'Regular'}}>{item.AttachFileName}</Text>
              </Col> 
              </Row>
            </Grid>  
             </CardItem>
           </Card>
        }

       keyExtractor={(item, index) => index.toString()}
       
      />
</View>
     <Card style={{width:'97%',alignSelf:"center"}}>
                <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
                <Item>
                <Input placeholder="Approval Comments"
                value={this.state.Comment}
                style={{fontFamily:'Regular'}}
                onChangeText={val => this.setState({ Comment: val })}
               />
               </Item>
              </CardItem>
              <CardItem style={{paddingLeft:20}}>       
              <RadioGroup flexDirection='row' 
              radioButtons={this.state.radiovalues} onPress={this.onPress} />
               </CardItem>
              </Card>

        
              <Grid style={{padding:4,width:"97%",alignSelf:'center',paddingBottom:5}}>
             <Row>
             <Col style={{alignItems:'center',width:'50%'}}>
             <Button onPress={() =>this.getStatus()} 
             raised={true}
             titleStyle={{fontSize:15,textAlign:'center',fontFamily:'Bold'}}
             buttonStyle={{
               flex:1,
               borderRadius:6,
               width:120,
               height:45
             }}
            
             title=" Status "/>
             </Col> 
             <Col style={{alignItems:'center',width:'50%'}}>
             <Button onPress={() =>this.submit()} 
              raised={true}
              titleStyle={{fontSize:15,textAlign:'center',fontFamily:'Bold'}}
              buttonStyle={{
               flex:1,
               borderRadius:6,
               width:120,
               height:45
              }}
            
             title=" Submit "/>
             </Col> 
             </Row>
            </Grid>
         
          

          <Toast ref="toast"/>
          </ScrollView>
          </KeyboardAvoidingView>
          </View>
      );
  }
}

const styles = StyleSheet.create({

    ButtonSection: {

        paddingTop:3,
        width: '100%',
        justifyContent: 'center',
        alignItems: 'center',
        paddingBottom:10
     },

  container: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: '#F5FCFF',
  },
  sectionHeader: {
      fontSize: 13,
      fontFamily:'Bold',
      color:'#fff',
  },
  itemView: {
    flex: 1,
    width,
    borderBottomWidth: 0.5,
    borderColor: '#cdcdcd',
    borderStyle: 'solid',
    paddingHorizontal: 12,
    flexDirection: 'row',
    paddingTop:2
},
textContent:{
  color:white,
  fontSize:12,
  fontFamily:'Bold'
},

textTotalContent:{
  color:'#3A6705',
  fontSize:12,
  fontFamily:'Bold'
},

testHead:{
    width:"100%",
    fontSize:13,
    color:colorprimary,
    fontFamily:'Bold',
    textAlign:'right',
    
},
CButton:{
    paddingTop:8,
    height:45,
    width:80,
    paddingBottom:4
},
imagebutton: {
    width:30,
    height: 30,        
  },
  modal: {  
    flex:1,
    width:'100%',
    backgroundColor:white,
    height:'auto',
    position: 'absolute',
    bottom: 0
     },
     headerback: {
      flexDirection: 'row',
      alignItems:'center',
      backgroundColor: colorprimary,
      borderWidth: 0.5,
      borderColor:white,
      height: 40,
      width:'100%',
      borderRadius: 5,
    },
    titleText: {
      flex:1,
      flexWrap:'wrap',
      color:white,
      fontSize:13,
      fontFamily:'Bold'
    },
    carditem:{
      alignItems:"flex-start",width:'100%',flexWrap:'wrap',
            paddingLeft: 5,
            paddingRight: 5,
            paddingTop: 10,
            paddingBottom: 10
    }
});


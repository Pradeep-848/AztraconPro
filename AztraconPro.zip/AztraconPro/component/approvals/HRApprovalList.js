import React from 'react';
import {ScrollView,Dimensions,Image,Modal,SectionList,StyleSheet,Text,View,TouchableOpacity,Alert,StatusBar} from 'react-native';
import axios from 'axios';
import { NavigationActions, StackActions,withNavigationFocus } from 'react-navigation';
import { Col, Grid, Row} from 'react-native-easy-grid';
import {Card,CardItem} from 'native-base';
import strings from '../res/strings'
import {logouttask} from '../class/logout';
import Toast from 'react-native-whc-toast'
import color from '../res/colors'


const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const { width, height } = Dimensions.get('window');

const lightblue=color.values.Colors.lightblue;
const blue=color.values.Colors.skyblue;
const colorprimary=color.values.Colors.colorPrimary;
const colorprimarydark=color.values.Colors.colorPrimaryDark;
const white=color.values.Colors.white;
const gray=color.values.Colors.gray;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});



export default class HRApprovalList extends React.Component{
  static navigationOptions = ({ navigation }) => ({ 
    title: navigation.getParam('Title', 'HR Approval List'),
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor:white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('../src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
      super(props);
      this.state = { 
        isLoading: true, 
        data: "",
        handlelogin:'',
        UserID:'',
        AType:'',
    };
      console.disableYellowBox = true;
  }

  login = async () => 
  {
  
    Alert.alert(
      'Logout',
      'Would you like to logout?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {text: 'OK', onPress: () => { logouttask()
          this.props.navigation.dispatch(resetAction);} },
      ],
      {cancelable: false},
    );
   
  }
  

componentDidMount() {

  this.setState({
    isLoading:true
  })

  console.disableYellowBox = true;

 const { navigation } = this.props;


 this.focusListener = navigation.addListener("didFocus", () => {


  this.setState({
    UserID:this.props.navigation.getParam('UserID', ''),
    AType:this.props.navigation.getParam('Type', ''),
  },()=>{
    this.props.navigation.setParams({
      handlelogin: this.login.bind(this),
      Title: this.gettitle(this.props.navigation.getParam('Type', ''))
      });
    this.getApprovalList();
  })


});

 
}


gettitle(apptype){

let type
type=String(apptype).trim()

if(type=='SLI'){
    return 'Salary Adjustment'
}else if(type=='RE'){
   return 'Recruitment'
}else if(type=='PAY'){
  return 'PayRoll'
}else if(type=='ST'){
  return 'Site Transfer'
}
else if(type=='EJL'){
  return 'Employee Joining'
}
else if(type=='ELS'){
  return 'Leave Settlement'
}
else if(type=='EOC'){
  return 'Final Settlement'
}
else{
  return 'HR Approval List'
}

}
gotoApproval(detail){
    
    const {apptype,desc,appid,seq,status,reqdate,reqby,reqname,pdays,ver,remark} = detail
  
    console.log(detail)
    console.log(apptype)
    if(apptype=='SLI'){
        this.props.navigation.navigate('SalaryAdjustApprovalActivity',{
            UserID:this.state.UserID,
            AppID:appid,
            AppType:apptype,
            Seq:seq,
            Ver:ver,
            Remark:remark
        });
    }else if(apptype=='RE'){
        this.props.navigation.navigate('RecruitmentApprovalActivity',{
            UserID:this.state.UserID,
            AppID:appid,
            AppType:apptype,
            Seq:seq,
            Ver:ver,
            Remark:remark
        });
    }else if(apptype=='PAY'){
        this.props.navigation.navigate('PayRollApprovalActivity',{
            UserID:this.state.UserID,
            AppID:appid,
            AppType:apptype,
            Seq:seq,
            Ver:ver,
            Remark:remark
        });
    }else if(apptype=='ST'){
      this.props.navigation.navigate('SiteTransferApprovalActivity',{
          UserID:this.state.UserID,
          AppID:appid,
          AppType:apptype,
          Seq:seq,
          Ver:ver,
          Remark:remark
      });
  }
  else if(apptype=='EJL'){
    this.props.navigation.navigate('EmployeeJoiningApprovalActivity',{
        UserID:this.state.UserID,
        AppID:appid,
        AppType:apptype,
        Seq:seq,
        Ver:ver,
        Remark:remark
    });
}
else if(apptype=='ELS'){
  this.props.navigation.navigate('EmpLeaveSettlementApprovalActivity',{
      UserID:this.state.UserID,
      AppID:appid,
      AppType:apptype,
      Seq:seq,
      Ver:ver,
      ReqDate:reqdate,
      ReqBy:reqby,
      ReqName:reqname,
      Remark:remark
  });
}
else if(apptype=='EOC'){
  this.props.navigation.navigate('FinalSettlementApprovalActivity',{
      UserID:this.state.UserID,
      AppID:appid,
      AppType:apptype,
      Seq:seq,
      Ver:ver,
      ReqDate:reqdate,
      ReqBy:reqby,
      ReqName:reqname,
      Remark:remark
  });
}
  else{
        this.props.navigation.navigate('HRApprovalListActivity',{
            UserID:this.state.UserID,
            Type:AType
        });
    }
  
}
getApprovalList(){
    const config = {
      headers: {   
      'currentToken':tokken,
    },
      params: {
        UserID:this.state.UserID,
        apptype:this.state.AType,
      }
    };
    this.setState({isLoading:true});
axios.get(ip+'/getHRApprovalListV2IOS', config)
  .then(response => this.setState({data:response.data},() => {if(response.status==200){
   this.setState({isLoading:false});
  }
}))
.catch(err => 
  {
    this.setState({
      isLoading:false
    },()=>{
     let error=err
     
     this.refs.toast.showBottom(error.toString())

     setTimeout(
      () => { 
        this.props.navigation.goBack();
       },
      2000
    )

    })
  }
  );
  
}

  renderItem(item) {    
      const {apptype,desc,appid,seq,status,reqdate,reqby,reqname,pdays,ver,remark} = item.item;
      return (
            <Card style={{width:'97%',alignSelf:'center'}}>
               <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
                  paddingLeft:5,paddingRight:5,paddingTop:5,paddingBottom:5}}>
               <Grid onPress={this.gotoApproval.bind(this,item.item)}>
               <Row>
               <Col style={{alignItems:'flex-start',width:'20%'}}>
               <Text style={{fontSize:13,color:colorprimarydark,fontFamily:'Bold'}}>{appid}</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'20%'}}>
               <Text style={{fontSize:13,color:colorprimarydark,fontFamily:'Bold'}}>{reqby}</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'55%'}}>
               <Text style={{fontSize:13,color:colorprimarydark,fontFamily:'Bold'}}>{reqname}</Text>
               </Col>
               </Row>
               <View style={{borderBottomColor:'#A9A9A9',borderBottomWidth: 1,height:5,
             width:'100%',alignSelf:'center'}}/>
               <Row>
               <Col style={{alignItems:'flex-start',width:'30%'}}>
               <Text style={{fontSize:13,color:colorprimarydark,fontFamily:'Bold'}}>Req. date</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'70%'}}>
               <Text style={{fontSize:13,fontFamily:'Italic',color:gray}}>{reqdate}</Text>
               </Col> 
               </Row>
               <Row>
               <Col style={{alignItems:'flex-start',width:'30%'}}>
               <Text style={{fontSize:13,color:colorprimarydark,fontFamily:'Bold'}}>Waiting for</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'70%'}}>
               <Text style={{fontSize:13,fontFamily:'Italic',color:gray}}>{pdays}</Text>
               </Col> 
               </Row>
               </Grid>   
               </CardItem>
               </Card>
      );

  }

  render() {
      if (this.state.isLoading) {
          return (
            <Modal
            transparent={false}
            supportedOrientations={['portrait', 'landscape']}
            visible={this.state.isLoading}
            >
             <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
              <Image
              style={{width: 300, height: 200}}
              source={require('../src/gears.gif')}  />
              </View>     
            </Modal>
          )
      }

      return (
    <View style={{flex:1,backgroundColor:lightblue}}>
    
    <ScrollView style={{height:'4%'}}>
    <View  style={{ flex: 1,paddingTop:5}}>
    <Grid style={{backgroundColor:colorprimary,padding:4,width:"97%",alignSelf:'center',borderRadius:2}}>
             <Row>
             <Col style={{alignItems:'flex-start',width:'20%'}}>
             <Text style={styles.textContent}>App. ID</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'20%'}}>
             <Text style={styles.textContent}>EmpID</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'60%'}}>
             <Text style={styles.textContent}>Requestor Name</Text>
             </Col> 
             </Row>
             </Grid>
    </View>
   </ScrollView>
   <ScrollView style={{height:'96%'}}>
              <SectionList
                  sections={this.state.data}
                  style={{paddingTop:2}}
                  initialNumToRender={this.state.data.length}
                  renderItem={this.renderItem.bind(this)}
                  renderSectionHeader={({ section }) => 
                  
                   <View  style={{ flex: 1,paddingTop:5,paddingBottom:5}}>
                   <Grid style={{backgroundColor:blue,padding:5,width:"97%",alignSelf:'center',borderRadius:2}}>
                   <Row>
                   <Col style={{alignItems:'flex-start',width:'100%'}}>
                   <Text style={styles.sectionHeader}>{section.Header}</Text>
                   </Col> 
                   </Row>
                   </Grid>
                   </View>
                  
               }
                  keyExtractor={(item, index) => index}
              />
                <Toast ref="toast"/>
          </ScrollView>
          </View>    
      );
  }
}

const styles = StyleSheet.create({
  container: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: '#F5FCFF',
  },
  sectionHeader: {
      alignSelf:'flex-start',
      fontSize: 13,
      fontFamily:'Bold',
      color:'#fff',
  },
  itemView: {
    flex: 1,
    width,
    borderBottomWidth: 0.5,
    borderColor: '#cdcdcd',
    borderStyle: 'solid',
    paddingHorizontal: 12,
    flexDirection: 'row',
    paddingTop:2
},
textContent:{
  color:white,
  fontSize:12,
  fontFamily:'Bold'
},
titleText: {
  flex:1,
  flexWrap:'wrap',
  color:white,
  fontSize:12,
  padding:5
},


});


import React from 'react';
import {ScrollView,Dimensions,Image,Modal,StyleSheet,Text,View,TouchableOpacity,
  Alert,KeyboardAvoidingView,Platform,FlatList,Linking} from 'react-native';
import axios from 'axios';
import { Col, Grid, Row} from 'react-native-easy-grid';
import {Card,CardItem,Item,Input} from 'native-base';
import RadioGroup from 'react-native-radio-buttons-group';
import { NavigationActions, StackActions } from 'react-navigation';
import strings from '../res/strings'
import {logouttask} from '../class/logout';
import Toast from 'react-native-whc-toast'
import color from '../res/colors'
import { Divider,Button,Overlay } from 'react-native-elements';
import Timeline from 'react-native-timeline-flatlist'
import moment from 'moment';

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;
const fileip=strings.values.commonvalues.fileip;

const { width } = Dimensions.get('window');

const lightblue=color.values.Colors.lightblue;
const colorprimary=color.values.Colors.colorPrimary;
const dark=color.values.Colors.colorPrimaryDark;
const white=color.values.Colors.white;
const black=color.values.Colors.black;
const gray=color.values.Colors.gray;

let selectedButton;
let AppStatus;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class ProjectInvoiceApproval extends React.Component{
  static navigationOptions = ({ navigation }) => ({ 
    title: "Approval",
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor:white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('../src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
      super(props);
      this.state = { 
        isLoading: true, 
        isVisibleDetail:false,
        isAttachment:false,
        isStatus:false,
        data:[],DocDataSource:[],Statusdata:[],DisStatusData:[],handlelogin:'',UserID:'',Comments:'',
        AppStatus:'',Seq:'',Ver:'',
        CountryName:'',City:'',Crno:'',Vatno:'',Category:'',Tcategory:'',Aramcoappr:'',
        Aramcoid:'',Nineco:'',Payterm:'',Add1:'',Add2:'',Add3:'',Add4:'',Phone:'',Telex:'',
        Fax:'',Email:'',Homepage:'',Currency:'',SupCode:'',SupName:'',DocList:[],BankList:[],
        radiovalues: [
            {
                label: 'Approve',
                value: "Approve",
                color:'#2452b2'
            },
            {
                label: 'Reject',
                value: "Reject",
                color:'#2452b2'
            },
            {
                label: 'ReWork',
                value: 'ReWork',
                color:'#2452b2'
            },
            
          
        ],
    };
      console.disableYellowBox = true;
      this.arrayholder = [] ;
  }

  login = async () => 
  {
  
    Alert.alert(
      'Logout',
      'Would you like to logout?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {text: 'OK', onPress: () => { logouttask()
          this.props.navigation.dispatch(resetAction);} },
      ],
      {cancelable: false},
    );
   
  }
  
  componentDidMount() {
    console.disableYellowBox = true;
  
  this.props.navigation.setParams({
    handlelogin: this.login.bind(this)
    });


    this.setState({
      UserID:this.props.navigation.getParam('UserID', ''),
      SupCode:this.props.navigation.getParam('SupCode', ''),
      SupName:this.props.navigation.getParam('SupName',''),
      Seq:this.props.navigation.getParam('Seq',''),
      Ver:this.props.navigation.getParam('Ver',''),
      AppType:this.props.navigation.getParam('Type',''),
      },()=>{this.getSupplierAppr();})
  }


getSupplierAppr(){
  
  const config = {
    headers: {   
    'currentToken':tokken,
  },
    params: {
        supcode:this.state.SupCode,
        ver:this.state.Ver,
        seq:this.state.Seq,
    }
  };
  this.setState({isLoading:true});
  axios.get(ip+'/getSupplierAppr', config)
.then(response => this.setState({data:response.data},() => {if(response.status==200){
     
     
  const{countryname,city,crno,vatno,category,tcategory,aramcoappr,aramcoid,nineco,payterm,
    add1,add2,add3,add4,phone,telex,fax,email,homepage,currency}=this.state.data[0]

this.setState({
    CountryName:countryname,City:city,Crno:crno,Vatno:vatno,Category:category,Tcategory:tcategory,Aramcoappr:aramcoappr,
    Aramcoid:aramcoid,Nineco:nineco,Payterm:payterm,Add1:add1,Add2:add2,Add3:add3,Add4:add4,Phone:phone,Telex:telex,
    Fax:fax,Email:email,Homepage:homepage,Currency:currency,
      isLoading:false
    },()=>{
       this.getDoclist()
      });
  }
}))
.catch(err => 
{
  this.setState({
    isLoading:false
  },()=>{
   let error=err
   
   this.refs.toast.showBottom(error.toString())

   setTimeout(
    () => { 
      this.props.navigation.goBack();
     },
    2000
  )

  })
}
);

}


getDoclist(){
  const config = {
    headers: {   
    'currentToken': tokken,
  },
    params: {
       // supcode:this.state.SupCode
        from:"I",
        doctype:this.state.AppType,
        param1:this.state.SupCode,
        param2:0
    }
    
  };

  this.setState({isLoading:true})
  axios.get(ip+'/getSuppApprDocsBank', config)
  .then(response => this.setState({ DocDataSource:response.data},() => {if(response.status==200){
      
    let DocArr=[],BankArr=[]
    for(let i=0;i<this.state.DocDataSource.length;i++){
      
        const{Doc,Bank}=this.state.DocDataSource[i]

        console.log(Doc)
        console.log(Bank)

        DocArr=Doc
        BankArr=Bank

        console.log(DocArr)
        console.log(BankArr)  
    }

    this.setState({
      isAttachment:DocArr.length==0?false:true,
      DocList:DocArr,
      BankList:BankArr,
      isLoading:false
    })}}))
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
}


getdetail(){
 
    this.setState({
        isVisibleDetail:true
    })
}

getStatus(){

  this.setState({isLoading:true, StatusData:[],DisStatusData:[]})

   const config = {
       headers: {   
       'currentToken':tokken,
     },
       params: {
        supcode:this.state.SupCode
       }
       
     };

 axios.get(ip+'/getSuppApprStatus', config)
   .then(response => this.setState({StatusData:response.data},() => {if(response.status==200){
   this.display()
   }}))
   .catch(err => 
     {
       this.setState({
         isLoading:false
       },()=>{
        let error=err
        
        this.refs.toast.showBottom(error.toString())
 
        setTimeout(
         () => { 
           this.props.navigation.goBack();
          },
         2000
       )
 
       })
     }
     );

}

display(){
  for(i=0;i< this.state.StatusData.length ;i++){
      const{E,C,D,A,F}=this.state.StatusData[i]
      let Desc
      if(E!==''){
        if(D!=='' && D!=null){
          if (F=='O' || F=='P') {
            Desc=C+"\n"+"Remarks : "+E
          }else{
            Desc=C+"\n"+moment(D).format('DD-MM-YYYY').toString()+"\n"+"Remarks : "+E
          }
         
        }
        else{
          Desc=C+"\n"+"Remarks : "+E
        }
        
      }else{

        if(D!=='' && D!=null){

          if (F=='O' || F=='P') {
            Desc=C
          }else{
            Desc=C+"\n"+moment(D).format('DD-MM-YYYY').toString()
          }
       
        }else{
          Desc=C
        }
        
      }

      if(F==='A'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#15ca7d",
              icon:require('../src/ic_approved.png')
          })
      }else if(F==='P'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc, 
              lineColor:"#f4b825",
              icon:require('../src/ic_pending.png')
          })
      }else if(F==='R'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#f6634b",
              icon:require('../src/ic_rejected.png')
          })
      }else if(F==='O'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#2d353a",
              icon:require('../src/ic_opened.png')
          })
      }else if(F=='W'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#2d353a",
              icon:require('../src/ic_opened.png')
          })
      }
  
    }
    this.setState({isLoading:false,isStatus:true})
}

DownloadDoc(data){

  const{SlNo,DocumentName,AttachFileName,FilePath}=data
 
  Linking.openURL(fileip+"/DocumentDownloadIOS?FPath="+FilePath+"&FileName="+AttachFileName) 
 
 }

submit(){
  switch (selectedButton) {
      case "Approve":
          AppStatus = "A";
          break;
      case "Reject":
            AppStatus = "R";
            break;
      case "ReWork":
          AppStatus = "W";
          break;      
  }
  if(AppStatus!=="A"){
    if(this.state.Comments.length === 0) {
      alert("Please Enter Comment")
      return
    }
  }
  this.Save();
}
Save(){
  this.setState({isLoading:true})
    let url=''
    if(AppStatus==='A'){
     url='/setSupplierApp'
    }else if(AppStatus=='R'){
      url='/setSupplierRej'
    }else if(AppStatus==='W'){
     url='/setSupplierRew'
    }  
  
    axios({
      method: 'post',
      url:ip+url,
      headers: {'currentToken':tokken}, 
      data: {
        supcode:this.state.SupCode,       
        comments:this.state.Comments,  
        currency:this.state.Comments,   
        status:this.state.AppStatus,    
        seqno:this.state.Seq,
        ver:this.state.Ver,       
      }
    }).then(response=>{if(response.status===200){
      this.setState({isLoading:false},()=>{
        this.refs.toast.showBottom("Submitted Successfully")
  
  
        this.props.navigation.goBack();
  
       
      })
    }else{
      this.refs.toast.showBottom("Failed")
    }})
    .catch(err => 
      {
        this.setState({
          isLoading:false
        },()=>{
         let error=err
         
         this.refs.toast.showBottom(error.toString())
  
         setTimeout(
          () => { 
            this.props.navigation.goBack();
           },
          2000
        )
  
        })
      }
      );
  }

onPress = radiovalues => this.setState({ radiovalues});

render() {
    selectedButton = this.state.radiovalues.find(e => e.selected == true);
    selectedButton = selectedButton ? selectedButton.value : this.state.radiovalues[0].label;   
      if (this.state.isLoading) {
          return (
            <Modal
            transparent={false}
            supportedOrientations={['portrait', 'landscape']}
            visible={this.state.isLoading}
            >
             <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
              <Image
              style={{width: 300, height: 200}}
              source={require('../src/gears.gif')}  />
              </View>     
            </Modal>
          )
      }

      return (
    <View style={{flex:1,backgroundColor:lightblue }}> 
    <KeyboardAvoidingView 
        behavior='padding'
        keyboardVerticalOffset={
        Platform.select({
           ios: () => 0,
           android: () => 60
        })()
        }>
  <ScrollView style={{height:"100%"}}>

  <Modal            
          animationType = {"slide"}  
          transparent = {true}  
          visible = {this.state.isStatus}  
          onRequestClose = {() =>{ console.log("Modal has been closed.") } }>  
          {/*All views of Modal*/}  
          <View style = {styles.modal}>  

          <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress = {() =>
           {  
            this.setState({ isStatus:!this.state.isStatus})
           }}>
        
        <Grid style={{width:'100%'}}>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontFamily:'Bold',alignSelf:'flex-start'}}>
             Approval Timeline
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('../src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
       </Grid>

          </TouchableOpacity>


          <Timeline 
          style={styles.list}
          data={this.state.DisStatusData}
          circleSize={25}
          showTime={false}
          circleColor='rgba(0,0,0,0)'
          lineColor='rgb(45,156,219)'
          descriptionStyle={{color:'gray',fontFamily:'Regular'}}
          innerCircle={'icon'}
        />
          </View>
          
  </Modal>

  <Overlay
  width="85%"
  height="75%"
  animationType="slide"
  isVisible={this.state.isVisibleDetail}
  onBackdropPress={() => this.setState({ isVisibleDetail: false })}> 
          {/*All views of Modal*/}  

          <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress = {() =>
           {  
            this.setState({ isVisibleDetail:!this.state.isVisibleDetail})
           }}>

         <Grid>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontFamily:'Bold',alignSelf:'flex-start'}}>
             Supplier Detail
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('../src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
       </Grid>
        

         </TouchableOpacity>
            
             <View  style={{ flex: 1,paddingTop:5}}>
             
             <Grid style={{width:'97%',alignSelf:'center'}}>
  
              <Row>
              <Col style={{alignItems:'flex-start',width:'20%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Code</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'80%'}}>
              <Text style={{fontSize:13,color:gray,fontFamily:'Regular'}}>{this.state.SupCode.trim()}</Text>
              </Col> 
              </Row>
              
              <Row>
              <Col style={{alignItems:'flex-start',width:'20%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Name</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'80%'}}>
              <Text style={{fontSize:13,color:gray,fontFamily:'Regular'}}>{this.state.SupName}</Text>
              </Col> 
              </Row>
              <Row>
              <Col style={{alignItems:'flex-start',width:'20%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Email</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'80%'}}>
              <Text style={{fontSize:13,color:gray,fontFamily:'Regular'}}>{this.state.Email}</Text>
              </Col> 
              </Row>
              <Row>
              <Col style={{alignItems:'flex-start',width:'20%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Mobile</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'80%'}}>
              <Text style={{fontSize:13,color:gray,fontFamily:'Regular'}}>{this.state.Mobile}</Text>
              </Col> 
              </Row>
              <Row>
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Fax</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'50%'}}>
              <Text style={{fontSize:13,color:gray,fontFamily:'Regular'}}>{this.state.Fax}</Text>
              </Col> 
              </Row>

              <Divider></Divider>
              <Divider></Divider>
              <Divider></Divider>

              <Row>
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Address 1</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'50%'}}>
              <Text style={{fontSize:13,color:gray,fontFamily:'Regular'}}>{this.state.Add1}</Text>
              </Col> 
              </Row>

            
              <Row>
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Address 2</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'50%'}}>
              <Text style={{fontSize:13,color:gray,fontFamily:'Regular'}}>{this.state.Add2}</Text>
              </Col> 
              </Row>

              <Row>
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Address 3</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'50%'}}>
              <Text style={{fontSize:13,color:gray,fontFamily:'Regular'}}>{this.state.Add3}</Text>
              </Col> 
              </Row>


              <Row>
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Address 4</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'50%'}}>
              <Text style={{fontSize:13,color:gray,fontFamily:'Regular'}}>{this.state.Add4}</Text>
              </Col> 
              </Row>

              <Row>
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>GL Category</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'50%'}}>
              <Text style={{fontSize:13,color:gray,fontFamily:'Regular'}}>{this.state.Category}</Text>
              </Col> 
              </Row>

              <Row>
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Trade Category</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'50%'}}>
              <Text style={{fontSize:13,color:gray,fontFamily:'Regular'}}>{this.state.Tcategory}</Text>
              </Col> 
              </Row>
          
              <Divider></Divider>
              <Divider></Divider>
              <Divider></Divider>

            
              <Row>
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Country</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'50%'}}>
              <Text style={{fontSize:13,color:gray,fontFamily:'Regular'}}>{this.state.CountryName}</Text>
              </Col> 
              </Row>


               <Row>
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>City</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'50%'}}>
              <Text style={{fontSize:13,color:gray,fontFamily:'Regular'}}>{this.state.City}</Text>
              </Col> 
              </Row>

              <Row>
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Currency</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'50%'}}>
              <Text style={{fontSize:13,color:gray,fontFamily:'Regular'}}>{this.state.Currency}</Text>
              </Col> 
              </Row>

              <Row>
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Pay Terms</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'50%'}}>
              <Text style={{fontSize:13,color:gray,fontFamily:'Regular'}}>{this.state.Payterm.trim()}</Text>
              </Col> 
              </Row>


              <Row>
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>CR No</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'50%'}}>
              <Text style={{fontSize:13,color:gray,fontFamily:'Regular'}}>{this.state.Crno}</Text>
              </Col> 
              </Row>


              <Row>
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Vat No</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'50%'}}>
              <Text style={{fontSize:13,color:gray,fontFamily:'Regular'}}>{this.state.Crno}</Text>
              </Col> 
              </Row>


             </Grid>


             </View>
             
  </Overlay>

    <View  style={{ flex: 1,paddingTop:2,paddingBottom:2}}>
    <Grid style={{paddingTop:'2%'}}>
    <Row style={{backgroundColor:colorprimary,padding:5,width:'97%',
    alignSelf:'center',alignItems:'center',borderRadius:2}}>
    <Col style={{alignItems:'center',width:'100%'}}>
    <Text style={styles.titleText}>Supplier Approval</Text>
    </Col>
    </Row>
    </Grid>
    </View>

     <Card style={{width:'97%',alignSelf:'center'}}>
               <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
                  paddingLeft:5,paddingRight:5,paddingTop:5,paddingBottom:5}}>
               <Grid>
               <Row style={{paddingTop:2,paddingBottom:3,}}>
               <Col style={{alignItems:'flex-start',width:'30%'}}>
               <Text style={styles.testHead}>Supp. Name : </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'70%'}}>
               <Text style={{fontSize:12,color:black,fontFamily:'Regular'}}>{this.state.SupName+'['+this.state.SupCode.trim()+']'}</Text>
               </Col>
               </Row>         
               </Grid>   
               </CardItem>
   </Card>


   <Card style={{width:'97%',alignSelf:'center',paddingBottom:'1%'}}>
               <CardItem style={{alignItems:"center",width:'100%',flexWrap:'wrap',paddingTop:10,
             paddingBottom:10,paddingLeft:5,paddingRight:5}}>

    <Grid>
    <Row style={{backgroundColor:colorprimary,padding:5,alignSelf:'center',alignItems:'center'}}>
    <Col style={{alignItems:'center',width:'100%'}}>
    <Text style={styles.titleText}>Supplier Detail</Text>
    </Col>
    </Row>
               

            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Country</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.tvalue}>{this.state.CountryName}</Text>
              </Col> 
            </Row>

            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>City</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.tvalue}>{this.state.City}</Text>
              </Col> 
            </Row>


            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>CR No</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.tvalue}>{this.state.Crno}</Text>
              </Col> 
            </Row>


            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>VAT</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.tvalue}>{this.state.Vatno}</Text>
              </Col> 
            </Row>


            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>GL Category</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.tvalue}>{this.state.Category}</Text>
              </Col> 
            </Row>


            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Material Category</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.tvalue}>{this.state.Tcategory}</Text>
              </Col> 
            </Row>
          
            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Pay Terms</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.tvalue}>{this.state.Payterm}</Text>
              </Col> 
            </Row>

            <Row style={styles.rowpadding}>
             <Col style={{width:'33%',alignItems:'flex-start'}}>
              </Col> 
              <Col style={{width:'34%',alignItems:'flex-start'}}>
             

              <Button onPress={() =>this.getdetail()} 
              raised={true}
              titleStyle={{fontSize:12,textAlign:'center',fontFamily:'Bold'}}
              buttonStyle={{
               flex:1,
               borderRadius:6,
               width:width*25/100,
               height:30
              }}
            
             title=" Detail "/>

              </Col> 
              <Col style={{width:'33%',alignItems:'flex-start'}}>
              </Col> 
            </Row>


                  <Divider color={dark}></Divider>
                  <Divider color={dark}></Divider>
                  <Divider color={dark}></Divider>
    </Grid>   
    </CardItem>
    </Card>     

 
{/* Doc List
 */}

<View  style={{display:this.state.isAttachment==true?'flex':'none',flex: 1,paddingTop:5}}>
            <Grid style={{backgroundColor:colorprimary,padding:5,width:'97%',
            alignSelf:'center',alignItems:'center',borderRadius:2}}>
              <Row>
              <Col style={{alignItems:'center',width:'100%'}}>
              <Text style={{color:white,fontSize:13,fontFamily:'Bold'}}>Attachments</Text>
              </Col>
              </Row>
            </Grid>

            <FlatList
       data={ this.state.DocList}
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',paddingTop:8,
            paddingBottom:8}}>
            <Grid onPress={this.DownloadDoc.bind(this,item)}>
              <Row>
              <Col style={{alignItems:'flex-start',width:'10%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-start',fontFamily:'Regular'}}>{item.SlNo}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'90%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-start',fontFamily:'Regular'}}>{item.AttachFileName}</Text>
              </Col> 
              </Row>
            </Grid>  
             </CardItem>
           </Card>
        }

       keyExtractor={(item, index) => index.toString()}
       
      />
</View>

 {/* Bank List
 */}

<View  style={{flex: 1,paddingTop:5}}>

            <Grid style={{backgroundColor:colorprimary,padding:5,width:'97%',
            alignSelf:'center',alignItems:'center'}}>
              <Row>
              <Col style={{alignItems:'center',width:'100%'}}>
              <Text style={{color:white,fontSize:13,fontFamily:'Bold'}}>Bank Detail</Text>
              </Col>
              </Row>
            </Grid>

            <FlatList
       data={ this.state.BankList}
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
            <Grid>

              <Row>
              <Col style={{alignItems:'flex-start',width:'10%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-start',fontFamily:'Regular'}}>{item.bid}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'90%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-start',fontFamily:'Regular'}}>{item.bname}</Text>
              </Col> 
              </Row>

            <Divider></Divider>
            <Divider></Divider>
            <Divider></Divider>

            <Row>
              <Col style={{alignItems:'flex-start',width:'25%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-start',
               fontFamily:'Bold',color:colorprimary}}>Acc Name : </Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'75%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-start',fontFamily:'Regular'}}>{item.accname}</Text>
              </Col> 
              </Row>


            </Grid>  
             </CardItem>
           </Card>
        }

       keyExtractor={(item, index) => index.toString()}
       
      />
</View>

     <Card style={{width:'97%',alignSelf:"center"}}>
                <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
                <Item>
                <Input placeholder="Approval Comments"
                value={this.state.Comments}
                style={{fontFamily:'Regular'}}
                onChangeText={val => this.setState({ Comments: val })}
               />
               </Item>
              </CardItem>
              <CardItem style={{paddingLeft:20}}>       
              <RadioGroup flexDirection='row' 
              radioButtons={this.state.radiovalues} onPress={this.onPress} />
               </CardItem>
              </Card>

        
              <Grid style={{padding:4,width:"97%",alignSelf:'center',paddingBottom:5}}>
             <Row>
             <Col style={{alignItems:'center',width:'50%'}}>
             <Button onPress={() =>this.getStatus()} 
             raised={true}
             titleStyle={{fontSize:15,textAlign:'center',fontFamily:'Bold'}}
             buttonStyle={{
               flex:1,
               borderRadius:6,
               width:120,
               height:45
             }}
            
             title=" Status "/>
             </Col> 
             <Col style={{alignItems:'center',width:'50%'}}>
             <Button onPress={() =>this.submit()} 
              raised={true}
              titleStyle={{fontSize:15,textAlign:'center',fontFamily:'Bold'}}
              buttonStyle={{
               flex:1,
               borderRadius:6,
               width:120,
               height:45
              }}
            
             title=" Submit "/>
             </Col> 
             </Row>
            </Grid>
         

          <Toast ref="toast"/>
          </ScrollView>
          </KeyboardAvoidingView>
          </View>
      );
  }
}

const styles = StyleSheet.create({
  rowpadding:{
    paddingTop:4,
    paddingBottom:4
},
  ButtonSection: {

      paddingTop:3,
      width: '100%',
      justifyContent: 'center',
      alignItems: 'center',
      paddingBottom:10
   },

container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
},
sectionHeader: {
    fontSize: 13,
    fontWeight: 'bold',
    color:'#fff',
},
itemView: {
  flex: 1,
  width,
  borderBottomWidth: 0.5,
  borderColor: '#cdcdcd',
  borderStyle: 'solid',
  paddingHorizontal: 12,
  flexDirection: 'row',
  paddingTop:2
},
textContent:{
color:white,
fontSize:12,
fontFamily:'Bold'
},

textTotalContent:{
color:'#3A6705',
fontSize:12,
fontFamily:'Bold'
},
htitle:{
  color:'#36428a',
  fontSize:14,
  alignSelf:'flex-start',
  fontFamily:'Bold'
 },
 tvalue:{
  alignSelf:'flex-end',
  fontSize:14,
  color:black,
  fontFamily:'Bold'
 },
testHead:{
  width:"100%",
  fontSize:13,
  color:colorprimary,
  fontFamily:'Bold',
  textAlign:'right',
  
},
CButton:{
  paddingTop:8,
  height:45,
  width:80,
  paddingBottom:4
},
imagebutton: {
  width:30,
  height: 30,        
},
modal: {  
  flex:1,
  width:'100%',
  backgroundColor:white,
  height:'auto',
  position: 'absolute',
  bottom: 0
   },
   headerback: {
    flexDirection: 'row',
    alignItems:'center',
    backgroundColor: colorprimary,
    borderWidth: 0.5,
    borderColor:white,
    height: 40,
    width:'100%',
    borderRadius: 5,
  },
  titleText: {
    flex:1,
    flexWrap:'wrap',
    color:white,
    fontSize:13,
    fontFamily:'Bold'
  },
  carditem:{
    alignItems:"flex-start",width:'100%',flexWrap:'wrap',
          paddingLeft: 5,
          paddingRight: 5,
          paddingTop: 10,
          paddingBottom: 10
  }
});

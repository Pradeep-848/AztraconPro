import React from 'react';
import { ScrollView,Dimensions,Image,Modal,StyleSheet,Text,View,TouchableOpacity,Alert,
         KeyboardAvoidingView,Platform} from 'react-native';
import axios from 'axios';
import { Col, Grid, Row} from 'react-native-easy-grid';
import {Card,CardItem,Item,Input,Spinner} from 'native-base';
import RadioGroup from 'react-native-radio-buttons-group';
import { NavigationActions, StackActions } from 'react-navigation';
import strings from '../res/strings'
import {logouttask} from '../class/logout';
import Toast from 'react-native-whc-toast'
import color from '../res/colors'
import { Divider,Button,Overlay } from 'react-native-elements';
import Timeline from 'react-native-timeline-flatlist'
import moment from 'moment';

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const { width, height } = Dimensions.get('window');

const lightblue=color.values.Colors.lightblue;
const blue=color.values.Colors.blue;
const colorprimary=color.values.Colors.colorPrimary;
const dark=color.values.Colors.colorprimarydark;
const white=color.values.Colors.white;
const black=color.values.Colors.black;
const gray=color.values.Colors.gray;

let selectedButton;
let AppStatus;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class EmployeeJoiningApproval extends React.Component{
  static navigationOptions = ({ navigation }) => ({ 
    title: "HR Approval",
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor:white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('../src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
      super(props);
      this.state = { 
        isLoading: true, 
        isStatus:false,
        data:[],Statusdata:[],DisStatusData:[],
        vrm:"",handlelogin:'',UserID:'',SalDate:'',AppID:'',dept:'',Comments:'',
        AppStatus:'',Seq:'',Ver:'',EmpID:'',EmpName:'',Designation:'',DOJ:'',JobPos:'',Country:'',Countryname:'',DeptCode:'',
        DeptName:'',ReqBy:'',ReqName:'',ReqDate:'',AppType:'',
        radiovalues: [
            {
                label: 'Approve',
                value: "Approve",
                color:'#2452b2'
            },
            {
                label: 'Reject',
                value: "Reject",
                color:'#2452b2'
            },
            {
                label: 'ReWork',
                value: 'ReWork',
                color:'#2452b2'
            },
          
        ],
    };
      this.arrayholder = [] ;
  }

  login = async () => 
  {
  
    Alert.alert(
      'Logout',
      'Would you like to logout?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {text: 'OK', onPress: () => { logouttask()
          this.props.navigation.dispatch(resetAction);} },
      ],
      {cancelable: false},
    );
   
  }
  

componentDidMount() {
  console.disableYellowBox = true;

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
 
  this.setState({
    UserID:this.props.navigation.getParam('UserID', ''),
    AppID:this.props.navigation.getParam('AppID', ''),
    AppType:this.props.navigation.getParam('AppType', ''),
    Seq:this.props.navigation.getParam('Seq', ''),
    Ver:this.props.navigation.getParam('Ver', ''),
    },()=>{this.getEmpJoinData();})
}

format(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

getEmpJoinData(){
  

    const config = {
      headers: {   
      'currentToken':tokken,
    },
      params: {
        appid:this.state.AppID,
      }
    };
    this.setState({isLoading:true});
    axios.get(ip+'/getEmpJoinData', config)
  .then(response => this.setState({data:response.data},() => {if(response.status==200){

    const{empid,empname,designation,doj,jobpos,country,deptcode,countryname,
        deptname,reqby,reqname,reqdate}=this.state.data

    this.setState({
        EmpID:empid,EmpName:empname,Designation:designation,DOJ:doj,JobPos:jobpos,
        Country:country,Countryname:countryname,DeptCode:deptcode,
        DeptName:deptname,ReqBy:reqby,ReqName:reqname,ReqDate:reqdate,
        isLoading:false});
    }
}))
.catch(err => 
  {
    this.setState({
      isLoading:false
    },()=>{
     let error=err
     
     this.refs.toast.showBottom(error.toString())

     setTimeout(
      () => { 
        this.props.navigation.goBack();
       },
      2000
    )

    })
  }
  );
  
}

getStatus(){

  this.setState({isLoading:true, StatusData:[],DisStatusData:[]})

   const config = {
       headers: {   
       'currentToken':tokken,
     },
       params: {
        appid:this.state.AppID,
        ver:this.state.Ver,
       }
       
     };

 axios.get(ip+'/getEmpJoinStatus', config)
   .then(response => this.setState({StatusData:response.data},() => {if(response.status==200){
   this.display()
   }}))
   .catch(err => 
     {
       this.setState({
         isLoading:false
       },()=>{
        let error=err
        
        this.refs.toast.showBottom(error.toString())
 
        setTimeout(
         () => { 
           this.props.navigation.goBack();
          },
         2000
       )
 
       })
     }
     );

}

display(){
  for(i=0;i< this.state.StatusData.length ;i++){
      const{E,C,D,A,F}=this.state.StatusData[i]
      let Desc,tit
      if(E!==''){
        if(D!=='' && D!=null){
          if (F=='O' || F=='P') {
            Desc=C+"\n"+"Remarks : "+E
          }else{
            Desc=C+"\n"+moment(D).format('DD-MM-YYYY').toString()+"\n"+"Remarks : "+E
          }
         
        }
        else{
          Desc=C+"\n"+"Remarks : "+E
        }
        
      }else{

        if(D!=='' && D!=null){

          if (F=='O' || F=='P') {
            Desc=C
          }else{
            Desc=C+"\n"+moment(D).format('DD-MM-YYYY').toString()
          }
       
        }else{
          Desc=C
        }
        
      }

      if(F==='A'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#15ca7d",
              icon:require('../src/ic_approved.png')
          })
      }else if(F==='P'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc, 
              lineColor:"#f4b825",
              icon:require('../src/ic_pending.png')
          })
      }else if(F==='R'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#f6634b",
              icon:require('../src/ic_rejected.png')
          })
      }else if(F==='O'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#2d353a",
              icon:require('../src/ic_opened.png')
          })
      }else if(F=='W'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#2d353a",
              icon:require('../src/ic_opened.png')
          })
      }
  
    }
    this.setState({isLoading:false,isStatus:true})
}


/* display(){
  for(let i=0;i< this.state.StatusData.length ;i++){
      const{E,C}=this.state.StatusData[i]
      let Desc
      if(E!==''){
        Desc=C+"\n"+"Remarks : "+E
      }else{
          Desc=C
      }
      const{D,A,F}=this.state.StatusData[i]

      if(F==='A'){
        let head
        if(moment(D).format('DD-MM-YYYY')=='Invalid date'){
          head=A
        }else{
          head=moment(D).format('DD-MM-YYYY')+"\n"+A
        }

          this.state.DisStatusData.push({
              time:moment(D).format('DD-MM-YYYY'),
              title:head,
              description:Desc,
              lineColor:"#15ca7d",
              icon:require('../src/ic_approved.png')
          })
      }else if(F==='P'){

        let head
        if(moment(D).format('DD-MM-YYYY')=='Invalid date'){
          head=A
        }else{
          head=moment(D).format('DD-MM-YYYY')+"\n"+A
        }

          this.state.DisStatusData.push({
              time:moment(D).format('DD-MM-YYYY'),
              title:head,
              description:Desc,
              lineColor:"#f4b825",
              icon:require('../src/ic_pending.png')
          })
      }else if(F==='R'){
        let head
        if(moment(D).format('DD-MM-YYYY')=='Invalid date'){
          head=A
        }else{
          head=moment(D).format('DD-MM-YYYY')+"\n"+A
        }
          this.state.DisStatusData.push({
              time:moment(D).format('DD-MM-YYYY'),
              title:head,
              description:Desc,
              lineColor:"#f6634b",
              icon:require('../src/ic_rejected.png'),
          })
      }else if(F==='O'){

        let head
        if(moment(D).format('DD-MM-YYYY')=='Invalid date'){
          head=A
        }else{
          head=moment(D).format('DD-MM-YYYY')+"\n"+A
        }

          this.state.DisStatusData.push({
              time:moment(D).format('DD-MM-YYYY'),
              title:head,
              description:Desc,
              lineColor:"#2d353a",
              icon:require('../src/ic_opened.png')
          })
      }else if(F=='W'){

        let head
        if(moment(D).format('DD-MM-YYYY')=='Invalid date'){
          head=A
        }else{
          head=moment(D).format('DD-MM-YYYY')+"\n"+A
        }

          this.state.DisStatusData.push({
              time:moment(D).format('DD-MM-YYYY'),
              title:head,
              description:Desc,
              lineColor:"#2d353a",
              icon:require('../src/ic_opened.png')
          })
      }
  
    }
    console.log(this.state.DisStatusData)
    this.setState({isLoading:false,isStatus:true})
} */

submit(){
  switch (selectedButton) {
      case "Approve":
          AppStatus = "A";
          break;
      case "Reject":
            AppStatus = "R";
            break;
      case "ReWork":
          AppStatus = "W";
          break;      
  }
  if(AppStatus!=="A"){
    if(this.state.Comments.length === 0) {
      alert("Please Enter Comment")
      return
    }
  }
  this.Save();
}

DOCUMENT(){


  this.props.navigation.navigate('DocumentActivity',{
    UserID:this.state.UserID,
    DocType:this.state.AppType,
    Param1:this.state.AppID,
    Param2:'0',
});

}

Save(){
this.setState({isLoading:true})
  let url=''
  if(AppStatus==='A'){
   url='/setEmpJoinApp'
  }else if(AppStatus=='R'){
    url='/setEmpJoinRej'
  }else if(AppStatus==='W'){
   url='/setEmpJoinRew'
  }  

  axios({
    method: 'post',
    url:ip+url,
    headers: {'currentToken':tokken}, 
    data: {
      appid:this.state.AppID,       
      userid:this.state.UserID,  
      comments:this.state.Comments,   
      status:this.state.AppStatus,    
      seqno:this.state.Seq,
      ver:this.state.Ver,       
    }
  }).then(response=>{if(response.status===200){
    this.setState({isLoading:false},()=>{
      this.refs.toast.showBottom("Submitted Successfully")

       this.props.navigation.goBack();

    })
  }else{
    this.refs.toast.showBottom("Failed")
  }})
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
}

onPress = radiovalues => this.setState({ radiovalues});

render() {
    selectedButton = this.state.radiovalues.find(e => e.selected == true);
    selectedButton = selectedButton ? selectedButton.value : this.state.radiovalues[0].label;   
      if (this.state.isLoading) {
          return (
            <Modal
            transparent={false}
            supportedOrientations={['portrait', 'landscape']}
            visible={this.state.isLoading}
            >
             <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
              <Image
              style={{width: 300, height: 200}}
              source={require('../src/gears.gif')}  />
              </View>     
            </Modal>
          )
      }

      return (
    <View style={{flex:1, backgroundColor:lightblue}}> 
    <KeyboardAvoidingView 
        behavior='padding'
        keyboardVerticalOffset={
        Platform.select({
           ios: () => 0,
           android: () => 60
        })()
        }>
  <ScrollView style={{height:"100%"}}>

  <Modal            
          animationType = {"slide"}  
          transparent = {true}  
          visible = {this.state.isStatus}  
          onRequestClose = {() =>{ console.log("Modal has been closed.") } }>  
          {/*All views of Modal*/}  
          <View style = {styles.modal}>  
          <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress = {() =>
           {  
            this.setState({ isStatus:!this.state.isStatus})
           }}>
        
        <Grid>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontFamily:'Bold',alignSelf:'flex-start'}}>
             Approval Timeline
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('../src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
       </Grid>
        

         </TouchableOpacity>


         <Timeline 
          style={styles.list}
          data={this.state.DisStatusData}
          circleSize={25}
          showTime={false}
          circleColor='rgba(0,0,0,0)'
          lineColor='rgb(45,156,219)'
          descriptionStyle={{color:'gray',fontFamily:'Regular'}}
          innerCircle={'icon'}
        />

          </View>
  </Modal>

 

    <View  style={{ flex: 1,paddingTop:2,paddingBottom:2}}>
    <Grid style={{paddingTop:'2%'}}>
    <Row style={{backgroundColor:colorprimary,padding:5,width:'97%',
    alignSelf:'center',alignItems:'center',borderRadius:2}}>
    <Col style={{alignItems:'center',width:'100%'}}>
    <Text style={styles.titleText}>Employee Joining Approval</Text>
    </Col>
     </Row>
     </Grid>
    </View>

    <Card style={{width:'97%',alignSelf:'center'}}>
               <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
                  paddingLeft:5,paddingRight:5,paddingTop:5,paddingBottom:5}}>
               <Grid>
               <Row style={{paddingTop:2,paddingBottom:3,}}>
               <Col style={{alignItems:'flex-start',width:'30%'}}>
               <Text style={styles.testHead}>Request By : </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'70%'}}>
               <Text style={{fontSize:12,color:black,fontFamily:'Regular'}}>{this.state.ReqName+'['+this.state.ReqBy+']'}</Text>
               </Col>
               </Row>         
               <Row style={{paddingTop:3,paddingBottom:3}}>
               <Col style={{alignItems:'flex-start',width:'30%'}}>
               <Text style={styles.testHead}>Request Date : </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'70%'}}>
               <Text style={{fontSize:12,color:black,fontFamily:'Regular'}}>{this.state.ReqDate}</Text>
               </Col>
               </Row>                   
               </Grid>   
               </CardItem>
   </Card>
   <Card style={{width:'97%',alignSelf:'center',paddingBottom:'1%'}}>
               <CardItem style={{alignItems:"center",width:'100%',flexWrap:'wrap',paddingTop:10,
             paddingBottom:10,paddingLeft:5,paddingRight:5}}>

    <Grid>
    <Row style={{backgroundColor:colorprimary,padding:5,alignSelf:'center',alignItems:'center'}}>
    <Col style={{alignItems:'center',width:'100%'}}>
    <Text style={styles.titleText}>Detail</Text>
    </Col>
    </Row>
               

            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Emp. No</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.tvalue}>{this.state.EmpID}</Text>
              </Col> 
            </Row>

            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Emp. Name</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.tvalue}>{this.state.EmpName}</Text>
              </Col> 
            </Row>


            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Country</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.tvalue}>{this.state.Countryname}</Text>
              </Col> 
            </Row>


            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Department</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.tvalue}>{this.state.DeptName}</Text>
              </Col> 
            </Row>


            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Job Title</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.tvalue}>{this.state.Designation}</Text>
              </Col> 
            </Row>


            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Joining Date</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.tvalue}>{this.state.DOJ}</Text>
              </Col> 
            </Row>
          
                  <Divider color={dark}></Divider>
                  <Divider color={dark}></Divider>
                  <Divider color={dark}></Divider>
    </Grid>   
    </CardItem>
    </Card>     

     <Card style={{width:'97%',alignSelf:"center"}}>
                <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
                <Item>
                <Input placeholder="Approval Comments"
                value={this.state.Comment}
                style={{fontFamily:'Regular'}}
                onChangeText={val => this.setState({ Comments: val })}
               />
               </Item>
              </CardItem>
              <CardItem style={{paddingLeft:20}}>       
              <RadioGroup flexDirection='row' 
              radioButtons={this.state.radiovalues} onPress={this.onPress} />
               </CardItem>
              </Card>

        
              <Grid style={{padding:4,width:"97%",alignSelf:'center',paddingBottom:5}}>
             <Row>
             <Col style={{alignItems:'center',width:'33%'}}>
             <Button onPress={() =>this.getStatus()} 
             raised={true}
             titleStyle={{fontSize:15,textAlign:'center',fontFamily:'Bold'}}
             buttonStyle={{
               flex:1,
               borderRadius:6,
               width:100,
               height:45
             }}
            
             title=" Status "/>
             </Col> 

             <Col style={{alignItems:'center',width:'34%'}}>
             <Button onPress={() =>this.DOCUMENT()} 
             raised={true}
             titleStyle={{fontSize:15,textAlign:'center',fontFamily:'Bold'}}
             buttonStyle={{
               flex:1,
               borderRadius:6,
               width:100,
               height:45
             }}
            
             title=" Documents "/>
             </Col> 

             <Col style={{alignItems:'center',width:'33%'}}>
             <Button onPress={() =>this.submit()} 
              raised={true}
              titleStyle={{fontSize:15,textAlign:'center',fontFamily:'Bold'}}
              buttonStyle={{
               flex:1,
               borderRadius:6,
               width:100,
               height:45
              }}
            
             title=" Submit "/>
             </Col> 
             </Row>
            </Grid>
          
          

          <Toast ref="toast"/>
          </ScrollView>
          </KeyboardAvoidingView>
          </View>
      );
  }
}

const styles = StyleSheet.create({

    rowpadding:{
        paddingTop:4
    },
    ButtonSection: {

        paddingTop:3,
        width: '100%',
        justifyContent: 'center',
        alignItems: 'center',
        paddingBottom:10
     },

  container: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: '#F5FCFF',
  },
    textContentHead: {
      backgroundColor:'#fff',
      fontSize: 14,
      color: '#36428a',
      fontWeight: 'bold',
      textShadowColor: 'rgba(0, 0, 0, 0.75)',
      textShadowOffset: {width: -1, height: 1},
      textShadowRadius: 10
    },
  itemView: {
    flex: 1,
    width,
    borderBottomWidth: 0.5,
    borderColor: '#cdcdcd',
    borderStyle: 'solid',
    paddingHorizontal: 12,
    flexDirection: 'row',
    paddingTop:2
},
textContent:{
  color:white,
  fontSize:12
},

textTotalContent:{
  color:'#3A6705',
  fontSize:12,
  fontFamily:'Bold'
},

testHead:{
    width:"100%",
    fontSize:13,
    color:colorprimary,
    fontFamily:'Bold',
    textAlign:'right',
    
},
CButton:{
    paddingTop:8,
    height:45,
    width:80,
    paddingBottom:4
},
imagebutton: {
    width:30,
    height: 30,        
  },
  modal: {  
    flex:1,
    width:'100%',
    backgroundColor:white,
    height:'auto',
    position: 'absolute',
    bottom: 0
     },
     headerback: {
      flexDirection: 'row',
      alignItems:'center',
      backgroundColor: colorprimary,
      borderWidth: 0.5,
      borderColor:white,
      height: 40,
      width:'100%',
      borderRadius: 5,
    },
    titleText: {
      flex:1,
      flexWrap:'wrap',
      color:white,
      fontSize:13,
      fontFamily:'Bold'
    },
    htitle:{
        color:'#36428a',
        fontSize:14,
        alignSelf:'flex-start',
        fontFamily:'Bold'
       },
       tvalue:{
        alignSelf:'flex-start',
        fontSize:14,
        color:black,
        fontFamily:'Bold'
       },
});


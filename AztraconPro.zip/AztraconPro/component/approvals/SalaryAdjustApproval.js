  import React from 'react';
import {ScrollView,Dimensions,Image,Modal,StyleSheet,
  Text,View,TouchableOpacity,Alert,KeyboardAvoidingView,Platform,
  FlatList,Linking} from 'react-native';
import axios from 'axios';
import { Col, Grid, Row} from 'react-native-easy-grid';
import {Card,CardItem,Item,Input,Spinner} from 'native-base';
import RadioGroup from 'react-native-radio-buttons-group';
import { NavigationActions, StackActions } from 'react-navigation';
import strings from '../res/strings'
import {logouttask} from '../class/logout';
import Toast from 'react-native-whc-toast'
import color from '../res/colors'
import { Divider,Button,Overlay } from 'react-native-elements';
import Timeline from 'react-native-timeline-flatlist'
import moment from 'moment';
import { CustomButton } from '../custom-button.js';
import * as Font from 'expo-font'

const ip=strings.values.commonvalues.ip;
const fileip=strings.values.commonvalues.fileip;
const tokken=strings.values.commonvalues.tokken;

const { width, height } = Dimensions.get('window');

const lightblue=color.values.Colors.lightblue;
const blue=color.values.Colors.blue;
const colorprimary=color.values.Colors.colorPrimary;
const dark=color.values.Colors.colorprimarydark;
const white=color.values.Colors.white;
const black=color.values.Colors.black;
const gray=color.values.Colors.gray;

let selectedButton;
let AppStatus;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class SalaryAdjustApproval extends React.Component{
  static navigationOptions = ({ navigation }) => ({ 
    title: "HR Approval",
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor:white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('../src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
      super(props);
      this.state = { 
        isLoading: true, 
        isAttachment:false,
        isStatus:false,
        AppType:'',
        data:[],DocDataSource:[],Statusdata:[],DisStatusData:[],
        vrm:"",handlelogin:'',UserID:'',SalDate:'',AppID:'',dept:'',Comments:'',
        AppStatus:'',Seq:'',Ver:'',dept:'',desig:'',Basic:'',Hallowance:'',Transpot:'',Food:'',Allowance:'',Oallowance:'',
        GOSI:'',ODect:'',Tallowance:'',TDect:'',NetPay:'',empname:'',EffDate:'',
        nBasic:'',nHallowance:'',nTranspot:'',nFood:'',nAllowance:'',nOallowance:'',
        nGOSI:'',nODect:'',nTallowance:'',nTDect:'',nNetPay:'',Comment:'',
        radiovalues: [
            {
                label: 'Approve',
                value: "Approve",
                color:'#2452b2'
            },
            {
                label: 'Reject',
                value: "Reject",
                color:'#2452b2'
            },
            {
                label: 'ReWork',
                value: 'ReWork',
                color:'#2452b2'
            },
          
        ],
    };
      this.arrayholder = [] ;
  }

  login = async () => 
  {
  
    Alert.alert(
      'Logout',
      'Would you like to logout?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {text: 'OK', onPress: () => { logouttask()
          this.props.navigation.dispatch(resetAction);} },
      ],
      {cancelable: false},
    );
   
  }
  

componentDidMount() {
  console.disableYellowBox = true;

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
 
  this.setState({
    UserID:this.props.navigation.getParam('UserID', ''),
    AppID:this.props.navigation.getParam('AppID', ''),
    AppType:this.props.navigation.getParam('AppType', ''),
    Seq:this.props.navigation.getParam('Seq', ''),
    Ver:this.props.navigation.getParam('Ver', ''),
    },()=>{this.getSalAppData();})
}

format(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

getSalAppData(){
  

    const config = {
      headers: {   
      'currentToken':tokken,
    },
      params: {
        pid:this.state.AppID,
      }
    };
    this.setState({isLoading:true});
    axios.get(ip+'/getSalAppData', config)
  .then(response => this.setState({data:response.data},() => {if(response.status==200){


    for(let i=0;i<this.state.data.length;i++){
        const{flag,dept,desig,ba,ha,ta,fa,al,oa,go,od,tall,tdet,net,empname,empid,effdate}=this.state.data[i]
        if(flag=='C'){
            this.setState({
                dept:dept,desig:desig,Basic:ba,Hallowance:ha,Transpot:ta,Food:fa,Allowance:al,Oallowance:oa,
                GOSI:go,ODect:od,Tallowance:tall,TDect:tdet,NetPay:net,empname:empname+'['+empid+']',EffDate:effdate
            })
        }
        if(flag=='N'){
            this.setState({
                nBasic:ba,nHallowance:ha,nTranspot:ta,nFood:fa,nAllowance:al,nOallowance:oa,
                nGOSI:go,nODect:od,nTallowance:tall,nTDect:tdet,nNetPay:net
            })
        }
    }
        
      
       
    this.setState({
        isLoading:false},()=>{
         this.getDoclist()
        });
    }
}))
.catch(err => 
  {
    this.setState({
      isLoading:false
    },()=>{
     let error=err
     
     this.refs.toast.showBottom(error.toString())

     setTimeout(
      () => { 
        this.props.navigation.goBack();
       },
      2000
    )

    })
  }
  );
  
}

getDoclist(){
  const config = {
    headers: {   
    'currentToken': tokken,
  },
    params: {
      doctype:this.state.AppType,
      param1:this.state.AppID,
      param2:0
    }
    
  };

  this.setState({isLoading:true})
  axios.get(ip+'/getDocumentListIOS', config)
  .then(response => this.setState({ DocDataSource:response.data},() => {if(response.status==200){
    this.setState({
      isAttachment:response.data.length==0?false:true,
      isLoading:false
    })}}))
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
}




DownloadDoc(data){

 const{SlNo,DocumentName,AttachFileName,FilePath}=data

 Linking.openURL(fileip+"/DocumentDownloadIOS?FPath="+FilePath+"&FileName="+AttachFileName) 

}


/* getDoclist(){
  const config = {
    headers: {   
    'currentToken': tokken,
  },
    params: {
      appid:this.state.AppID,
      apptype:this.state.AppType,
    }
    
  };

  this.setState({isLoading:true})
  axios.get(ip+'/getHRAppDocs', config)
  .then(response => this.setState({ DocDataSource:response.data},() => {if(response.status==200){
    this.setState({
      isAttachment:response.data.length==0?false:true,
      isLoading:false
    })}}))
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
}
 */
amountformatter(amount){

  let FV
  FV=this.format(Math.round(amount).toString())
  return FV;
}

getStatus(){

  this.setState({isLoading:true, StatusData:[],DisStatusData:[]})

   const config = {
       headers: {   
       'currentToken':tokken,
     },
       params: {
        appid:this.state.AppID,
        ver:this.state.Ver,
       }
       
     };

 axios.get(ip+'/getSalAdjStatus', config)
   .then(response => this.setState({StatusData:response.data},() => {if(response.status==200){
   this.display()
   }}))
   .catch(err => 
     {
       this.setState({
         isLoading:false
       },()=>{
        let error=err
        
        this.refs.toast.showBottom(error.toString())
 
        setTimeout(
         () => { 
           this.props.navigation.goBack();
          },
         2000
       )
 
       })
     }
     );

}

display(){
  for(i=0;i< this.state.StatusData.length ;i++){
      const{E,C,D,A,F}=this.state.StatusData[i]
      let Desc,tit
      if(E!==''){
        if(D!=='' && D!=null){
          if (F=='O' || F=='P') {
            Desc=C+"\n"+"Remarks : "+E
          }else{
            Desc=C+"\n"+moment(D).format('DD-MM-YYYY').toString()+"\n"+"Remarks : "+E
          }
         
        }
        else{
          Desc=C+"\n"+"Remarks : "+E
        }
        
      }else{

        if(D!=='' && D!=null){

          if (F=='O' || F=='P') {
            Desc=C
          }else{
            Desc=C+"\n"+moment(D).format('DD-MM-YYYY').toString()
          }
       
        }else{
          Desc=C
        }
        
      }

      if(F==='A'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#15ca7d",
              icon:require('../src/ic_approved.png')
          })
      }else if(F==='P'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc, 
              lineColor:"#f4b825",
              icon:require('../src/ic_pending.png')
          })
      }else if(F==='R'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#f6634b",
              icon:require('../src/ic_rejected.png')
          })
      }else if(F==='O'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#2d353a",
              icon:require('../src/ic_opened.png')
          })
      }else if(F=='W'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#2d353a",
              icon:require('../src/ic_opened.png')
          })
      }
  
    }
    this.setState({isLoading:false,isStatus:true})
}


submit(){
  switch (selectedButton) {
      case "Approve":
          AppStatus = "A";
          break;
      case "Reject":
            AppStatus = "R";
            break;
      case "ReWork":
          AppStatus = "W";
          break;      
  }
  if(AppStatus!=="A"){
    if(this.state.Comment.length === 0) {
      alert("Please Enter Comment")
      return
    }
  }
  this.Save();
}
Save(){
this.setState({isLoading:true})
  let url=''
  if(AppStatus==='A'){
   url='/setSalAdjApp'
  }else if(AppStatus=='R'){
    url='/setSalAdjRej'
  }else if(AppStatus==='W'){
   url='/setSalAdjRew'
  }  

  axios({
    method: 'post',
    url:ip+url,
    headers: {'currentToken':tokken}, 
    data: {
      appid:this.state.AppID,       
      userid:this.state.UserID,  
      comments:this.state.Comment,   
      status:this.state.AppStatus,    
      seqno:this.state.Seq,
      ver:this.state.Ver,       
    }
  }).then(response=>{if(response.status===200){
    this.setState({isLoading:false},()=>{
      this.refs.toast.showBottom("Submitted Successfully")

       this.props.navigation.goBack()

     // this.props.navigation.navigate(saveresetAction)
    })
  }else{
    this.refs.toast.showBottom("Failed")
  }})
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
}

onPress = radiovalues => this.setState({ radiovalues});

render() {
    selectedButton = this.state.radiovalues.find(e => e.selected == true);
    selectedButton = selectedButton ? selectedButton.value : this.state.radiovalues[0].label;   
      if (this.state.isLoading) {
          return (
            <Modal
            transparent={false}
            supportedOrientations={['portrait', 'landscape']}
            visible={this.state.isLoading}
            >
             <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
              <Image
              style={{width: 300, height: 200}}
              source={require('../src/gears.gif')}  />
              </View>     
            </Modal>
          )
      }

      return (
    <View style={{flex:1,backgroundColor:lightblue }}> 
    <KeyboardAvoidingView 
        behavior='padding'
        keyboardVerticalOffset={
        Platform.select({
           ios: () => 0,
           android: () => 60
        })()
        }>
  <ScrollView style={{height:"100%"}}>

  <Modal            
          animationType = {"slide"}  
          transparent = {true}  
          visible = {this.state.isStatus}  
          onRequestClose = {() =>{ console.log("Modal has been closed.") } }>  
          {/*All views of Modal*/}  
          <View style = {styles.modal}>  
          <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress = {() =>
           {  
            this.setState({ isStatus:!this.state.isStatus})
           }}>
      
      <Grid>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontFamily:'Bold',alignSelf:'flex-start'}}>
             Approval Timeline
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('../src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
       </Grid>

         </TouchableOpacity>

         <Timeline 
          style={styles.list}
          data={this.state.DisStatusData}
          circleSize={25}
          showTime={false}
          circleColor='rgba(0,0,0,0)'
          lineColor='rgb(45,156,219)'
          descriptionStyle={{color:'gray',fontFamily:'Regular'}}
          innerCircle={'icon'}
        />

          </View>
          </Modal>

 

    <View  style={{ flex: 1,paddingTop:2,paddingBottom:2}}>
    <Grid style={{paddingTop:'2%'}}>
    <Row style={{backgroundColor:colorprimary,padding:5,borderRadius:2,width:'97%',alignSelf:'center',alignItems:'center'}}>
    <Col style={{alignItems:'center',width:'100%'}}>
    <Text style={styles.titleText}>Salary Adjustment Approval</Text>
    </Col>
     </Row>
     </Grid>
    </View>

    <Card style={{width:'97%',alignSelf:'center'}}>
               <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
                  paddingLeft:5,paddingRight:5,paddingTop:5,paddingBottom:5}}>
               <Grid>
               <Row style={{paddingTop:2,paddingBottom:3,}}>
               <Col style={{alignItems:'flex-start',width:'30%'}}>
               <Text style={styles.testHead}>Employee : </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'70%'}}>
               <Text style={{fontSize:12,color:black,fontFamily:'Regular'}}>{this.state.empname}</Text>
               </Col>
               </Row>         
               <Row style={{paddingTop:3,paddingBottom:3}}>
               <Col style={{alignItems:'flex-start',width:'30%'}}>
               <Text style={styles.testHead}>Department : </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'70%'}}>
               <Text style={{fontSize:12,color:black,fontFamily:'Regular'}}>{this.state.dept}</Text>
               </Col>
               </Row>       
               <Row style={{paddingTop:3,paddingBottom:3}}>
               <Col style={{alignItems:'flex-start',width:'30%'}}>
               <Text style={styles.testHead}>Designation : </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'70%'}}>
               <Text style={{fontSize:12,color:black,fontFamily:'Regular'}}>{this.state.desig}</Text>
               </Col>
               </Row>   
               <Row style={{paddingTop:3,paddingBottom:3}}>
               <Col style={{alignItems:'flex-start',width:'30%'}}>
               <Text style={styles.testHead}>Effective Date : </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'70%'}}>
               <Text style={{fontSize:12,color:black,fontFamily:'Regular'}}>{this.state.EffDate}</Text>
               </Col>
               </Row>               
               </Grid>   
               </CardItem>
   </Card>
   <Card style={{width:'97%',alignSelf:'center',paddingBottom:'1%'}}>
               <CardItem style={{alignItems:"center",width:'100%',flexWrap:'wrap',paddingTop:10,
             paddingBottom:10,paddingLeft:5,paddingRight:5}}>

    <Grid>
             <Row style={{paddingBottom:4}}>
              <Col style={{width:'46%',alignItems:'center'}}>
              <Text style={styles.textContentHead}>Earnings</Text>
              </Col> 
              <Col style={{width:'27%',alignItems:'flex-end'}}>
              <Text style={styles.textContentHead}>Current</Text>
              </Col> 
              <Col style={{width:'27%',alignItems:'flex-end'}}>
              <Text style={styles.textContentHead}>New</Text>
              </Col> 
              </Row>
                  <Divider color={dark}></Divider>
                  <Divider color={dark}></Divider>
                  <Divider color={dark}></Divider>

            <Row style={styles.rowpadding}>
             <Col style={{width:'46%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Basic</Text>
              </Col> 
              <Col style={{width:'27%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.Basic)}</Text>
              </Col> 
              <Col style={{width:'27%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.nBasic)}</Text>
              </Col> 
            </Row>

            <Row style={styles.rowpadding}>
             <Col style={{width:'46%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Housing Allowance</Text>
              </Col> 
              <Col style={{width:'27%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.Hallowance)}</Text>
              </Col> 
              <Col style={{width:'27%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.nHallowance)}</Text>
              </Col> 
            </Row>

            <Row style={styles.rowpadding}>
             <Col style={{width:'46%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Transportation</Text>
              </Col> 
              <Col style={{width:'27%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.Transpot)}</Text>
              </Col> 
              <Col style={{width:'27%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.nTranspot)}</Text>
              </Col> 
            </Row>


            <Row style={styles.rowpadding}>
             <Col style={{width:'46%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Food  Allowance</Text>
              </Col> 
              <Col style={{width:'27%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.Food)}</Text>
              </Col> 
              <Col style={{width:'27%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.nFood)}</Text>
              </Col> 
            </Row>


            <Row style={styles.rowpadding}>
             <Col style={{width:'46%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Allowance</Text>
              </Col> 
              <Col style={{width:'27%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.Allowance)}</Text>
              </Col> 
              <Col style={{width:'27%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.nAllowance)}</Text>
              </Col> 
            </Row>

            <Row style={styles.rowpadding}>
             <Col style={{width:'46%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Other Allowance</Text>
              </Col> 
              <Col style={{width:'27%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.Oallowance)}</Text>
              </Col> 
              <Col style={{width:'27%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.nOallowance)}</Text>
              </Col> 
            </Row>

            <Divider></Divider>
            <Divider></Divider>
            <Divider></Divider>

            <Row style={styles.rowpadding}>
             <Col style={{width:'46%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Total Earnings</Text>
              </Col> 
              <Col style={{width:'27%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.Tallowance)}</Text>
              </Col> 
              <Col style={{width:'27%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.nTallowance)}</Text>
              </Col> 
            </Row>
            <Divider></Divider>
            <Divider></Divider>
            <Divider></Divider>
            <Row style={{paddingBottom:4}}>
              <Col style={{width:'46%',alignItems:'center'}}>
              <Text style={styles.textContentHead}>Deductions</Text>
              </Col> 
              <Col style={{width:'27%',alignItems:'flex-end'}}>
              <Text style={styles.textContentHead}></Text>
              </Col> 
              <Col style={{width:'27%',alignItems:'flex-end'}}>
              <Text style={styles.textContentHead}></Text>
              </Col> 
              </Row>


              <Row style={styles.rowpadding}>
             <Col style={{width:'46%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>GOSI</Text>
              </Col> 
              <Col style={{width:'27%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.GOSI)}</Text>
              </Col> 
              <Col style={{width:'27%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.nGOSI)}</Text>
              </Col> 
            </Row>

            <Row style={styles.rowpadding}>
             <Col style={{width:'46%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Other Deductions</Text>
              </Col> 
              <Col style={{width:'27%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.ODect)}</Text>
              </Col> 
              <Col style={{width:'27%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.nODect)}</Text>
              </Col> 
            </Row>

            <Divider></Divider>
            <Divider></Divider>
            <Divider></Divider>

            <Row style={styles.rowpadding}>
             <Col style={{width:'46%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Total Deductions</Text>
              </Col> 
              <Col style={{width:'27%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.TDect)}</Text>
              </Col> 
              <Col style={{width:'27%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.nTDect)}</Text>
              </Col> 
            </Row>

            <Divider></Divider>
            <Divider></Divider>
            <Divider></Divider>

            <Row style={styles.rowpadding}>
             <Col style={{width:'46%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Gross</Text>
              </Col> 
              <Col style={{width:'27%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.NetPay)}</Text>
              </Col> 
              <Col style={{width:'27%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.nNetPay)}</Text>
              </Col> 
            </Row>
    </Grid>   
    </CardItem>
    </Card>     

{/* Doc List
 */}

<View  style={{display:this.state.isAttachment==true?'flex':'none',flex: 1,paddingTop:5}}>
            <Grid style={{backgroundColor:colorprimary,padding:5,width:'97%',
            alignSelf:'center',alignItems:'center',borderRadius:2}}>
              <Row>
              <Col style={{alignItems:'center',width:'100%'}}>
              <Text style={{color:white,fontSize:13,fontFamily:'Bold'}}>Attachments</Text>
              </Col>
              </Row>
            </Grid>

            <FlatList
       data={ this.state.DocDataSource}
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
            <Grid onPress={this.DownloadDoc.bind(this,item)}>
              <Row>
              <Col style={{alignItems:'flex-start',width:'10%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-start',fontFamily:'Regular'}}>{item.SlNo}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'90%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-start',fontFamily:'Regular'}}>{item.AttachFileName}</Text>
              </Col> 
              </Row>
            </Grid>  
             </CardItem>
           </Card>
        }

       keyExtractor={(item, index) => index.toString()}
       
      />
</View>

{/* <View  style={{display:this.state.isAttachment==true?'flex':'none' ,flex: 1,paddingTop:5}}>
            <Grid style={{backgroundColor:colorprimary,padding:5,borderRadius:2,width:'97%',alignSelf:'center',alignItems:'center'}}>
              <Row>
              <Col style={{alignItems:'center',width:'100%'}}>
              <Text style={{color:white,fontSize:13,fontFamily:'Bold'}}>Attachments</Text>
              </Col>
              </Row>
            </Grid>

            <FlatList
       data={ this.state.DocDataSource}
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
            <Grid>
              <Row>
              <Col style={{alignItems:'flex-start',width:'10%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-start',fontFamily:'Regular'}}>{item.A}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'90%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-start',fontFamily:'Regular'}}>{item.C}</Text>
              </Col> 
              </Row>
            </Grid>  
             </CardItem>
           </Card>
        }
       
       keyExtractor={(item, index) => index.toString()}
       
      />
</View>
      */}
     <Card style={{width:'97%',alignSelf:"center"}}>
                <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
                <Item>
                <Input placeholder="Approval Comments"
                value={this.state.Comment}
                style={{fontFamily:'Regular'}}
                onChangeText={val => this.setState({ Comment: val })}
               />
               </Item>
              </CardItem>
              <CardItem style={{paddingLeft:20}}>       
              <RadioGroup flexDirection='row' 
              radioButtons={this.state.radiovalues} onPress={this.onPress} />
               </CardItem>
              </Card>

    
            <Grid style={{padding:4,width:"97%",alignSelf:'center',paddingBottom:5}}>
             <Row>
             <Col style={{alignItems:'center',width:'50%'}}>
             <Button onPress={() =>this.getStatus()} 
             raised={true}
             titleStyle={{fontSize:15,textAlign:'center',fontFamily:'Bold'}}
             buttonStyle={{
               flex:1,
               borderRadius:6,
               width:120,
               height:45
             }}
            
             title=" Status "/>
             </Col> 
             <Col style={{alignItems:'center',width:'50%'}}>
             <Button onPress={() =>this.submit()} 
              raised={true}
              titleStyle={{fontSize:15,textAlign:'center',fontFamily:'Bold'}}
              buttonStyle={{
               flex:1,
               borderRadius:6,
               width:120,
               height:45
              }}
            
             title=" Submit "/>
             </Col> 
             </Row>
            </Grid>
          

          <Toast ref="toast"/>

          </ScrollView>
          </KeyboardAvoidingView>
          </View>
      );
  }
}

const styles = StyleSheet.create({

    rowpadding:{
        paddingTop:4
    },
    ButtonSection: {

        paddingTop:3,
        width: '100%',
        justifyContent: 'center',
        alignItems: 'center',
        paddingBottom:10
     },

  container: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: '#F5FCFF',
  },
    textContentHead: {
      backgroundColor:'#fff',
      fontSize: 14,
      color: '#36428a',
      fontFamily:'Bold',
      textShadowColor: 'rgba(0, 0, 0, 0.75)',
      textShadowOffset: {width: -1, height: 1},
      textShadowRadius: 10
    },
  itemView: {
    flex: 1,
    width,
    borderBottomWidth: 0.5,
    borderColor: '#cdcdcd',
    borderStyle: 'solid',
    paddingHorizontal: 12,
    flexDirection: 'row',
    paddingTop:2
},
textContent:{
  color:white,
  fontSize:12
},

textTotalContent:{
  color:'#3A6705',
  fontSize:12,
  fontFamily:'Bold'
},

testHead:{
    width:"100%",
    fontSize:13,
    color:colorprimary,
    fontFamily:'Bold',
    textAlign:'right',
    
},
CButton:{
    flex:1,
    paddingTop:8,
    height:55,
    width:100,
    paddingBottom:4,
},
imagebutton: {
    width:30,
    height: 30,        
  },
  modal: {  
    flex:1,
    backgroundColor:white,
    height:'auto',
    position: 'absolute',
    bottom: 0,
    width:'100%',
     },
     headerback: {
      flexDirection: 'row',
      alignItems:'center',
      backgroundColor: colorprimary,
      borderWidth: 0.5,
      borderColor:white,
      height: 40,
      width:'100%',
      borderRadius: 5,
    },
    titleText: {
      flex:1,
      flexWrap:'wrap',
      color:white,
      fontSize:13,
      fontFamily:'Bold'
    },
    htitle:{
        color:'#36428a',
        fontSize:14,
        alignSelf:'flex-start',
        fontFamily:'Bold'
       },
       tvalue:{
        alignSelf:'flex-end',
        fontSize:14,
        color:black,
        fontFamily:'Bold'
       },
});


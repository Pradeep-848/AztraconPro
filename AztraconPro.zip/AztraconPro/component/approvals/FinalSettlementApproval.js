import React from 'react';
import {ScrollView,Dimensions,Image,Modal,StyleSheet,Text,View,TouchableOpacity,
  Alert,KeyboardAvoidingView,Platform,FlatList,Linking } from 'react-native';
import axios from 'axios';
import { Col, Grid, Row} from 'react-native-easy-grid';
import {Card,CardItem,Item,Input,Spinner} from 'native-base';
import RadioGroup from 'react-native-radio-buttons-group';
import { NavigationActions, StackActions } from 'react-navigation';
import strings from '../res/strings'
import {logouttask} from '../class/logout';
import Toast from 'react-native-whc-toast'
import color from '../res/colors'
import { Divider,Button,Overlay } from 'react-native-elements';
import Timeline from 'react-native-timeline-flatlist'
import moment from 'moment';
import * as FileSystem from 'expo-file-system';
import base64 from 'react-native-base64'

const ip=strings.values.commonvalues.ip;
const fileip=strings.values.commonvalues.fileip;
const tokken=strings.values.commonvalues.tokken;

const { width, height } = Dimensions.get('window');

const lightblue=color.values.Colors.lightblue;
const blue=color.values.Colors.blue;
const colorprimary=color.values.Colors.colorPrimary;
const dark=color.values.Colors.colorprimarydark;
const white=color.values.Colors.white;
const black=color.values.Colors.black;
const gray=color.values.Colors.gray;
const red=color.values.Colors.red;
let selectedButton;
let AppStatus;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class FinalSettlementApproval extends React.Component{
  static navigationOptions = ({ navigation }) => ({ 
    title: "HR Approval",
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor:white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('../src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
      super(props);
      this.state = { 
        isLoading: true, 
        isAttachment:false,
        isStatus:false,
        data:[],DocDataSource:[],Statusdata:[],DisStatusData:[],
        vrm:"",handlelogin:'',UserID:'',AppID:'',dept:'',Comments:'',ReqName:'',ReqBy:'',ReqDate:'',
        AppType:'',AppStatus:'',Seq:'',Ver:'',dept:'',empname:'',qual:'',natid:'',exp:'',desig:'',
        grade:'',vac:'',med:'',ctype:'',
        cp:'',pp:'',
        totalallowance:'',leavebal:'',perday:'',leaveamt:'',serlen:'',
        total_indem:'',Indem:'',balsal:'',other_earn:'',tot_bal_sal:'',
        month:'',w_day:'',a_days:'',pay_per_day:'',salary:'',OT_HRS:'',
        ot_rate:'',OT_Pay:'',total_salary:'',loan:'',Total_Deduction:'',
        other_Deduction:'',PettyCash:'',loan:'',net_payable:'',
        deduction:'',other_earn_f:'',bal_sal_f:'',current_sal:'',
        leave_pay:'',indem_f:'',
        radiovalues: [
            {
                label: 'Approve',
                value: "Approve",
                color:'#2452b2'
            },
            {
                label: 'Reject',
                value: "Reject",
                color:'#2452b2'
            },
            {
                label: 'ReWork',
                value: 'ReWork',
                color:'#2452b2'
            },
          
        ],
    };
      this.arrayholder = [] ;
  }

  login = async () => 
  {
  
    Alert.alert(
      'Logout',
      'Would you like to logout?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {text: 'OK', onPress: () => { logouttask()
          this.props.navigation.dispatch(resetAction);} },
      ],
      {cancelable: false},
    );
   
  }
  

componentDidMount() {
  console.disableYellowBox = true;

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
 
  this.setState({
    UserID:this.props.navigation.getParam('UserID', ''),
    AppID:this.props.navigation.getParam('AppID', ''),
    Seq:this.props.navigation.getParam('Seq', ''),
    Ver:this.props.navigation.getParam('Ver', ''),
    ReqName:this.props.navigation.getParam('ReqName', ''),
    AppType:this.props.navigation.getParam('AppType', ''),
    ReqBy:this.props.navigation.getParam('ReqBy', ''),
    ReqDate:this.props.navigation.getParam('ReqDate', ''),
    },()=>{this.getFinalSettlement();})
}

format(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

report() {

/*   this.props.navigation.navigate('PdfViewActivity',{
     UserID:this.state.UserID,
     AppID:this.state.AppID,
     Ver:this.state.Ver,
     AppType:this.state.AppType,
     PdfWindow:'dw_final_settle_approval',
     Type:'A',
 }); 
 */

 //let pdfUrl = ip+'/PDFGen?Query=dw_final_settle_approval$number$'+this.state.AppID+'$number$'+this.state.Ver+
 //'&Type=A'+'&ID='+this.state.AppID

 let Query = base64.encode('dw_final_settle_approval$number$'+this.state.AppID+'$number$'+this.state.Ver)
 let Type = base64.encode('A')
 let ID = base64.encode(this.state.AppID)

 let pdfUrl = ip+'/PDFGenV1?Query='+Query+
 '&Type='+Type+'&ID='+ID

 Linking.openURL(pdfUrl) 

}

getFinalSettlement(){
  
    const config = {
      headers: {   
      'currentToken':tokken,
    },
      params: {
        AppID:this.state.AppID,
      }
    };
    this.setState({isLoading:true});
    axios.get(ip+'/getFinalSettlement', config)
  .then(response => this.setState({data:response.data},() => {if(response.status==200){
   

    const{empid,empname,desig,doj,basic,ha,ta,totalallowance,totalearning,leavebalance,
        leavepay,totalyear,indemnity,total,salbal,ticket,balsaltotal,remark,
        salarymonth,workingdays,absentday,perday,salarypay,othrs,otrate,otpay,
        totcursal,loan,pettycash,deduction,todeuction,totalpay}=this.state.data[0]

    this.setState({
     empname:empname+' ['+empid+' ] ', reqby:this.state.ReqName+'[ '+this.state.ReqBy+' ]',
     reqdate:this.state.ReqDate,desig:desig,doj:doj,totalallowance:totalallowance,
     tot_earn:totalearning,leavebal:leavebalance,leaveamt:leavepay,
     serlen:totalyear,total_indem:total,Indem:indemnity,balsal:salbal,other_earn:ticket,
     tot_bal_sal:balsaltotal,month:salarymonth,w_day:workingdays,a_days:absentday,pay_per_day:perday,
     salary:salarypay,OT_HRS:othrs,ot_rate:otrate,OT_Pay:otpay,total_salary:totcursal,loan:loan,
     Total_Deduction:todeuction,other_Deduction:deduction,
     PettyCash:pettycash,net_payable:totalpay,deduction:deduction,other_earn_f:ticket,
     bal_sal_f:balsaltotal,current_sal:totcursal,leave_pay:leavepay,indem_f:indemnity,
     rem:remark,Basic:basic,Hallowance:ha,Transpot:ta,isLoading:false},()=>{
         this.getDoclist()
        });
    }
}))
.catch(err => 
  {
    this.setState({
      isLoading:false
    },()=>{
     let error=err
     
     this.refs.toast.showBottom(error.toString())

     setTimeout(
      () => { 
        this.props.navigation.goBack();
       },
      2000
    )

    })
  }
  );
  
}

getDoclist(){
  const config = {
    headers: {   
    'currentToken': tokken,
  },
    params: {
      doctype:this.state.AppType,
      param1:this.state.AppID,
      param2:0
    }
    
  };

  this.setState({isLoading:true})
  axios.get(ip+'/getDocumentListIOS', config)
  .then(response => this.setState({ DocDataSource:response.data},() => {if(response.status==200){
    this.setState({
      isAttachment:response.data.length==0?false:true,
      isLoading:false
    })}}))
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
}

amountformatter(amount) {

  let FV
  FV=parseFloat(amount).toFixed(2)
  return this.format(FV).toString()

}

getStatus(){

  this.setState({isLoading:true, StatusData:[],DisStatusData:[]})

   const config = {
       headers: {   
       'currentToken':tokken,
     },
       params: {
        appid:this.state.AppID,
        ver:this.state.Ver,
       }
       
     };

 axios.get(ip+'/getFinalSettlementStatus', config)
   .then(response => this.setState({StatusData:response.data},() => {if(response.status==200){
   this.display()
   }}))
   .catch(err => 
     {
       this.setState({
         isLoading:false
       },()=>{
        let error=err
        
        this.refs.toast.showBottom(error.toString())
 
        setTimeout(
         () => { 
           this.props.navigation.goBack();
          },
         2000
       )
 
       })
     }
     );

}

display(){
  for(i=0;i< this.state.StatusData.length ;i++){
      const{E,C,D,A,F}=this.state.StatusData[i]
      let Desc,tit
      if(E!==''){
        if(D!=='' && D!=null){
          if (F=='O' || F=='P') {
            Desc=C+"\n"+"Remarks : "+E
          }else{
            Desc=C+"\n"+moment(D).format('DD-MM-YYYY').toString()+"\n"+"Remarks : "+E
          }
         
        }
        else{
          Desc=C+"\n"+"Remarks : "+E
        }
        
      }else{

        if(D!=='' && D!=null){

          if (F=='O' || F=='P') {
            Desc=C
          }else{
            Desc=C+"\n"+moment(D).format('DD-MM-YYYY').toString()
          }
       
        }else{
          Desc=C
        }
        
      }

      if(F==='A'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#15ca7d",
              icon:require('../src/ic_approved.png')
          })
      }else if(F==='P'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc, 
              lineColor:"#f4b825",
              icon:require('../src/ic_pending.png')
          })
      }else if(F==='R'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#f6634b",
              icon:require('../src/ic_rejected.png')
          })
      }else if(F==='O'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#2d353a",
              icon:require('../src/ic_opened.png')
          })
      }else if(F=='W'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#2d353a",
              icon:require('../src/ic_opened.png')
          })
      }
  
    }
    this.setState({isLoading:false,isStatus:true})
}

submit(){
  switch (selectedButton) {
      case "Approve":
          AppStatus = "A";
          break;
      case "Reject":
            AppStatus = "R";
            break;
      case "ReWork":
          AppStatus = "W";
          break;      
  }
  if(AppStatus!=="A"){
    if(this.state.Comment.length === 0) {
      alert("Please Enter Comment")
      return
    }
  }
  this.Save();
}

Save(){
this.setState({isLoading:true})
  let url=''
  if(AppStatus==='A'){
   url='/setFinalSettlementApp'
  }else if(AppStatus=='R'){
    url='/setFinalSettlementRej'
  }else if(AppStatus==='W'){
   url='/setFinalSettlementRew'
  }  

  axios({
    method: 'post',
    url:ip+url,
    headers: {'currentToken':tokken}, 
    data: {
      appid:this.state.AppID,       
      userid:this.state.UserID,  
      comments:this.state.Comment,   
      status:this.state.AppStatus,    
      seqno:this.state.Seq,
      ver:this.state.Ver,       
    }
  }).then(response=>{if(response.status===200){
    this.setState({isLoading:false},()=>{
      this.refs.toast.showBottom("Submitted Successfully")

       this.props.navigation.goBack()

     // this.props.navigation.navigate(saveresetAction)
    })
  }else{
    this.refs.toast.showBottom("Failed")
  }})
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
}



DownloadDoc(data){

 const{SlNo,DocumentName,AttachFileName,FilePath}=data

 Linking.openURL(fileip+"/DocumentDownloadIOS?FPath="+FilePath+"&FileName="+AttachFileName) 

}

onPress = radiovalues => this.setState({ radiovalues});

render() {
    selectedButton = this.state.radiovalues.find(e => e.selected == true);
    selectedButton = selectedButton ? selectedButton.value : this.state.radiovalues[0].label;   
      if (this.state.isLoading) {
          return (
            <Modal
            transparent={false}
            supportedOrientations={['portrait', 'landscape']}
            visible={this.state.isLoading}
            >
             <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
              <Image
              style={{width: 300, height: 200}}
              source={require('../src/gears.gif')}  />
              </View>     
            </Modal>
          )
      }

      return (
    <View style={{flex:1,backgroundColor:lightblue }}> 
    <KeyboardAvoidingView 
        behavior='padding'
        keyboardVerticalOffset={
        Platform.select({
           ios: () => 0,
           android: () => 60
        })()
        }>
  <ScrollView style={{height:"100%"}}>

  <Modal            
          animationType = {"slide"}  
          transparent = {true}  
          visible = {this.state.isStatus}  
          onRequestClose = {() =>{ console.log("Modal has been closed.") } }>  
          {/*All views of Modal*/}  
          <View style = {styles.modal}>  
          <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress = {() =>
           {  
            this.setState({ isStatus:!this.state.isStatus})
           }}>
        
        <Grid>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontFamily:'Bold',alignSelf:'flex-start'}}>
             Approval Timeline
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('../src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
       </Grid>

         </TouchableOpacity>


         <Timeline 
          style={styles.list}
          data={this.state.DisStatusData}
          circleSize={25}
          showTime={false}
          circleColor='rgba(0,0,0,0)'
          lineColor='rgb(45,156,219)'
          descriptionStyle={{color:'gray',fontFamily:'Regular'}}
          innerCircle={'icon'}
        />

          </View>
  </Modal>

 

    <View  style={{ flex: 1,paddingTop:2,paddingBottom:2}}>
    <Grid style={{paddingTop:'2%'}}>
    <Row style={{backgroundColor:colorprimary,padding:5,width:'97%',
    alignSelf:'center',alignItems:'center',borderRadius:2}}>
    <Col style={{alignItems:'center',width:'100%'}}>
    <Text style={styles.titleText}>Final Settlement Approval</Text>
    </Col>
     </Row>
     </Grid>
    </View>

    <Card style={{width:'97%',alignSelf:'center'}}>
               <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',paddingLeft:4,paddingRight:4}}>
               <Grid>
               <Row style={{paddingTop:2,paddingBottom:3,}}>
               <Col style={{alignItems:'flex-start',width:'30%'}}>
               <Text style={styles.testHead}>Employee : </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'70%'}}>
               <Text style={{fontSize:14,color:black,fontFamily:'Regular'}}>{this.state.empname}</Text>
               </Col>
               </Row>         
               
               <Row style={{paddingTop:3,paddingBottom:3}}>
               <Col style={{alignItems:'flex-start',width:'30%'}}>
               <Text style={styles.testHead}>Job Title : </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'70%'}}>
               <Text style={{fontSize:14,color:black,fontFamily:'Regular'}}>{this.state.desig}</Text>
               </Col>
               </Row>   
           
               <Row style={{paddingTop:3,paddingBottom:3}}>
               <Col style={{alignItems:'flex-start',width:'30%'}}>
               <Text style={styles.testHead}>DOJ : </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'70%'}}>
               <Text style={{fontSize:14,color:black,fontFamily:'Regular'}}>{this.state.doj}</Text>
               </Col>
               </Row>   
               <Row style={{paddingTop:3,paddingBottom:3}}>
               <Col style={{alignItems:'flex-start',width:'30%'}}>
               <Text style={styles.testHead}>Requested By : </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'70%'}}>
               <Text style={{fontSize:14,color:black,fontFamily:'Regular'}}>{this.state.reqby}</Text>
               </Col>
               </Row>   
               <Row style={{paddingTop:3,paddingBottom:3}}>
               <Col style={{alignItems:'flex-start',width:'30%'}}>
               <Text style={styles.testHead}>Request Date : </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'70%'}}>
               <Text style={{fontSize:14,color:black,fontFamily:'Regular'}}>{this.state.reqdate}</Text>
               </Col>
               </Row>               
               </Grid>   
               </CardItem>
   </Card>

   <Card style={{width:'97%',alignSelf:'center',paddingBottom:'1%'}}>
               <CardItem style={{alignItems:"center",width:'100%',flexWrap:'wrap',paddingTop:10,
             paddingBottom:10,paddingLeft:5,paddingRight:5}}>

    <Grid>
             <Row style={{paddingBottom:4}}>
              <Col style={{width:'100%',alignItems:'center'}}>
              <Text style={styles.textContentHead}>Compensation and Benefit Detail</Text>
              </Col> 
              </Row>
                  <Divider color={dark}></Divider>
                  <Divider color={dark}></Divider>
                  <Divider color={dark}></Divider>

            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Basic</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.Basic)}</Text>
              </Col> 
            </Row>

            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Housing Allowance</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.Hallowance)}</Text>
              </Col> 
            </Row>

            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Transportation</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.Transpot)}</Text>
              </Col> 
            </Row>


            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Total Allowance</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.totalallowance)}</Text>
              </Col> 
            </Row>

            <Divider></Divider>
            <Divider></Divider>
            <Divider></Divider>

            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Total Earning</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.tot_earn)}</Text>
              </Col> 
            </Row>
            <Divider></Divider>
            <Divider></Divider>
            <Divider></Divider>

    </Grid>   
    </CardItem>
    </Card>     

    <Card style={{width:'97%',alignSelf:'center',paddingBottom:'1%'}}>
               <CardItem style={{alignItems:"center",width:'100%',flexWrap:'wrap',paddingTop:10,
             paddingBottom:10,paddingLeft:5,paddingRight:5}}>

    <Grid>
             <Row style={{paddingBottom:4}}>
              <Col style={{width:'100%',alignItems:'center'}}>
              <Text style={styles.textContentHead}>Indemnity Details</Text>
              </Col> 
              </Row>
                  <Divider color={dark}></Divider>
                  <Divider color={dark}></Divider>
                  <Divider color={dark}></Divider>

            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Leave Balance</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.leavebal)}</Text>
              </Col> 
            </Row>

            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Per Day</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(String(parseFloat(this.state.tot_earn)/30))}</Text>
              </Col> 
            </Row>

            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Leave Amount</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.leaveamt)}</Text>
              </Col> 
            </Row>


            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Service Length</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.serlen)}</Text>
              </Col> 
            </Row>

            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Indemnity</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.Indem)}</Text>
              </Col> 
            </Row>


            <Divider></Divider>
            <Divider></Divider>
            <Divider></Divider>

            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Total</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.total_indem)}</Text>
              </Col> 
            </Row>
            <Divider></Divider>
            <Divider></Divider>
            <Divider></Divider>

    </Grid>   
    </CardItem>
    </Card>   

    <Card style={{width:'97%',alignSelf:'center',paddingBottom:'1%'}}>
               <CardItem style={{alignItems:"center",width:'100%',flexWrap:'wrap',paddingTop:10,
               paddingBottom:10,paddingLeft:5,paddingRight:5}}>

               <Grid>

              <Row style={{paddingBottom:4}}>
              <Col style={{width:'100%',alignItems:'center'}}>
              <Text style={styles.textContentHead}>Balance Salary Details</Text>
              </Col> 
              </Row>
             
                  <Divider color={dark}></Divider>
                  <Divider color={dark}></Divider>
                  <Divider color={dark}></Divider>

              <Row style={styles.rowpadding}>

              <Col style={{width:'33%',alignItems:'flex-start'}}>
              <Text style={styles.htitlec}>Balance Salary</Text>
              </Col> 
        
              <Col style={{width:'34%',alignItems:'flex-start'}}>
              <Text style={styles.htitlec}>Other Earnings</Text>
              </Col> 
        

              <Col style={{width:'33%',alignItems:'flex-start'}}>
              <Text style={styles.htitlec}>Total</Text>
              </Col> 
        
              </Row>

                

              <Row style={styles.rowpadding}>
              <Col style={{width:'33%',alignItems:'flex-start'}}>
              <Text style={styles.tvaluenc}>{this.state.balsal}</Text>
              </Col> 
              <Col style={{width:'34%',alignItems:'flex-start'}}>
              <Text style={styles.tvaluenc}>{this.state.other_earn}</Text>
              </Col> 
              <Col style={{width:'33%',alignItems:'flex-start'}}>
              <Text style={styles.tvaluenc}>{this.state.tot_bal_sal}</Text>
              </Col> 
              </Row>    


              <Divider style={{display:parseFloat(this.state.other_earn)>0?'flex':'none'}} color={dark}/>
              <Divider style={{display:parseFloat(this.state.other_earn)>0?'flex':'none'}} color={dark}/>

               <Row style={{display:parseFloat(this.state.other_earn)>0?'flex':'none',
               paddingTop:4,paddingBottom:4}}
               >
               <Col style={{width:'100%',alignItems:'flex-start'}}>
               <Text style={{
                    alignSelf:'flex-start',
                    fontSize:14,
                    color:black,
                    fontFamily:'Italic'
               }}>{this.state.rem}</Text>
               </Col> 
               </Row>

           </Grid>   

    </CardItem>
    </Card>     

    <Card style={{width:'97%',alignSelf:'center',paddingBottom:'1%'}}>
               <CardItem style={{alignItems:"center",width:'100%',flexWrap:'wrap',paddingTop:10,
             paddingBottom:10,paddingLeft:5,paddingRight:5}}>

    <Grid>
             <Row style={{paddingBottom:4}}>
              <Col style={{width:'100%',alignItems:'center'}}>
              <Text style={styles.textContentHead}>Current Salary Details</Text>
              </Col> 
              </Row>
                  <Divider color={dark}></Divider>
                  <Divider color={dark}></Divider>
                  <Divider color={dark}></Divider>

            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Month</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.state.month}</Text>
              </Col> 
            </Row>

            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>W Days</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.state.w_day}</Text>
              </Col> 
            </Row>

            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>A Days</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.state.a_days}</Text>
              </Col> 
            </Row>


            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Per/Day</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.pay_per_day)}</Text>
              </Col> 
            </Row>

            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Salary</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.salary)}</Text>
              </Col> 
            </Row>

            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>OT Hrs</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.state.OT_HRS}</Text>
              </Col> 
            </Row>

            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>OT Rate</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.state.ot_rate}</Text>
              </Col> 
            </Row>

            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>OT Pay</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.state.OT_Pay}</Text>
              </Col> 
            </Row>

            <Divider></Divider>
            <Divider></Divider>
            <Divider></Divider>

            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Total Salary</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.total_salary)}</Text>
              </Col> 
            </Row>
            <Divider></Divider>
            <Divider></Divider>
            <Divider></Divider>

    </Grid>   
    </CardItem>
    </Card>   

    <Card style={{width:'97%',alignSelf:'center',paddingBottom:'1%'}}>
               <CardItem style={{alignItems:"center",width:'100%',flexWrap:'wrap',paddingTop:10,
             paddingBottom:10,paddingLeft:5,paddingRight:5}}>

    <Grid>
             <Row style={{paddingBottom:4}}>
              <Col style={{width:'100%',alignItems:'center'}}>
              <Text style={styles.textContentHeadR}>Deduction Details</Text>
              </Col> 
              </Row>
                  <Divider color={dark}></Divider>
                  <Divider color={dark}></Divider>
                  <Divider color={dark}></Divider>

            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Loan</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.loan)}</Text>
              </Col> 
            </Row>

            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>PettyCash</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.PettyCash)}</Text>
              </Col> 
            </Row>

            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Other Deduction</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.other_Deduction)}</Text>
              </Col> 
            </Row>

            <Divider></Divider>
            <Divider></Divider>
            <Divider></Divider>

            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Total Deduction</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.Total_Deduction)}</Text>
              </Col> 
            </Row>
            <Divider></Divider>
            <Divider></Divider>
            <Divider></Divider>

    </Grid>   
    </CardItem>
    </Card>    
 

    <Card style={{width:'97%',alignSelf:'center',paddingBottom:'1%'}}>
               <CardItem style={{alignItems:"center",width:'100%',flexWrap:'wrap',paddingTop:10,
             paddingBottom:10,paddingLeft:5,paddingRight:5}}>

    <Grid>
             <Row style={{paddingBottom:4}}>
              <Col style={{width:'100%',alignItems:'center'}}>
              <Text style={styles.textContentHead}>Final Payable</Text>
              </Col> 
              </Row>
                  <Divider color={dark}></Divider>
                  <Divider color={dark}></Divider>
                  <Divider color={dark}></Divider>

            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Indemnity</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.indem_f)}</Text>
              </Col> 
            </Row>

            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Leave Pay</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.leave_pay)}</Text>
              </Col> 
            </Row>

            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Current Salary</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.current_sal)}</Text>
              </Col> 
            </Row>

            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Balance Salary</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.bal_sal_f)}</Text>
              </Col> 
            </Row>

            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Other Earning</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.other_earn_f)}</Text>
              </Col> 
            </Row>

            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Deduction</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.Total_Deduction)}</Text>
              </Col> 
            </Row>
            <Divider></Divider>
            <Divider></Divider>
            <Divider></Divider>

            <Row style={styles.rowpadding}>
             <Col style={{width:'50%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Net Payable</Text>
              </Col> 
              <Col style={{width:'50%',alignItems:'flex-end'}}>
              <Text style={styles.tvalue}>{this.amountformatter(this.state.net_payable)}</Text>
              </Col> 
            </Row>
            <Divider></Divider>
            <Divider></Divider>
            <Divider></Divider>

    </Grid>   
    </CardItem>
    </Card>    
 
   

{/* Doc List
 */}

<View  style={{display:this.state.isAttachment==true?'flex':'none',flex: 1,paddingTop:5}}>
            <Grid style={{backgroundColor:colorprimary,padding:5,width:'97%',
            alignSelf:'center',alignItems:'center',borderRadius:2}}>
              <Row>
              <Col style={{alignItems:'center',width:'100%'}}>
              <Text style={{color:white,fontSize:13,fontFamily:'Bold'}}>Attachments</Text>
              </Col>
              </Row>
            </Grid>

            <FlatList
       data={ this.state.DocDataSource}
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
            <Grid onPress={this.DownloadDoc.bind(this,item)}>
              <Row>
              <Col style={{alignItems:'flex-start',width:'10%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-start',fontFamily:'Regular'}}>{item.SlNo}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'90%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-start',fontFamily:'Regular'}}>{item.AttachFileName}</Text>
              </Col> 
              </Row>
            </Grid>  
             </CardItem>
           </Card>
        }

       keyExtractor={(item, index) => index.toString()}
       
      />
</View>
     
     <Card style={{width:'97%',alignSelf:"center"}}>
                <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
                <Item>
                <Input placeholder="Approval Comments"
                value={this.state.Comment}
                style={{fontFamily:'Regular'}}
                onChangeText={val => this.setState({ Comment: val })}
               />
               </Item>
              </CardItem>
              <CardItem style={{paddingLeft:20}}>       
              <RadioGroup flexDirection='row' 
              radioButtons={this.state.radiovalues} onPress={this.onPress} />
               </CardItem>
              </Card>

        
              <Grid style={{padding:4,width:"97%",alignSelf:'center',paddingBottom:5}}>
             <Row>
             <Col style={{alignItems:'center',width:'33%',paddingLeft:3,paddingRight:3}}>
             <Button onPress={() =>this.getStatus()} 
             raised={true}
             titleStyle={{fontSize:15,textAlign:'center',fontFamily:'Bold'}}
             buttonStyle={{
               flex:1,
               borderRadius:6,
               width:width*30/100,
               height:45
             }}
            
             title=" Status "/>
             </Col> 

             <Col style={{alignItems:'center',width:'34%',paddingLeft:3,paddingRight:3}}>
             <Button onPress={() =>this.submit()} 
              raised={true}
              titleStyle={{fontSize:15,textAlign:'center',fontFamily:'Bold'}}
              buttonStyle={{
               flex:1,
               borderRadius:6,
               width:width*30/100,
               height:45
              }}
            
             title=" Submit "/>
             </Col> 

             <Col style={{alignItems:'center',width:'33%',paddingLeft:3,paddingRight:3}}>
             <Button onPress={() =>this.report()} 
              raised={true}
              titleStyle={{fontSize:15,textAlign:'center',fontFamily:'Bold'}}
              buttonStyle={{
               flex:1,
               borderRadius:6,
               width:width*30/100,
               height:45
              }}
            
             title=" Report "/>
             </Col>

             </Row>
              </Grid>
         

          <Toast ref="toast"/>
          </ScrollView>
          </KeyboardAvoidingView>
          </View>
      );
  }
}

const styles = StyleSheet.create({

    rowpadding:{
        paddingTop:4,
        paddingBottom:4
    },
    ButtonSection: {

        paddingTop:3,
        width: '100%',
        justifyContent: 'center',
        alignItems: 'center',
        paddingBottom:10
     },

  container: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: '#F5FCFF',
  },
    textContentHead: {
      backgroundColor:'#fff',
      fontSize: 15,
      color: '#36428a',
      fontFamily:'Bold',
      textShadowColor: 'rgba(0, 0, 0, 0.75)',
      textShadowOffset: {width: -1, height: 1},
      textShadowRadius: 10
    },
    
    textContentHeadR: {
        backgroundColor:'#fff',
        fontSize: 15,
        color: red,
        fontFamily:'Bold',
        textShadowColor: 'rgba(0, 0, 0, 0.75)',
        textShadowOffset: {width: -1, height: 1},
        textShadowRadius: 10
      },

  itemView: {
    flex: 1,
    width,
    borderBottomWidth: 0.5,
    borderColor: '#cdcdcd',
    borderStyle: 'solid',
    paddingHorizontal: 12,
    flexDirection: 'row',
    paddingTop:2
},
textContent:{
  color:white,
  fontSize:12
},

textTotalContent:{
  color:'#3A6705',
  fontSize:12,
  fontFamily:'Bold'
},

testHead:{
    width:"100%",
    fontSize:14,
    color:colorprimary,
    fontFamily:'Bold',
    textAlign:'right',
    
},
CButton:{
    paddingTop:8,
    height:45,
    width:80,
    paddingBottom:4
},
imagebutton: {
    width:30,
    height: 30,        
  },
  modal: {  
    flex:1,
    backgroundColor:white,
    height:'auto',
    position: 'absolute',
    bottom: 0,
    width:'100%',
     },
     headerback: {
      flexDirection: 'row',
      alignItems:'center',
      backgroundColor: colorprimary,
      borderWidth: 0.5,
      borderColor:white,
      height: 40,
      width:'100%',
      borderRadius: 5,
    },
    titleText: {
      flex:1,
      flexWrap:'wrap',
      color:white,
      fontSize:13,
      fontFamily:'Bold'
    },
    htitle:{
        color:'#36428a',
        fontSize:14,
        alignSelf:'flex-start',
        fontFamily:'Bold'
       },
       htitlec:{
        color:'#36428a',
        fontSize:14,
        alignSelf:'center',
        fontFamily:'Bold'
       },
       tvalue:{
        alignSelf:'flex-end',
        fontSize:14,
        color:black,
        fontFamily:'Bold'
       },
       tvaluec:{
        alignSelf:'center',
        fontSize:14,
        color:colorprimary,
        fontFamily:'Bold'
       },
       tvaluen:{
        alignSelf:'flex-start',
        fontSize:14,
        color:black,
        fontFamily:'Italic'
       },
       tvaluenc:{
        alignSelf:'center',
        fontSize:14,
        color:black,
        fontFamily:'Italic'
       },
});


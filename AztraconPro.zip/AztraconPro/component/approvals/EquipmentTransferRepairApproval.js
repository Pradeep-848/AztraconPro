import React from 'react';
import {ScrollView,Dimensions,Image,Modal,StyleSheet,Text,View,
  TouchableOpacity,Alert,KeyboardAvoidingView,Platform,FlatList,
  Linking} from 'react-native';
import axios from 'axios';
import { Col, Grid, Row} from 'react-native-easy-grid';
import { Snackbar } from 'react-native-paper';
import {Card,CardItem,Item,Input,Form,Icon} from 'native-base';
import RadioGroup from 'react-native-radio-buttons-group';
import { NavigationActions, StackActions } from 'react-navigation';
import { Divider,Button,Overlay } from 'react-native-elements';
import Toast from 'react-native-whc-toast'
import Timeline from 'react-native-timeline-flatlist'
import moment from 'moment';
import { RFValue } from "react-native-responsive-fontsize";

//own lib
import strings from '../res/strings'
import {logouttask} from '../class/logout';
import color from '../res/colors'
import SelectDropdown from 'react-native-select-dropdown';


//constant
const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const { width, height } = Dimensions.get('window');

//size
const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);

const lightblue=color.values.Colors.lightblue;
const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const black=color.values.Colors.black;
const gray=color.values.Colors.gray;

//common style
const style_common = require('../class/style');

let selectedButton;
let AppStatus;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

let ID;

export default class EquipmentTransferRepairApproval extends React.Component{
  static navigationOptions = ({ navigation }) => ({ 
    title: "Approval",
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor:white,
    headerTitleStyle: {
      fontFamily:'Bold',
      fontSize:RFValue(20)
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('../src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
      super(props);
      this.state = { 
        isLoading: false, 
        isStatus:false,
        isAttachment:false,
        isVisible:false,
        passingdataarray:[],
        DocDataSource:[],
        ListDataSource:[],
        pickerstatus:"",
        data:[],Statusdata:[],DisStatusData:[],svisible:false,
        SUBCAT:'',SUBDESC:'',EQID:'',EQDESC:'',FPROJ:'',TPROJ:'',DREMARK:'',LOC:'',
        handlelogin:'',UserID:'',AppID:'',Comments:'',AppType:'',
        AppStatus:'',Seq:'',Ver:'',ReqBy:'',ReqName:'',ReqDate:'',PID:'',Remark:'',Mtype:'',
        radiovalues: [
            {
                label: 'Approve',
                value: "Approve",
                color:'#2452b2'
            },
            {
                label: 'Reject',
                value: "Reject",
                color:'#2452b2'
            },
            {
                label: 'ReWork',
                value: 'ReWork',
                color:'#2452b2'
            },
          
        ],
    };
      this.arrayholder = [] ;
  }

  login = async () => 
  {
  
    Alert.alert(
      'Logout',
      'Would you like to logout?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {text: 'OK', onPress: () => { logouttask()
          this.props.navigation.dispatch(resetAction);} },
      ],
      {cancelable: false},
    );
   
  }
  

componentDidMount() {

  console.log("herererer")
  console.disableYellowBox = true;

  this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
 
  this.setState({
    UserID:this.props.navigation.getParam('UserID', ''),
    AppID:this.props.navigation.getParam('AppID', ''),
    AppType:this.props.navigation.getParam('AppType', ''),
    Seq:this.props.navigation.getParam('Seq', ''),
    Ver:this.props.navigation.getParam('Ver', ''),
    PID:this.props.navigation.getParam('PID', ''),
    ReqBy:this.props.navigation.getParam('ReqBy', ''),
    ReqName:this.props.navigation.getParam('ReqName', ''),
    ReqDate:this.props.navigation.getParam('ReqDate', ''),
    Remark:this.props.navigation.getParam('Remark', ''),
    Mtype:this.props.navigation.getParam('Mtype', ''),
    },()=>{this.getEquipTransferAppData()})
}

getEquipTransferAppData() {
  
  console.error('App ID '+ this.state.AppID)
  this.setState({
    isLoading:true
  })
  
    const config = {
      headers: {   
      'currentToken':tokken,
      'deviceType':'I'
    },
      params: {
        appid:this.state.AppID,
      }
    };
    this.setState({isLoading:true});
    axios.get(ip+'/getEquipmentTransferApprovalV1', config)
   .then(response => this.setState({ data:response.data },() => {if(response.status==200) {

    const{ listdocs,list } = this.state.data[0]

    this.setState({
        isLoading:false,
        ListDataSource:list,
        DocDataSource:listdocs,
        isAttachment:listdocs.length==0?false:true,
    });
    }
}))
.catch(err => 
  {
    this.setState({
      isLoading:false
    },()=>{
     let error=err
     
     this.refs.toast.showBottom(error.toString())

     setTimeout(
      () => { 
        this.props.navigation.goBack();
       },
      2000
    )

    })
  }
  );
  
}

DownloadDoc(data){

  const{SlNo,DocumentName,AttachFileName,FilePath}=data
 
  Linking.openURL(fileip+"/DocumentDownloadIOS?FPath="+FilePath+"&FileName="+AttachFileName) 
 
 }


getStatus(){

  this.setState({isLoading:true, StatusData:[],DisStatusData:[]})

   const config = {
       headers: {   
       'currentToken':tokken,
     },
       params: {
        appid:this.state.AppID,
        ver:this.state.Ver,
       }
       
     };

 axios.get(ip+'/getEquipmentTransferStatus', config)
   .then(response => this.setState({StatusData:response.data},() => {if(response.status==200){
   this.display()
   }}))
   .catch(err => 
     {
       this.setState({
         isLoading:false
       },()=>{
        let error=err
        
        this.refs.toast.showBottom(error.toString())
 
        setTimeout(
         () => { 
           this.props.navigation.goBack();
          },
         2000
       )
 
       })
     }
     );

}

display(){
  let i
  for(i=0;i< this.state.StatusData.length ;i++){
      const{E,C,D,A,F}=this.state.StatusData[i]
      let Desc,tit
      if(E!==''){
        if(D!=='' && D!=null){
          if (F=='O' || F=='P') {
            Desc=C+"\n"+"Remarks : "+E
          }else{
            Desc=C+"\n"+moment(D).format('DD-MM-YYYY').toString()+"\n"+"Remarks : "+E
          }
         
        }
        else{
          Desc=C+"\n"+"Remarks : "+E
        }
        
      }else{

        if(D!=='' && D!=null){

          if (F=='O' || F=='P') {
            Desc=C
          }else{
            Desc=C+"\n"+moment(D).format('DD-MM-YYYY').toString()
          }
       
        }else{
          Desc=C
        }
        
      }

      if(F==='A'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#15ca7d",
              icon:require('../src/ic_approved.png')
          })
      }else if(F==='P'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc, 
              lineColor:"#f4b825",
              icon:require('../src/ic_pending.png')
          })
      }else if(F==='R'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#f6634b",
              icon:require('../src/ic_rejected.png')
          })
      }else if(F==='O'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#2d353a",
              icon:require('../src/ic_opened.png')
          })
      }else if(F=='W'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#2d353a",
              icon:require('../src/ic_opened.png')
          })
      }
  
    }
    this.setState({isLoading:false,isStatus:true})
}

submit(){
  switch (selectedButton) {
      case "Approve":
          AppStatus = "A";
          break;
      case "Reject":
            AppStatus = "R";
            break;
      case "ReWork":
          AppStatus = "W";
          break;      
  }
  if(AppStatus!=="A"){
    if(this.state.Comments.length === 0) {
      alert("Please Enter Comment")
      return
    }
  }

  if(this.state.Mtype=='Y' && this.state.Seq == '3' && AppStatus=='A') {

    if(this.checkLoc()) {
        this.setState({
            svisible:true
        })
        return;
    }

}

for(i=0;i< this.state.ListDataSource.length ;i++){
  const{loc,eqid}=this.state.ListDataSource[i]
  this.state.passingdataarray.push({loc:loc,eqid:eqid})
}


  this.Save();

}

checkLoc() {

let rtr_val
rtr_val = false

for(let i=0;i< this.state.ListDataSource.length ;i++) {
    const{ loc }=this.state.ListDataSource[i]
    if (loc=="" || loc=="null" || String(loc).length == 0 || loc==null) {
        rtr_val = true;
        return rtr_val
    }

}

return rtr_val

}

Save(){
this.setState({isLoading:true})
  let url=''
  if(AppStatus==='A'){
   url='/setEquipmentTransferRepairApp'
  }else if(AppStatus=='R'){
    url='/setEquipmentTransferRej'
  }else if(AppStatus==='W'){
   url='/setEquipmentTransferRew'
  }  

  axios({
    method: 'post',
    url:ip+url,
    headers: {'currentToken':tokken}, 
    data: AppStatus!='A'
    ?
    {
      appid:this.state.AppID,       
      userid:this.state.UserID,  
      comments:this.state.Comments,   
      status:this.state.AppStatus,    
      seqno:this.state.Seq,
      ver:this.state.Ver,       
    }
    :
    {
      Info:{
        "appid":this.state.AppID,       
        "userid":this.state.UserID,  
        "comments":this.state.Comments,   
        "status":this.state.AppStatus,    
        "seqno":this.state.Seq,
        "ver":this.state.Ver,      
        "mflag":this.state.Mtype 
      },
      LocItems:this.state.passingdataarray,
    }

  }).then(response=>{if(response.status===200){
    this.setState({isLoading:false},()=>{
      this.refs.toast.showBottom("Submitted Successfully")

       this.props.navigation.goBack();

    })
  }else{
    this.refs.toast.showBottom("Failed")
  }})
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
}

getvisible(vale) {
    let b
    if(vale==null || vale==''){
        b=false
        console.log(vale)
    }else{
        b=true
    }
    return b;
}

modelopen(visible) 
{
  this.setState({ isVisible:visible,pickerstatus:this.state.ListDataSource[ID].loc });
}

oncommentsumbit() {
 
  let dataSource=this.state.ListDataSource
  dataSource[ID].loc=this.state.pickerstatus
  this.setState({ListDataSource:dataSource , pickerstatus:null},()=>{
    this.modelopen(!this.state.isVisible)})
}

listitempress(index) {

  ID=index

  if(this.state.Mtype=='Y' && this.state.Seq=='3') {

  const{subcat ,subcatdesc , eqid , eqdesc , fromproj , toproj, remark, loc}=this.state.ListDataSource[index]
  this.setState({
    SUBCAT:subcat,
    SUBDESC:subcatdesc,
    EQID:eqid,
    EQDESC:eqdesc,
    FPROJ:fromproj,
    TPROJ:toproj,
    DREMARK:remark,
    LOC:loc
    },()=>{ this.modelopen(true) })

  }
  
  }

  getLocDesc(val) {
    if(val=='P') {
      return 'Plant'
    }

    if(val=='S') {
      return 'Site'
    }

  }
onPress = radiovalues => this.setState({ radiovalues});

render() {
    selectedButton = this.state.radiovalues.find(e => e.selected == true);
    selectedButton = selectedButton ? selectedButton.value : this.state.radiovalues[0].label;   
      if (this.state.isLoading) {
          return (
            <Modal
            transparent={false}
            supportedOrientations={['portrait', 'landscape']}
            visible={this.state.isLoading}
            >
             <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
              <Image
               style={style_common.load_gif}
              source={require('../src/gears.gif')}  />
              </View>     
            </Modal>
          )
      }

      return (
    <View style={{flex:1,backgroundColor:lightblue}}> 
    <KeyboardAvoidingView 
        behavior='padding'
        keyboardVerticalOffset={
        Platform.select({
           ios: () => 0,
           android: () => 60
        })()
        }>
  <ScrollView style={{height:"100%"}}>

  <Modal            
          animationType = {"slide"}  
          transparent = {true}  
          supportedOrientations={['portrait', 'landscape']}
          visible = {this.state.isStatus}  
          onRequestClose = {() =>{ console.log("Modal has been closed.") } }>  
          {/*All views of Modal*/}  
          <View style = {styles.modal}>  
          <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress = {() =>
           {  
            this.setState({ isStatus:!this.state.isStatus})
           }}>
       
       <Grid>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontFamily:'Bold',alignSelf:'flex-start'}}>
             Approval Timeline
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('../src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
       </Grid>

         </TouchableOpacity>


         <Timeline 
          style={styles.list}
          data={this.state.DisStatusData}
          circleSize={25}
          showTime={false}
          circleColor='rgba(0,0,0,0)'
          lineColor='rgb(45,156,219)'
          descriptionStyle={{color:'gray',fontFamily:'Regular'}}
          innerCircle={'icon'}
        />

          </View>
  </Modal>

 

    <View  style={{ flex: 1,paddingTop:2,paddingBottom:2}}>
    <Grid style={{paddingTop:'2%'}}>
    <Row style={{backgroundColor:colorprimary,padding:5,borderRadius:2,width:'97%',alignSelf:'center',alignItems:'center'}}>
    <Col style={{alignItems:'center',width:'100%'}}>
    <Text style={styles.titleText}>Equipment Repair Transfer Approval</Text>
    </Col>
     </Row>
     </Grid>
    </View>

    <Card style={{width:'97%',alignSelf:'center'}}>
               <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
                  paddingLeft:5,paddingRight:5,paddingTop:5,paddingBottom:5}}>
               <Grid>

               <Row style={{paddingTop:2,paddingBottom:3,}}>
               <Col style={{alignItems:'flex-start',width:'30%'}}>
               <Text style={styles.testHead}>Project ID : </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'70%'}}>
               <Text style={{fontSize:RFValue(12),color:black,fontFamily:'Regular'}}>{this.state.PID}</Text>
               </Col>
               </Row>       

               <Row style={{paddingTop:2,paddingBottom:3,}}>
               <Col style={{alignItems:'flex-start',width:'30%'}}>
               <Text style={styles.testHead}>Req Name : </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'70%'}}>
               <Text style={{fontSize:RFValue(12),color:black,fontFamily:'Regular'}}>{this.state.ReqName+" [ "+this.state.ReqBy+" ] "}</Text>
               </Col>
               </Row>           
               <Row style={{paddingTop:3,paddingBottom:3}}>
               <Col style={{alignItems:'flex-start',width:'30%'}}>
               <Text style={styles.testHead}>Request Date : </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'70%'}}>
               <Text style={{fontSize:RFValue(12),color:black,fontFamily:'Regular'}}>{this.state.ReqDate}</Text>
               </Col>
               </Row>               
               </Grid>   
               </CardItem>
   </Card>
   <Card style={{width:'97%',alignSelf:'center',paddingBottom:'1%'}}>
               <CardItem style={{alignItems:"center",width:'100%',flexWrap:'wrap',paddingTop:10,
             paddingBottom:10,paddingLeft:5,paddingRight:5}}>
    <View  style={{ flex: 1,paddingTop:2,paddingBottom:2}}>
    <Grid style={{paddingTop:'2%'}}>
    <Row style={{backgroundColor:colorprimary,padding:5,borderRadius:2,width:'100%',alignSelf:'center',alignItems:'center'}}>
    <Col style={{alignItems:'flex-start',width:'100%'}}>
    <Text style={styles.titleText}>Category</Text>
    </Col>
     </Row>
     </Grid>

            <FlatList
            extraData={this.state.ListDataSource}
       data={ this.state.ListDataSource}
       renderItem={({item,index}) =>  
       <Card style={{alignSelf:'center'}}>
            <CardItem style={{alignItems:"center",width:'100%',flexWrap:'wrap',paddingTop:10,
             paddingBottom:10,paddingLeft:5,paddingRight:5}}>
            <Grid onPress={()=>this.listitempress(index)}>
               <Row>
               <Col style={{alignItems:'flex-start',width:'20%'}}>
               <Text style={{fontSize:RFValue(13),color:colorprimary,fontFamily:'Bold'}}>{item.subcat}</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'80%'}}>
               <Text style={{fontSize:RFValue(13),color:colorprimary,fontFamily:'Bold'}}>{item.subcatdesc}</Text>
               </Col>
               </Row>
               <View style={{borderBottomColor:'#A9A9A9',borderBottomWidth: 1,height:5,
             width:'100%',alignSelf:'center'}}/>
               <Row>
               <Col style={{alignItems:'flex-start',width:'20%'}}>
               <Text style={{fontSize:RFValue(13),color:colorprimary,fontFamily:'Bold'}}>Asset ID</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'80%'}}>
               <Text style={{fontSize:RFValue(13),color:gray,fontFamily:'Italic'}}>{item.eqid}</Text>
               </Col>
               </Row>

               <Row>
               <Col style={{alignItems:'flex-start',width:'25%'}}>
               <Text style={{fontSize:RFValue(13),color:colorprimary,fontFamily:'Bold'}}>Location</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'75%'}}>
               <Text style={{fontSize:RFValue(13),fontFamily:'Italic',color:gray}}>{this.getLocDesc(item.loc)}</Text>
               </Col> 
               </Row>

               <Row>
               <Col style={{alignItems:'flex-start',width:'25%'}}>
               <Text style={{fontSize:RFValue(13),color:colorprimary,fontFamily:'Bold'}}>Desc</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'75%'}}>
               <Text style={{fontSize:RFValue(13),fontFamily:'Italic',color:gray}}>{item.eqdesc}</Text>
               </Col> 
               </Row>

               <Row>
               <Col style={{alignItems:'flex-start',width:'25%'}}>
               <Text style={{fontSize:RFValue(13),color:colorprimary,fontFamily:'Bold'}}>Project</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'25%'}}>
               <Text style={{fontSize:RFValue(13),fontFamily:'Italic',color:gray}}>{item.fromproj}</Text>
               </Col> 
               <Col style={{alignItems:'flex-start',width:'25%'}}>
               <Text style={{fontSize:RFValue(13),color:colorprimary,fontFamily:'Bold'}}>to</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'25%'}}>
               <Text style={{fontSize:RFValue(13),fontFamily:'Italic',color:gray}}>{item.toproj}</Text>
               </Col> 
               </Row>

               <Row 
                style={ this.getvisible(item.remark) ? {} : { opacity: 0, height: 0 } }  >
               <Col style={{alignItems:'flex-start',width:'25%'}}>
               <Text style={{fontSize:RFValue(13),color:colorprimary,fontFamily:'Bold'}}>Remark</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'75%'}}>
               <Text style={{fontSize:RFValue(13),fontFamily:'Italic',color:gray}}>{item.remark}</Text>
               </Col> 
               </Row>

            </Grid>  
             </CardItem>
           </Card>
        }

       keyExtractor={(item, index) => index.toString()}
       
      />
    </View>
        
          
    </CardItem>
    </Card>     

     {/* Doc List
*/}

<View  style={{display:this.state.isAttachment==true?'flex':'none',flex: 1,paddingTop:5}}>
          <Grid style={{backgroundColor:colorprimary,padding:5,width:'97%',
          alignSelf:'center',alignItems:'center',borderRadius:2}}>
            <Row>
            <Col style={{alignItems:'center',width:'100%'}}>
            <Text style={{color:white,fontSize:RFValue(13),fontFamily:'Bold'}}>Attachments</Text>
            </Col>
            </Row>
          </Grid>

     <FlatList
     data={ this.state.DocDataSource}
     renderItem={({item,index}) =>  
     <Card style={{width:'97%',alignSelf:'center'}}>
          <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',paddingTop:8,paddingBottom:8}}>
          <Grid onPress={this.DownloadDoc.bind(this,item)}>
            <Row>
            <Col style={{alignItems:'flex-start',width:'10%'}}>
            <Text style={{fontSize:RFValue(12),alignSelf:'flex-start',fontFamily:'Regular'}}>{item.SlNo}</Text>
            </Col> 
            <Col style={{alignItems:'flex-start',width:'90%'}}>
            <Text style={{fontSize:RFValue(12),alignSelf:'flex-start',fontFamily:'Regular'}}>{item.AttachFileName}</Text>
            </Col> 
            </Row>
          </Grid>  
           </CardItem>
         </Card>
      }

     keyExtractor={(item, index) => index.toString()}
     
    />
</View>
     
     <Card style={{width:'97%',alignSelf:"center"}}>
                <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
                <Item>
                <Input placeholder="Approval Comments"
                value={this.state.Comments}
                style={{fontFamily:'Regular'}}
                onChangeText={val => this.setState({ Comments: val })}
               />
               </Item>
              </CardItem>
              <CardItem style={{ alignItems: 'center',
               flex: 1,
               justifyContent: 'center'}}>       
              <RadioGroup flexDirection='row' 
              radioButtons={this.state.radiovalues} onPress={this.onPress} />
               </CardItem>
              </Card>

        
              <Grid style={{padding:4,width:"97%",alignSelf:'center',paddingBottom:5}}>
             <Row>
             <Col style={{alignItems:'center',width:'50%'}}>
             <Button onPress={() =>this.getStatus()} 
             raised={true}
             titleStyle={{fontSize:RFValue(13),textAlign:'center',fontFamily:'Bold'}}
              buttonStyle={{
               flex:1,
               borderRadius:6,
               width:RFValue(120),
               height:RFValue(40)
              }}
            
             title=" Status "/>
             </Col> 
             <Col style={{alignItems:'center',width:'50%'}}>
             <Button onPress={() =>this.submit()} 
              raised={true}
              titleStyle={{fontSize:RFValue(13),textAlign:'center',fontFamily:'Bold'}}
              buttonStyle={{
               flex:1,
               borderRadius:6,
               width:RFValue(120),
               height:RFValue(40)
              }}
            
             title=" Submit "/>
             </Col> 
             </Row>
            </Grid>
         
          
          <Toast ref="toast"/>

          <Snackbar
          visible={this.state.svisible}
          onDismiss={() => this.setState({ svisible: false })}
          duration={5000}
          >
          Location Cannot Be Empty , Please Select Location By Click List !!
         </Snackbar>

          </ScrollView>
    </KeyboardAvoidingView>

    <Modal            
          animationType = {"slide"}  
          transparent = {true}  
          supportedOrientations={['portrait', 'landscape']}
          visible = {this.state.isVisible}  
          onRequestClose = {() =>{ console.log("Modal has been closed.") } }>  
          {/*All views of Modal*/}  
          <View style = {styles.modal}>  
          <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress = {() =>
           {  
            this.setState({ isVisible:!this.state.isVisible})
           }}>
       
       <Grid>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontFamily:'Bold',alignSelf:'flex-start'}}>
             Equipment Detail
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('../src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
       </Grid>

         </TouchableOpacity>
<ScrollView style={{margin:RFValue(10)}}>

<View style={styles.b}>
<Grid>
  <Col style={styles.C}>
  <Text style={styles.tittle} >Category</Text>
  </Col> 
  <Col>
  <Text style={styles.detail}>{this.state.SUBCAT+" - "+this.state.SUBDESC}</Text>
  </Col> 
</Grid>
</View>
<View style={styles.b}>
<Grid>
  <Col style={styles.C}>
  <Text style={styles.tittle}>Asset ID</Text>
  </Col> 
  <Col>
  <Text style={styles.detail}>{this.state.EQID}</Text>
  </Col> 
</Grid>
</View>
<View style={styles.b}>
<Grid>
  <Col style={styles.C}>
  <Text style={styles.tittle}>Description</Text>
  </Col> 
  <Col>
  <Text style={styles.detail}>{this.state.EQDESC}</Text>
  </Col> 
</Grid>
</View>
<View style={styles.b}>
<Grid>
  <Col style={styles.C}>
  <Text style={styles.tittle}>From Project</Text>
  </Col> 
  <Col>
  <Text style={styles.detail}>{this.state.FPROJ}</Text>
  </Col> 
</Grid>
</View>
<View style={styles.b}>
<Grid>
  <Col style={styles.C}>
  <Text style={styles.tittle}>To Project</Text>
  </Col> 
  <Col>
  <Text style={styles.detail}>{this.state.TPROJ}</Text>
  </Col> 
</Grid>
</View>
<View style={styles.b}>
<Grid>
  <Col style={styles.C}>
  <Text style={styles.tittle}>Remarks</Text>
  </Col> 
  <Col>
  <Text style={styles.detail}>{this.state.DREMARK}</Text>
  </Col> 
</Grid>
</View>

<View style={{flexDirection:"row",alignItems:'center',paddingTop:10}}>
<Grid>
  <Row>
  <Text style={styles.tittle}>Location</Text>
  </Row>
  <Row>

       <Form style={{ flex: 1, alignItems: 'flex-start' ,fontFamily:'Regular'}}>
        <Item  style={{ marginLeft: 0,height:45}}  picker>

        <SelectDropdown
                                  data={[
                                    { title: "Plant", value: "P" },
                                    { title: "Site", value: "S" },
                                  ]}
                                  onSelect={(selectedItem, index) => {
                                    console.log(
                                      "Selected Item:",
                                      selectedItem.value
                                    );      
                                    this.setState(
                                      { pickerresponse: selectedItem.value },
                                      () => {
                                        this.getResList(selectedItem.value);
                                      }
                                    );
                                  }}
                                  renderButton={(isOpened) => {
                                    const data = [
                                      { title: "Plant", value: "P" },
                                      { title: "Site", value: "S" },
                                    ];
                                
                                    const buttonText = this.state.pickerresponse
                                      ? data.find((item) => item.value === this.state.pickerresponse)?.title
                                      : "Select Location";

                                    return (
                                      <View style={styles.dropdownButtonStyle}>
                                        <Text
                                          style={{
                                            flex: 1,
                                            fontSize: 16,
                                            color: "black",
                                          }}
                                        >
                                          {buttonText}
                                        </Text>
                                        <Icon
                                          name={
                                            isOpened
                                              ? "chevron-up"
                                              : "chevron-down"
                                          }
                                          style={{
                                            fontSize: 20,
                                            color: colorprimary,
                                          }}
                                        />
                                      </View>
                                    );
                                  }}
                                  renderItem={(item, index, isSelected) => {
                                    return (
                                      <View
                                        style={{
                                          ...styles.dropdownItemStyle,
                                          ...(isSelected && {
                                            backgroundColor: "#D2D9DF",
                                          }),
                                        }}
                                      >
                                        <Text
                                          style={{
                                            fontSize: 16,
                                            color: "black",
                                          }}
                                        >
                                          {item.title}
                                        </Text>
                                      </View>
                                    );
                                  }}
                                  showsVerticalScrollIndicator={false}
                                  dropdownStyle={{
                                    borderRadius: 8,
                                    borderWidth: 1,
                                    borderColor: "#ccc",
                                    backgroundColor: "#fff",
                                  }}
                                />   

      </Item>

    </Form> 

  </Row>
</Grid>
</View>

<View style={{flexDirection:"row",alignItems:'center',paddingTop:10}}>
<View style={styles.button_2}>
<Button
    title="SUBMIT"
    titleStyle={{fontFamily:'Regular'}}
    onPress={this.oncommentsumbit.bind(this)}
/>
</View>
<View style={styles.button_2}>
<Button
    title="CANCEL"
    titleStyle={{fontFamily:'Regular'}}
    onPress={() => { this.modelopen(!this.state.isVisible)} } 
  />
</View>
</View>

</ScrollView>
      

          </View>
    </Modal>
     
          </View>
      );
  }
}

const styles = StyleSheet.create({

    rowpadding:{
        paddingTop:RFValue(6)
    },
    ButtonSection: {
        paddingTop:RFValue(5),
        width: '100%',
        justifyContent: 'center',
        alignItems: 'center',
        paddingBottom:10
     },

  container: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: '#F5FCFF',
  },
    textContentHead: {
      backgroundColor:'#fff',
      fontSize:RFValue(14),
      color: '#36428a',
      fontWeight: 'bold',
      textShadowColor: 'rgba(0, 0, 0, 0.75)',
      textShadowOffset: {width: -1, height: 1},
      textShadowRadius: 10
    },
  itemView: {
    flex: 1,
    width,
    borderBottomWidth: 0.5,
    borderColor: '#cdcdcd',
    borderStyle: 'solid',
    paddingHorizontal: 12,
    flexDirection: 'row',
    paddingTop:2
},
textContent:{
  color:white,
  fontSize:RFValue(12)
},

textTotalContent:{
  color:'#3A6705',
  fontSize:RFValue(12),
  fontFamily:'Bold'
},

testHead:{
    width:"100%",
    fontSize:RFValue(13),
    color:colorprimary,
    fontFamily:'Bold',
    textAlign:'right',
    
},
CButton:{
    paddingTop:8,
    height:45,
    width:80,
    paddingBottom:4
},
imagebutton: {
    width:30,
    height: 30,        
  },
  modal: {  
    flex:1,
    backgroundColor:white,
    height:'auto',
    position: 'absolute',
    bottom: 0,
    width:'100%',
     },
     headerback: {
      flexDirection: 'row',
      alignItems:'center',
      backgroundColor: colorprimary,
      borderWidth: 0.5,
      borderColor:white,
      height: 40,
      width:'100%',
      borderRadius: 5,
    },
    titleText: {
      flex:1,
      flexWrap:'wrap',
      color:white,
      fontSize:RFValue(13),
      fontFamily:'Bold'
    },
    htitle:{
        color:'#36428a',
        fontSize:RFValue(14),
        alignSelf:'flex-start',
        fontFamily:'Bold'
       },
       tvalue:{
        alignSelf:'flex-end',
        fontSize:RFValue(14),
        color:black,
        fontFamily:'Bold'
       },
       tittle:{
        color:'#36428a',
        fontSize:RFValue(13),
        fontFamily:'Bold'
       },
       C:{
        alignItems:"flex-start",
        width:150
       },
       b: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop:5,
      },
      detail:{
        fontSize:RFValue(13),
        fontFamily:'Regular'
      },
      button_1:{
        width:'33%',
        height:50,
        paddingLeft:6,
        paddingRight:6
      },
     button_2:{
        width:'45%',
        height:50,
        paddingLeft:'10%'
      },
});


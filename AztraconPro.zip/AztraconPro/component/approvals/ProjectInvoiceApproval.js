import React from 'react';
import {ScrollView,Dimensions,Image,Modal,StyleSheet,Text,View,TouchableOpacity,Alert,
  KeyboardAvoidingView,Platform,FlatList,Linking} from 'react-native';
import axios from 'axios';
import { Col, Grid, Row} from 'react-native-easy-grid';
import {Card,CardItem,Item,Input,Spinner} from 'native-base';
import RadioGroup from 'react-native-radio-buttons-group';
import { NavigationActions, StackActions } from 'react-navigation';
import strings from '../res/strings'
import {logouttask} from '../class/logout';
import Toast from 'react-native-whc-toast'
import color from '../res/colors'
import { Divider,Button,Overlay } from 'react-native-elements';
import Timeline from 'react-native-timeline-flatlist'
import moment from 'moment';
import Popover, { PopoverPlacement,PopoverMode } from 'react-native-popover-view';
import base64 from 'react-native-base64'

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;
const fileip=strings.values.commonvalues.fileip;

const { width, height } = Dimensions.get('window');

const lightblue=color.values.Colors.lightblue;
const blue=color.values.Colors.blue;
const colorprimary=color.values.Colors.colorPrimary;
const colorprimarydark=color.values.Colors.colorprimarydark;
const white=color.values.Colors.white;
const black=color.values.Colors.black;
const gray=color.values.Colors.gray;
const red=color.values.Colors.red;
let selectedButton;
let AppStatus;
let passdata=[];
let datacg=[];
let dataga =[];

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class ProjectInvoiceApproval extends React.Component{
  static navigationOptions = ({ navigation }) => ({ 
    title: "Approval",
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor:white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('../src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
      super(props);
      this.state = { 
        ispop:false,
        isLoading: true, 
        isVisibleDetail:false,
        isAttachment:false,
        AppType:'',
        isStatus:false,
        data:[],DocDataSource:[],Statusdata:[],DisStatusData:[],vrm:"",handlelogin:'',UserID:'',
        AppID:'',dept:'',Comments:'',
        AppStatus:'',Seq:'',Ver:'',cnt:'',Remark:'',ReqBy:'',ReqName:'',ReqDate:'',Total_Amount:'',
        Stage:'',ProgVale:'',BillPercent:'',VatPercent:'',VatAmount:'',Advanced:'',Retention:'',NetAmount:'',Description:'',
        radiovalues: [
            {
                label: 'Approve',
                value: "Approve",
                color:'#2452b2'
            },
            {
                label: 'Reject',
                value: "Reject",
                color:'#2452b2'
            },
            {
                label: 'ReWork',
                value: 'ReWork',
                color:'#2452b2'
            },
            
          
        ],
    };
      console.disableYellowBox = true;
      this.arrayholder = [] ;
  }

  login = async () => 
  {
  
    Alert.alert(
      'Logout',
      'Would you like to logout?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {text: 'OK', onPress: () => { logouttask()
          this.props.navigation.dispatch(resetAction);} },
      ],
      {cancelable: false},
    );
   
  }
  
  componentDidMount() {
    console.disableYellowBox = true;
  
  this.props.navigation.setParams({
    handlelogin: this.login.bind(this)
    });

    
  
    this.setState({
      UserID:this.props.navigation.getParam('UserID', ''),
      AppID:this.props.navigation.getParam('AppID', ''),
      ReqBy:this.props.navigation.getParam('ReqBy',''),
      ReqName:this.props.navigation.getParam('ReqName',''),
      ReqDate:this.props.navigation.getParam('ReqDate',''),
      Seq:this.props.navigation.getParam('Seq', ''),
      Ver:this.props.navigation.getParam('Ver', ''),
      Remark:this.props.navigation.getParam('Remark', ''),
      AppType:this.props.navigation.getParam('AppType', ''),
      },()=>{this.getProjInvAppr();})
  }


format(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    
}

removepop(){
  this.setState({
    ispop:false
  })
}

getProjInvAppr(){
  
  const config = {
    headers: {   
    'currentToken':tokken,
  },
    params: {
      appid:this.state.AppID,
    }
  };
  this.setState({isLoading:true});
  axios.get(ip+'/getProjInvAppr', config)
.then(response => this.setState({data:response.data},() => {if(response.status==200){
  
  let tot_net= 0.0;

      for(let i=0;i<this.state.data.length;i++){
          const{netamount}=this.state.data[i]
              
          tot_net=parseFloat(tot_net)+parseFloat(netamount)       
      }

    
this.setState({
      Total_Amount:tot_net,
      isLoading:false,
      ispop:true},()=>{
       this.getDoclist()
      });
  }
}))
.catch(err => 
{
  this.setState({
    isLoading:false
  },()=>{
   let error=err
   
   this.refs.toast.showBottom(error.toString())

   setTimeout(
    () => { 
      this.props.navigation.goBack();
     },
    2000
  )

  })
}
);

}

getDoclist(){
  const config = {
    headers: {   
    'currentToken': tokken,
  },
    params: {
      doctype:this.state.AppType,
      param1:this.state.AppID,
      param2:0
    }
    
  };

  this.setState({isLoading:true})
  axios.get(ip+'/getDocumentListIOS', config)
  .then(response => this.setState({ DocDataSource:response.data},() => {if(response.status==200){
    this.setState({
      isAttachment:response.data.length==0?false:true,
      isLoading:false
    })}}))
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
}




DownloadDoc(data){

 const{SlNo,DocumentName,AttachFileName,FilePath}=data

 Linking.openURL(fileip+"/DocumentDownloadIOS?FPath="+FilePath+"&FileName="+AttachFileName) 

}

/* 
getDoclist(){
  const config = {
    headers: {   
    'currentToken': tokken,
  },
    params: {
      appid:this.state.AppID
    }
    
  };

  this.setState({isLoading:true})
  axios.get(ip+'/getProjInvApprDocs', config)
  .then(response => this.setState({ DocDataSource:response.data},() => {if(response.status==200){
   
   
    this.setState({
      isAttachment:response.data.length==0?false:true,
      isLoading:false
    })

    setTimeout(
      () => { 
        this.removepop()
       },
      3000
    )
  
  
  
  }}))
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
}

 */
amountformatter(amount){

  let FV
  FV=this.format(amount)
  return FV;
}

getdetail(index){
  
  const{stagedesc,progressvalue,billingpercent,vatpercent,vatamount,
    advance,retention,netamount,description}=this.state.data[index]

  this.setState({
    Stage:stagedesc,ProgVale:progressvalue,BillPercent:billingpercent,VatPercent:vatpercent,
    VatAmount:vatamount,Advanced:advance,Retention:retention,NetAmount:netamount,Description:description,
    isVisibleDetail:true
  })

}

getStatus(){

  this.setState({isLoading:true, StatusData:[],DisStatusData:[]})

   const config = {
       headers: {   
       'currentToken':tokken,
     },
       params: {
        appid:this.state.AppID
       }
       
     };

 axios.get(ip+'/getProjInvApprStatus', config)
   .then(response => this.setState({StatusData:response.data},() => {if(response.status==200){
   this.display()
   }}))
   .catch(err => 
     {
       this.setState({
         isLoading:false
       },()=>{
        let error=err
        
        this.refs.toast.showBottom(error.toString())
 
        setTimeout(
         () => { 
           this.props.navigation.goBack();
          },
         2000
       )
 
       })
     }
     );

}

display(){
  for(i=0;i< this.state.StatusData.length ;i++){
      const{E,C,D,A,F}=this.state.StatusData[i]
      let Desc,tit
      if(E!==''){
        if(D!=='' && D!=null){
          if (F=='O' || F=='P') {
            Desc=C+"\n"+"Remarks : "+E
          }else{
            Desc=C+"\n"+moment(D).format('DD-MM-YYYY').toString()+"\n"+"Remarks : "+E
          }
         
        }
        else{
          Desc=C+"\n"+"Remarks : "+E
        }
        
      }else{

        if(D!=='' && D!=null){

          if (F=='O' || F=='P') {
            Desc=C
          }else{
            Desc=C+"\n"+moment(D).format('DD-MM-YYYY').toString()
          }
       
        }else{
          Desc=C
        }
        
      }

      if(F==='A'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#15ca7d",
              icon:require('../src/ic_approved.png')
          })
      }else if(F==='P'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc, 
              lineColor:"#f4b825",
              icon:require('../src/ic_pending.png')
          })
      }else if(F==='R'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#f6634b",
              icon:require('../src/ic_rejected.png')
          })
      }else if(F==='O'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#2d353a",
              icon:require('../src/ic_opened.png')
          })
      }else if(F=='W'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#2d353a",
              icon:require('../src/ic_opened.png')
          })
      }
  
    }
    this.setState({isLoading:false,isStatus:true})
}

submit(){
  switch (selectedButton) {
      case "Approve":
          AppStatus = "A";
          break;
      case "Reject":
            AppStatus = "R";
            break;
      case "ReWork":
          AppStatus = "W";
          break;      
  }
  if(AppStatus!=="A"){
    if(this.state.Comments.length === 0) {
      alert("Please Enter Comment")
      return
    }
  }
  this.Save();
}
Save(){
  this.setState({isLoading:true})
    let url=''
    if(AppStatus==='A'){
     url='/setProjInvApp'
    }else if(AppStatus=='R'){
      url='/setProjInvRej'
    }else if(AppStatus==='W'){
     url='/setProjInvRew'
    }  
  
    axios({
      method: 'post',
      url:ip+url,
      headers: {'currentToken':tokken}, 
      data: {
        appid:this.state.AppID,       
        userid:this.state.UserID,  
        comments:this.state.Comments,   
        status:this.state.AppStatus,    
        seqno:this.state.Seq,
        ver:this.state.Ver,       
      }
    }).then(response=>{if(response.status===200){
      this.setState({isLoading:false},()=>{
        this.refs.toast.showBottom("Submitted Successfully")
  
  
        this.props.navigation.goBack();
  
       
      })
    }else{
      this.refs.toast.showBottom("Failed")
    }})
    .catch(err => 
      {
        this.setState({
          isLoading:false
        },()=>{
         let error=err
         
         this.refs.toast.showBottom(error.toString())
  
         setTimeout(
          () => { 
            this.props.navigation.goBack();
           },
          2000
        )
  
        })
      }
      );
  }

  report(){

/*     this.props.navigation.navigate('PdfViewActivity',{
     UserID:this.state.UserID,
     AppID:this.state.AppID,
     AppType:'PIV',
     Ver:this.state.Ver,
     PdfWindow:'dw_project_proforma_invoice',
     Type:'A',
 }); 
 */

/*  let url = ip+'/PDFGen?Query=dw_project_proforma_invoice$number$'+this.state.AppID+'$number$'+this.state.Ver+
 '&Type=A'+'&ID='+this.state.AppID

 Linking.openURL(url)  */


 let Query = base64.encode('dw_project_proforma_invoice$number$'+this.state.AppID+'$number$'+this.state.Ver)
 let Type = base64.encode('A')
 let ID = base64.encode(this.state.AppID)

 let pdfUrl = ip+'/PDFGenV1?Query='+Query+
 '&Type='+Type+'&ID='+ID

 Linking.openURL(pdfUrl) 

}

onPress = radiovalues => this.setState({ radiovalues});

render() {
    selectedButton = this.state.radiovalues.find(e => e.selected == true);
    selectedButton = selectedButton ? selectedButton.value : this.state.radiovalues[0].label;   
      if (this.state.isLoading) {
          return (
            <Modal
            transparent={false}
            supportedOrientations={['portrait', 'landscape']}
            visible={this.state.isLoading}
            >
             <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
              <Image
              style={{width: 300, height: 200}}
              source={require('../src/gears.gif')}  />
              </View>     
            </Modal>
          )
      }

      return (
    <View style={{flex:1,backgroundColor:lightblue }}> 
    <KeyboardAvoidingView 
        behavior='padding'
        keyboardVerticalOffset={
        Platform.select({
           ios: () => 0,
           android: () => 60
        })()
        }>
  <ScrollView style={{height:"100%"}}>

  <Modal            
          animationType = {"slide"}  
          transparent = {true}  
          visible = {this.state.isStatus}  
          onRequestClose = {() =>{ console.log("Modal has been closed.") } }>  
          {/*All views of Modal*/}  
          <View style = {styles.modal}>  

          <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress = {() =>
           {  
            this.setState({ isStatus:!this.state.isStatus})
           }}>
        
        <Grid style={{width:'100%'}}>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontFamily:'Bold',alignSelf:'flex-start'}}>
             Approval Timeline
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('../src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
       </Grid>

          </TouchableOpacity>


          <Timeline 
          style={styles.list}
          data={this.state.DisStatusData}
          circleSize={25}
          showTime={false}
          circleColor='rgba(0,0,0,0)'
          lineColor='rgb(45,156,219)'
          descriptionStyle={{color:'gray',fontFamily:'Regular'}}
          innerCircle={'icon'}
        />
          </View>
          
  </Modal>

  <Overlay
  width="85%"
  height="50%"
  animationType="slide"
  isVisible={this.state.isVisibleDetail}
  onBackdropPress={() => this.setState({ isVisibleDetail: false })}> 
          {/*All views of Modal*/}  

          <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress = {() =>
           {  
            this.setState({ isVisibleDetail:!this.state.isVisibleDetail})
           }}>

         <Grid>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontFamily:'Bold',alignSelf:'flex-start'}}>
             Project Invoice Approval Detail
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('../src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
       </Grid>
        

         </TouchableOpacity>
            
             <View  style={{ flex: 1,paddingTop:5}}>
             
             <Grid style={{width:'97%',alignSelf:'center'}}>

  
               <Row style={{paddingTop:2}}> 
               <Col style={{alignItems:'center',width:'100%'}}>
               <Text style={{fontSize:13,color:gray,fontFamily:'Bold'}}>{this.state.Stage}</Text>
               </Col>
               </Row>
              
               <Row style={{paddingBottom:4}}>
               <Col style={{alignItems:'center',width:'100%'}}>
               <Text style={{fontSize:12,color:gray,fontFamily:'Bold'}}>{this.state.Description}</Text>
               </Col>
               </Row>

               <Divider></Divider>
               <Divider></Divider>
               <Divider></Divider>

              <Row>
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Progress Value</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'50%'}}>
              <Text style={{fontSize:13,color:gray,fontFamily:'Regular'}}>{this.format(this.state.ProgVale)}</Text>
              </Col> 
              </Row>
              
              <Row>
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Billing %</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'50%'}}>
              <Text style={{fontSize:13,color:gray,fontFamily:'Regular'}}>{this.state.BillPercent}</Text>
              </Col> 
              </Row>
              <Row>
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Vat %</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'50%'}}>
              <Text style={{fontSize:13,color:gray,fontFamily:'Regular'}}>{this.state.VatPercent}</Text>
              </Col> 
              </Row>
              <Row>
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Vat Amount</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'50%'}}>
              <Text style={{fontSize:13,color:gray,fontFamily:'Regular'}}>{this.format(this.state.VatAmount)}</Text>
              </Col> 
              </Row>
              <Row>
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Advance</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'50%'}}>
              <Text style={{fontSize:13,color:gray,fontFamily:'Regular'}}>{this.format(this.state.Advanced)}</Text>
              </Col> 
              </Row>
              <Row>
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Retention</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'50%'}}>
              <Text style={{fontSize:13,color:gray,fontFamily:'Regular'}}>{this.format(this.state.Retention)}</Text>
              </Col> 
              </Row>

              <Divider></Divider>
              <Divider></Divider>
              <Divider></Divider>

              <Row style={{alignSelf:'center',alignItems:'center'}}>
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Net Amount</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'50%'}}>
              <Text style={{fontSize:13,color:black,fontFamily:'Bold'}}>{this.format(this.state.NetAmount)}</Text>
              </Col> 
              </Row>

          
              <Divider></Divider>
              <Divider></Divider>
              <Divider></Divider>

            
             </Grid>


             </View>
             
    </Overlay>

    <View  style={{ flex: 1,paddingTop:2,paddingBottom:2}}>
    <Grid style={{paddingTop:'2%'}}>
    <Row style={{backgroundColor:colorprimary,padding:5,width:'97%',
    alignSelf:'center',alignItems:'center',borderRadius:2}}>
    <Col style={{alignItems:'center',width:'100%'}}>
    <Text style={styles.titleText}>Project Invoice Approval</Text>
    </Col>
    </Row>
    </Grid>
    </View>

     <Card style={{width:'97%',alignSelf:'center'}}>
               <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
                  paddingLeft:5,paddingRight:5,paddingTop:5,paddingBottom:5}}>
               <Grid>
               <Row style={{paddingTop:2,paddingBottom:3,}}>
               <Col style={{alignItems:'flex-start',width:'30%'}}>
               <Text style={styles.testHead}>Req Name : </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'70%'}}>
               <Text style={{fontSize:12,color:black,fontFamily:'Regular'}}>{this.state.ReqName}</Text>
               </Col>
               </Row>         
               <Row style={{paddingTop:3,paddingBottom:3}}>
               <Col style={{alignItems:'flex-start',width:'30%'}}>
               <Text style={styles.testHead}>Req Date : </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'70%'}}>
               <Text style={{fontSize:12,color:black,fontFamily:'Regular'}}>{this.state.ReqDate}</Text>
               </Col>
               </Row>       
               <Row style={{paddingTop:3,paddingBottom:3,
                display:this.state.Remark==''?'none':'flex'}}>
               <Col style={{alignItems:'flex-start',width:'30%'}}>
               <Text style={styles.testHead}>Remarks : </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'70%'}}>
               <Text style={{fontSize:12,color:black,fontFamily:'Regular'}}>{this.state.Remark}</Text>
               </Col>
               </Row>          
               </Grid>   
               </CardItem>
   </Card>


 
   <View  style={{ flex: 1,paddingTop:5}}>
    <Grid style={{backgroundColor:colorprimary,padding:5,width:'97%',
    alignSelf:'center',alignItems:'center',borderRadius:4}}>
             <Row>
             <Col style={{alignItems:'center',width:'15%'}}>
             <Text style={styles.textContent}>SNo</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'55%'}}>
             <Text style={styles.textContent}>Stage</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'30%'}}>
             <Text style={styles.textContent}>Net Amt</Text>
             </Col> 
             </Row>
             </Grid>
    </View>


    <Popover placement={PopoverPlacement.TOP} 
     mode={PopoverMode.TOOLTIP}
     popoverStyle={{borderRadius:3,backgroundColor:red,height:25}}
     isVisible={this.state.ispop} onRequestClose={() => this.removepop()} 
    
    from={(

<FlatList
data={ this.state.data }
renderItem={({item,index}) =>  
<Card style={{width:'97%',alignSelf:'center'}}>
     <CardItem style={styles.carditem}>
     <Grid  onPress={() => this.getdetail(index)}>
     <Row style={{paddingBottom:3}}>
       <Col style={{alignItems:'center',width:'15%'}}>
       <Text style={{fontSize:12,alignSelf:'center',fontFamily:'Regular'}}>{index+1}</Text>
       </Col> 
       <Col style={{alignItems:'flex-start',width:'55%'}}>
       <Text style={{fontSize:12,alignSelf:'flex-start',fontFamily:'Regular'}}>{item.stagedesc}</Text>
       </Col> 
       <Col style={{alignItems:'flex-end',width:'30%'}}>
       <Text style={{fontSize:12,alignSelf:'flex-end',fontFamily:'Regular'}}>{this.format(item.netamount)}</Text>
       </Col> 
      </Row>
      <Divider></Divider>
      <Divider></Divider>
      <Divider></Divider>
      <Row style={{paddingTop:3}}>
      <Col style={{alignItems:'center',width:'25%'}}>
       <Text style={{fontSize:12,alignSelf:'flex-start',fontFamily:'Bold',color:colorprimary}}>Description : </Text>
       </Col> 
       <Col style={{alignItems:'flex-start',width:'75%'}}>
       <Text style={{fontSize:12,alignSelf:'flex-start',fontFamily:'Regular'}}>{item.description}</Text>
       </Col> 
      </Row>
     </Grid>  
      </CardItem>
    </Card>
 }

keyExtractor={(item, index) => index.toString()}

/>

    )}>      
     <Text style={{color:white,fontSize:13,fontFamily:'Bold',textAlign:'center'}}> Click To View </Text>

    </Popover>

      <View  style={{ flex: 1,paddingTop:5}}>
       <Grid style={{backgroundColor:'#D7EFFA',padding:4,width:"97%",alignSelf:'center',
       borderRadius:2}}>
             <Row>
             <Col style={{alignItems:'flex-start',width:'40%'}}>
             <Text style={styles.textTotalContent}>Total Net Amount : </Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'60%'}}>
             <Text style={styles.textTotalContent}>{this.format(this.state.Total_Amount)}</Text>
             </Col> 
             </Row>
             </Grid>
      </View>


{/* Doc List
 */}


<View  style={{display:this.state.isAttachment==true?'flex':'none',flex: 1,paddingTop:5}}>
            <Grid style={{backgroundColor:colorprimary,padding:5,width:'97%',
            alignSelf:'center',alignItems:'center',borderRadius:2}}>
              <Row>
              <Col style={{alignItems:'center',width:'100%'}}>
              <Text style={{color:white,fontSize:13,fontFamily:'Bold'}}>Attachments</Text>
              </Col>
              </Row>
            </Grid>

            <FlatList
       data={ this.state.DocDataSource}
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
            <Grid onPress={this.DownloadDoc.bind(this,item)}>
              <Row>
              <Col style={{alignItems:'flex-start',width:'10%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-start',fontFamily:'Regular'}}>{item.SlNo}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'90%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-start',fontFamily:'Regular'}}>{item.AttachFileName}</Text>
              </Col> 
              </Row>
            </Grid>  
             </CardItem>
           </Card>
        }

       keyExtractor={(item, index) => index.toString()}
       
      />
</View>
     

{/* <View  style={{display:this.state.isAttachment==true?'flex':'none',flex: 1,paddingTop:5}}>

            <Grid style={{backgroundColor:colorprimary,padding:5,width:'97%',
            alignSelf:'center',alignItems:'center'}}>
              <Row>
              <Col style={{alignItems:'center',width:'100%'}}>
              <Text style={{color:white,fontSize:13,fontFamily:'Bold'}}>Attachments</Text>
              </Col>
              </Row>
            </Grid>

            <FlatList
       data={ this.state.DocDataSource}
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
            <Grid>
              <Row>
              <Col style={{alignItems:'flex-start',width:'10%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-start',fontFamily:'Regular'}}>{item.A}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'90%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-start',fontFamily:'Regular'}}>{item.C}</Text>
              </Col> 
              </Row>
            </Grid>  
             </CardItem>
           </Card>
        }

       keyExtractor={(item, index) => index.toString()}
       
      />
</View>
      */}
     <Card style={{width:'97%',alignSelf:"center"}}>
                <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
                <Item>
                <Input placeholder="Approval Comments"
                value={this.state.Comments}
                style={{fontFamily:'Regular'}}
                onChangeText={val => this.setState({ Comments: val })}
               />
               </Item>
              </CardItem>
              <CardItem style={{paddingLeft:20}}>       
              <RadioGroup flexDirection='row' 
              radioButtons={this.state.radiovalues} onPress={this.onPress} />
               </CardItem>
              </Card>

        
              <Grid style={{padding:4,width:"97%",alignSelf:'center',paddingBottom:5}}>
             <Row>
             <Col style={{alignItems:'center',width:'33%',paddingLeft:3,paddingRight:3}}>
             <Button onPress={() =>this.getStatus()} 
             raised={true}
             titleStyle={{fontSize:15,textAlign:'center',fontFamily:'Bold'}}
             buttonStyle={{
               flex:1,
               borderRadius:6,
               width:width*30/100,
               height:45
             }}
            
             title=" Status "/>
             </Col> 

             <Col style={{alignItems:'center',width:'34%',paddingLeft:3,paddingRight:3}}>
             <Button onPress={() =>this.submit()} 
              raised={true}
              titleStyle={{fontSize:15,textAlign:'center',fontFamily:'Bold'}}
              buttonStyle={{
               flex:1,
               borderRadius:6,
               width:width*30/100,
               height:45
              }}
            
             title=" Submit "/>
             </Col> 

             <Col style={{alignItems:'center',width:'33%',paddingLeft:3,paddingRight:3}}>
             <Button onPress={() =>this.report()} 
              raised={true}
              titleStyle={{fontSize:15,textAlign:'center',fontFamily:'Bold'}}
              buttonStyle={{
               flex:1,
               borderRadius:6,
               width:width*30/100,
               height:45
              }}
            
             title=" Report "/>
             </Col>

             </Row>
              </Grid>
          
          

          <Toast ref="toast"/>
          </ScrollView>
          </KeyboardAvoidingView>
          </View>
      );
  }
}

const styles = StyleSheet.create({

  ButtonSection: {

      paddingTop:3,
      width: '100%',
      justifyContent: 'center',
      alignItems: 'center',
      paddingBottom:10
   },

container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
},
sectionHeader: {
    fontSize: 13,
    fontWeight: 'bold',
    color:'#fff',
},
itemView: {
  flex: 1,
  width,
  borderBottomWidth: 0.5,
  borderColor: '#cdcdcd',
  borderStyle: 'solid',
  paddingHorizontal: 12,
  flexDirection: 'row',
  paddingTop:2
},
textContent:{
color:white,
fontSize:12,
fontFamily:'Bold'
},

textTotalContent:{
color:'#3A6705',
fontSize:12,
fontFamily:'Bold'
},

testHead:{
  width:"100%",
  fontSize:13,
  color:colorprimary,
  fontFamily:'Bold',
  textAlign:'right',
  
},
CButton:{
  paddingTop:8,
  height:45,
  width:80,
  paddingBottom:4
},
imagebutton: {
  width:30,
  height: 30,        
},
modal: {  
  flex:1,
  width:'100%',
  backgroundColor:white,
  height:'auto',
  position: 'absolute',
  bottom: 0
   },
   headerback: {
    flexDirection: 'row',
    alignItems:'center',
    backgroundColor: colorprimary,
    borderWidth: 0.5,
    borderColor:white,
    height: 40,
    width:'100%',
    borderRadius: 5,
  },
  titleText: {
    flex:1,
    flexWrap:'wrap',
    color:white,
    fontSize:13,
    fontFamily:'Bold'
  },
  carditem:{
    alignItems:"flex-start",width:'100%',flexWrap:'wrap',
          paddingLeft: 5,
          paddingRight: 5,
          paddingTop: 10,
          paddingBottom: 10
  }
});

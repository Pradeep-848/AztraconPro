import React,{ Component }  from 'react';
import {ScrollView,Modal,StyleSheet,Text,View,Image,Dimensions,FlatList,ProgressBarAndroid,TouchableOpacity,Alert} from 'react-native';
import { Col, Grid, Row } from 'react-native-easy-grid';
import Toast from 'react-native-whc-toast'
import axios from 'axios';
import { NavigationActions, StackActions ,withNavigationFocus    } from 'react-navigation';
import {Card,CardItem} from 'native-base';
import strings from '../res/strings'
import {logouttask} from '../class/logout';
import color from '../res/colors'

const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const lightblue=color.values.Colors.lightblue;
const blue=color.values.Colors.blue;
const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const colorprimarydark=color.values.Colors.colorPrimaryDark;
const gray=color.values.Colors.gray;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class ProjectInvoiceApprovalList extends React.Component {
  
  static navigationOptions = ({ navigation }) => ({ 
    
    title: "Invoice List",
    color:"#fff",
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('../src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false, 
      handlelogin:'',
      dataSource:'',
      UserID:'',
      Type:''
    };
}



login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
      this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}
format(x) {
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

amountformatter(amount){

  let FV
  FV=this.format(amount)
  return FV;
}


getProjectInvDetail=(data)=>{

  const {reqby,reqname,reqdate,appid,seq,ver,remark}=data

if(String(this.state.Type).substring(0,1)=='I'){
  this.props.navigation.navigate('ProjectInvoiceApprovalActivity',
  {
      UserID:this.state.UserID,ReqBy:reqby,ReqName:reqname+'['+reqby+']',
      ReqDate:reqdate,AppID:appid,Seq:seq,AppType:this.state.Type,
      Ver:ver,Remark:remark
  });
}else{
  this.props.navigation.navigate('ScrapInvoiceApprovalActivity',
  {
      UserID:this.state.UserID,ReqBy:reqby,ReqName:reqname+'['+reqby+']',
      ReqDate:reqdate,AppID:appid,Seq:seq,AppType:this.state.Type,
      Ver:ver,Remark:remark
  });
}
  
  

}

getProjInvList=()=>{
  const config = {
    headers: {   
    'currentToken': tokken,
  },
    params: {
        approver:this.state.UserID,
        apprtype:String(this.state.Type).substring(0,1)
    }
    
  };
  this.setState({  isLoading:true })
  axios.get(ip+'/getProjInvListV1', config)
  .then(response => this.setState({ dataSource:response.data},() => {if(response.status==200){this.setState({isLoading:false})}}))
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
}

componentDidMount(){

  this.setState({
    isLoading:true
  })
  
  console.disableYellowBox = true;

  const { navigation } = this.props;


  this.focusListener = navigation.addListener("didFocus", () => {
    this.setState({
      UserID:this.props.navigation.getParam('UserID', ''),
      Type:this.props.navigation.getParam('Type', '')
  },()=>{
    this.getProjInvList()
  })
  
  });

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
  

  

}


  render() {
    if (this.state.isLoading) {
      return (
        <Modal
        transparent={false}
        supportedOrientations={['portrait', 'landscape']}
        visible={this.state.isLoading}
        >
         <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
           useNativeDriver={true}
           style={{width: 300, height: 200}}
           source={require('../src/gears.gif')}  />
          </View>     
        </Modal>
      )
  }
    return (
        <View style={{flex:1,backgroundColor:lightblue}}>
    
        <ScrollView style={{height:'9%'}}>

       

        <View  style={{ flex: 1,paddingTop:5}}>

        <Grid>
        <Row style={{backgroundColor:colorprimary,width:'97%',alignSelf:'center',borderRadius:2}}>
        <Text style={styles.titleText}>
        {String(this.state.Type).substring(0,1)=='I'?
                 'Project Invoice Approval':'Scrap Invoice Approval'}
        </Text>
        </Row>
        </Grid>

        <View style={{borderBottomColor:'#fff',borderBottomWidth: 1,paddingTop:3}}/>

        <Grid style={{backgroundColor:colorprimary,padding:4,width:"97%",alignSelf:'center',borderRadius:4}}>
                 <Row>
                 <Col style={{alignItems:'flex-start',width:'20%'}}>
                 <Text style={styles.textContent}>App. ID</Text>
                 </Col> 
                 <Col style={{alignItems:'flex-start',width:'15%'}}>
                 <Text style={styles.textContent}>PID</Text>
                 </Col> 
                 <Col style={{alignItems:'flex-start',width:'65%'}}>
                 <Text style={styles.textContent}>Req by</Text>
                 </Col> 
                 </Row>
                 </Grid>
        </View>
        </ScrollView>
       <ScrollView style={{height:'91%'}}>
       <FlatList
       data={ this.state.dataSource }
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
       <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
        paddingLeft:5,paddingRight:5,paddingTop:10,paddingBottom:10}}>
       <Grid onPress={this.getProjectInvDetail.bind(this,item)}>
       <Row>
       <Col style={{alignItems:'flex-start',width:'20%'}}>
       <Text style={{fontSize:13,fontFamily:'Italic'}}>{item.appid}</Text>
       </Col>
       <Col style={{alignItems:'flex-start',width:'15%'}}>
       <Text style={{fontSize:13,fontFamily:'Italic'}}>{item.projid}</Text>
       </Col>
       <Col style={{alignItems:'flex-start',width:'65%'}}>
       <Text style={{fontSize:13,fontFamily:'Italic'}}>{item.reqname+"["+item.reqby+"]"}</Text>
       </Col>
       </Row>
       <View style={{borderBottomColor:'#A9A9A9',borderBottomWidth: 1,height:5,
     width:'100%',alignSelf:'center'}}/>
       <Row>
       <Col style={{alignItems:'flex-start',width:'20%'}}>
       <Text style={{fontSize:13,color:colorprimarydark,fontFamily:'Bold'}}>Req. date : </Text>
       </Col>
       <Col style={{alignItems:'flex-start',width:'25%'}}>
       <Text style={{fontSize:13,fontFamily:'Italic',color:gray}}>{item.reqdate}</Text>
       </Col> 
       <Col style={{alignItems:'flex-start',width:'25%'}}>
       <Text style={{fontSize:13,color:colorprimarydark,fontFamily:'Bold'}}>Net Amount : </Text>
       </Col>
       <Col style={{alignItems:'flex-start',width:'30%'}}>
       <Text style={{fontSize:13,fontFamily:'Italic',color:gray}}>{this.amountformatter(item.netvalue)}</Text>
       </Col> 
       </Row>
       </Grid>   
       </CardItem>
       </Card>
        }

       keyExtractor={(item, index) => index.toString()}
       
      />

<Toast ref="toast"/>
              </ScrollView>
              </View>   
        )
      }
 };
 const styles = StyleSheet.create({
  titleText: {
    flex:1,
    flexWrap:'wrap',
    color:white,
    fontSize:12,
    padding:5,
    fontFamily:'Bold'
  },
  textContent:{
    color:white,
    fontSize:12,
    fontFamily:'Bold'
  }
  });
  
  
  
import React from 'react';
import {ScrollView,Dimensions,Image,Modal,StyleSheet,Text,View,
  TouchableOpacity,Alert,KeyboardAvoidingView,Platform,FlatList,
  Linking} from 'react-native';
import axios from 'axios';
import { Col, Grid, Row} from 'react-native-easy-grid';
import {Card,CardItem,Item,Input,Spinner} from 'native-base';
import RadioGroup from 'react-native-radio-buttons-group';
import { NavigationActions, StackActions } from 'react-navigation';
import Toast from 'react-native-whc-toast'
import { Divider,Button,Overlay } from 'react-native-elements';
import Timeline from 'react-native-timeline-flatlist'
import moment from 'moment';
import { RFValue } from "react-native-responsive-fontsize";

//own lib
import color from '../res/colors'
import strings from '../res/strings'
import {logouttask} from '../class/logout';

//constant
const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const { width, height } = Dimensions.get('window');

const lightblue=color.values.Colors.lightblue;
const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const black=color.values.Colors.black;
const gray=color.values.Colors.gray;


//common style
const style_common = require('../class/style');

let selectedButton;
let AppStatus;

//logout
const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class EquipmentTransferApproval extends React.Component{
  static navigationOptions = ({ navigation }) => ({ 
    title: "Approval",
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor:white,
    headerTitleStyle: {
      fontFamily:'Bold',
      fontSize:RFValue(20)
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('../src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
      super(props);
      this.state = { 
        isLoading: true, 
        isStatus:false,
        data:[],Statusdata:[],DisStatusData:[],
        handlelogin:'',UserID:'',AppID:'',Comments:'',AppType:'',
        AppStatus:'',Seq:'',Ver:'',ReqBy:'',ReqName:'',ReqDate:'',PID:'',Remark:'',
        radiovalues: [
            {
                label: 'Approve',
                value: "Approve",
                color:'#2452b2'
            },
            {
                label: 'Reject',
                value: "Reject",
                color:'#2452b2'
            },
            {
                label: 'ReWork',
                value: 'ReWork',
                color:'#2452b2'
            },
          
        ],
    };
      this.arrayholder = [] ;
  }

  login = async () => 
  {
  
    Alert.alert(
      'Logout',
      'Would you like to logout?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {text: 'OK', onPress: () => { logouttask()
          this.props.navigation.dispatch(resetAction);} },
      ],
      {cancelable: false},
    );
   
  }
  

componentDidMount() {
  console.disableYellowBox = true;

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
 
  this.setState({
    UserID:this.props.navigation.getParam('UserID', ''),
    AppID:this.props.navigation.getParam('AppID', ''),
    AppType:this.props.navigation.getParam('AppType', ''),
    Seq:this.props.navigation.getParam('Seq', ''),
    Ver:this.props.navigation.getParam('Ver', ''),
    PID:this.props.navigation.getParam('PID', ''),
    ReqBy:this.props.navigation.getParam('ReqBy', ''),
    ReqName:this.props.navigation.getParam('ReqName', ''),
    ReqDate:this.props.navigation.getParam('ReqDate', ''),
    Remark:this.props.navigation.getParam('Remark', ''),
    },()=>{this.getEquipTransferAppData();})
}

getEquipTransferAppData(){
  
    const config = {
      headers: {   
      'currentToken':tokken,
    },
      params: {
        appid:this.state.AppID,
      }
    };
    this.setState({isLoading:true});
    axios.get(ip+'/getEquipmentTransferApproval', config)
  .then(response => this.setState({data:response.data},() => {if(response.status==200){

    this.setState({
        isLoading:false});
    }
}))
.catch(err => 
  {
    this.setState({
      isLoading:false
    },()=>{
     let error=err
     
     this.refs.toast.showBottom(error.toString())

     setTimeout(
      () => { 
        this.props.navigation.goBack();
       },
      2000
    )

    })
  }
  );
  
}


getStatus(){

  this.setState({isLoading:true, StatusData:[],DisStatusData:[]})

   const config = {
       headers: {   
       'currentToken':tokken,
     },
       params: {
        appid:this.state.AppID,
        ver:this.state.Ver,
       }
       
     };

 axios.get(ip+'/getEquipmentTransferStatus', config)
   .then(response => this.setState({StatusData:response.data},() => {if(response.status==200){
   this.display()
   }}))
   .catch(err => 
     {
       this.setState({
         isLoading:false
       },()=>{
        let error=err
        
        this.refs.toast.showBottom(error.toString())
 
        setTimeout(
         () => { 
           this.props.navigation.goBack();
          },
         2000
       )
 
       })
     }
     );

}

display(){
  let i
  for(i=0;i< this.state.StatusData.length ;i++){
      const{E,C,D,A,F}=this.state.StatusData[i]
      let Desc,tit
      if(E!==''){
        if(D!=='' && D!=null){
          if (F=='O' || F=='P') {
            Desc=C+"\n"+"Remarks : "+E
          }else{
            Desc=C+"\n"+moment(D).format('DD-MM-YYYY').toString()+"\n"+"Remarks : "+E
          }
         
        }
        else{
          Desc=C+"\n"+"Remarks : "+E
        }
        
      }else{

        if(D!=='' && D!=null){

          if (F=='O' || F=='P') {
            Desc=C
          }else{
            Desc=C+"\n"+moment(D).format('DD-MM-YYYY').toString()
          }
       
        }else{
          Desc=C
        }
        
      }

      if(F==='A'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#15ca7d",
              icon:require('../src/ic_approved.png')
          })
      }else if(F==='P'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc, 
              lineColor:"#f4b825",
              icon:require('../src/ic_pending.png')
          })
      }else if(F==='R'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#f6634b",
              icon:require('../src/ic_rejected.png')
          })
      }else if(F==='O'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#2d353a",
              icon:require('../src/ic_opened.png')
          })
      }else if(F=='W'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#2d353a",
              icon:require('../src/ic_opened.png')
          })
      }
  
    }
    this.setState({isLoading:false,isStatus:true})
}

submit(){
  switch (selectedButton) {
      case "Approve":
          AppStatus = "A";
          break;
      case "Reject":
            AppStatus = "R";
            break;
      case "ReWork":
          AppStatus = "W";
          break;      
  }
  if(AppStatus!=="A"){
    if(this.state.Comments.length === 0) {
      alert("Please Enter Comment")
      return
    }
  }
  this.Save();
}
Save(){
this.setState({isLoading:true})
  let url=''
  if(AppStatus==='A'){
   url='/setEquipmentTransferApp'
  }else if(AppStatus=='R'){
    url='/setEquipmentTransferRej'
  }else if(AppStatus==='W'){
   url='/setEquipmentTransferRew'
  }  

  axios({
    method: 'post',
    url:ip+url,
    headers: {'currentToken':tokken}, 
    data: {
      appid:this.state.AppID,       
      userid:this.state.UserID,  
      comments:this.state.Comments,   
      status:this.state.AppStatus,    
      seqno:this.state.Seq,
      ver:this.state.Ver,       
    }
  }).then(response=>{if(response.status===200){
    this.setState({isLoading:false},()=>{
      this.refs.toast.showBottom("Submitted Successfully")

       this.props.navigation.goBack();

     // this.props.navigation.navigate(saveresetAction)
    })
  }else{
    this.refs.toast.showBottom("Failed")
  }})
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
}

getvisible(vale){
    let b
    if(vale==null || vale==''){
        b=false
        console.log(vale)
    }else{
        b=true
    }
    return b;
}

onPress = radiovalues => this.setState({ radiovalues});

render() {
    selectedButton = this.state.radiovalues.find(e => e.selected == true);
    selectedButton = selectedButton ? selectedButton.value : this.state.radiovalues[0].label;   
      if (this.state.isLoading) {
          return (
            <Modal
            transparent={false}
            supportedOrientations={['portrait', 'landscape']}
            visible={this.state.isLoading}
            >
             <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
              <Image
               style={style_common.load_gif}
              source={require('../src/gears.gif')}  />
              </View>     
            </Modal>
          )
      }

      return (
    <View style={{flex:1,backgroundColor:lightblue}}> 
    <KeyboardAvoidingView 
        behavior='padding'
        keyboardVerticalOffset={
        Platform.select({
           ios: () => 0,
           android: () => 60
        })()
        }>
  <ScrollView style={{height:"100%"}}>

  <Modal            
          animationType = {"slide"}  
          transparent = {true}  
          supportedOrientations={['portrait', 'landscape']}
          visible = {this.state.isStatus}  
          onRequestClose = {() =>{ console.log("Modal has been closed.") } }>  
          {/*All views of Modal*/}  
          <View style = {styles.modal}>  
          <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress = {() =>
           {  
            this.setState({ isStatus:!this.state.isStatus})
           }}>
       
       <Grid>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontFamily:'Bold',alignSelf:'flex-start'}}>
             Approval Timeline
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('../src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
       </Grid>

         </TouchableOpacity>


         <Timeline 
          style={styles.list}
          data={this.state.DisStatusData}
          circleSize={25}
          showTime={false}
          circleColor='rgba(0,0,0,0)'
          lineColor='rgb(45,156,219)'
          descriptionStyle={{color:'gray',fontFamily:'Regular'}}
          innerCircle={'icon'}
        />

          </View>
          </Modal>

 

    <View  style={{ flex: 1,paddingTop:2,paddingBottom:2}}>
    <Grid style={{paddingTop:'2%'}}>
    <Row style={{backgroundColor:colorprimary,padding:RFValue(5),borderRadius:2,width:'97%',alignSelf:'center',alignItems:'center'}}>
    <Col style={{alignItems:'center',width:'100%'}}>
    <Text style={styles.titleText}>Equipment Transfer Approval</Text>
    </Col>
     </Row>
     </Grid>
    </View>

    <Card style={{width:'97%',alignSelf:'center'}}>
               <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
                  paddingLeft:RFValue(5),paddingRight:RFValue(5),paddingTop:RFValue(5),paddingBottom:RFValue(5)}}>
               <Grid>

               <Row style={{paddingTop:RFValue(2),paddingBottom:RFValue(3)}}>
               <Col style={{alignItems:'flex-start',width:'30%'}}>
               <Text style={styles.testHead}>Project ID : </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'70%'}}>
               <Text style={{fontSize:RFValue(12),color:black,fontFamily:'Regular'}}>{this.state.PID}</Text>
               </Col>
               </Row>       

               <Row style={{paddingTop:RFValue(2),paddingBottom:RFValue(3)}}>
               <Col style={{alignItems:'flex-start',width:'30%'}}>
               <Text style={styles.testHead}>Req Name : </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'70%'}}>
               <Text style={{fontSize:RFValue(12),color:black,fontFamily:'Regular'}}>{this.state.ReqName+" [ "+this.state.ReqBy+" ] "}</Text>
               </Col>
               </Row>           
               <Row style={{paddingTop:RFValue(2),paddingBottom:RFValue(3)}}>
               <Col style={{alignItems:'flex-start',width:'30%'}}>
               <Text style={styles.testHead}>Request Date : </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'70%'}}>
               <Text style={{fontSize:RFValue(12),color:black,fontFamily:'Regular'}}>{this.state.ReqDate}</Text>
               </Col>
               </Row>               
               </Grid>   
               </CardItem>
   </Card>
   <Card style={{width:'97%',alignSelf:'center',paddingBottom:'1%'}}>
               <CardItem style={{alignItems:"center",width:'100%',flexWrap:'wrap',paddingTop:RFValue(10),
             paddingBottom:RFValue(10),paddingLeft:RFValue(5),paddingRight:RFValue(5)}}>
    <View  style={{ flex: 1,paddingTop:2,paddingBottom:2}}>
    <Grid style={{paddingTop:'2%'}}>
    <Row style={{backgroundColor:colorprimary,padding:5,borderRadius:2,width:'100%',alignSelf:'center',alignItems:'center'}}>
    <Col style={{alignItems:'flex-start',width:'100%'}}>
    <Text style={styles.titleText}>Category</Text>
    </Col>
     </Row>
     </Grid>

            <FlatList
       data={ this.state.data}
       renderItem={({item,index}) =>  
       <Card style={{alignSelf:'center'}}>
            <CardItem style={{alignItems:"center",width:'100%',flexWrap:'wrap',paddingTop:RFValue(10),
             paddingBottom:RFValue(10),paddingLeft:RFValue(5),paddingRight:RFValue(5)}}>
            <Grid>
               <Row>
               <Col style={{alignItems:'flex-start',width:'20%'}}>
               <Text style={{fontSize:RFValue(13),color:colorprimary,fontFamily:'Bold'}}>{item.subcat}</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'80%'}}>
               <Text style={{fontSize:RFValue(13),color:colorprimary,fontFamily:'Bold'}}>{item.subcatdesc}</Text>
               </Col>
               </Row>
               <View style={{borderBottomColor:'#A9A9A9',borderBottomWidth: 1,height:5,
             width:'100%',alignSelf:'center'}}/>
               <Row>
               <Col style={{alignItems:'flex-start',width:'20%'}}>
               <Text style={{fontSize:RFValue(13),color:colorprimary,fontFamily:'Bold'}}>Asset ID</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'80%'}}>
               <Text style={{fontSize:RFValue(13),color:gray,fontFamily:'Italic'}}>{item.eqid}</Text>
               </Col>
               </Row>
               <Row>
               <Col style={{alignItems:'flex-start',width:'25%'}}>
               <Text style={{fontSize:RFValue(13),color:colorprimary,fontFamily:'Bold'}}>Desc</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'75%'}}>
               <Text style={{fontSize:RFValue(13),fontFamily:'Italic',color:gray}}>{item.eqdesc}</Text>
               </Col> 
               </Row>

               <Row>
               <Col style={{alignItems:'flex-start',width:'25%'}}>
               <Text style={{fontSize:RFValue(13),color:colorprimary,fontFamily:'Bold'}}>Project</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'25%'}}>
               <Text style={{fontSize:RFValue(13),fontFamily:'Italic',color:gray}}>{item.fromproj}</Text>
               </Col> 
               <Col style={{alignItems:'flex-start',width:'25%'}}>
               <Text style={{fontSize:RFValue(13),color:colorprimary,fontFamily:'Bold'}}>to</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'25%'}}>
               <Text style={{fontSize:RFValue(13),fontFamily:'Italic',color:gray}}>{item.toproj}</Text>
               </Col> 
               </Row>

               <Row 
                style={ this.getvisible(item.remark) ? {} : { opacity: 0, height: 0 } }  >
               <Col style={{alignItems:'flex-start',width:'25%'}}>
               <Text style={{fontSize:RFValue(13),color:colorprimary,fontFamily:'Bold'}}>Remark</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'75%'}}>
               <Text style={{fontSize:RFValue(13),fontFamily:'Italic',color:gray}}>{item.remark}</Text>
               </Col> 
               </Row>

            </Grid>  
             </CardItem>
           </Card>
        }

       keyExtractor={(item, index) => index.toString()}
       
      />
    </View>
        
          
    </CardItem>
    </Card>     
     
     <Card style={{width:'97%',alignSelf:"center"}}>
                <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
                <Item>
                <Input placeholder="Approval Comments"
                value={this.state.Comments}
                style={{fontFamily:'Regular'}}
                onChangeText={val => this.setState({ Comments: val })}
               />
               </Item>
              </CardItem>
              <CardItem style={{ alignItems: 'center',
               flex: 1,
               justifyContent: 'center'}}>       
              <RadioGroup flexDirection='row' 
              radioButtons={this.state.radiovalues} onPress={this.onPress} />
               </CardItem>
              </Card>

        
              <Grid style={{padding:4,width:"97%",alignSelf:'center',paddingBottom:5}}>
             <Row>
             <Col style={{alignItems:'center',width:'50%'}}>
             <Button onPress={() =>this.getStatus()} 
             raised={true}
             titleStyle={{fontSize:RFValue(13),textAlign:'center',fontFamily:'Bold'}}
             buttonStyle={{
              flex:1,
              borderRadius:6,
              width:RFValue(120),
              height:RFValue(40)
             }}
            
             title=" Status "/>
             </Col> 
             <Col style={{alignItems:'center',width:'50%'}}>
             <Button onPress={() =>this.submit()} 
              raised={true}
              titleStyle={{fontSize:RFValue(13),textAlign:'center',fontFamily:'Bold'}}
              buttonStyle={{
               flex:1,
               borderRadius:6,
               width:RFValue(120),
               height:RFValue(40)
              }}
            
             title=" Submit "/>
             </Col> 
             </Row>
            </Grid>
         
          

          <Toast ref="toast"/>
          </ScrollView>
          </KeyboardAvoidingView>
          </View>
      );
  }
}

const styles = StyleSheet.create({

    rowpadding:{
        paddingTop:4
    },
    ButtonSection: {

        paddingTop:3,
        width: '100%',
        justifyContent: 'center',
        alignItems: 'center',
        paddingBottom:10
     },

  container: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: '#F5FCFF',
  },
    textContentHead: {
      backgroundColor:'#fff',
      fontSize: RFValue(14),
      color: '#36428a',
      fontWeight: 'bold',
      textShadowColor: 'rgba(0, 0, 0, 0.75)',
      textShadowOffset: {width: -1, height: 1},
      textShadowRadius: 10
    },
  itemView: {
    flex: 1,
    width,
    borderBottomWidth: 0.5,
    borderColor: '#cdcdcd',
    borderStyle: 'solid',
    paddingHorizontal: 12,
    flexDirection: 'row',
    paddingTop:2
},
textContent:{
  color:white,
  fontSize:RFValue(12)
},

textTotalContent:{
  color:'#3A6705',
  fontSize:RFValue(12),
  fontFamily:'Bold'
},

testHead:{
    width:"100%",
    fontSize:RFValue(13),
    color:colorprimary,
    fontFamily:'Bold',
    textAlign:'right',
    
},
CButton:{
    paddingTop:8,
    height:45,
    width:80,
    paddingBottom:4
},
imagebutton: {
    width:30,
    height: 30,        
  },
  modal: {  
    flex:1,
    backgroundColor:white,
    height:'auto',
    position: 'absolute',
    bottom: 0,
    width:'100%',
     },
     headerback: {
      flexDirection: 'row',
      alignItems:'center',
      backgroundColor: colorprimary,
      borderWidth: 0.5,
      borderColor:white,
      height: 40,
      width:'100%',
      borderRadius: 5,
    },
    titleText: {
      flex:1,
      flexWrap:'wrap',
      color:white,
      fontSize:RFValue(13),
      fontFamily:'Bold'
    },
    htitle:{
        color:'#36428a',
        fontSize:RFValue(14),
        alignSelf:'flex-start',
        fontFamily:'Bold'
       },
       tvalue:{
        alignSelf:'flex-end',
        fontSize:RFValue(14),
        color:black,
        fontFamily:'Bold'
       },
});


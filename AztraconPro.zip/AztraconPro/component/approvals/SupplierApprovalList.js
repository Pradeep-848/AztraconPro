import React,{ Component }  from 'react';
import {ScrollView,Modal,StyleSheet,Text,View,Image,Dimensions,FlatList,ProgressBarAndroid,TouchableOpacity,Alert} from 'react-native';
import { Col, Grid, Row } from 'react-native-easy-grid';
import Toast from 'react-native-whc-toast'
import axios from 'axios';
import { NavigationActions, StackActions ,withNavigationFocus    } from 'react-navigation';
import {Card,CardItem} from 'native-base';
import strings from '../res/strings'
import {logouttask} from '../class/logout';
import color from '../res/colors'
import { Divider } from 'react-native-elements';

const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const lightblue=color.values.Colors.lightblue;
const blue=color.values.Colors.blue;
const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const colorprimarydark=color.values.Colors.colorPrimaryDark;
const gray=color.values.Colors.gray;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class SupplierApprovalList extends React.Component {
  
  static navigationOptions = ({ navigation }) => ({ 
    
    title: "Supplier List",
    color:"#fff",
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('../src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false, 
      handlelogin:'',
      dataSource:'',
      UserID:'',
      AppType:''
    };
}



login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
      this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}

getSupplierDetail=(data)=>{

  const {supcode,supname,seq,ver}=data

  this.props.navigation.navigate('SupplierApprovalActivity',
  {
      UserID:this.state.UserID,SupCode:supcode,SupName:supname,
      Seq:seq,Ver:ver,Type:this.state.AppType
  });
  
}

getSupplierList=()=>{
  const config = {
    headers: {   
    'currentToken': tokken,
  },
    params: {
        approver:this.state.UserID,
    }
    
  };
  this.setState({  isLoading:true })
  axios.get(ip+'/getSupplierApprovalListV1', config)
  .then(response => this.setState({ dataSource:response.data},() => {if(response.status==200){this.setState({isLoading:false})}}))
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
}

componentDidMount(){

  this.setState({
    isLoading:true
  })
  
  console.disableYellowBox = true;

  const { navigation } = this.props;


  this.focusListener = navigation.addListener("didFocus", () => {
    this.setState({
      UserID:this.props.navigation.getParam('UserID', ''),
      AppType:this.props.navigation.getParam('Type', ''),
  },()=>{
    this.getSupplierList()
  })
  
  });

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
  

  

}


  render() {
    if (this.state.isLoading) {
      return (
        <Modal
        transparent={false}
        supportedOrientations={['portrait', 'landscape']}
        visible={this.state.isLoading}
        >
         <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
           useNativeDriver={true}
           style={{width: 300, height: 200}}
           source={require('../src/gears.gif')}  />
          </View>     
        </Modal>
      )
  }
    return (
        <View style={{flex:1,backgroundColor:lightblue}}>
    
        <ScrollView style={{height:'5%'}}>

        <View  style={{ flex: 1,paddingTop:5}}>

        <View style={{borderBottomColor:'#fff',borderBottomWidth: 1,paddingTop:3}}/>

        <Grid style={{backgroundColor:colorprimary,padding:4,width:"97%",alignSelf:'center',borderRadius:4}}>
                 <Row>
                 <Col style={{alignItems:'flex-start',width:'20%'}}>
                 <Text style={styles.textContent}>Sup. Code</Text>
                 </Col> 
                 <Col style={{alignItems:'flex-start',width:'80%'}}>
                 <Text style={styles.textContent}>Supplier Name</Text>
                 </Col> 
                 </Row>
                 </Grid>
        </View>
        </ScrollView>
        <ScrollView style={{height:'95%'}}>
        <FlatList
       data={ this.state.dataSource }
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
       <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
        paddingLeft:5,paddingRight:5,paddingTop:10,paddingBottom:10}}>
       <Grid onPress={this.getSupplierDetail.bind(this,item)}>
       <Row>
       <Col style={{alignItems:'flex-start',width:'20%'}}>
       <Text style={{fontSize:13,fontFamily:'Italic'}}>{item.supcode}</Text>
       </Col>
       <Col style={{alignItems:'flex-start',width:'80%'}}>
       <Text style={{fontSize:13,fontFamily:'Italic'}}>{item.supname}</Text>
       </Col>
       </Row>
       <Divider></Divider>
       <Divider></Divider>
       <Divider></Divider>

       <Row style={{paddingTop:3,paddingBottom:3}}>
       <Col style={{alignItems:'flex-start',width:'25%'}}>
       <Text style={{fontSize:13,fontFamily:'ItalicBold',color:colorprimarydark}}>Category : </Text>
       </Col>
       <Col style={{alignItems:'flex-start',width:'75%'}}>
       <Text style={{fontSize:13,fontFamily:'Italic'}}>{item.cat}</Text>
       </Col>
       </Row>

       <Divider></Divider>
       <Divider></Divider>
       <Divider></Divider>

       <Row style={{paddingTop:3}}>
       <Col style={{alignItems:'flex-start',width:'25%'}}>
       <Text style={{fontSize:13,fontFamily:'ItalicBold',color:colorprimarydark}}>Req Name : </Text>
       </Col>
       <Col style={{alignItems:'flex-start',width:'75%'}}>
       <Text style={{fontSize:13,fontFamily:'Italic'}}>{item.reqname+" [ "+item.reqby+" ]"}</Text>
       </Col>
       </Row>

       </Grid>   
       </CardItem>
       </Card>
        }

       keyExtractor={(item, index) => index.toString()}
       
      />

<Toast ref="toast"/>
              </ScrollView>
              </View>   
        )
      }
 };
 const styles = StyleSheet.create({
  titleText: {
    flex:1,
    flexWrap:'wrap',
    color:white,
    fontSize:12,
    padding:5,
    fontFamily:'Bold'
  },
  textContent:{
    color:white,
    fontSize:12,
    fontFamily:'Bold'
  }
  });
  
  
  
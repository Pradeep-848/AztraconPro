import React, { Component } from 'react';
import { ScrollView, Modal, StyleSheet, Text, View, Image, FlatList, TouchableOpacity, Alert, Dimensions } from 'react-native';
import { Col, Grid, Row } from 'react-native-easy-grid';
import Toast from 'react-native-whc-toast'
import axios from 'axios';
import { NavigationActions, StackActions } from 'react-navigation';
import { Card, CardItem } from 'native-base';
import { RFValue } from 'react-native-responsive-fontsize';
import { Divider } from 'react-native-elements';

//own lib
import strings from '../res/strings'
import color from '../res/colors'
import { logouttask } from '../class/logout';
import { isPortrait } from '../class/useOrientation';

//constant
const ip = strings.values.commonvalues.ip;
const tokken = strings.values.commonvalues.tokken;

//color
const lightblue = color.values.Colors.lightblue;
const colorprimary = color.values.Colors.colorPrimary;
const white = color.values.Colors.white;

//common style
const style_common = require('../class/style');

//logout
const resetAction = StackActions.reset({
    index: 0,
    actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class EmpLeaveReturnAppList extends React.Component {

    static navigationOptions = ({ navigation }) => ({

        title: "Employee Leave Return List",
        color: "#fff",
        headerStyle: {
            backgroundColor: colorprimary,
        },
        headerTintColor: white,
        headerTitleStyle: {
            fontFamily: 'Bold',
        },
        headerRight: (
            <TouchableOpacity style={{ paddingRight: 10 }} onPress={() =>
                navigation.state.params.handlelogin()
            }>
                <Image
                    style={{ alignSelf: 'center', justifyContent: 'center' }}
                    source={require('../src/logout.png')} />
            </TouchableOpacity>
        ),

    });
    constructor(props) {
        super(props);
        this.state = {
            isLoading: false,
            handlelogin: '',
            dataSource: '',
            UserID: '',
            orientation: '',
            DeviceType: '',
        };
    }



    login = async () => {

        Alert.alert(
            'Logout',
            'Would you like to logout?',
            [
                {
                    text: 'Cancel',
                    onPress: () => console.log('Cancel Pressed'),
                    style: 'cancel',
                },
                {
                    text: 'OK', onPress: () => {
                        logouttask()
                        this.props.navigation.dispatch(resetAction);
                    }
                },
            ],
            { cancelable: false },
        );

    }

    getReleaseDetail = (data) => {

        const { appId, reqDate, reqBy, reqName, dept, seq, ver, Remark } = data

        this.props.navigation.navigate('EmpLeaveReturnAppActivity',
            {
                UserID: this.state.UserID,
                AppID: appId,
                ReqBy: reqBy,
                ReqName: reqName,
                ReqDate: reqDate,
                SeqNo: seq,
                Ver: ver,
                Department: dept,
                Remark: Remark,
            });
        console.log(data)

    }

    getReleaseList = () => {
        const config = {
            headers: {
                'currentToken': tokken,
            },
            params: {
                approver: this.state.UserID,
            }

        };
        this.setState({ isLoading: true })
        axios.get(ip + '/getEmpLeaveReturnAppList', config)
            .then(response => this.setState({ dataSource: response.data }, () => { if (response.status == 200) { this.setState({ isLoading: false }) } }))
            .catch(err => {
                this.setState({
                    isLoading: false
                }, () => {
                    let error = err

                    this.refs.toast.showBottom(error.toString())

                    setTimeout(
                        () => {
                            this.props.navigation.goBack();
                        },
                        2000
                    )

                })
            }
            );
    }

    componentDidMount() {

        this.setState({
            isLoading: true
        })

        console.disableYellowBox = true;

        const { navigation } = this.props;

        Dimensions.addEventListener('change', () => {
            this.setState({
                orientation: isPortrait() ? 'portrait' : 'landscape'
            });
        });


        this.focusListener = navigation.addListener("didFocus", () => {
            this.setState({
                UserID: this.props.navigation.getParam('UserID', ''),
                orientation: isPortrait() ? 'portrait' : 'landscape',
                DeviceType: this.props.navigation.getParam('DeviceType', '')
            }, () => {
                this.getReleaseList()
            })

        });

        this.props.navigation.setParams({
            handlelogin: this.login.bind(this)
        });

    }

    getheight(which) {

        let orient = ''
        let device = ''

        orient = this.state.orientation
        device = this.state.DeviceType

        if (which == '1') { //header
            if (device == 'phone') {

                if (orient == 'portrait') {
                    return '5%'
                } else {
                    //landscape
                    return '15%'
                }

            } else {
                //tab
                if (orient == 'portrait') {
                    return '5%'
                } else {
                    //landscape
                    return '8%'
                }

            }
        }


        if (which == '2') { //body
            if (device == 'phone') {

                if (orient == 'portrait') {
                    return '95%'
                } else {
                    //landscape
                    return '85%'
                }

            } else {
                //tab
                if (orient == 'portrait') {
                    return '95%'
                } else {
                    //landscape
                    return '92%'
                }

            }
        }

    }

    render() {
        if (this.state.isLoading) {
            return (
                <Modal
                    transparent={false}
                    supportedOrientations={['portrait', 'landscape']}
                    visible={this.state.isLoading}
                >
                    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
                        <Image
                            useNativeDriver={true}
                            style={style_common.load_gif}
                            source={require('../src/gears.gif')} />
                    </View>
                </Modal>
            )
        }
        return (
            <View style={{ flex: 1, backgroundColor: lightblue }}>

                <ScrollView style={{ height: this.getheight('1') }}>

                    <View style={{ flex: 1, paddingTop: 5 }}>

                        <View style={{ borderBottomColor: '#fff', borderBottomWidth: 1, paddingTop: 3 }} />

                        <Grid style={{ backgroundColor: colorprimary, padding: RFValue(4), width: "97%", alignSelf: 'center', borderRadius: 4 }}>
                            <Row>
                                <Col style={{ alignItems: 'flex-start', width: '20%' }}>
                                    <Text style={styles.textContent}>App ID</Text>
                                </Col>
                                <Col style={{ alignItems: 'flex-start', width: '20%' }}>
                                    <Text style={styles.textContent}>Emp No</Text>
                                </Col>
                                <Col style={{ alignItems: 'flex-start', width: '40%' }}>
                                    <Text style={styles.textContent}>Req Date</Text>
                                </Col>
                                <Col style={{ alignItems: 'flex-start', width: '20%' }}>
                                    <Text style={styles.textContent}>Department</Text>
                                </Col>
                            </Row>
                        </Grid>

                    </View>
                </ScrollView>

                <ScrollView style={{ height: this.getheight('2') }}>
                    <FlatList
                        data={this.state.dataSource}
                        renderItem={({ item, index }) =>
                            <Card style={{ width: '97%', alignSelf: 'center' }}>
                                <CardItem style={{
                                    alignItems: "flex-start", width: '100%', flexWrap: 'wrap',
                                    paddingLeft: 5, paddingRight: 5, paddingTop: 5, paddingBottom: 5
                                }}>
                                    <Grid onPress={this.getReleaseDetail.bind(this, item)}>
                                        <Row>
                                            <Col style={{ alignItems: 'flex-start', width: '20%' }}>
                                                <Text style={{ fontSize: 13, fontFamily: 'Italic' }}>{item.appId}</Text>
                                            </Col>
                                            <Col style={{ alignItems: 'flex-start', width: '20%' }}>
                                                <Text style={{ fontSize: 13, fontFamily: 'Italic' }}>{item.reqBy}</Text>
                                            </Col>
                                            <Col style={{ alignItems: 'flex-start', width: '40%' }}>
                                                <Text style={{ fontSize: 13, fontFamily: 'Italic' }}>{item.reqDate}</Text>
                                            </Col>
                                            <Col style={{ alignItems: 'flex-start', width: '20%' }}>
                                                <Text style={{ fontSize: 13, fontFamily: 'Italic' }}>{String(item.dept).trim()}</Text>
                                            </Col>
                                        </Row>

                                        <Divider></Divider>

                                        <Row style={{ paddingTop: 3, paddingBottom: 3 }}>
                                            <Col style={{ alignItems: 'flex-start', width: '23%' }}>
                                                <Text style={{ fontSize: 13, fontFamily: 'Bold', color: colorprimary }}>Req Name : </Text>
                                            </Col>
                                            <Col style={{ alignItems: 'flex-start', width: '77%' }}>
                                                <Text style={{ fontSize: 13, fontFamily: 'Italic', textAlign: 'left' }}>{item.reqName}</Text>
                                            </Col>
                                        </Row>
                                    </Grid>
                                </CardItem>
                            </Card>
                        }

                        keyExtractor={(item, index) => index.toString()}

                    />

                    <Toast ref="toast" />
                </ScrollView>
            </View>
        )
    }
};
const styles = StyleSheet.create({
    textContent: {
        color: white,
        fontSize: 12,
        fontFamily: 'Bold'
    }
});



import React from 'react';
import { ScrollView,Dimensions,Image,Modal,StyleSheet,Text,View,TouchableOpacity,Alert,
         KeyboardAvoidingView,Platform,FlatList,Linking} from 'react-native';
import axios from 'axios';
import { Col, Grid, Row} from 'react-native-easy-grid';
import {Card,CardItem,Item,Input,Spinner} from 'native-base';
import RadioGroup from 'react-native-radio-buttons-group';
import { NavigationActions, StackActions } from 'react-navigation';
import strings from '../res/strings'
import {logouttask} from '../class/logout';
import Toast from 'react-native-whc-toast'
import color from '../res/colors'
import { Divider,Button,Overlay } from 'react-native-elements';
import Timeline from 'react-native-timeline-flatlist'
import moment from 'moment';

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;
const fileip=strings.values.commonvalues.fileip;

const { width, height } = Dimensions.get('window');

const lightblue=color.values.Colors.lightblue;
const blue=color.values.Colors.blue;
const colorprimary=color.values.Colors.colorPrimary;
const dark=color.values.Colors.colorprimarydark;
const white=color.values.Colors.white;
const black=color.values.Colors.black;
const gray=color.values.Colors.gray;

let selectedButton;
let AppStatus;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});


export default class ProjectDrawingApproval extends React.Component {
  static navigationOptions = ({ navigation }) => ({ 
    title: "Approval",
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor:white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('../src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
      super(props);
      this.state = { 
        isLoading: true, 
        isStatus:false,
        data:[],Statusdata:[],DisStatusData:[],
        From:'',To:'',Subject:'',Date:'',Body:'',
        MsgdataSource:[],
        DrawDocDataSource:[],
        AttachdataSource:[],
        DrawDataSource:[],
        isDrawAttachment:false,
        DocDataSource:[],
        handlelogin:'',UserID:'',Comments:'',
        AppStatus:'',AppType:'',
        AppID:'',Seq:'',Ver:'',appType:'',typeDesc:'',pid:'',reqBy:'',
        reqName:'',appDate:'',tClass:'',category:'',ecrNo:'',Remark:'',reqDate:'',
        isMail:false,
        radiovalues: [
            {
                label: 'Approve',
                value: "Approve",
                color:'#2452b2'
            },
            {
                label: 'Reject',
                value: "Reject",
                color:'#2452b2'
            },
             {
                label: 'Rework',
                value: "Rework",
                color:'#2452b2'
            },
        ],
    };
      this.arrayholder = [] ;
  }

  login = async () => 
  {
  
    Alert.alert(
      'Logout',
      'Would you like to logout?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {text: 'OK', onPress: () => { logouttask()
          this.props.navigation.dispatch(resetAction);} },
      ],
      {cancelable: false},
    );
   
  }
  

componentDidMount() {

  console.disableYellowBox = true;

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
 
  this.setState({
    UserID:this.props.navigation.getParam('UserID', ''),
    AppID:this.props.navigation.getParam("AppID"),
    Seq:this.props.navigation.getParam("Seq"),
    Ver:this.props.navigation.getParam("Ver"),
    appType:this.props.navigation.getParam("appType"),
    typeDesc:this.props.navigation.getParam("typeDesc"),
    pid:this.props.navigation.getParam("pid"),
    reqBy:this.props.navigation.getParam("reqBy"),
    reqName:this.props.navigation.getParam("reqName"),
    appDate:this.props.navigation.getParam("appDate"),
    tClass:this.props.navigation.getParam("tClass"),
    category:this.props.navigation.getParam("category"),
    ecrNo:this.props.navigation.getParam("ecrNo"),
    Remark:this.props.navigation.getParam("Remark"),
    reqDate:this.props.navigation.getParam("reqDate"),
    },()=>{ this.getDrawing()})
    
}


getDrawing(){

  const config = {
    headers: {   
    'currentToken': tokken,
  },
  
  params: {
    appid:this.state.AppID,
  }
    
  };

  this.setState({isLoading:true})
  axios.get(ip+'/getDrawingDetail', config) 
  .then(response => this.setState({ DrawDataSource:response.data},() => {if(response.status==200){
    this.setState({
      isLoading:true,
    },()=>{
      this.getDoclist();
    })}}))
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );



}

getStatus(){

  this.setState({isLoading:true, StatusData:[],DisStatusData:[]})

   const config = {
       headers: {   
       'currentToken':tokken,
     },
       params: {
        appid:this.state.AppID,
       }
       
     };

 axios.get(ip+'/getProjectDrawingStatus', config)
   .then(response => this.setState({StatusData:response.data},() => {if(response.status==200){
   this.display()
   }}))
   .catch(err => 
     {
       this.setState({
         isLoading:false
       },()=>{
        let error=err
        
        this.refs.toast.showBottom(error.toString())
 
        setTimeout(
         () => { 
           this.props.navigation.goBack();
          },
         2000
       )
 
       })
     }
     );

}

getDoclist() {

    const config = {
      headers: {   
      'currentToken': tokken,
    },
    
    params: {
      doctype:this.state.appType,
      param1:this.state.AppID,
      param2:'0'
    }
      
    };
  
    //this.setState({isLoading:true})
    axios.get(ip+'/getDocumentListIOS', config) 
    .then(response => this.setState({ DocDataSource:response.data},() => {if(response.status==200){
      this.setState({
        isAttachment:response.data.length==0?false:true,
        //isLoading:false
      },()=>{
        if(this.state.DrawDataSource.length>0){
          const{dwgid}=this.state.DrawDataSource[0]
          this.getDocDrawlist(dwgid)
        }
      })}}))
    .catch(err => 
      {
        this.setState({
          isLoading:false
        },()=>{
         let error=err
         
         this.refs.toast.showBottom(error.toString())
  
         setTimeout(
          () => { 
            this.props.navigation.goBack();
           },
          2000
        )
  
        })
      }
      );
  }

getAttach(data){
    const {dwgid} = data
    this.getDocDrawlist(dwgid)
}
getDocDrawlist(dwdid) {

    const config = {
      headers: {   
      'currentToken': tokken,
    },
    
    params: {
      doctype:'DWGA',
      param1:dwdid,
      param2:'0'
    }
      
    };
  
    this.setState({isLoading:true})
    axios.get(ip+'/getDocumentListIOS', config) 
    .then(response => this.setState({ DrawDocDataSource:response.data},() => {if(response.status==200){
      this.setState({
        isDrawAttachment:response.data.length==0?false:true,
        isLoading:false
      })}}))
    .catch(err => 
      {
        this.setState({
          isLoading:false
        },()=>{
         let error=err
         
         this.refs.toast.showBottom(error.toString())
  
         setTimeout(
          () => { 
            this.props.navigation.goBack();
           },
          2000
        )
  
        })
      }
      );
  }

  DownloadDoc(data){
    
    const{SlNo,DocumentName,AttachFileName,FilePath}=data
    
    if(String(AttachFileName).slice(-3).toLowerCase()=='msg'){
       this.getMsgFile(FilePath,AttachFileName)
    }else{
        Linking.openURL(fileip+"/DocumentDownloadIOS?FPath="+FilePath+"&FileName="+AttachFileName) 
    }

   }

   DownloadFile= async (Path,Name) =>{

    console.log('here')
    
     let url=''
      
     url=fileip+"/DocumentDownloadIOS?FPath="+Path+"&FileName="+Name 
    
     const supported = await Linking.canOpenURL(url);
    
     if (supported) {
      await Linking.openURL(url);
    } else {
      Alert.alert(`Don't know how to open this URL: ${url}`);
    } 
    
    }
    

   getMsgFile(FilePath,AttachFileName){
    let FName;

    FName =AttachFileName

    const config = {
        headers: {   
        'currentToken': tokken,
      },
        params: {
          FPath:FilePath,
          FileName:FName
        }
        
      };
    
      this.setState({isLoading:true})
      axios.get(ip+'/MailDocumentDownloadIOS', config)
      .then(response => this.setState({ MsgdataSource:response.data},() => {if(response.status==200){
        console.log(this.state.MsgdataSource)
        const{Attachments,from,to,subject,date,body}=this.state.MsgdataSource[0]
        this.setState({
          From:from,
          To:to,
          Subject:subject,
          Date:date,
          Body:body,
          AttachdataSource:Attachments,
          isLoading:false,
          isMail:true})
  
      }}))
      .catch(err => 
        {
          this.setState({
            isLoading:false
          },()=>{
           let error=err
           
           this.refs.toast.showBottom(error.toString())
    
           setTimeout(
            () => { 
              this.props.navigation.goBack();
             },
            2000
          )
    
          })
        }
        );
  
  
  }
display(){
    let i=0
  for(i=0;i< this.state.StatusData.length ;i++){
      const{E,C,D,A,F}=this.state.StatusData[i]
      let Desc,tit
      if(E!==''){
        if(D!=='' && D!=null){
          if (F=='O' || F=='P') {
            Desc=C+"\n"+"Remarks : "+E
          }else{
            Desc=C+"\n"+moment(D).format('DD-MM-YYYY').toString()+"\n"+"Remarks : "+E
          }
         
        }
        else{
          Desc=C+"\n"+"Remarks : "+E
        }
        
      }else{

        if(D!=='' && D!=null){

          if (F=='O' || F=='P') {
            Desc=C
          }else{
            Desc=C+"\n"+moment(D).format('DD-MM-YYYY').toString()
          }
       
        }else{
          Desc=C
        }
        
      }

      if(F==='A'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#15ca7d",
              icon:require('../src/ic_approved.png')
          })
      }else if(F==='P'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc, 
              lineColor:"#f4b825",
              icon:require('../src/ic_pending.png')
          })
      }else if(F==='R'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#f6634b",
              icon:require('../src/ic_rejected.png')
          })
      }else if(F==='O'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#2d353a",
              icon:require('../src/ic_opened.png')
          })
      }else if(F=='W'){
          this.state.DisStatusData.push({
              title:A,
              description:Desc,
              lineColor:"#2d353a",
              icon:require('../src/ic_opened.png')
          })
      }
  
    }
    this.setState({isLoading:false,isStatus:true})
}


submit(){
  switch (selectedButton) {
      case "Approve":
          AppStatus = "A";
          break;
      case "Rework":
            AppStatus = "W";
            break;
      case "Reject":
            AppStatus = "R";
            break;

  }



  if(AppStatus!=="A"){
    if(this.state.Comments.length === 0) {
      alert("Please Enter Comment")
      return
    }
  }
  this.Save();
}
Save(){

this.setState({isLoading:true})

for(let i=0;i<this.state.DrawDataSource.length;i++){

    const{dwgid}=this.state.DrawDataSource[i]

    this.arrayholder.push({
        dwgid:dwgid
      })
}
  let url=''
  if(AppStatus==='A'){
   url='/setProjectDrawingApp'
  }else if(AppStatus=='R'){
    url='/setProjectDrawingRej'
  }else if(AppStatus=='W'){
    url='/setProjectDrawingRew'
  } 





  axios({
    method: 'post',
    url:ip+url,
    headers: {'currentToken':tokken}, 
    data: {

      "appid":this.state.AppID,
      "ver":this.state.Ver,
      "seqno":this.state.Seq,
      "apptype":this.state.appType,
      "ecrno":this.state.ecrNo,
      "category":this.state.category,
      "comments":this.state.Comments,
      "UserID":this.state.UserID,

        Dwg:{
          "appid":this.state.AppID,
          "ver":this.state.Ver,
          "seqno":this.state.Seq,
          "apptype":this.state.appType,
          "ecrno":this.state.ecrNo,
          "category":this.state.category,
          "comments":this.state.Comments,
          "UserID":this.state.UserID,
      },
      dwgItems:this.arrayholder,

      }
  }).then(response=>{if(response.status===200){
    this.setState({isLoading:false},()=>{
      this.refs.toast.showBottom("Submitted Successfully")

       this.props.navigation.goBack();

    })
  }else{
    this.refs.toast.showBottom("Failed")
  }})
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
}


onPress = radiovalues => this.setState({ radiovalues});

render() {
    selectedButton = this.state.radiovalues.find(e => e.selected == true);
    selectedButton = selectedButton ? selectedButton.value : this.state.radiovalues[0].label;   
      if (this.state.isLoading) {
          return (
            <Modal
            transparent={false}
            visible={this.state.isLoading}
            >
             <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
              <Image
              style={{width: 300, height: 200}}
              source={require('../src/gears.gif')}  />
              </View>     
            </Modal>
          )
      }

      return (
    <View style={{flex:1, backgroundColor:lightblue}}> 
    <KeyboardAvoidingView 
        behavior='padding'
        keyboardVerticalOffset={
        Platform.select({
           ios: () => 0,
           android: () => 60
        })()
        }>
  <ScrollView style={{height:"100%"}}>

  <Modal            
          animationType = {"slide"}  
          transparent = {true}  
          visible = {this.state.isStatus}  
          onRequestClose = {() =>{ console.log("Modal has been closed.") } }>  
          {/*All views of Modal*/}  
          <View style = {styles.modal}>  
          <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress = {() =>
           {  
            this.setState({ isStatus:!this.state.isStatus})
           }}>
        
        <Grid>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontFamily:'Bold',alignSelf:'flex-start'}}>
             Approval Timeline
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('../src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
       </Grid>
        

         </TouchableOpacity>


         <Timeline 
          style={styles.list}
          data={this.state.DisStatusData}
          circleSize={25}
          showTime={false}
          circleColor='rgba(0,0,0,0)'
          lineColor='rgb(45,156,219)'
          descriptionStyle={{color:'gray',fontFamily:'Regular'}}
          innerCircle={'icon'}
        />

          </View>
  </Modal>

    <View  style={{ flex: 1,paddingTop:2,paddingBottom:2}}>
    <Grid style={{paddingTop:'2%'}}>
    <Row style={{backgroundColor:colorprimary,padding:5,width:'97%',
    alignSelf:'center',alignItems:'center',borderRadius:2}}>
    <Col style={{alignItems:'center',width:'100%'}}>
    <Text style={styles.titleText}>Project Drawing Approval</Text>
    </Col>
     </Row>
     </Grid>
    </View>

  
   <Card style={{width:'97%',alignSelf:'center',paddingBottom:'1%'}}>
               <CardItem style={{alignItems:"center",width:'100%',flexWrap:'wrap',paddingTop:10,
             paddingBottom:10,paddingLeft:5,paddingRight:5}}>

    <Grid>
    <Row style={{backgroundColor:colorprimary,padding:5,alignSelf:'center',alignItems:'center'}}>
    <Col style={{alignItems:'center',width:'100%'}}>
    <Text style={styles.titleText}>Detail</Text>
    </Col>
    </Row>
               

            <Row style={styles.rowpadding}>
             <Col style={{width:'30%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Project</Text>
              </Col> 
              <Col style={{width:'70%',alignItems:'flex-start'}}>
              <Text style={styles.tvalue}>{this.state.pid}</Text>
              </Col> 
            </Row>

            <Row style={styles.rowpadding}>
             <Col style={{width:'30%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Req By</Text>
              </Col> 
              <Col style={{width:'70%',alignItems:'flex-start'}}>
              <Text style={styles.tvalue}>{this.state.reqName+'['+this.state.reqBy+']'}</Text>
              </Col> 
            </Row>

                
            <Row style={styles.rowpadding}>
             <Col style={{width:'30%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Req Date</Text>
              </Col> 
              <Col style={{width:'70%',alignItems:'flex-start'}}>
              <Text style={styles.tvalue}>{this.state.reqDate}</Text>
              </Col> 
            </Row>


            <Row style={styles.rowpadding}>
             <Col style={{width:'30%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Design Group</Text>
              </Col> 
              <Col style={{width:'70%',alignItems:'flex-start'}}>
              <Text style={styles.tvalue}>{this.state.tClass}</Text>
              </Col> 
            </Row>


            <Row style={styles.rowpadding}>
             <Col style={{width:'30%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Appr. Type</Text>
              </Col> 
              <Col style={{width:'70%',alignItems:'flex-start'}}>
              <Text style={styles.tvalue}>{this.state.typeDesc+'['+this.state.appType+']'}</Text>
              </Col> 
            </Row>

           
            <Row  style={styles.rowpadding}>
             <Col style={{width:'30%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Purpose</Text>
              </Col> 
              <Col style={{width:'70%',alignItems:'flex-start'}}>
              <Text style={styles.tvalue}>{this.state.category=='I'?'For Internal':'For Client'}</Text>
              </Col> 
            </Row>

            <Row style={styles.rowpadding}>
             <Col style={{width:'30%',alignItems:'flex-start'}}>
              <Text style={styles.htitle}>Remark</Text>
              </Col> 
              <Col style={{width:'70%',alignItems:'flex-start'}}>
              <Text style={styles.tvalue}>{this.state.Remark}</Text>
              </Col> 
            </Row>

            <Divider></Divider>
            <Divider></Divider>
            <Divider></Divider>
    </Grid>   
    </CardItem>
   </Card>     


    <View  style={{flex: 1,paddingTop:5 }}>
            <Grid style={{backgroundColor:colorprimary,padding:5,width:'97%',
            alignSelf:'center',alignItems:'center',borderRadius:2}}>
              <Row>
              <Col style={{alignItems:'center',width:'100%'}}>
              <Text style={{color:white,fontSize:13,fontFamily:'Bold'}}>Drawing Detail</Text>
              </Col>
              </Row>
            </Grid>

            <View  style={{ flex: 1,paddingTop:5}}>
             <Grid style={{backgroundColor:colorprimary,
              padding:5,width:"97%",alignSelf:'center',borderRadius:4}}>
             <Row>
             <Col style={{alignItems:'center',width:'12%'}}>
             <Text style={styles.textContent}>SNo</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'50%'}}>
             <Text style={styles.textContent}>Drawing No</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'38%'}}>
             <Text style={styles.textContent}>Revision</Text>
             </Col> 
             </Row>
             </Grid>
             </View> 
  
       <FlatList nestedScrollEnabled
       data={ this.state.DrawDataSource}
       style = {{ flexGrow: 0}}
       initialNumToRender = {this.state.DrawDataSource.length}
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'
            ,paddingTop:8,paddingBottom:8,paddingLeft:4,paddingRight:4}}>
            <Grid onPress={this.getAttach.bind(this,item)}>
              <Row style={styles.rowpadding}>
              <Col style={{alignItems:'center',width:'12%'}}>
              <Text style={{fontSize:12,alignSelf:'center',fontFamily:'Regular'}}>{index+1}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-start',fontFamily:'Regular'}}>{item.dwgno}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'38%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-start',fontFamily:'Regular'}}>{item.rev}</Text>
              </Col> 
              </Row>

            <Divider></Divider>
            <Divider></Divider>
            <Divider></Divider>

              <Row style={styles.rowpadding}>
              <Col style={{alignItems:'flex-end',width:'30%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-end',fontFamily:'Bold',color:colorprimary}}>Design  : </Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'70%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-start',fontFamily:'Regular'}}>{item.tagclass}</Text>
              </Col> 
              </Row>

            <Divider></Divider>
            <Divider></Divider>
            <Divider></Divider>

             
            <Row style={styles.rowpadding}>
              <Col style={{alignItems:'flex-end',width:'30%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-end',fontFamily:'Bold',color:colorprimary}}>Dwg. Name : </Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'70%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-start',fontFamily:'Regular'}}>{item.dwgtitle}</Text>
              </Col> 
              </Row>

            </Grid>  
             </CardItem>
           </Card>
        }

       keyExtractor={(item, index) => index.toString()}   
      />

</View>



    {/* Doc List
 */}

<View  style={{display:this.state.isAttachment==true?'flex':'none',flex: 1,paddingTop:5}}>
            <Grid style={{backgroundColor:colorprimary,padding:5,width:'97%',
            alignSelf:'center',alignItems:'center',borderRadius:2}}>
              <Row>
              <Col style={{alignItems:'center',width:'100%'}}>
              <Text style={{color:white,fontSize:13,fontFamily:'Bold'}}>Attachments</Text>
              </Col>
              </Row>
            </Grid>

       <FlatList
       data={ this.state.DocDataSource}
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',paddingTop:8,paddingBottom:8}}>
            <Grid onPress={this.DownloadDoc.bind(this,item)}>
              <Row>
              <Col style={{alignItems:'flex-start',width:'10%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-start',fontFamily:'Regular'}}>{item.SlNo}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'90%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-start',fontFamily:'Regular'}}>{item.AttachFileName}</Text>
              </Col> 
              </Row>
            </Grid>  
             </CardItem>
           </Card>
        }

       keyExtractor={(item, index) => index.toString()}
       
      />
</View>
     


  {/*Drawing Doc List
 */}

<View  style={{display:this.state.isDrawAttachment==true?'flex':'none',flex: 1,paddingTop:5}}>
            <Grid style={{backgroundColor:colorprimary,padding:5,width:'97%',
            alignSelf:'center',alignItems:'center',borderRadius:2}}>
              <Row>
              <Col style={{alignItems:'center',width:'100%'}}>
              <Text style={{color:white,fontSize:13,fontFamily:'Bold'}}>Drawing Attachments</Text>
              </Col>
              </Row>
            </Grid>

       <FlatList
       data={ this.state.DrawDocDataSource}
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',paddingTop:8,paddingBottom:8}}>
            <Grid onPress={this.DownloadDoc.bind(this,item)}>
              <Row>
              <Col style={{alignItems:'flex-start',width:'10%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-start',fontFamily:'Regular'}}>{item.SlNo}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'90%'}}>
              <Text style={{fontSize:12,alignSelf:'flex-start',fontFamily:'Regular'}}>{item.AttachFileName}</Text>
              </Col> 
              </Row>
            </Grid>  
             </CardItem>
           </Card>
        }

       keyExtractor={(item, index) => index.toString()}
       
      />
</View>
     

     <Card style={{width:'97%',alignSelf:"center"}}>
                <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
                <Item>
                <Input placeholder="Approval Comments"
                value={this.state.Comment}
                style={{fontFamily:'Regular'}}
                onChangeText={val => this.setState({ Comments: val })}
               />
               </Item>
              </CardItem>
              <CardItem style={{paddingLeft:'4%'}}>       
              <RadioGroup flexDirection='row' 
              radioButtons={this.state.radiovalues} onPress={this.onPress} />
               </CardItem>
              </Card>

        
              <Grid style={{padding:4,width:"97%",alignSelf:'center',paddingBottom:5}}>
             <Row>
             <Col style={{alignItems:'center',width:'50%',alignSelf:'center'}}>
             <Button onPress={() =>this.getStatus()} 
             raised={true}
             titleStyle={{fontSize:15,textAlign:'center',fontFamily:'Bold'}}
             buttonStyle={{
               flex:1,
               borderRadius:6,
               width:120,
               height:45
             }}
            
             title=" Status "/>
             </Col> 
             <Col style={{alignItems:'center',width:'50%'}}>
             <Button onPress={() =>this.submit()} 
              raised={true}
              titleStyle={{fontSize:15,textAlign:'center',fontFamily:'Bold'}}
              buttonStyle={{
               flex:1,
               borderRadius:6,
               width:120,
               height:45
              }}
            
             title=" Submit "/>
             </Col> 
             </Row>
            </Grid>
          
          

             {/*Mail View Modal*/} 

         <Modal            
          animationType = {"slide"}  
          transparent = {true}  
          visible = {this.state.isMail}  
          onRequestClose = {() =>{ console.log("Modal has been closed.") } }>  
          {/*All views of Modal*/}  
          <View style = {styles.modal}>  
          <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress = {() =>
           {  
            this.setState({ isMail:!this.state.isMail})
           }}>
        
          <Grid>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontFamily:'Bold',alignSelf:'flex-start'}}>
             Mail Detail
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('../src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
       </Grid>

         </TouchableOpacity>

         <Grid style={{width:'97%',alignSelf:'center'}}>
             <Row style={styles.row}>
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={styles.htitle}>From</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'70%'}}>
              <Text style={styles.tvalue}>{this.state.From}</Text>
              </Col> 
             </Row>
             <Row style={styles.row}>
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={styles.htitle}>To</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'70%'}}>
              <Text style={styles.tvalue}>{this.state.To}</Text>
              </Col> 
             </Row>
             <Row style={styles.row}>
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={styles.htitle}>Date</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'70%'}}>
              <Text style={styles.tvalue}>{this.state.Date}</Text>
              </Col> 
             </Row>
             <Row style={styles.row}>
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={styles.htitle}>Subject</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'70%'}}>
              <Text style={styles.tvalue}>{this.state.Subject}</Text>
              </Col> 
             </Row>
             <Row style={styles.row}>
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={styles.htitle}>Body</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'70%'}}>
              <Text style={styles.tvalue}>{this.state.Body}</Text>
              </Col> 
             </Row>


             <Divider style={{ backgroundColor:colorprimary}} />
             <Divider style={{ backgroundColor:colorprimary}} />

         </Grid>

     <Grid style={{paddingTop:'2%'}}>

     <Row style={{backgroundColor:colorprimary,width:'97%',alignSelf:'center',borderRadius:3}}>
     <Text style={{  flex:1,flexWrap:'wrap',color:white,fontSize:12,padding:5,fontFamily:'Bold'}}>
      Attachments
     </Text>
     </Row>  

     </Grid>

         <FlatList
       data={ this.state.AttachdataSource }
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
             paddingLeft:5,paddingRight:5,paddingTop:10,paddingBottom:10}}>

            <Grid  onPress={() => this.DownloadFile(item.FilePath,item.FileName)}>      
              <Row>
              <Col style={{alignItems:'flex-start',width:'100%'}}>
              <Text style={{fontSize:13,fontFamily:'Italic'}}>{item.FileName}</Text>
              </Col> 
              </Row>
            </Grid>  
             </CardItem>
           </Card>
        }

       keyExtractor={(item, index) => index.toString()}
       
      />

        </View>
  </Modal>

          <Toast ref="toast"/>
          </ScrollView>
          </KeyboardAvoidingView>
          </View>
      );
  }
}

const styles = StyleSheet.create({

    rowpadding:{
        paddingTop:4,
        paddingBottom:4
    },
    ButtonSection: {

        paddingTop:3,
        width: '100%',
        justifyContent: 'center',
        alignItems: 'center',
        paddingBottom:10
     },

  container: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: '#F5FCFF',
  },
    textContentHead: {
      backgroundColor:'#fff',
      fontSize: 14,
      color: '#36428a',
      fontWeight: 'bold',
      textShadowColor: 'rgba(0, 0, 0, 0.75)',
      textShadowOffset: {width: -1, height: 1},
      textShadowRadius: 10
    },
  itemView: {
    flex: 1,
    width,
    borderBottomWidth: 0.5,
    borderColor: '#cdcdcd',
    borderStyle: 'solid',
    paddingHorizontal: 12,
    flexDirection: 'row',
    paddingTop:2
},
textContent:{
  color:white,
  fontSize:12
},

textTotalContent:{
  color:'#3A6705',
  fontSize:12,
  fontFamily:'Bold'
},

testHead:{
    width:"100%",
    fontSize:13,
    color:colorprimary,
    fontFamily:'Bold',
    textAlign:'right',
    
},
CButton:{
    paddingTop:8,
    height:45,
    width:80,
    paddingBottom:4
},
imagebutton: {
    width:30,
    height: 30,        
  },
  modal: {  
    flex:1,
    width:'100%',
    backgroundColor:white,
    height:'auto',
    position: 'absolute',
    bottom: 0
     },
     headerback: {
      flexDirection: 'row',
      alignItems:'center',
      backgroundColor: colorprimary,
      borderWidth: 0.5,
      borderColor:white,
      height: 40,
      width:'100%',
      borderRadius: 5,
    },
    titleText: {
      flex:1,
      flexWrap:'wrap',
      color:white,
      fontSize:13,
      fontFamily:'Bold'
    },
    htitle:{
        color:'#36428a',
        fontSize:14,
        alignSelf:'flex-start',
        fontFamily:'Bold'
       },
       tvalue:{
        alignSelf:'flex-end',
        fontSize:14,
        color:black,
        fontFamily:'Regular'
       },
       modal: {  
        flex:1,
        backgroundColor:white,
        height:'auto',
        position: 'absolute',
        bottom: 0,
        width:'100%',
         },
         headerback: {
          flexDirection: 'row',
          alignItems:'center',
          backgroundColor: colorprimary,
          borderWidth: 0.5,
          borderColor:white,
          height: 40,
          width:'100%',
          borderRadius: 5,
        },
        row:{
            paddingTop:3,
            paddingBottom:3
          }
});


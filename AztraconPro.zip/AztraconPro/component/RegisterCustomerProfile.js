import React,{ Component }  from 'react';
import {View,TouchableOpacity,StyleSheet,Image,ScrollView,Alert,Modal} from 'react-native';
import { Col, Grid,Row } from 'react-native-easy-grid';
import { Item,Input,Form,Label } from 'native-base';
import { NavigationActions, StackActions } from 'react-navigation';
import Toast from 'react-native-whc-toast'
import axios from 'axios';
import { CustomButton } from './custom-button.js';
import {logouttask} from './class/logout';
import color from './res/colors'
import strings from './res/strings'

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const colorprimarydark=color.values.Colors.colorPrimaryDark;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

 export default class RegisterCustomerProfile extends React.Component {
   static navigationOptions = ({ navigation }) => ({ 
    title: "Customer Profile",
    headerStyle: {
      backgroundColor: colorprimary
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
  });
  
  constructor(props) {
    super(props);
    this.state = {
        ed_email:"",
        handlelogin:'',
        isLoading:false,
        ed_name:"",
        ed_add1:"",
        ed_add2:"",
        ed_add3:"",
        ed_add4:"",
        ed_fax:"",
        ed_telex:""
    };

}

getprofile=()=>{
    const config = {
      headers: {   
      'currentToken':tokken,
    },
      params: {
        UserID:this.state.UserID,
      }
      
    };
  
    this.setState({isLoading:true})
    axios.get(ip+'/getCustomerProfile', config)
    .then(response => this.setState({ data:response.data},() => {if(response.status==200){
        const { Email, Name, Add1, Add2 ,Add3 ,Add4 ,Fax ,Telex } = this.state.data;
        this.setState({
            ed_email:Email,
            ed_name:Name,
            ed_add1:Add1,
            ed_add2:Add2,
            ed_add3:Add3,
            ed_add4:Add4,
            ed_fax:Fax,
            ed_telex:Telex,
            isLoading:false
        });
    }}))
    .catch(err => 
      {
  
        this.setState({
          isLoading:false
        },()=>{
         let error=err
         
         this.refs.toast.showBottom(error.toString())
  
         setTimeout(
          () => { 
            this.props.navigation.goBack();
           },
          2000
        )
  
        })
      }
      );
} 

onsave(){

  console.log("save")


  this.setState({isLoading:true})

  let u="/updateCustomerRegisterProfile"

  axios({
    method: 'post',
    url:ip+u,
    headers: {'currentToken':tokken}, 

    data:{
      Email:this.state.ed_email==null?'':this.state.ed_email, 
      Name:this.state.ed_name==null?'':this.state.ed_name,    
      Add1:this.state.ed_add1==null?'':this.state.ed_add1,
      Add2:this.state.ed_add2==null?'':this.state.ed_add2,    
      Add3:this.state.ed_add3==null?'':this.state.ed_add3,
      Add4:this.state.ed_add4==null?'':this.state.ed_add4,
      Fax:this.state.ed_fax==null?'':this.state.ed_fax,
      Telex:this.state.ed_telex==null?'':this.state.ed_telex
    },


  }).then(response=>{if(response.status===200){
        this.setState({isLoading:false},()=>{ 
          this.refs.toast.showBottom('Update Successful');
        })
  }else{
    this.refs.toast.showBottom('Save Failed');
  }})
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())
  
       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )
      })
    }
    );
}


login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
        this.props.navigation.dispatch(resetAction);
    } },
    ],
    {cancelable: false},
  );
 
}


componentDidMount(){

  console.disableYellowBox = true;

  this.props.navigation.setParams({
    handlelogin: this.login.bind(this)
    });

  this.setState({
    UserID:this.props.navigation.getParam('UserID', ''),
    name:this.props.navigation.getParam('Name', ''),
},()=>{
  this.getprofile()
})
  
}


render() {

  if (this.state.isLoading) {
    return (
      <Modal
      transparent={false}
      visible={this.state.isLoading}
      >
       <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
        <Image
        style={{width: 300, height: 200}}
        source={require('./src/gears.gif')}  />
        </View>     
      </Modal>
    )
  }
return (
<ScrollView>
       <Grid style={{paddingBottom:20}}>
       <Form>


           <Row style={styles.rowstyle}>
           <Col style={{width:'100%',alignItems:"flex-start"}}>
           <Item  floatingLabel>
              <Label style={styles.floatlabel}>Email</Label>
              <Input 
                getRef={(input) => { this.email = input; }}
                returnKeyType='next'
                maxLength={50}
                style={styles.istyle}
                autoCorrect={false}
                autoCapitalize='words'
                editable={false}
                keyboardType={'default'}
                value={this.state.ed_email}
                onChangeText={(ed_email) => this.setState({ ed_email })}
                onSubmitEditing={() => { this.name._root.focus(); }}
              />
            </Item>
            </Col>
           </Row>


           <Row style={styles.rowstyle}>
           <Col style={{width:'100%',alignItems:"flex-start"}}>
           <Item floatingLabel>
              <Label style={styles.floatlabel}>Name</Label>
              <Input 
                getRef={(input) => { this.name = input; }}
                returnKeyType='next'
                maxLength={50}
                style={styles.istyle}
                autoCorrect={false}
                autoCapitalize='words'
                keyboardType={'default'}
                value={this.state.ed_name}
                onChangeText={(ed_name) => this.setState({ ed_name })}
                onSubmitEditing={() => { this.add1._root.focus(); }}
              />
            </Item>
            </Col>
           </Row>

           <Row style={styles.rowstyle}>
           <Col style={{width:'100%',alignItems:"flex-start"}}>
           <Item  floatingLabel>
              <Label style={styles.floatlabel}>Address 1</Label>
              <Input 
                getRef={(input) => { this.add1 = input; }}
                returnKeyType='next'
                maxLength={50}
                style={styles.istyle}
                autoCorrect={false}
                autoCapitalize='words'
                keyboardType={'default'}
                value={this.state.ed_add1}
                onChangeText={(ed_add1) => this.setState({ ed_add1 })}
                onSubmitEditing={() => { this.add2._root.focus(); }}
              />
            </Item>
            </Col>
           </Row>

           <Row style={styles.rowstyle}>
           <Col style={{width:'100%',alignItems:"flex-start"}}>
           <Item  floatingLabel>
              <Label style={styles.floatlabel}>Address 2</Label>
              <Input 
                getRef={(input) => { this.add2 = input; }}
                returnKeyType='next'
                maxLength={50}
                style={styles.istyle}
                autoCorrect={false}
                autoCapitalize='words'
                keyboardType={'default'}
                value={this.state.ed_add2}
                onChangeText={(ed_add2) => this.setState({ ed_add2 })}
                onSubmitEditing={() => { this.add3._root.focus(); }}
              />
            </Item>
            </Col>
           </Row>

           <Row style={styles.rowstyle}>
           <Col style={{width:'100%',alignItems:"flex-start"}}>
           <Item  floatingLabel>
              <Label style={styles.floatlabel}>Address 3</Label>
              <Input 
                getRef={(input) => { this.add3 = input; }}
                returnKeyType='next'
                maxLength={50}
                style={styles.istyle}
                autoCorrect={false}
                autoCapitalize='words'
                keyboardType={'default'}
                value={this.state.ed_add3}
                onChangeText={(ed_add3) => this.setState({ ed_add3 })}
                onSubmitEditing={() => { this.add4._root.focus(); }}
              />
            </Item>
            </Col>
           </Row>

           <Row style={styles.rowstyle}>
           <Col style={{width:'60%',alignItems:"flex-start"}}>
           <Item floatingLabel>
              <Label style={styles.floatlabel}>Address 4</Label>
              <Input 
                getRef={(input) => { this.add4 = input; }}
                returnKeyType='next'
                autoCorrect={false}
                style={styles.istyle}
                maxLength={50}
                autoCapitalize='words'
                keyboardType={'default'}
                value={this.state.ed_add4}
                onChangeText={(ed_add4) => this.setState({ ed_add4 })}
                onSubmitEditing={() => { this.fax._root.focus(); }}
              />
            </Item>
           </Col> 
           <Col style={{width:'40%',alignItems:"flex-start"}}>
          
           <Item floatingLabel>
              <Label style={styles.floatlabel}>FAX</Label>
              <Input 
                getRef={(input) => { this.fax = input; }}
                returnKeyType='next'
                autoCorrect={false}
                style={styles.istyle}
                maxLength={20}
                autoCapitalize='words'
                keyboardType={'default'}
                value={this.state.ed_fax}
                onChangeText={(ed_fax) => this.setState({ ed_fax })}
                onSubmitEditing={() => { this.telex._root.focus(); }}
              />
            </Item>

           </Col> 
           </Row>

           <Row style={styles.rowstyle}>
           <Col style={{width:'100%',alignItems:"flex-start"}}>
           <Item floatingLabel>
              <Label style={styles.floatlabel}>Telex</Label>
              <Input 
                getRef={(input) => { this.telex = input; }}
                returnKeyType='done'
                maxLength={20}
                style={styles.istyle}
                autoCorrect={false}
                autoCapitalize='words'
                keyboardType={'default'}
                value={this.state.ed_telex}
                onChangeText={(ed_telex) => this.setState({ ed_telex })}
              />
            </Item>
            </Col>
           </Row>
       
          </Form>
       </Grid>
    

       <CustomButton
                 title="SUBMIT"
                 onPress={() => this.onsave()}
                 style={{ backgroundColor:colorprimarydark,
                 width:'90%',alignSelf:'center'}}
                 textStyle={{ fontSize:13,fontWeight:'bold' }}/>
       

    <Toast ref="toast" />

</ScrollView>  
)
}
}

const styles = StyleSheet.create({
image:{
    width:40,
    height:40
},
textContent: {
    backgroundColor:colorprimary,
    fontSize: 12,
    padding:4,
    width:'97%',
    alignSelf:'center',
    color:white,
    fontWeight: 'bold'
  },
  imagebutton: {
    width:80,
    height: 80,
    alignSelf:'center'
  },
  imagetext:{
      color:colorprimary,
      fontSize:12,
      alignSelf:'center'
  },
  i: {
    paddingTop:10,
  },
  floatlabel:{
  color:colorprimarydark,
  fontSize:15
  },
  TButton:{
    width:'45%',
    height:50,
    paddingLeft:'10%'
  },
  headerback: {
    flexDirection: 'row',
    alignItems:'center',
    backgroundColor: colorprimary,
    borderWidth: 0.5,
    borderColor:white,
    height: 40,
    width:'100%',
    borderRadius: 5,
  },
  modal: {  
    flex: 1,
    backgroundColor:white,
    height:'70%', 
    position: 'absolute',
    bottom: 0
     },
  container: {
    backgroundColor:white,
    flex: 1,
    height: '100%',
    justifyContent: 'space-around',
    left: 0,
    position: 'absolute',
    top: 0,
    width: '100%'
  },
  rowstyle:{
    paddingTop:6,
  },
  istyle:{
   fontSize: 13 
  }
});

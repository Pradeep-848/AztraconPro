import React,{ Component }  from 'react';
import {Dimensions,ScrollView,StyleSheet,View,Image,FlatList,Text,TouchableOpacity,Modal,Alert} from 'react-native';
import { Col, Grid,Row } from 'react-native-easy-grid';
import axios from 'axios';
import {Card,CardItem,Item,Input} from 'native-base';
import { Overlay,Button } from 'react-native-elements';
import RadioGroup from 'react-native-radio-buttons-group';
import strings from './res/strings'
import color from './res/colors'
import Toast from 'react-native-whc-toast'

var { width, height } = Dimensions.get('window');
const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;


const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;

const mheight=Math.round(Dimensions.get('window').height)/2;
const sheight=(mheight/2)+mheight;
let selectedButton;
let AppStatus;

let ID;

let m;
let m1;

 export default class POAppPro extends React.Component {
  static navigationOptions  = ({ navigation }) => ({ 
    title: "PO Project",
    color:"#fff",
    headerStyle: {
      backgroundColor: "#2452b2",
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
      USER:'',
      PONO:'',
      handlelogin:'',
      SEQNO:'',
      isLoading: false, 
      dataSource:[],
      Approve:false,
      Rework:false,
      Remarks:'',
      data:'',
      PODate:'',
      POValue_SCY:'',
      Pid:'',
      POValue_SAR:'',
      Cur:'',
      value: 'first',
      PODate:'',
      DueDate:'',
      Pid:'',
      POValue:'',
      POValueLcy:'',
      Cur:'',
      Sup:'',
      WH:'',
      POBy:'',
      POStatus:'',
      radiovalues: [
        {
            label: 'Approve',
            value: "Approve",
            color:'#2452b2'
        },
        {
            label: 'Reject',
            value: 'Reject',
            color:'#2452b2'
        },
        {
            label: 'ReWork',
            value: 'ReWork',
            color:'#2452b2'
        },
      
    ],
   // selectedButton:'',
   isv: false,
    Comment:'',
    RComment:'',
    dataRESULT:'',
    passingdata:[],
    passingdataarray:[],
    OSNO:'',
    OITYPE:'',
    OPRNO:'',
    OICODE:'', 
    OIMEMO:'', 
    OTOTLCY:'', 
    OVAT:'', 
    OLENGTH:'', 
    ODESC:'', 
    OCAT:'', 
    OMAT:'', 
    OREQQTY:'', 
    OPUOM:'', 
    ORPUOM:'', 
    OTOTVAL:'',
    OTOTWGT:'',
    isVisible:true
    };

}

login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
      this.props.navigation.navigate('LoginActivity');} },
    ],
    {cancelable: false},
  );
 
}

onPress = radiovalues => this.setState({ radiovalues});

listitempress(index) {

ID=index

const{A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q}=this.state.dataSource[ID]

this.setState({OSNO:A,OITYPE:D,OPRNO:B,OICODE:F,OIMEMO:P,OTOTLCY:O,OVAT:Q,OLENGTH:I,ODESC:G,OCAT:E,OMAT:H,OREQQTY:J,OPUOM:K,ORPUOM:L,OTOTVAL:O,OTOTWGT:M},()=>{this.modelopen(true)})
}
modelopen(visible){
  this.setState({isv: visible});
}
c(visible){
  this.setState({isVisible: visible});
}

onSave(){
  switch (selectedButton) {
    case "Approve":
        AppStatus = "A";
        break;
    case "ReWork":
        AppStatus = "W";
        break;
    case "Reject":
            AppStatus = "R";
            break;
}
if(AppStatus!=="A"){
  if(this.state.Comment.length === 0) {
    alert("Please Enter Comment")
  }
}
this.CheckBudget();
}
onStatus(){
this.props.navigation.navigate('POStatusActivity',{PONo:this.state.PONO,UserID:this.state.USER});
}


DOCUMENT(){


  this.props.navigation.navigate('DocumentActivity',{
    UserID:this.state.UserID,
    DocType:"PO",
    Param1:this.state.PONO,
    Param2:'0',
});

}

CheckBudget(){
    console.log(this.state.PONO)
    const config = {
        headers: {   
        'currentToken':tokken,
      },
        params: {
            pono:this.state.PONO,
        }
        
      };
    
      this.setState({isLoading:true})
      axios.get(ip+'/checkBudget', config)
      .then(response => this.setState({ dataRESULT:response.data},() => {if(response.status==200){this.onInsert()}}))
      .catch(err => 
        {
          this.setState({
            isLoading:false
          },()=>{
           let error=err
           
           this.refs.toast.showBottom(error.toString())
    
           setTimeout(
            () => { 
              this.props.navigation.goBack();
             },
            2000
          )
    
          })
        }
        );
}
onInsert(){
    this.setState({isLoading:true})

    const{Result}=this.state.dataRESULT

    if(Result==='Yes'){  
          this.onpass();
    }else{
         this.refs.toast.showBottom('Budget Validation - Error '+Result.toString())
         this.setState({isLoading:false})
    }
}
onpass(){
  let url=''
  if(AppStatus==='A'){
   url='/setPOAppPro'
  }else if(AppStatus==='R'){
    url='/setPORejPro'
  }else if(AppStatus==='W'){
   url='/setPORewPro'
  }

  axios({
    method: 'post',
    url:ip+url,
    headers: {'currentToken':tokken}, 
    data: {
        pono:this.state.PONO,       
        userid:this.state.USER,     
        comments:this.state.Comment,   
        status:AppStatus,    
        seqno:this.state.SEQNO      
    }
  }).then(response=>{if(response.status===200){
    this.setState({isLoading:false},()=>{
      this.refs.toast.showBottom('Success')
      this.props.navigation.goBack();
    })
  }else{
    this.refs.toast.showBottom('Failed')
  }})
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );

}
componentDidMount(){
  console.disableYellowBox = true;

  this.props.navigation.setParams({
    handlelogin: this.login.bind(this)
    });
    this.setState({USER:this.props.navigation.getParam('UserID', ''),PONO:this.props.navigation.getParam('PONo', ''),SEQNO:this.props.navigation.getParam('SeqNo', '')},()=>{this.getPOListProDetail();})
}
approve(){
    alert(this.state.Approve)
    this.setState({Approve:!this.state.Approve})
}
rework(){
    this.setState({Rework:!this.state.Rework})
}
getPOListProDetail(){
    const config = {
        headers: {   
        'currentToken':tokken,
      },
        params: {
            pono:this.state.PONO,
        }
        
      };
    
      this.setState({isLoading:true})
      axios.get(ip+'/getPOListProDetail', config)
      .then(response => this.setState({ data:response.data},() => {if(response.status==200){this.getPOListProItem()}}))
      .catch(err => 
        {
          this.setState({
            isLoading:false
          },()=>{
           let error=err
           
           this.refs.toast.showBottom(error.toString())
    
           setTimeout(
            () => { 
              this.props.navigation.goBack();
             },
            2000
          )
    
          })
        }
        );
}
getPOListProItem(){
    const config = {
        headers: {   
        'currentToken':tokken,
      },
        params: {
            pono: this.state.PONO,
        }
        
      };

  axios.get(ip+'/getPOListProItem', config)
    .then(response => this.setState({dataSource:response.data},() => {if(response.status==200){
      const {A,B,C,D,E,F,G,H,I,J} = this.state.data;
      this.setState({PODate:A,DueDate:B,Pid:C,POValue:D,POValueLcy:E,Cur:F,Sup:G,WH:H,POBy:I,POStatus:J});
      this.setState({isLoading:false}); }}))
      .catch(err => 
        {
          this.setState({
            isLoading:false
          },()=>{
           let error=err
           
           this.refs.toast.showBottom(error.toString())
    
           setTimeout(
            () => { 
              this.props.navigation.goBack();
             },
            2000
          )
    
          })
        }
        );
}
  render() {
    selectedButton = this.state.radiovalues.find(e => e.selected == true);
    selectedButton = selectedButton ? selectedButton.value : this.state.radiovalues[0].label;    
 
    if (this.state.isLoading) {
      return (
        <Modal
        transparent={false}
        supportedOrientations={['portrait', 'landscape']}
        visible={this.state.isLoading}
        >
         <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
          style={{width: 300, height: 200}}
          source={require('./src/gears.gif')}  />
          </View>     
        </Modal>
      )
  }
    return (
    <ScrollView>

    <View style={{flex: 1,paddingTop:'2%',width:'97%',alignSelf:'center'}}>
       <Grid style={{backgroundColor:colorprimary,borderRadius:4,padding:5}}>
       <Row>
       <Col>
       <Text style={styles.textContent}>Purchase Order Detail(Project)</Text>
       </Col>
       </Row>
       </Grid>
    </View> 

    <Card style={{width:'97%',alignSelf:'center'}}>
      <CardItem style={{alignItems:'flex-start',width:'100%',flexWrap:'wrap'}}>
      <Grid>
      <Row style={{paddingTop:3}}>
      <Col style={{alignItems:'flex-start',width:'15%'}}>
      <Text style={{color:'#2452b2',fontSize:13,fontFamily:'Bold'}}>PO No.</Text>
      </Col>
      <Col style={{alignItems:'flex-start',width:'35%'}}>
      <Text style={{fontSize:13,fontFamily:'Regular'}}>{this.state.PONO}</Text>
      </Col>
      <Col style={{alignItems:'flex-start',width:'20%'}}>
      <Text style={{color:'#2452b2',fontSize:13,fontFamily:'Bold'}}>PO Date -</Text>
      </Col>
      <Col style={{alignItems:'flex-start',width:'30%'}}>
      <Text style={{fontSize:13,fontFamily:'Regular'}}>{this.state.PODate}</Text>
      </Col>
      </Row>
      <View style={{borderBottomColor:'#A9A9A9',borderBottomWidth: 1,height:5,width:'100%',alignSelf:'center'}}/>
      <Row style={{paddingTop:6}}>
      <Col style={{alignItems:'flex-start',width:'15%'}}>
      <Text style={{color:'#2452b2',fontSize:12,fontFamily:'Bold'}}>Project</Text>
      </Col>
      <Col style={{alignItems:'flex-start',width:'10%'}}>
      <Text style={{fontSize:12,fontFamily:'Regular'}}>{this.state.Pid}</Text>
      </Col>
      <Col style={{alignItems:'flex-start',width:'20%'}}>
      <Text style={{color:'#2452b2',fontSize:12,fontFamily:'Bold'}}>Supplier</Text>
      </Col>
      <Col style={{alignItems:'flex-start',width:'25%'}}>
      <Text style={{fontSize:12,fontFamily:'Regular'}}>{this.state.Sup}</Text>
      </Col>
      <Col style={{alignItems:'flex-start',width:'20%'}}>
      <Text style={{color:'#2452b2',fontSize:12,fontFamily:'Bold'}}>Location</Text>
      </Col>
      <Col style={{alignItems:'flex-start',width:'10%'}}>
      <Text style={{fontSize:12,fontFamily:'Regular'}}>{this.state.WH}</Text>
      </Col>
      </Row>
      <View style={{borderBottomColor:'#A9A9A9',borderBottomWidth: 1,height:5,width:'100%',alignSelf:'center'}}/>
      <Row style={{paddingTop:6}}>
      <Col style={{alignItems:'flex-start',width:'30%'}}>
      <Text style={{color:'#2452b2',fontSize:13,fontFamily:'Bold'}}>PO By</Text>
      </Col>
      <Col style={{alignItems:'flex-start',width:'70%'}}>
      <Text style={{fontSize:13,fontFamily:'Regular'}}>{this.state.POBy}</Text>
      </Col>
      </Row>
      <Row style={{paddingTop:6}}>
      <Col style={{alignItems:'flex-start',width:'30%'}}>
      <Text style={{color:'#2452b2',fontSize:13,fontFamily:'Bold'}}>Due Date</Text>
      </Col>
      <Col style={{alignItems:'flex-start',width:'70%'}}>
      <Text style={{fontSize:13,fontFamily:'Regular'}}>{this.state.DueDate}</Text>
      </Col>
      </Row>
      <Row style={{paddingTop:6}}>
      <Col style={{alignItems:'flex-start',width:'30%'}}>
      <Text style={{color:'#2452b2',fontSize:13,fontFamily:'Bold'}}>PO Value[SCY]</Text>
      </Col>
      <Col style={{alignItems:'flex-start',width:'70%'}}>
      <Text style={{fontSize:13,fontFamily:'Regular'}}>{this.state.POValue + " " + this.state.Cur}</Text>
      </Col>
      </Row>
      <Row style={{paddingTop:6}}>
      <Col style={{alignItems:'flex-start',width:'30%'}}>
      <Text style={{color:'#2452b2',fontSize:13,fontFamily:'Bold'}}>PO Value[SAR]</Text>
      </Col>
      <Col style={{alignItems:'flex-start',width:'70%'}}>
      <Text style={{fontSize:13,fontFamily:'Regular'}}>{this.state.POValueLcy}</Text>
      </Col>
      </Row>
      </Grid>
      </CardItem>
    </Card>

<View style={styles.Head}>
            <Grid style={{width:'97%',alignSelf:'center',backgroundColor:'#2452b2',padding:5,borderRadius:4}}>
              <Col style={{alignItems:'flex-start',width:'15%'}}>
              <Text style={{color:'#fff',fontSize:13,fontFamily:'Bold'}}>SNo</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{color:'#fff',fontSize:13,fontFamily:'Bold'}}>Item Type</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'35%'}}>
              <Text style={{color:'#fff',fontSize:13,fontFamily:'Bold'}}>Item Code</Text>
              </Col> 
            </Grid>  
</View> 
   <FlatList
       data={ this.state.dataSource }
       initialNumToRender={this.state.dataSource.length}
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
                  paddingLeft:5,paddingRight:5,paddingTop:5,paddingBottom:5}}>
            <Grid onPress={()=>this.listitempress(index)}>
            <Row>
              <Col style={{alignItems:'flex-start',width:'15%'}}>
              <Text style={{fontSize:13,fontFamily:'Regular'}}>{item.A}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,fontFamily:'Regular'}}>{item.D}</Text>
              </Col> 
               <Col style={{alignItems:'flex-start',width:'35%'}}>
              <Text style={{fontSize:13,fontFamily:'Regular'}}>{item.F}</Text>
              </Col> 
            </Row>
        <View style={{borderBottomColor:'#A9A9A9',borderBottomWidth: 1,height:5,width:'100%',alignSelf:'center'}}/>
        <Row style={{paddingTop:1}}>
        <Col style={{alignItems:'flex-start',width:'100%'}}>
              <Text style={{fontSize:13,fontFamily:'Italic'}}>{item.G}</Text>
        </Col> 
        </Row>
            </Grid>  
             </CardItem>
           </Card>
        }

       keyExtractor={(item, index) => index.toString()} 
      />
      <Card style={{width:'97%',alignSelf:'center'}}>
          <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
          <Item>
              <Input placeholder="Approval Comments"
                value={this.state.Comment}
                style={{fontFamily:'Regular'}}
                onChangeText={val => this.setState({ Comment: val })}
               />
         </Item>
      
          </CardItem>
        <CardItem style={{paddingLeft:20}}>
      <RadioGroup flexDirection='row' radioButtons={this.state.radiovalues} onPress={this.onPress} />
     </CardItem>
      </Card>

<View style={{flexDirection:"row",alignItems:'center',paddingTop:20}}>
<View style={styles.button_1}>
<Button
            title="STATUS"
            titleStyle={{fontFamily:'Bold',fontSize:13}}
            containerStyle={{borderRadius:4}}
            onPress={this.onStatus.bind(this)}
/>
</View>
<View style={styles.button_1}>
<Button
            title="DOCUMENT"
            containerStyle={{borderRadius:4}}
            titleStyle={{fontFamily:'Bold',fontSize:13}}
            onPress={this.DOCUMENT.bind(this)}
          />
</View>
<View style={styles.button_1}>
<Button
            title="SUBMIT"
            containerStyle={{borderRadius:4}}
            titleStyle={{fontFamily:'Bold',fontSize:13}}
            onPress={this.onSave.bind(this)}
          />
</View>
</View>

<Overlay
       overlayStyle={{ width:"95%" , height:"88%",borderRadius:4}}
       animationType='slide'
       isVisible={this.state.isv}
       onBackdropPress={() => this.setState({ isv: false })}>
       <View style={styles.b}>
       <Grid>
       <Col style={styles.C}>
       <Text style={styles.tittle} >SNo</Text>
       </Col> 
       <Col>
       <Text style={styles.detail}>{this.state.OSNO}</Text>
       </Col> 
       </Grid>
       </View>
       <View style={styles.b}>
       <Grid>
       <Col style={styles.C}>
       <Text style={styles.tittle}>Item Type</Text>
       </Col> 
       <Col>
       <Text style={styles.detail}>{this.state.OITYPE}</Text>
       </Col> 
       </Grid>
       </View>
       <View style={styles.b}>
       <Grid>
       <Col style={styles.C}>
       <Text style={styles.tittle}>PR NO</Text>
       </Col> 
       <Col>
       <Text style={styles.detail}>{this.state.OPRNO}</Text>
       </Col> 
       </Grid>
       </View>
       <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle}>Item Code</Text>
          </Col> 
          <Col>
          <Text style={styles.detail}>{this.state.OICODE}</Text>
          </Col> 
        </Grid>
      </View>
      <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle}>Item Description</Text>
          </Col> 
          <Col>
          <Text style={styles.detail}>{this.state.ODESC}</Text>
          </Col> 
        </Grid>
      </View>
      <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle}>Category</Text>
          </Col> 
          <Col>
          <Text style={styles.detail}>{this.state.OCAT}</Text>
          </Col> 
        </Grid>
      </View>
      <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle}>Material</Text>
          </Col> 
          <Col>
          <Text style={styles.detail}>{this.state.OMAT}</Text>
          </Col> 
        </Grid>
      </View>
      <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle}>Required Quentity</Text>
          </Col> 
          <Col>
          <Text style={styles.detail}>{this.state.OREQQTY}</Text>
          </Col> 
        </Grid>
      </View>
      <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle}>Purchase UOM</Text>
          </Col> 
          <Col>
          <Text style={styles.detail}>{this.state.OPUOM}</Text>
          </Col> 
        </Grid>
      </View>
      <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle}>Rate Per UOM</Text>
          </Col>
          <Col>
          <Text style={styles.detail}>{this.state.ORPUOM}</Text>
          </Col> 
        </Grid>
      </View>
      <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle}>Total Value[AED]</Text>
          </Col> 
          <Col>
          <Text style={styles.detail}>{this.state.OTOTVAL}</Text>
          </Col> 
        </Grid>
      </View>
      <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle}>Total Weight[Kgs]</Text>
          </Col> 
          <Col>
          <Text style={styles.detail}>{this.state.OTOTWGT}</Text>
          </Col> 
        </Grid>
      </View>
      <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle}>Item Memo</Text>
          </Col> 
          <Col>
          <Text style={styles.detail}>{this.state.OIMEMO}</Text>
          </Col> 
        </Grid>
      </View>
      <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle}>Total Value LCY</Text>
          </Col> 
          <Col>
          <Text style={styles.detail}>{this.state.OTOTLCY}</Text>
          </Col> 
        </Grid>
      </View>
      <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle}>VAT %</Text>
          </Col> 
          <Col>
          <Text style={styles.detail}>{this.state.OVAT}</Text>
          </Col> 
        </Grid>
      </View>
      <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle}>Length</Text>
          </Col> 
          <Col>
          <Text style={styles.detail}>{this.state.OLENGTH}</Text>
          </Col> 
        </Grid>
      </View>
      <Grid>
        <Col style={{alignItems:'center'}}>
        <View style={{flexDirection:"row",alignItems:'center',paddingTop:5}}>
        <View style={styles.button_1}>
        <Button
        title={'CANCEL'}
        titleStyle={{fontFamily:'Bold'}}
        containerStyle={{borderRadius:4}}
        onPress={() => { this.modelopen(!this.state.isv)} } 
        />
        </View>
        </View>
        </Col>
      </Grid>
       </Overlay>
       <Toast ref="toast"/>
   </ScrollView>
        )
      }
 };
 const styles = StyleSheet.create({
    textContent: {
      fontSize: 13,
      alignItems:'center',
      color: '#fff',
      fontFamily:'Bold'
      },
      Head: {
        flex: 1,
        paddingTop:'1%',
        alignSelf:'center',
        width:'100%'
      },
      text: {
        padding: 15,
        width:100,
        alignSelf:'center',
        color:'#fff',
        backgroundColor:"#1ca0ff"
     },
 
     Alert_Main_View:{
      alignItems: 'center',
      justifyContent: 'center',
      height:300,
      width: '90%',
      borderWidth: 1,
      borderColor: '#fff',
      borderRadius:7,
     
    },
     
      buttonStyle: {
          
          width: '50%',
          height: '100%',
          justifyContent: 'center',
          alignItems: 'center'
       
      },
         
      TextStyle:{
          color:'#fff',
          textAlign:'center',
          fontSize: 22,
          marginTop: -5
      },
      tittle:{
        color:'#36428a',
        fontSize:13,
        fontFamily:'Bold'
       },
       C:{
        alignItems:"flex-start",
        width:150
       },
       b: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
      },
      MainContainer :{
        flex:1,
        justifyContent: 'center',
        alignItems: 'center',
     
       },
       modal: {  
        justifyContent: 'center',
        alignItems: 'center', 
        height: '90%' ,
        width: '90%',
        borderRadius:10,
        borderWidth: 1,
        borderColor: '#fff'
         }, 
         modalContent: {
            backgroundColor: "#fff",
            padding: 22,
            borderRadius: 15,
            borderColor: "rgba(0, 0, 0, 0.1)",
            alignSelf:'center'
          },
          overlay: {
            flex: 1,
            position: 'absolute',
            left: 0,
            top: 0,
            opacity: 0.5,
            backgroundColor: 'black',
            width: width
          } ,
          detail:{
           fontSize:13,
           fontFamily:'Bold'
          },
          button_1:{
            width:'33%',
            height:50,
            paddingLeft:6,
            paddingRight:6
          },
        
  });
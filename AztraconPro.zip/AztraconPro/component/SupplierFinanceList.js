import React,{ Component }  from 'react';
import {ScrollView,Modal,StyleSheet,Text,View,Image,Dimensions,FlatList,TouchableOpacity,Alert} from 'react-native';
import { Col, Grid, Row } from 'react-native-easy-grid';
import Toast from 'react-native-whc-toast'
import { NavigationActions, StackActions } from 'react-navigation';
import axios from 'axios';
import {Card,CardItem} from 'native-base';
import strings from './res/strings'
import {logouttask} from './class/logout';
import color from './res/colors'


const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const blue=color.values.Colors.blue;
const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const black=color.values.Colors.black;
const lightblue=color.values.Colors.lightblue;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});
 export default class SupplierFinanceList extends React.Component {
  static navigationOptions = ({ navigation }) => ({ 
    title: "Supplier List",
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false, 
      dataSource:'',
      handlelogin:'',
      UserID:'',ACode:''
    };
}
login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
        this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}

format(x) {
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

getsupplierfinancedetail=(index)=>{
  const id=index

  const {Party}=this.state.dataSource[id]

  this.props.navigation.navigate('SupplierFinanceDetailActivity',{
    AgeCode:this.state.ACode,
    SupID:Party,
    UserID:this.state.UserID,
  });

}

getsupplierfinancelist=()=>{
  const config = {
    headers: {   
    'currentToken': tokken,
  },
    params: {
        AgeCode:this.state.ACode,
    }
    
  };

  this.setState({isLoading:true})
  axios.get(ip+'/getSupplierFinanceList', config)
  .then(response => this.setState({ dataSource:response.data},() => {if(response.status==200){this.setState({isLoading:false})}}))
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
}



componentDidMount(){
  
console.disableYellowBox = true;

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
  
 this.setState({

      UserID:this.props.navigation.getParam('UserID', ''),
      ACode:this.props.navigation.getParam('AgeCode', ''),

},()=>{this.getsupplierfinancelist();})
}
  render() {
    if (this.state.isLoading) {
      return (
        <Modal
        transparent={false}
        supportedOrientations={['portrait', 'landscape']}
        visible={this.state.isLoading}
        >
         <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
          style={{width: 300, height: 200}}
          source={require('./src/gears.gif')}  />
          </View>     
        </Modal>
      )
  }
    return (
<View style={{flex:1,backgroundColor:lightblue}}>
<ScrollView style={{height:'6%'}}>
<View  style={{ flex: 1,paddingTop:'2%'}}>
    <Grid style={{backgroundColor:colorprimary,padding:5,width:"97%",alignSelf:'center',borderRadius:3}}>
             <Row>
             <Col style={{alignItems:'flex-start',width:'40%'}}>
             <Text style={styles.textContent}>Supplier</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'60%'}}>
             <Text style={styles.textContent}>Balance Amount</Text>
             </Col> 
             </Row>
             </Grid>
    </View>
</ScrollView>
<ScrollView style={{height:'94%'}}>
    <FlatList
       data={ this.state.dataSource}
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
        paddingLeft:5,paddingRight:5,paddingTop:10,paddingBottom:10}}>
            <Grid  onPress={() => this.getsupplierfinancedetail(index)}>
            <Row>
              <Col style={{alignItems:'flex-start',width:'40%'}}>
              <Text style={{fontSize:13,fontFamily:'Regular'}}>{item.Party.toString().trim()}</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'60%'}}>
              <Text style={{fontSize:13,fontFamily:'Regular'}}>{this.format(item.Amount)}</Text>
              </Col> 
             </Row>
             <Row style={{paddingTop:2}}>
                 <Col style={{alignItems:'flex-start',width:'100%'}}>
                     <Text style={{fontSize:13,fontFamily:'Regular'}}>
                         {item.PartyDesc}
                     </Text>
                 </Col>
             </Row>
            </Grid>  
             </CardItem>
           </Card>
        }

       keyExtractor={(item, index) => index.toString()}
       
      />
 <Toast ref="toast"/>
          </ScrollView>
          </View>
        )
      }
 };
 const styles = StyleSheet.create({
  titleText: {
    flex:1,
    flexWrap:'wrap',
    color:white,
    fontSize:12,
    padding:5,
    fontFamily:'Bold'
  },
  textContent:{
    color:white,
    fontSize:12,
    fontFamily:'Bold'
  }
  });
  
  
  
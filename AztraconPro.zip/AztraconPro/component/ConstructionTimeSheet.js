import React from 'react';
import {TouchableWithoutFeedback,Dimensions,Image,TouchableHighlight,SectionList,AppRegistry, StyleSheet, ActivityIndicator, ListView, Text,TextInput, View,Alert, Platform, TouchableOpacity} from 'react-native';
import axios from 'axios';
import { Col, Grid } from 'react-native-easy-grid';
import {Card,CardItem} from 'native-base';
import { FAB, Portal, Provider } from 'react-native-paper';
import strings from './res/strings'
import { ScrollView } from 'react-native-gesture-handler';
import { NavigationActions, StackActions } from 'react-navigation';

const ip=strings.values.commonvalues.ip;

const tokken=strings.values.commonvalues.tokken;

const { width, height } = Dimensions.get('window');

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class ConstructionTimeSheet extends React.Component{
  static navigationOptions = {
    title: "Construction TimeSheet",
    color:"#fff",
    headerStyle: {
      backgroundColor: "#2452b2",
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontFamily:'Bold',
    },
  };
  constructor(props) {
      super(props);
      this.state = { 
        isLoading: true, 
        data: "" ,
        open: false,
    
    };
      console.disableYellowBox = true;
  }

componentDidMount() {
  this.setState({USER:this.props.navigation.getParam('USER', '')},()=>{this.getconstructionlist();})
}
add(){
  this.props.navigation.navigate('ConstructionTimeSheetAddActivity',{USER:this.state.USER});
}

getconstructionlist(){
    const config = {
      headers: {   
      'currentToken':tokken,
    },
      params: {
      empid:'2403' //this.state.USER,
      }
    };

axios.get(ip+'/getConstructionTS', config)
  .then(response => this.setState({data:response.data},() => {if(response.status==200){
   this.setState({isLoading:false});
  }
}))
  .catch(err => console.log(err));  
}

itempress(empid,date,slno){
    let EmpID=empid;
    let ADate=date;
    let SlNo=slno;
    
    console.log(EmpID+' '+ADate+' '+SlNo)

    Alert.alert(
      'Delete',
      'Would you like to delete? \n Activity date='+ADate+'\n SNo ='+SlNo,
      [
        {text: 'OK', onPress: () => this.listitemdelete(EmpID,ADate,SlNo)},
        {text: 'Cancel', onPress: () => console.log('Cancel Pressed'), style: 'cancel'},  
      ]
    )
  }

  listitemdelete(empid,date,slno){
    
    let EmpID=empid;
    let ADate=date;
    let SlNo=slno;

    console.log(EmpID+'  '+ADate+'  '+SlNo)

    if(ADate===''||SlNo===''){
  
      alert('Please Select Record To Delete')
    }else{
      const config = {
        headers: {   
        'currentToken':tokken,
      },
        params: {
          userid:this.state.USER,
          empid:EmpID,
          actdate:ADate,
          slno:SlNo
        }
      };
  
  axios.get(ip+'/deleteSupervisorTS', config)
    .then(response =>{if(response.status==200){
     this.setState({isLoading:false}),
     this.getconstructionlist(); }})
    .catch(err => console.log(err));  
    }
  }

  renderItem(item) {
      const {EmpID,EmpName,SlNo,ProjectID,RegularTime,OverTime,AStatus,TagClass,TaskDesc,TaskID,PercentComplete,Remarks,ActivityDate} = item.item;
      return (
        <View style={styles.itemView}>
            <Grid onPress={this.itempress.bind(this,EmpID,ActivityDate,SlNo)}>
            <Card>
               <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
               <Col style={{alignItems:'flex-start',width:'15%'}}>
               <Text style={{fontSize:13,fontFamily:'Regular'}}>{SlNo}</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'15%'}}>
               <Text style={{fontSize:13,fontFamily:'Regular'}}>{ProjectID}</Text>
               </Col> 
               <Col style={{alignItems:'flex-start',width:'15%'}}>
               <Text style={{fontSize:13,fontFamily:'Regular'}}>{RegularTime}</Text>
               </Col> 
               <Col style={{alignItems:'flex-start',width:'15%'}}>
               <Text style={{fontSize:13,fontFamily:'Regular'}}>{OverTime}</Text>
               </Col> 
               <Col style={{alignItems:'flex-start',width:'15%'}}>
               <Text style={{fontSize:13,fontFamily:'Regular'}}>{PercentComplete}</Text>
               </Col> 
               <Col style={{alignItems:'flex-start',width:'25%'}}>
               <Text style={{fontSize:13,fontFamily:'Regular'}}>{AStatus}</Text>
               </Col> 
               </CardItem>
            </Card>
            </Grid>   
          </View>
      );

     
  }

  render() {
      if (this.state.isLoading) {
          return (
            <View style={{ flex: 1,
              justifyContent: 'center',
              flexDirection: 'column' }}>
                <ActivityIndicator size="large" color="#0000ff" />
            </View>
          )
      }

      return (
          <View style={styles.container}>
              <SectionList
                  sections={this.state.data}
                  renderItem={this.renderItem.bind(this)}
                  renderSectionHeader={({ section }) => <Text style={styles.sectionHeader}>{section.Title}</Text>}
                  keyExtractor={(item, index) => index}
              />
    <Provider>
         <Portal>
           <FAB.Group
             open={this.state.open}
             icon={this.state.open ? 'add' : 'add'}
             actions={[
               { icon: 'add', label: 'Insert',color:'#FF007F',onPress: () => this.add() },
               //{ icon:'delete', label: 'Delete',color:'#FF007F', onPress: () => this.delete() },
             ]}
             onStateChange={({ open }) => this.setState({ open })}
             onPress={() => {
               if (this.state.open) {
                 // do something if the speed dial is open
               }
             }}
           />
         </Portal>
      </Provider>
  
          </View>
      );
  }
}

const styles = StyleSheet.create({
  container: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: '#F5FCFF',
  },
  sectionHeader: {
      paddingTop: 2,
      paddingLeft: 10,
      paddingRight: 10,
      paddingBottom: 2,
      fontSize: 14,
      fontFamily:'Bold',
      color:'#fff',
      backgroundColor: '#2452b2'
  },
  itemView: {
    flex: 1,
    width,
    borderBottomWidth: 0.5,
    borderColor: '#cdcdcd',
    borderStyle: 'solid',
    paddingHorizontal: 12,
    flexDirection: 'row',
}

});


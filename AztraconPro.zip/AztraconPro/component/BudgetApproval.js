import React from 'react';
import {ScrollView,Dimensions,Image,Modal,SectionList,StyleSheet,Text,View,TouchableOpacity,Alert,KeyboardAvoidingView,Platform,FlatList} from 'react-native';
import axios from 'axios';
import { Col, Grid, Row} from 'react-native-easy-grid';
import {Card,CardItem,Item,Input,Spinner} from 'native-base';
import RadioGroup from 'react-native-radio-buttons-group';
import { NavigationActions, StackActions } from 'react-navigation';
import strings from './res/strings'
import {logouttask} from './class/logout';
import Toast from 'react-native-whc-toast'
import color from './res/colors'
import { Divider,Button } from 'react-native-elements';

import { CustomButton } from './custom-button.js';

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const { width, height } = Dimensions.get('window');

const black=color.values.Colors.black;
const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const lightblue=color.values.Colors.lightblue;

let selectedButton;
let AppStatus;
let passdata=[];

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class BudgetApproval extends React.Component{
  static navigationOptions = ({ navigation }) => ({ 
    title: "Budget Approval",
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor:white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
      super(props);
      this.state = { 
        isLoading: true, 
        isVisible:false,
        data:[],
        vrm:"",
        BudgetSource:"",
        UOM:"",
        Material:"",
        handlelogin:'',
        UserID:'',
        RNo:'',
        Pid:'',
        RDate:'',
        SeqNo:'',
        Ver:'',
        Name:'',
        Desig:'',
        Comment:'',
        indexj:-1,
        indexi:-1,
        mat:'',
        qty:'',
        rate:'',
        rem:'',
        value:'',
        MGroup:'',
        ProjectValue:'',
        ProValue:'',
        radiovalues: [
            {
                label: 'Approve',
                value: "Approve",
                color:'#2452b2'
            },
            {
              label: 'Reject',
              value: "Reject",
              color:'#2452b2'
           },
            {
                label: 'ReWork',
                value: 'ReWork',
                color:'#2452b2'
            },
          
        ],
    };
      console.disableYellowBox = true;
      this.arrayholder = [] ;
  }

  login = async () => 
  {
  
    Alert.alert(
      'Logout',
      'Would you like to logout?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {text: 'OK', onPress: () => { logouttask()
          this.props.navigation.dispatch(resetAction);} },
      ],
      {cancelable: false},
    );
   
  }
  

componentDidMount() {
  console.disableYellowBox = true;

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
 
  this.setState({
    UserID:this.props.navigation.getParam('UserID', ''),
    RNo:this.props.navigation.getParam('RNo', ''),
    Pid:this.props.navigation.getParam('PID', ''),
    RDate:this.props.navigation.getParam('RDate', ''),
    SeqNo:this.props.navigation.getParam('Seq', ''),
    Ver:this.props.navigation.getParam('Ver', ''),
    Name:this.props.navigation.getParam('Name', ''),
    Desig:this.props.navigation.getParam('Desig', ''),
    ProjectValue:this.props.navigation.getParam('ProjValue', ''),
    ProValue:this.props.navigation.getParam('PurValue', ''),
    },()=>{this.getcostapproval();})
}

format(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

getcostapproval(){
    const config = {
      headers: {   
      'currentToken':tokken,
    },
      params: {
        UserID:this.state.UserID,
        PID:this.state.Pid,
        RNo:this.state.RNo
      }
    };
    this.setState({isLoading:true});
  /*   axios.get(ip+'/getBudgetListIOS', config) */
  axios.get(ip+'/getBudgetListIOSV1', config)
  .then(response => this.setState({data:response.data},() => {if(response.status==200){
    this.setState({isLoading:false});
    }
}))
.catch(err => 
  {
    this.setState({
      isLoading:false
    },()=>{
     let error=err
     
     this.refs.toast.showBottom(error.toString())

     setTimeout(
      () => { 
        this.props.navigation.goBack();
       },
      2000
    )

    })
  }
  );
  
}

submit(){
  
  if(selectedButton=="Approve"){
    AppStatus="A"
  }else if(selectedButton=="Reject")
    AppStatus="N"
  else{
    AppStatus="R"
  }

  if(AppStatus!="A"){
    if(this.state.Comment=="" || this.state.Comment=="undefinde"){
      this.refs.toast.showBottom("Please enter comments")
    }else{
      this.saveon()
    }
  }else{
    this.saveon()
  }
}

saveon(){
  let url

  this.setState({
    isLoading:true
  })

   if(AppStatus=="A"){
     url="/setBudgetApproval"
   }else if(AppStatus=="N"){
    url="/setBudgetReject"
   }
   else{
     url="/setBudgetRework"
   }

    axios({
        method: 'post',
        url:ip+url,
        headers: {'currentToken':tokken}, 
        data: {
          Value:{"rno":this.state.RNo,
          "userid":this.state.UserID,
          "comments":this.state.Comment,
          "status":AppStatus,
          "seqno":this.state.SeqNo,
          "pid":this.state.Pid,
          "ver":this.state.Ver,
          },
          Items:passdata,
        }
      }).then(response=>{if(response.status===200){
        this.setState({isLoading:false},()=>{
          this.refs.toast.showBottom('Submitted Successfully')
          this.props.navigation.goBack();
        })
      }else{
        this.refs.toast.showBottom('Some Error Occured!')
      }})
      .catch(err => 
        {
          this.setState({
            isLoading:false
          },()=>{
           let error=err
           
           this.refs.toast.showBottom(error.toString())
    
           setTimeout(
            () => { 
              this.props.navigation.goBack();
             },
            2000
          )
    
          })
        }
        );
}
commentsubmit(){
  let i=this.state.indexi
  let j=this.state.indexj

  let dataSource=this.state.data

  dataSource[i].data[j].remarks=this.state.ListComment

  for(let i=0;i<passdata.length;i++){
    if(passdata[i].mat==this.state.MGroup){
      passdata.pop(i)
    }
  }

  if(this.state.ListComment!="" || this.state.ListComment!="undefined"){
    let data=({
      mat:this.state.mat,
      rem:this.state.ListComment,
      qty:this.state.qty,
      rate:this.state.rate,
      value:this.state.value,
    })

    passdata.push(data)
  }

  this.setState({data:dataSource,isVisible:false},()=>{
    console.log(this.state.data[i].data[j])
})

}
onPress = radiovalues => this.setState({ radiovalues});

renderSeperator() {    

      return (
                <Divider></Divider>           
      );

  }

  listpress(material,uom,comment,cnt,group,idj,idi,Rate,Qty,Value){

    let vremark
    if(cnt=="0"){
      vremark=false
    }else{
      vremark=true
    }


    const config = {
      headers: {   
      'currentToken':tokken,
    },
      params: {
        RNo:this.state.RNo,
        PID:this.state.Pid,
        Mat:group
      }
    };
    this.setState({isLoading:true});
    axios.get(ip+'/getBudgetDetailList', config)
   .then(response => this.setState({BudgetSource:response.data},() => {if(response.status==200){
     this.setState({
       vrm:vremark,
       Material:material,
       MGroup:group,
       UOM:uom,
       mat:group,
       qty:Qty,    
       rate:Rate,
       value:Value,
       isLoading:false,
       isVisible:true,
       indexj:idj,
       indexi:idi,
       ListComment:comment
    });
    }
}))
.catch(err => 
  {
    this.setState({
      isLoading:false
    },()=>{
     let error=err
     this.refs.toast.showBottom(error.toString())
     setTimeout(
      () => { 
        this.props.navigation.goBack();
       },
      2000
    )
    })
  }
  );
  }
  renderItem(item) {    
    const {Name,UOM,Rate,Qty,Value,Cnt,MGroup,remarks,indexj,indexi} = item.item; 
 
      return (
               <Grid onPress={this.listpress.bind(this,Name,UOM,remarks,Cnt,MGroup,indexj,indexi,Rate,Qty,Value)} style={{padding:4,alignItems:"flex-start",width:'100%',flexWrap:'wrap',
               backgroundColor:Cnt=="0"?white:'#EAFDD3',paddingTop:8,paddingBottom:8,width:'97%',alignSelf:'center'
               }}>
               <Row>
               <Col style={{alignItems:'flex-start',width:'5%'}}>
               <Image
                style={{width:8,height:8,display:Cnt=="0"?'none':'flex',alignSelf:'center'}}
                source={require('./src/blink.gif')}  />
               </Col>
               <Col style={{alignItems:'flex-start',width:'30%'}}>
               <Text style={{fontSize:11,color:'#000',fontFamily:'Regular'}}>{Name}</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'15%'}}>
               <Text style={{fontSize:11,color:'#000',fontFamily:'Regular'}}>{UOM}</Text>
               </Col>
               <Col style={{alignItems:'flex-end',width:'15%'}}>
               <Text style={{fontSize:11,color:'#000',fontFamily:'Regular'}}>{this.format(Math.round(Rate))}</Text>
               </Col>
               <Col style={{alignItems:'flex-end',width:'10%'}}>
               <Text style={{fontSize:11,color:'#000',fontFamily:'Regular'}}>{this.format(Math.round(Qty))}</Text>
               </Col>
               <Col style={{alignItems:'flex-end',width:'25%'}}>
               <Text style={{fontSize:11,color:'#000',fontFamily:'Regular'}}>{this.format(Math.round(Value))}</Text>
               </Col>
               </Row>
               <Row style={{display:remarks==""?'none':'flex'}} >
               <Col style={{alignItems:'flex-start',width:'30%'}}>
               <Text style={{fontSize:12,color:colorprimary,paddingLeft:18,fontFamily:'Bold'}}>Remarks -</Text>
               </Col> 
               <Col style={{alignItems:'flex-start',width:'70%'}}>
               <Text style={{fontSize:12,fontFamily:'Regular'}}>{remarks}</Text>
               </Col>
               </Row>
               </Grid>   
                        
      );

  }

  render() {
    selectedButton = this.state.radiovalues.find(e => e.selected == true);
    selectedButton = selectedButton ? selectedButton.value : this.state.radiovalues[0].label;   
      if (this.state.isLoading) {
          return (
            <Modal
            transparent={false}
            supportedOrientations={['portrait', 'landscape']}
            visible={this.state.isLoading}
            >
             <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
              <Image
              style={{width: 300, height: 200}}
              source={require('./src/gears.gif')}  />
              </View>     
            </Modal>
          )
      }

      return (
    <View style={{flex:1,backgroundColor:lightblue}}>
    <ScrollView style={{height:"18%"}}>
 
    <View  style={{ flex: 1,paddingTop:2,paddingBottom:2}}>
    <Grid style={{backgroundColor:'#36428a',padding:4,width:"98%",alignSelf:'center',borderRadius:3}}>
             <Row>
             <Col style={{alignItems:'flex-start',width:'100%'}}>
             <Text style={styles.textContent}>Budget Approval</Text>
             </Col> 
             </Row>
             </Grid>
    </View>

    <Card style={{width:'97%',alignSelf:'center'}}>
               <CardItem  style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
                  paddingLeft:5,paddingRight:5,paddingTop:5,paddingBottom:5}}>
               <Grid>
               <Row style={{paddingTop:3,paddingBottom:3}}>
               <Col style={{alignItems:'flex-start',width:'15%'}}>
               <Text style={{fontSize:12,color:colorprimary,fontFamily:'Bold'}}>BR No - </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'17%'}}>
               <Text style={{fontSize:12,color:black,fontFamily:'Regular'}}>{this.state.RNo}</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'15%'}}>
               <Text style={{fontSize:12,color:colorprimary,fontFamily:'Bold'}}>Project - </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'15%'}}>
               <Text style={{fontSize:12,color:black,fontFamily:'Regular'}}>{this.state.Pid}</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'13%'}}>
               <Text style={{fontSize:12,color:colorprimary,fontFamily:'Bold'}}>Date - </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'25%'}}>
               <Text style={{fontSize:12,color:black,fontFamily:'Regular'}}>{this.state.RDate}</Text>
               </Col>
               </Row>
               <Divider></Divider>
               <Divider></Divider>
               <Row style={{paddingTop:3,paddingBottom:3}}>
               <Col style={{alignItems:'flex-start',width:'28%'}}>
               <Text style={{fontSize:12,color:colorprimary,fontFamily:'Bold'}}>Requested by - </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'72%'}}>
               <Text numberOfLines={2} style={{fontSize:12,color:black,fontFamily:'Italic'}}>
                 {this.state.Name+"\n"+this.state.Desig}
                 </Text>
               </Col>
               </Row>

               <Divider></Divider>
               <Divider></Divider>

               <Row style={{paddingTop:3,paddingBottom:3}}>
               <Col style={{alignItems:'flex-start',width:'23%'}}>
               <Text style={{fontSize:12,color:colorprimary,fontFamily:'Bold'}}>Project Val. : </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'27%'}}>
               <Text style={{fontSize:12,color:black,fontFamily:'Regular'}}>{this.format(this.state.ProjectValue)}</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'26%'}}>
               <Text style={{fontSize:12,color:colorprimary,fontFamily:'Bold'}}>Proposed Val. : </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'24%'}}>
               <Text style={{fontSize:12,color:black,fontFamily:'Regular'}}>{this.format(this.state.ProValue)}</Text>
               </Col>
               </Row>

               </Grid>   
               </CardItem>
   </Card>

    </ScrollView>
    <ScrollView style={{height:"5%"}}>
    <View  style={{ flex: 1,paddingTop:5}}>
    <Grid style={{backgroundColor:'#36428a',padding:4,width:"98%",alignSelf:'center',borderRadius:2}}>
             <Row>
             <Col style={{alignItems:'flex-start',width:'5%'}}>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'30%'}}>
             <Text style={styles.textContent}>Material</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'15%'}}>
             <Text style={styles.textContent}>UOM</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'15%'}}>
             <Text style={styles.textContent}>Rate</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'10%'}}>
             <Text style={styles.textContent}>Qty</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'25%'}}>
             <Text style={styles.textContent}>Value</Text>
             </Col> 
             </Row>
             </Grid>
    </View>
    </ScrollView>
    <KeyboardAvoidingView 
        behavior='padding'
        keyboardVerticalOffset={
        Platform.select({
           ios: () => 0,
           android: () => 100
        })()
        }>
    <ScrollView style={{height:"77%"}}>
    <Modal            
          animationType = {"slide"}  
          transparent = {true}  
          visible = {this.state.isVisible}  
          onRequestClose = {() =>{ console.log("Modal has been closed.") } }>  
          {/*All views of Modal*/}  
          <View style = {styles.modal}>  


          <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress = {() =>
           {  
            this.setState({ isVisible:!this.state.isVisible})
           }}>
         

         <Grid>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontFamily:'Bold',alignSelf:'flex-start'}}>
             Remarks / Rework Comments
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('./src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
       </Grid>

        
        </TouchableOpacity>



            <View style={{ flex: 1,paddingTop:5}}>
            <Card style={{width:'97%',alignSelf:'center'}}>
               <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
               <Grid>
               <Row> 
               <Col style={{alignItems:'flex-start',width:'20%'}}>
               <Text style={{fontSize:12,color:colorprimary,fontFamily:'Bold'}}>Material : </Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'45%'}}>
               <Text style={{fontSize:12,color:black}}>{this.state.Material}</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'15%'}}>
               <Text style={{fontSize:12,color:colorprimary,fontFamily:'Bold'}}>UOM :</Text>
               </Col>
               <Col style={{alignItems:'flex-start',width:'20%'}}>
               <Text style={{fontSize:12,color:black}}>{this.state.UOM}</Text>
               </Col>
               </Row>
               </Grid>
               </CardItem>
              </Card>
              </View>
           
            <View  style={{ flex: 1,paddingTop:5}}>
            <Grid style={{backgroundColor:'#36428a',padding:4,width:"97%",alignSelf:'center',borderRadius:3
            ,display:this.state.BudgetSource.length!=0?'flex':'none'}}>
             <Row>
             <Col style={{alignItems:'flex-start',width:'15%'}}>
             <Text style={styles.textContent}>Ver./Seq</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'40%'}}>
             <Text style={styles.textContent}>Employee</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'15%'}}>
             <Text style={styles.textContent}>Rate</Text>
             </Col> 
             <Col style={{alignItems:'flex-start',width:'10%'}}>
             <Text style={styles.textContent}>Qty</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'15%'}}>
             <Text style={styles.textContent}>Value</Text>
             </Col> 
             </Row>
             </Grid>
              </View>

         <FlatList
         data={ this.state.BudgetSource}
         initialNumToRender={this.state.BudgetSource.length}
         renderItem={({item}) => 
         <Card style={{width:'97%',alignSelf:'center'}}>
           <CardItem  style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
                  paddingLeft:5,paddingRight:5,paddingTop:5,paddingBottom:5}}>
           <Grid>
           <Row>
              <Col style={{alignItems:'flex-start',width:'15%'}}>
              <Text style={{fontSize:13,fontFamily:'Regular'}}>{item.ver+" / "+item.seq}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'40%'}}>
              <Text style={{fontSize:13,fontFamily:'Regular'}}>{item.name}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'15%'}}>
              <Text style={{fontSize:13,fontFamily:'Regular'}}>{this.format(Math.round(item.rate))}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'10%'}}>
              <Text style={{fontSize:13,fontFamily:'Regular'}}>{this.format(Math.round(item.qty))}</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'15%'}}>
              <Text style={{fontSize:13,fontFamily:'Regular'}}>{this.format(Math.round(item.value))}</Text>
              </Col> 
           </Row>
           <Divider></Divider>
           <Row style={{display:this.state.vrm?'flex':'none'}}>
              <Col style={{alignItems:'flex-start',width:'20%'}}>
              <Text style={{fontSize:13,color:colorprimary,fontFamily:'Bold'}}>Remarks -</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'80%'}}>
              <Text style={{fontSize:13,fontFamily:'Regular'}}>{item.cmt}</Text>
              </Col> 
           </Row>
         </Grid>
           </CardItem>
         </Card>
        }
       keyExtractor={(item, index) => index.toString()}
      />
                <Card style={{width:'97%',alignSelf:"center"}}>
                <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
                <Item>
                <Input placeholder="Remark/Rework Comments"
                value={this.state.ListComment}
                textDecorationStyle={{fontFamily:'Regular'}}
                onChangeText={val => this.setState({ ListComment: val })}
               />
               </Item>
               </CardItem>

              </Card>

              <Grid style={{padding:4,width:"97%",alignSelf:'center',paddingBottom:5}}>
             <Row>
             <Col style={{alignItems:'center',width:'50%'}}>
             <Button onPress={() => this.commentsubmit()}
             raised={true}
             titleStyle={{fontSize:15,textAlign:'center',fontFamily:'Bold'}}
             buttonStyle={{
               flex:1,
               borderRadius:6,
               width:120,
               height:45
             }}
            
             title=" SUBMIT "/>
             </Col> 
             <Col style={{alignItems:'center',width:'50%'}}>
             <Button  onPress={() =>
                  this.setState({
                 isVisible:false
               })}
              raised={true}
              titleStyle={{fontSize:15,textAlign:'center',fontFamily:'Bold'}}
              buttonStyle={{
               flex:1,
               borderRadius:6,
               width:120,
               height:45
              }}
            
             title=" CANCEL "/>
             </Col> 
             </Row>
            </Grid>

      
          </View>
   </Modal>
              <SectionList
                  sections={this.state.data}
                  style={{paddingTop:1}}
                  extraData={this.state.data}
                  initialNumToRender={100}
                  ItemSeparatorComponent={this.renderSeperator.bind(this)}
                  renderItem={this.renderItem.bind(this)}
                  renderSectionHeader={({ section }) => 
                   <View  style={{ flex: 1,paddingTop:1,paddingBottom:5}}>
                   <Grid style={{backgroundColor:'#3498db',padding:4,width:"97%",alignSelf:'center',borderRadius:3}}>
                   <Row>
                   <Col style={{alignItems:'flex-start',width:'70%',paddingLeft:4,fontFamily:'Regular'}}>
                   <Text style={styles.sectionHeader}>{section.Title}</Text>
                   </Col> 
                   <Col style={{alignItems:'flex-end',width:'30%',paddingLeft:4,fontFamily:'Regular'}}>
                   <Text style={styles.sectionHeader}>{this.format(section.BudgetValue)}</Text>
                   </Col> 
                   </Row>
                   </Grid>
                   </View>
               }
               keyExtractor={(item, index) => index}
              />


<View  style={{ flex: 1,paddingTop:5}}>
       <Grid style={{backgroundColor:'#D7EFFA',padding:4,width:"97%",alignSelf:'center',borderRadius:2}}>
             <Row>
             <Col style={{alignItems:'flex-start',width:'70%'}}>
             <Text style={styles.textTotalContent}>Grand Total : </Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'30%'}}>
             <Text style={styles.textTotalContent}>{this.format(this.state.ProValue)}</Text>
             </Col> 
             </Row>
          
             </Grid>
      </View>

                <Card style={{width:'97%',alignSelf:"center"}}>
                <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
                <Item>
                <Input placeholder="Approval Comments"
                value={this.state.Comment}
                textDecorationStyle={{fontFamily:'Regular'}}
                onChangeText={val => this.setState({ Comment: val })}
               />
               </Item>
              </CardItem>
              <CardItem>       
              <RadioGroup flexDirection='row' 
              radioButtons={this.state.radiovalues} onPress={this.onPress} />
               </CardItem>
              </Card>
  

            <Grid style={{padding:4,width:"97%",alignSelf:'center',paddingBottom:5}}>
             <Row>
             <Col style={{alignItems:'center',width:'100%'}}>
             <Button onPress={() =>this.submit()} 
              raised={true}
              titleStyle={{fontSize:15,textAlign:'center',fontFamily:'Bold'}}
              buttonStyle={{
               flex:1,
               borderRadius:6,
               width:120,
               height:45
              }}
            
             title=" SUBMIT "/>
             </Col>
             </Row>
             </Grid>

             
            
              
             

          <Toast ref="toast"/>
          </ScrollView>
          </KeyboardAvoidingView>
          </View>
      );
  }
}

const styles = StyleSheet.create({
  textTotalContent:{
    color:'#3A6705',
    fontSize:12,
    fontFamily:'Bold'
  },
    ButtonSection: {
        paddingTop:3,
        width: '100%',
        justifyContent: 'center',
        alignItems: 'center',
        paddingBottom:10
     },

  container: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: '#F5FCFF',
  },
  sectionHeader: {
      fontSize: 13,
      fontFamily: 'Bold',
      color:'#fff',
  },
  itemView: {
    flex: 1,
    width,
    borderBottomWidth: 0.5,
    borderColor: '#cdcdcd',
    borderStyle: 'solid',
    paddingHorizontal: 12,
    flexDirection: 'row',
    paddingTop:2
},
textContent:{
  color:white,
  fontSize:12,
  fontFamily:'Bold'
},
CButton:{
    paddingTop:8,
    height:45,
    width:70,
    paddingBottom:4
},
imagebutton: {
    width:30,
    height: 30,        
  },
  modal: {  
    flex:1,
    backgroundColor:white,
    height:'auto',
    position: 'absolute',
    bottom: 0,
    width:'100%'
     },
     headerback: {
      flexDirection: 'row',
      alignItems:'center',
      backgroundColor: colorprimary,
      borderWidth: 0.5,
      borderColor:white,
      height: 40,
      width:'100%',
      borderRadius: 5,
    },
});


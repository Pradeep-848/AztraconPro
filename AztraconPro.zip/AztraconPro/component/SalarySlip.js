import React,{ Component }  from 'react';
import {ScrollView,Modal,StyleSheet,Text,View,Image,Dimensions,TouchableOpacity,Alert,ImageBackground,useWindowDimensions} from 'react-native';
import { Col,Grid,Row } from 'react-native-easy-grid';
import Toast from 'react-native-whc-toast'
import axios from 'axios';
import { NavigationActions, StackActions } from 'react-navigation';
import moment, { parseTwoDigitYear } from 'moment';
import colors from './res/colors'
import strings from './res/strings'
import {logouttask} from './class/logout';

const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const dark=colors.values.Colors.colorPrimaryDark;
const primary=colors.values.Colors.colorPrimary;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

var { height, width } = Dimensions.get("window");

 export default class SalarySlip extends React.Component {
  static navigationOptions = ({ navigation }) => ({ 
    title: "Salary Slip",
    color:"#fff",
    headerStyle: {
      backgroundColor: "#2452b2",
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
      isLoading:false, 
      dataSource:'',
      handlelogin:'',
      Employee:'',
      Department:'',
      Designation:'',
      Payment:'',
      Month:'',
      Basic:'',
      HouseAllowance:'',
      Transportation:'',
      FoodAllowance :' ',
      Allowance:'',
      OverTime:'',
      Adjust:'', 
      OtherAllowance:'',
      TotalEarnings:'',
      LOP:'',
      LateDeduction:'',
      Gosi:'', 
      Loan:'',
      AHA:'',
      OD:'', 
      TD:'',
      NP:'',
      USER:'',
      DATE:'',
      layout: {
        height: height,
        width: width
    }
    };
}

_onLayout = event => {
  this.setState({
      layout: {
          height: event.nativeEvent.layout.height,
          width: event.nativeEvent.layout.width
      }
  });
};
componentDidMount(){
  console.disableYellowBox = true;

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
  
   this.setState({DATE:this.props.navigation.getParam('SalaryDate', '')
   ,USER:this.props.navigation.getParam('UserID', '')},()=>{this.getsalaryslip();})
}

login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
        this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}


getsalaryslip=()=>{
    const config = {
      headers: {   
      'currentToken':tokken,
    },
      params: {
        Empid:this.state.USER,
        Date:this.state.DATE,
      }
      
    };
  
    this.setState({isLoading:true})
    axios.get(ip+'/getSalarySlip', config)
    .then(response => this.setState({dataSource:response.data},() => {if(response.status==200){
     const{dept,desig,payment,Basic,Hallowance,Transpot,Food,Allowance,Overtime,Adjust,Oallowance,Tallowance,Lpay,LDect,GOSI,Loan,AdvHallowance,ODect,TDect,Netpay,empname}=this.state.dataSource
this.setState({
    Employee:empname,
    Department:dept,
    Designation:desig,
    Payment:payment,
    Month:moment(moment(this.state.DATE.toString(), 'DD/MMM/YYYY')).format('MMMM - YYYY').toString(),
    Basic:Basic,
    HouseAllowance:Hallowance,
    Transportation:Transpot,
    FoodAllowance :Food,
    Allowance:Allowance,
    OverTime:Overtime,
    Adjust:Adjust, 
    OtherAllowance:Oallowance,
    TotalEarnings:Tallowance,
    LOP:Lpay,
    LateDeduction:LDect,
    Gosi:GOSI, 
    Loan:Loan,
    AHA:AdvHallowance,
    OD:ODect, 
    TD:TDect,
    NP:Netpay,
    isLoading:false
})
    }}))
    .catch(err => 
      {
        this.setState({
          isLoading:false
        },()=>{
         let error=err
         
         this.refs.toast.showBottom(error.toString())

         setTimeout(
          () => { 
            this.props.navigation.goBack();
           },
          2000
        )
  
        })
      }
      );
  }
  render() {
    if (this.state.isLoading) {
      return (
        <Modal
        transparent={false}
        supportedOrientations={['portrait', 'landscape']}
        visible={this.state.isLoading}
        >
         <View  onLayout={this._onLayout} style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
          style={{width: 300, height: 200}}
          source={require('./src/gears.gif')}  />
          </View>     
        </Modal>
      )
  }
    return (
      <View
            style={{ flex: 1 }}
            onLayout={this._onLayout}
        >
            <ImageBackground
              source={require('./src/aztracon_bg.jpg')}
                style={{
                    height: this.state.layout.height,
                    width: this.state.layout.width,
                }}
            >

          <ScrollView>
    <Text style={styles.textContent}>
              Salary Slip
     </Text>

     <View style={{flexDirection: 'row',width:'97%',alignSelf:'center'}}>
     <View style={{backgroundColor: dark, height: 2, flex: 1, alignSelf: 'center'}} />
     <View style={{backgroundColor: dark, height: 2, flex: 1, alignSelf: 'center'}} />
     </View>

    <Grid style={{paddingTop:'1%',width:'97%',alignSelf:'center',paddingBottom:'1%'}}>
            <Row style={styles.rowpadding}>
              <Col style={{width:'30%'}}>
              <Text style={styles.hittle}>Employee: </Text>
              </Col> 
              <Col style={{width:'70%'}}>
              <Text style={styles.tvalue}>{this.state.Employee}</Text>
              </Col> 
            </Row>
            <Row style={styles.rowpadding}>
              <Col style={{width:'30%'}}>
              <Text style={styles.hittle}>Department: </Text>
              </Col> 
              <Col style={{width:'70%'}}>
              <Text style={styles.tvalue}>{this.state.Department}</Text>
              </Col> 
            </Row>
            <Row style={styles.rowpadding}>
              <Col style={{width:'30%'}}>
              <Text style={styles.hittle}>Designation: </Text>
              </Col> 
              <Col style={{width:'70%'}}>
              <Text style={styles.tvalue}>{this.state.Designation}</Text>
              </Col> 
            </Row>   
            </Grid>  

            <View style={{flexDirection: 'row',width:'97%',alignSelf:'center'}}>
            <View style={{backgroundColor: dark, height: 2, flex: 1, alignSelf: 'center'}} />
            <View style={{backgroundColor: dark, height: 2, flex: 1, alignSelf: 'center'}} />
            </View>
        <Grid style={{paddingTop:'1%',width:'97%',alignSelf:'center',paddingBottom:'1%'}}>
          <Row style={styles.rowpadding}>
              <Col style={{width:'20%'}}>
               <Text style={styles.hittle}>Month: </Text>   
              </Col>
              <Col style={{width:'30%'}}>
                <Text style={styles.tvalue}>{this.state.Month}</Text>  
              </Col>
              <Col style={{width:'20%'}}>
                 <Text style={styles.hittle}>Payment: </Text> 
              </Col>
              <Col style={{width:'30%'}}>
                 <Text style={styles.tvalue}>{this.state.Payment}</Text> 
              </Col>
          </Row>
        </Grid>
        
            <View style={{flexDirection: 'row',width:'97%',alignSelf:'center'}}>
            <View style={{backgroundColor: dark, height: 2, flex: 1, alignSelf: 'center'}} />
            <View style={{backgroundColor: dark, height: 2, flex: 1, alignSelf: 'center'}} />
            </View>

      <Grid style={{paddingTop:'2%',width:'97%',alignSelf:'center'}}>
      <Row style={styles.rowpadding}>
          <Col>
          <Text style={styles.Headtittle}>Earnings</Text>
          </Col>
          <Col>
          <Text style={styles.Valuetittle}>SAR</Text>
          </Col>
      </Row>    
      <Row style={styles.rowpadding}>
          <Col>
          <Text style={styles.tittle}>Basic</Text>
          </Col>
          <Col>
          <Text style={styles.detail}>{this.state.Basic}</Text>
          </Col>
      </Row>
      <Row style={styles.rowpadding}>
          <Col>
          <Text style={styles.tittle}>House Allowance</Text>
          </Col>
          <Col>
          <Text style={styles.detail}>{this.state.HouseAllowance}</Text>
          </Col>
      </Row>
      <Row style={styles.rowpadding}>
          <Col>
          <Text style={styles.tittle}>Transportation</Text>
          </Col>
          <Col>
          <Text style={styles.detail}>{this.state.Transportation}</Text>
          </Col>
      </Row>
      <Row style={styles.rowpadding}>
          <Col>
          <Text style={styles.tittle}>Food Allowance</Text>
          </Col>
          <Col>
          <Text style={styles.detail}>{this.state.FoodAllowance}</Text>
          </Col>
      </Row>
      <Row style={styles.rowpadding}>
          <Col>
          <Text style={styles.tittle}>Allowance</Text>
          </Col>
          <Col>
          <Text style={styles.detail}>{this.state.Allowance}</Text>
          </Col>
      </Row>
      <Row style={styles.rowpadding}>
          <Col>
          <Text style={styles.tittle}>OverTime</Text>
          </Col>
          <Col>
          <Text style={styles.detail}>{this.state.OverTime}</Text>
          </Col>
      </Row>
      <Row style={styles.rowpadding}>
          <Col>
          <Text style={styles.tittle}>Adjust</Text>
          </Col>
          <Col> 
          <Text style={styles.detail}>{this.state.Adjust}</Text>
          </Col>
      </Row>
      <Row style={styles.rowpadding}>
          <Col>
          <Text style={styles.tittle}>Other Allowance</Text>
          </Col>
          <Col>
          <Text style={styles.detail}>{this.state.OtherAllowance}</Text>
          </Col>
      </Row>
      <View style={{borderBottomColor:'#36428a',borderBottomWidth: 1,width:"100%",alignSelf:'center',paddingTop:2}}/>
      <Row style={styles.rowpadding}>
          <Col>
          <Text style={styles.tittle}>Total Earnings</Text>
          </Col>
          <Col>
          <Text style={styles.detail}>{this.state.TotalEarnings}</Text>
          </Col>
      </Row>
      <View style={{borderBottomColor:'#36428a',borderBottomWidth: 1,width:"100%",alignSelf:'center',paddingTop:2}}/>
      <Row style={styles.rowpadding}>
          <Col>
          <Text style={styles.Headtittle}>Deduction</Text>
          </Col>
          <Col>
          <Text style={styles.Valuetittle}>SAR</Text>
          </Col>
      </Row>
      <Row style={styles.rowpadding}>
          <Col>
          <Text style={styles.tittle}>Loss of Pay</Text>
          </Col>
          <Col>
          <Text style={styles.detail}>{this.state.LOP}</Text>
          </Col>
      </Row>
      <Row style={styles.rowpadding}>
          <Col>
          <Text style={styles.tittle}>Late Deduction</Text>
          </Col>
          <Col>
          <Text style={styles.detail}>{this.state.LateDeduction}</Text>
          </Col>
      </Row>
      <Row style={styles.rowpadding}>
          <Col>
          <Text style={styles.tittle}>GOSI</Text>
          </Col>
          <Col> 
          <Text style={styles.detail}>{this.state.Gosi}</Text>
          </Col>
      </Row>
      <Row style={styles.rowpadding}>
          <Col>
          <Text style={styles.tittle}>Loan</Text>
          </Col>
          <Col>
          <Text style={styles.detail}>{this.state.Loan}</Text>
          </Col>
      </Row>
      <Row style={styles.rowpadding}>
          <Col>
          <Text style={styles.tittle}>Adv.House Allowance</Text>
          </Col>
          <Col>
          <Text style={styles.detail}>{this.state.AHA}</Text>
          </Col>
      </Row>
      <Row style={styles.rowpadding}>
          <Col>
          <Text style={styles.tittle}>Other Deduction</Text>
          </Col>
          <Col>
          <Text style={styles.detail}>{this.state.OD}</Text>
          </Col>
      </Row>
      <View style={{borderBottomColor:'#36428a',borderBottomWidth: 1,width:"100%",alignSelf:'center',paddingTop:2}}/>
      <Row style={styles.rowpadding}>
          <Col>
          <Text style={styles.tittle}>Total Deductions</Text>
          </Col>
          <Col>
          <Text style={styles.detail}>{this.state.TD}</Text>
          </Col> 
      </Row>
      <View style={{borderBottomColor:'#36428a',borderBottomWidth: 1,width:"100%",alignSelf:'center',paddingTop:2}}/>
      <Row style={styles.rowpadding}>
          <Col>
          <Text style={styles.tittle}>Net Pay</Text>
          </Col>
          <Col>
          <Text style={styles.detail}>{this.state.NP}</Text>
          </Col> 
      </Row>
      <View style={{borderBottomColor:'#36428a',borderBottomWidth: 1,width:"100%",alignSelf:'center'}}/>
      </Grid>           

      <Toast ref="toast"/>
      
          </ScrollView>


          </ImageBackground>
      </View>
        )
      }
 };
 const styles = StyleSheet.create({
  imageStyle:{
    width:  screenWidth, 
    height: screenHeight, 
    justifyContent: 'center',
    alignItems: 'center'
   },
    textContent: {
      backgroundColor:'#fff',
      fontSize: 18,
      padding:8,
      textAlign:'center',
      color: '#36428a',
      fontFamily: 'Bold',
      textShadowColor: 'rgba(0, 0, 0, 0.75)',
      textShadowOffset: {width: -1, height: 1},
      textShadowRadius: 10
    },
   tittle:{
    color:'#36428a',
    paddingLeft:4,
    fontFamily:'Bold',
    fontSize:14,
   },
   hittle:{
    color:'#36428a',
    paddingRight:'4%',
    fontSize:14,
    alignSelf:'flex-end',
    fontFamily:'Bold'
   },
   tvalue:{
    alignSelf:'flex-start',
    fontSize:14,
   },
   Headtittle:{
    color:'#36428a',
    alignSelf:'center',
    fontSize:15,
    fontFamily: 'Bold',
    textShadowColor: 'rgba(0, 0, 0, 0.75)',
    textShadowOffset: {width: -1, height: 1},
    textShadowRadius: 10
   },
   Valuetittle:{
    color:'#36428a',
    paddingRight:4,
    alignSelf:'flex-end',
    fontSize:15,
    fontFamily: 'Bold',
    textShadowColor: 'rgba(0, 0, 0, 0.75)',
    textShadowOffset: {width: -1, height: 1},
    textShadowRadius: 10
   },

   rowpadding:{
     paddingTop:4
   },
   detail:{
     fontSize:14,
     fontFamily:'Bold',
     paddingRight:4,
     alignSelf:"flex-end"
   }
  });
  


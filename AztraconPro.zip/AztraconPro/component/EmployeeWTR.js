import React,{ Component }  from 'react';
import { ScrollView,StyleSheet,Text,View,Modal,FlatList,
  Dimensions,Image,TouchableOpacity,Alert,Appearance } from 'react-native';
import { Col, Grid,Row } from 'react-native-easy-grid';
import axios from 'axios';
import { Card,CardItem } from 'native-base';
import DateTimePicker from "react-native-modal-datetime-picker";
import moment, { parseTwoDigitYear } from 'moment';
import { NavigationActions, StackActions } from 'react-navigation';
import { Overlay,Button } from 'react-native-elements';
import {logouttask} from './class/logout';
import { CustomButton } from './custom-button.js';
import App from '../App';
import strings from './res/strings'
import color from './res/colors'
import Toast from 'react-native-whc-toast'
const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const colorprimary=color.values.Colors.colorPrimary;
const dark=color.values.Colors.colorPrimaryDark;
const black= color.values.Colors.black;
const white=color.values.Colors.white;
const lightblue=color.values.Colors.lightblue;

 var colorScheme = Appearance.getColorScheme()

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});
export default class EmployeeWTR extends React.Component {
  static navigationOptions = ({ navigation }) => ({ 
    title: "Employee WTR",
    color:"#fff",
    headerStyle: {
      backgroundColor: "#2452b2",
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });


  constructor(props) {
    super(props);
    this.state = {
      handlelogin:'',
      USER:'',
      isLoading: false, 
      dataSource:'',
      isDateTimePickerVisible:false,
      isDateTimePickerVisibleE:false,
      StartDate:'',
      EndDate:'',
      RT:'',
      OT:'',
      isVisible:false,
      ModelDataSource:'',
      
    };

    colorScheme
}
login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
        this.props.navigation.dispatch(resetAction);
      } },
    ],
    {cancelable: false},
  );
 
}

hideDateTimePicker = () => {
    this.setState({ isDateTimePickerVisible: false });
}
hideDateTimePickerB = () => {
    this.setState({ isDateTimePickerVisibleE: false });
}
showDateTimePicker = () => {
  this.setState({ isDateTimePickerVisible: true });
}


showDateTimePickerE = () => {
    this.setState({ isDateTimePickerVisibleE: true });
}
handleDatePicked = date => {
    const NewDate =moment(date).format('DD/MM/YYYY')
    this.setState({StartDate:NewDate})
    this.hideDateTimePicker();
};
handleDatePickedB = date => {
    const NewDate =moment(date).format('DD/MM/YYYY')
    this.setState({EndDate:NewDate})
    this.hideDateTimePickerB();
};
componentDidMount(){ 
  console.disableYellowBox = true;
  
  console.log("color code"+colorScheme)  
     
this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
  
  this.setState({USER:this.props.navigation.getParam('UserID', '')},()=>{this.getEmployeeFilterlist();})    
}
filter(){

if(this.state.StartDate.length>0 && this.state.EndDate.length>0){
    this.setState({RT:0,OT:0},()=>{
     this.filtertask()
    })
}else{
  alert('Please Give the Start Date and End Date')
}

}


filtertask(){
  this.setState({ isLoading:true})

  const SDATE = moment(this.state.StartDate,'DD/MM/YYYY').format('MM/DD/YYYY');
  const EDATE=moment(this.state.EndDate,'DD/MM/YYYY').format('MM/DD/YYYY');

  const config = {
      headers: {   
      'currentToken':tokken,
    },
   params: {
   Empid:this.state.USER,
   StartDate:SDATE.toString(),
   EndDate:EDATE.toString()
      }    
    };

axios.get(ip+'/getEmployeePeriodFilter', config)
  .then(response => this.setState({dataSource:response.data},() => {if(response.status==200){
    this.ROTFORFILTER();
    this.setState({isLoading:false}); }}))
    .catch(err => 
      {
        this.setState({
          isLoading:false
        },()=>{
         let error=err
         
         this.refs.toast.showBottom(error.toString())
  
         setTimeout(
          () => { 
            this.props.navigation.goBack();
           },
          2000
        )
  
        })
      }
      );
}
absense(){
if(this.state.StartDate.length>0 && this.state.EndDate.length>0){
this.getabsentbetweendate()
}else{
this.getabsentall()
}

}
getabsentbetweendate(){
 this.setState({ isLoading:true})

  const SDATE = moment(this.state.StartDate,'DD/MM/YYYY').format('MM/DD/YYYY');
  const EDATE=moment(this.state.EndDate,'DD/MM/YYYY').format('MM/DD/YYYY');

  const config = {
    headers: {   
      'currentToken':tokken,
    },
   params: {
   Empid:this.state.USER,
   StartDate:SDATE.toString(),
   EndDate:EDATE.toString()
      }    
    };

axios.get(ip+'/getAbsentBetween', config)
  .then(response => this.setState({ModelDataSource:response.data},() => {if(response.status==200){
    this.setState({isLoading:false,isVisible:true}); }}))
    .catch(err => 
      {
        this.setState({
          isLoading:false
        },()=>{
         let error=err
         
         this.refs.toast.showBottom(error.toString())
  
         setTimeout(
          () => { 
            this.props.navigation.goBack();
           },
          2000
        )
  
        })
      }
      );

}


format(x) {
  if(x==''){
    return ''
  }else{
    var value = parseInt(x);
    value = value.toFixed(2);
    return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  }
  
}

getabsentall(){
this.setState({ isLoading:true})
const config = {
      headers: {   
      'currentToken':tokken,
    },
   params: {
    Empid:this.state.USER,
      }    
    };
axios.get(ip+'/getAbsent', config)
  .then(response => this.setState({ModelDataSource:response.data},() => {if(response.status==200){
  this.setState({isLoading:false,isVisible:true}); }}))
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );

}
hidemodel(){
  this.setState({isVisible:false})
}
ROTFORFILTER(){
  let rt,ot

  rt=0
  ot=0

  for(let i=1;i<this.state.dataSource.length;i++){
    const{RT,OT}=this.state.dataSource[i]
    rt=parseFloat(rt)+parseFloat(RT)
    ot=parseFloat(ot)+parseFloat(OT)
  }
 
  this.setState({RT:rt,OT:ot})
}
ROTCALL(){

let rt,ot

  rt=0
  ot=0
    
  for(i=1;i<this.state.dataSource.length;i++){
    const{RT,OT}=this.state.dataSource[i]
    rt=parseInt(rt)+parseInt(RT)
    ot=parseInt(ot)+parseInt(OT)
  }
 
  const{SDate,EDate}=this.state.dataSource[1]
  

  this.setState({RT:rt,OT:ot,StartDate:moment(SDate).format('DD/MM/YYYY'),EndDate:moment(EDate).format('DD/MM/YYYY')})

}

getEmployeeFilterlist(){
  this.setState({ isLoading:true})
    const config = {
        headers: {
        'currentToken':tokken,
      },
        params: {
            Empid:this.state.USER,
        }
        
      }; 
    axios.get(ip+'/getEmployeePeriod', config)
    .then(response => this.setState({dataSource:response.data},() => {if(response.status==200){
      if(this.state.dataSource.length!=0){
        this.ROTCALL();
       
      }
     
      this.setState({isLoading:false}); }}))
      .catch(err => 
        {
          this.setState({
            isLoading:false
          },()=>{
           let error=err
           
           this.refs.toast.showBottom(error.toString())
    
           setTimeout(
            () => { 
              this.props.navigation.goBack();
             },
            2000
          )
    
          })
        }
        );
}
  render() {
    if (this.state.isLoading) {
      return (
        <Modal
        transparent={false}
        supportedOrientations={['portrait', 'landscape']}
        visible={this.state.isLoading}
        >
         <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
          style={{width: 300, height: 200}}
          source={require('./src/gears.gif')}  />
          </View>     
        </Modal>
      )
  }
    return (
           <View style={{flex:1,backgroundColor:lightblue}}>
           <ScrollView style={{height:'13%'}}>
           <Card style={{alignSelf:'center',width:'97%'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
            <Grid>
            <Row>
            <Col  style={{alignItems:'center',width:'75%'}}>
            <Row>
            <Col style={{alignItems:'flex-start',width:'50%'}}>
            <Text style={{fontSize:12,paddingBottom:5,color:colorprimary,fontFamily:'Bold'}}>Start Date</Text>   
            </Col>
            <Col style={{alignItems:'flex-start',width:'50%'}}>
            <Text style={{fontSize:12,paddingBottom:5,color:colorprimary,fontFamily:'Bold'}}>End Date</Text>   
            </Col>
            </Row>
            <Row>
            <Col onPress={this.showDateTimePicker.bind(this)} style={{alignItems:'flex-start',width:'50%'}}>
            <View>
            <View style={styles.datePickerBox}>
            <Text style={styles.datePickerText}>{this.state.StartDate}</Text>
            </View>
            </View>
            <DateTimePicker
              style={{backgroundColor:colorScheme=='dark'?black:white}}
              datePickerContainerStyleIOS={{backgroundColor:colorScheme=='dark'?black:white}}
              cancelButtonContainerStyleIOS={{backgroundColor:colorScheme=='dark'?black:white}}
              cancelTextStyle={{color:colorScheme=='dark'?white:colorprimary}}
              confirmTextStyle={{color:colorScheme=='dark'?white:colorprimary}}
              titleStyle={{color:colorScheme=='dark'?white:colorprimary}}
            isVisible={this.state.isDateTimePickerVisible}
            onConfirm={this.handleDatePicked}
            onCancel={this.hideDateTimePicker}/>   
            </Col>
            <Col onPress={this.showDateTimePickerE.bind(this)}  style={{alignItems:'flex-start',width:'50%'}}>
            <View>
            <View style={styles.datePickerBox}>
            <Text style={styles.datePickerText}>{this.state.EndDate}</Text>
            </View>
            </View>
            <DateTimePicker
            style={{backgroundColor:colorScheme=='dark'?black:white}}
            datePickerContainerStyleIOS={{backgroundColor:colorScheme=='dark'?black:white}}
            cancelButtonContainerStyleIOS={{backgroundColor:colorScheme=='dark'?black:white}}
            cancelTextStyle={{color:colorScheme=='dark'?white:colorprimary}}
            confirmTextStyle={{color:colorScheme=='dark'?white:colorprimary}}
            titleStyle={{color:colorScheme=='dark'?white:colorprimary}}
            isVisible={this.state.isDateTimePickerVisibleE}
            onConfirm={this.handleDatePickedB}
            onCancel={this.hideDateTimePickerB}/>   
            </Col>
            </Row>

            </Col>
            <Col style={{alignItems:'center',width:'25%',alignSelf:'center'}}>
            <Col style={{alignItems:'center',width:'100%',alignSelf:'center'}}>
            <Button
            title={'Filter'}
            titleStyle={{fontFamily:'Bold'}}
            containerStyle={{borderRadius:6,width:'85%'}}
            onPress={this.filter.bind(this)}
            />
            </Col>
            </Col>
              </Row>  
         
           
            </Grid>
            </CardItem>
            </Card>

             <View style={styles.Head}>
             <Grid style={{width:'97%',alignSelf:'center',padding:5,backgroundColor:colorprimary,borderRadius:4}}>
              <Col style={{alignItems:'center',width:'25%'}}>
              <Text style={{color:'#fff',fontSize:13}}>Date</Text>
              </Col> 
              <Col style={{alignItems:'center',width:'25%'}}>
              <Text style={{color:'#fff',fontSize:13}}>RT</Text>
              </Col> 
              <Col style={{alignItems:'center',width:'25%'}}>
              <Text style={{color:'#fff',fontSize:13}}>OT</Text>
              </Col> 
              <Col style={{alignItems:'center',width:'25%'}}>
              <Text style={{color:'#fff',fontSize:13}}>Arrival+()</Text>
              </Col> 
             </Grid>  
             </View> 

     </ScrollView>

    <ScrollView style={{height:'57%'}}>   
    <FlatList
       data={this.state.dataSource}
       initialNumToRender={this.state.dataSource.length}
       renderItem={({item}) =>  
       <Card style={{alignSelf:'center',width:'97%'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
        paddingLeft:5,paddingRight:5,paddingTop:10,paddingBottom:10}}>
            <Grid>
              <Col style={{alignItems:'center',width:'25%'}}>
              <Text style={{fontSize:13,fontFamily:'Italic'}}>{item.Date}</Text>
              </Col> 
              <Col style={{alignItems:'center',width:'25%'}}>
              <Text style={{fontSize:13,fontFamily:'Italic'}}>{item.RT}</Text>
              </Col> 
              <Col style={{alignItems:'center',width:'25%'}}>
              <Text style={{fontSize:13,fontFamily:'Italic'}}>{item.OT}</Text>
              </Col> 
              <Col style={{alignItems:'center',width:'25%'}}>
              <Text style={{fontSize:13,alignSelf:'center',fontFamily:'Italic'}}>{item.Arrival}</Text>
              </Col> 
            </Grid>  
            </CardItem>
        </Card>
        }
       keyExtractor={(item, index) => index.toString()}
      />   

</ScrollView>
  
         <ScrollView style={{height:'10%'}}>
        <Card style={{alignSelf:'center',width:'97%'}}>
        <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
        <Grid>
        <Row>
        <Col style={{alignItems:'center',width:'25%'}}>
        <Text style={{fontSize:14,fontFamily:'Bold',color:colorprimary}}>Total : </Text>
        </Col>
        <Col style={{alignItems:'center',width:'25%'}}>
          <Text style={{fontSize:13,fontFamily:'Bold'}}>{this.format(this.state.RT)}</Text></Col>
        <Col style={{alignItems:'center',width:'25%'}}>
          <Text style={{fontSize:13,fontFamily:'Bold'}}>{this.format(this.state.OT)}</Text></Col>
        <Col style={{alignItems:'flex-start',width:'25%'}}>
        <Text></Text>    
        </Col>
        </Row>
        </Grid>
        </CardItem>
      </Card>

<View style={{alignSelf:'center',paddingTop:5,paddingBottom:5}}>
<Button
          title={'SHOW ABSENSE'}
          onPress={this.absense.bind(this)}
          titleStyle={{fontFamily:'Bold'}}
          containerStyle={{borderRadius:6}}
        />
</View>
<Overlay
  overlayStyle = {{width:'90%',height:'60%',borderRadius:15}}
  animationType='slide'
  isVisible={this.state.isVisible}
  onBackdropPress={() => this.setState({ isVisible: false })}>

  <View style={{flex:1}}>
  <ScrollView style={{height:'10%'}}>
  <View style={styles.Head}>
              <Grid style={{backgroundColor:'#2452b2',borderRadius:4,padding:5,}}>
              <Row>
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{color:'#fff',fontSize:13,paddingLeft:15,fontFamily:'Bold'}}>Absent Date</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{color:'#fff',fontSize:13,fontFamily:'Bold'}}>Day Name</Text>
              </Col> 
              </Row>
            </Grid>  
</View> 
</ScrollView>
<ScrollView style={{height:'75%'}}>
 <FlatList
       data={this.state.ModelDataSource}
       initialNumToRender={this.state.ModelDataSource.length}
       renderItem={({item}) =>  
       <Card>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
            <Grid>
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,fontFamily:'Italic'}}>{item.Date}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,fontFamily:'Italic'}}>{item.Name}</Text>
              </Col> 
            </Grid>  
            </CardItem>
        </Card>
        }
       keyExtractor={(item, index) => index.toString()}
      />
  </ScrollView>

  <ScrollView style={{height:'15%'}}>
  <CustomButton
                 title="CANCEL"
                 onPress={() => this.hidemodel()}
                 style={{ backgroundColor:dark,width:'40%',alignSelf:'center',height:40}}
                 textStyle={{ fontSize:13,fontFamily:'Bold' }}/>
  </ScrollView>
  </View>

</Overlay>

<Toast ref="toast"
        />

</ScrollView>
</View>
        )
      }
 };
 const styles = StyleSheet.create({
    tbutton: {
        height:50
      },
      spinner: {
        fontSize: 12,
        padding:10,
        height:40,
        flexWrap: 'wrap',
        color: 'grey',
      },
      Head: {
        flex: 1,
        paddingTop:'2%',
      },
      datePickerBox:{
        borderColor: '#1ca0ff',
        borderWidth: 0.5,
        padding: 0,
        borderTopLeftRadius: 4,
        borderTopRightRadius: 4,
        borderBottomLeftRadius: 4,
        borderBottomRightRadius: 4,
        height: 38,
        width:100,
        justifyContent:'center'
      },
     
      datePickerText: {
        fontSize: 13,
        marginLeft: 5,
        borderWidth: 0,
        color: '#000',
        fontFamily:'Regular'
      }, 
  });


























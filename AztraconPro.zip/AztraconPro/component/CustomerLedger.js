import React,{ Component }  from 'react';
import {ScrollView,StyleSheet,Text,View,Image,Dimensions,FlatList,Modal,TouchableOpacity,Alert} from 'react-native';
import { Col, Grid, Row } from 'react-native-easy-grid';
import {logouttask} from './class/logout';
import { Divider } from 'react-native-elements';
import { NavigationActions, StackActions } from 'react-navigation';
import axios from 'axios';
import Toast from 'react-native-whc-toast'
import {Card,CardItem} from 'native-base';
import strings from './res/strings'
import color from './res/colors'

const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const dark=color.values.Colors.colorPrimaryDark;
const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const lightblue=color.values.Colors.lightblue;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

 export default class CustomerLedger extends React.Component {
  static navigationOptions = ({ navigation }) => ({ 
    title: "Ledger",
    color:color,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },

    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false, 
      handlelogin:'',
      dataSource:'',
      CusID:'',UserID:'',CusName:''
    };
}

login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
     this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}

getcustomerledger=()=>{
  const config = {
    headers: {   
    'currentToken': tokken,
  },
    params: {
        CusID:this.state.CusID,
    }
    
  };

  this.setState({isLoading:true})
  axios.get(ip+'/getCLedger', config)
  .then(response => this.setState({ dataSource:response.data},() => {if(response.status==200){this.setState({isLoading:false})}}))
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
}

format(x) {
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

componentDidMount(){
  console.disableYellowBox = true;

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
  
  this.setState({
      CusID:this.props.navigation.getParam('CusID', ''),
      CusName:this.props.navigation.getParam('CusName', ''),
      UserID:this.props.navigation.getParam('UserID', ''),
},()=>{this.getcustomerledger();})
}
  render() {
    if (this.state.isLoading){
      return (
        <Modal
        transparent={false}
        supportedOrientations={['portrait', 'landscape']}
        visible={this.state.isLoading}
        >
         <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
          style={{width: 300, height: 200}}
          source={require('./src/gears.gif')}  />
          </View>     
        </Modal>
      )
  }
    return (
<View style={{flex:1,backgroundColor:lightblue}}>      
<ScrollView style={{height:'10%'}}>
  <Grid style={{paddingTop:'2%'}}>
  <Row style={{backgroundColor:colorprimary,width:'97%',alignSelf:'center',borderRadius:4}}>
  <Text style={styles.titleText}>
          {this.state.CusID.toString().trim()+" - "+this.state.CusName}
  </Text>
   </Row>
   <Divider style={{ backgroundColor:white}} />
   <Divider style={{ backgroundColor:white}} />
  </Grid>

  <View  style={{ flex: 1,paddingTop:5,paddingBottom:5}}>
    <Grid style={{backgroundColor:colorprimary,padding:4,width:"97%",alignSelf:'center',borderRadius:4}}>
             <Row>
             <Col style={{alignItems:'flex-start',width:'50%'}}>
             <Text style={styles.textContent}>Voucher Details</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'25%'}}>
             <Text style={styles.textContent}>Debit</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'25%'}}>
             <Text style={styles.textContent}>Credit</Text>
             </Col> 
             </Row>
    </Grid>
  </View>
</ScrollView>
<ScrollView style={{height:'90%'}}>
    <FlatList
       data={ this.state.dataSource }
       initialNumToRender={this.state.dataSource.length}
       renderItem={({item,index}) =>  
       <Card style={{alignSelf:'center',width:'97%'}}>
            <CardItem  style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
        paddingLeft:5,paddingRight:5,paddingTop:10,paddingBottom:10}}>
            <Grid>
            <Row style={{paddingTop:2}}>
              <Col style={{alignItems:'flex-start',width:'15%'}}>
              <Text style={{fontSize:12, fontFamily:'Bold'}}>{item.A}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'25%'}}>
              <Text style={{fontSize:12, fontFamily:'Bold'}}>{item.B}</Text>
              </Col> 
              <Col style={{alignItems:'center',width:'10%'}}>
              <Text style={{fontSize:12, fontFamily:'Bold'}}>{item.C}</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'25%'}}>
              <Text style={{fontSize:12, fontFamily:'Bold'}}>{this.format(item.E.toString())}</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'25%'}}>
              <Text style={{fontSize:12, fontFamily:'Bold'}}>{this.format(item.F.toString())}</Text>
              </Col> 
             </Row>
             <Row style={{paddingTop:4}}>
              <Col style={{alignItems:'flex-start',width:'100%'}}>
              <Text style={{fontSize:12, fontFamily:'Italic'}}>{item.D}</Text>
              </Col> 
             </Row>
            </Grid>  
             </CardItem>
           </Card>
        }
       keyExtractor={(item, index) => index.toString()}
       
      />

<Toast ref="toast"
        />
          </ScrollView>
          </View>
        )
      }
 };
 const styles = StyleSheet.create({
  titleText: {
    flex:1,
    flexWrap:'wrap',
    color:white,
    fontSize:12,
    padding:5,
    fontFamily:'Bold'
  },
  textContent:{
    color:white,
    fontSize:13,
    fontFamily:'Bold'
  }
  });
  
  
  
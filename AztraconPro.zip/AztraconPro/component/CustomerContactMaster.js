import React, { Component } from 'react';
import {
  TouchableWithoutFeedback, Linking, Platform, ScrollView,
  TouchableOpacity, StyleSheet, Text, View, Image, FlatList, Modal, Alert, Dimensions
} from 'react-native';
import { Col, Grid, Row } from 'react-native-easy-grid';
import { SearchBar } from 'react-native-elements';
import axios from 'axios';
import sms from 'react-native-sms-linking'
import Toast from 'react-native-whc-toast'
import { NavigationActions, StackActions } from 'react-navigation';
import { Card, CardItem } from 'native-base';
import { RFValue } from "react-native-responsive-fontsize";
//import * as Permissions from 'expo-permissions';
import * as Contacts from 'expo-contacts';

//own lib
import strings from './res/strings'
import color from './res/colors'
import { isPortrait } from './class/useOrientation'

//constant
const ip = strings.values.commonvalues.ip;
const tokken = strings.values.commonvalues.tokken;

const blue = color.values.Colors.blue;
const colorprimary = color.values.Colors.colorPrimary;
const white = color.values.Colors.white;
const black = color.values.Colors.black;
const lightblue = color.values.Colors.lightblue;

//common style
const style_common = require('./class/style');

//logout
const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class CustomerContactMaster extends React.Component {
  static navigationOptions = ({ navigation }) => ({
    title: "Contact Master",
    color: white,
    headerStyle: {
      backgroundColor: colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily: 'Bold',
      fontSize: RFValue(20)
    },
    headerRight: (
      <TouchableOpacity style={{ paddingRight: 10 }} onPress={() =>
        navigation.state.params.handlelogin()
      }>
        <Image
          style={{ alignSelf: 'center', justifyContent: 'center' }}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),

  });
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      handlelogin: '',
      dataSource: [],
      data: '',
      UserID: '',
      CusID: '',
      cname: '',
      orientation: '',
      DeviceType: '',
    };
    this.arrayholder = [];
  }

  login = async () => {

    Alert.alert(
      'Logout',
      'Would you like to logout?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {
          text: 'OK', onPress: () => {
            logouttask()
            this.props.navigation.dispatch(resetAction);
          }
        },
      ],
      { cancelable: false },
    );

  }


  getcontactlist() {
    const config = {
      headers: {
        'currentToken': tokken,
      },
      params: {
        cusid: this.state.CusID,
      },
    };
    this.setState({ isLoading: true })
    axios.get(ip + '/getCusContactlist', config)
      .then(response => this.setState({ dataSource: response.data }, () => {
        if (response.status == 200) {
          this.arrayholder = this.state.dataSource;
          this.setState({ isLoading: false })
        }
      }))
      .catch(err => {
        this.setState({
          isLoading: false
        }, () => {
          let error = err

          this.refs.toast.showBottom(error.toString())

          setTimeout(
            () => {
              this.props.navigation.goBack();
            },
            2000
          )

        })
      }
      );
  }
  SearchFilterFunction(text) {
    const newData = this.arrayholder.filter(function (item) {
      const itemData = item.sCode.toUpperCase() + item.sCName.toUpperCase()
      const textData = text.toUpperCase()
      return itemData.indexOf(textData) > -1
    })
    this.setState({
      dataSource: newData,
      text: text
    })
  }

  componentDidMount() {
    console.disableYellowBox = true;

    Dimensions.addEventListener('change', () => {
      this.setState({
        orientation: isPortrait() ? 'portrait' : 'landscape'
      });
    });

    this.props.navigation.setParams({
      handlelogin: this.login.bind(this)
    });

    this.setState({
      CusID: this.props.navigation.getParam('CusID', ''),
      cname: this.props.navigation.getParam('CusName', ''),
      UserID: this.props.navigation.getParam('UserID', ''),
      orientation: isPortrait() ? 'portrait' : 'landscape',
      DeviceType: this.props.navigation.getParam('DeviceType', '')
    }, () => {
      this.getcontactlist()
    })

  }

  call(ID) {

    let index = ID

    const { sPhone } = this.state.dataSource[index]

    if (Platform.OS === 'android') {
      Linking.openURL('tel:${' + sPhone.toString() + '}');
    }
    else {
      Linking.openURL('telprompt:${' + sPhone + '}');
    }
  }
  sms(ID) {

    let index = ID

    const { sMobile } = this.state.dataSource[index]

    sms(sMobile.toString(), 'Hi friend').catch(console.error)
  }
  email(ID) {

    let index = ID

    const { sEmail } = this.state.dataSource[index]

    Linking.openURL('mailto:' + sEmail.toString() + '?subject=hi&body=hi')
    title = "support@example.com"
  }

  contact = async (ID) => {
    let index = ID;
    const { sCode, sCName, sMobile } = this.state.dataSource[index];

    // Request permission to access contacts
    const { status } = await Contacts.requestPermissionsAsync();

    if (status === 'granted') {
      const contact = {
        [Contacts.Fields.FirstName]: sCode,
        [Contacts.Fields.LastName]: sCName,
        [Contacts.Fields.PhoneNumbers]: sMobile
      };

      try {
        const contactId = await Contacts.addContactAsync(contact);
        console.log(contactId);
        if (contactId) {
          alert("Contact Saved");
        } else {
          alert("Contact not saved.");
        }
      } catch (err) {
        alert("Contact not saved.");
      }
    } else {
      alert('Permission to access contacts was denied');
    }
  };

  // contact(ID){

  //   let index=ID

  //   const{sCode,sCName,sMobile}=this.state.dataSource[index]

  //   const { status } =  Permissions.askAsync(Permissions.CONTACTS);

  //   if (status === 'granted') {

  //     const contact = {
  //       [Contacts.Fields.FirstName]:sCode ,
  //       [Contacts.Fields.LastName]: sCName ,
  //       [Contacts.Fields.PhoneNumbers]:sMobile
  //       }
  //       try{
  //       const contactId =  Contacts.addContactAsync(contact);
  //       console.log(contactId);
  //       if(contactId){
  //       alert("Contact Saved")
  //       }
  //       else{
  //       alert("Contact not saved.")
  //       }}
  //       catch(err){
  //       alert("Contact not saved.")
  //       }

  //   }


  // }

  getheight(which) {

    console.log(which)
    let orient = ''
    let device = ''

    orient = this.state.orientation
    device = this.state.DeviceType

    console.log(orient + device)

    if (which == '1') { //header
      if (device == 'phone') {


        if (orient == 'portrait') {
          console.log(orient + device + 'g')
          return '15%'
        } else {
          //landscape
          return '15%'
        }

      } else {
        //tab
        if (orient == 'portrait') {
          return '5%'
        } else {
          //landscape
          return '10%'
        }

      }
    }


    if (which == '2') { //body
      if (device == 'phone') {

        if (orient == 'portrait') {
          return '85%'
        } else {
          //landscape
          return '85%'
        }

      } else {
        //tab
        if (orient == 'portrait') {
          return '95%'
        } else {
          //landscape
          return '90%'
        }

      }
    }

  }

  render() {
    if (this.state.isLoading) {
      return (
        <Modal
          transparent={false}
          supportedOrientations={['portrait', 'landscape']}
          visible={this.state.isLoading}
        >
          <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
            <Image
              useNativeDriver={true}
              style={style_common.load_gif}
              source={require('./src/gears.gif')} />
          </View>
        </Modal>
      )
    }
    return (
      <View style={{ flex: 1, backgroundColor: lightblue }}>
        <ScrollView style={{ height: this.getheight('1') }}>
          <Grid style={{ paddingTop: '2%' }}>
            <Row style={{ backgroundColor: colorprimary, width: '97%', alignSelf: 'center', borderRadius: RFValue(6) }}>
              <Text numberOfLines={1} style={styles.titleText}>
                {this.state.CusID.toString().trim() + " - " + this.state.cname}
              </Text>
            </Row>
          </Grid>
          <SearchBar
            style={{ paddingTop: 1 }}
            placeholder="Search Customer ID / Name"
            onChangeText={(text) => this.SearchFilterFunction(text)}
            value={this.state.text}
            searchIcon={{ name: "search", size: 19, color: colorprimary }}
            clearIcon={{ name: "close-circle", size: 19 }}
            loadingProps={{ size: "small" }}
            platform={'ios'}
          />
        </ScrollView>
        <ScrollView style={{ height: this.getheight('2') }}>
          <FlatList
            data={this.state.dataSource}
            initialNumToRender={this.state.dataSource.length}
            renderItem={({ item, index }) =>
              <Card style={{ width: '97%', alignSelf: 'center' }}>
                <CardItem style={style_common.card_item_padding}>
                  <Grid>

                    <Row>
                      <Col style={{ alignItems: 'flex-start', width: "100%" }}>
                        <Text style={styles.values}>{item.sConCode}</Text>
                      </Col>
                    </Row>

                    <Row>
                      <Col style={{ alignItems: 'flex-start', width: "40%" }}>
                        <Text style={styles.values}>{item.sConName}</Text>
                      </Col>
                      <Col style={{ alignItems: 'flex-start', width: "20%" }}>
                        <Text style={styles.values}>{item.sPhone}</Text>
                      </Col>
                      <Col style={{ alignItems: 'flex-start', width: "10%" }}>
                        <TouchableWithoutFeedback onPress={() => this.call(index)}>
                          <Image
                            style={styles.imagebutton}
                            source={require('./src/tm_call.png')}></Image>
                        </TouchableWithoutFeedback>
                      </Col>
                      <Col style={{ alignItems: 'flex-start', width: "10%" }}>
                        <TouchableWithoutFeedback onPress={() => this.sms(index)}>
                          <Image
                            style={styles.imagebutton}
                            source={require('./src/tm_sms.png')}></Image>
                        </TouchableWithoutFeedback>
                      </Col>
                      <Col style={{ alignItems: 'flex-start', width: "10%" }}>
                        <TouchableWithoutFeedback onPress={() => this.email(index)}>
                          <Image
                            style={styles.imagebutton}
                            source={require('./src/tm_email.png')}></Image>
                        </TouchableWithoutFeedback>
                      </Col>
                      <Col style={{ alignItems: 'flex-start', width: "10%" }}>
                        <TouchableOpacity activeOpacity={.5} onPress={() => this.contact(index)}>
                          <Image
                            style={styles.imagebutton}
                            source={require('./src/tm_save_contact.png')}></Image>
                        </TouchableOpacity>
                      </Col>
                    </Row>
                    <Row>
                      <Col style={{ alignItems: 'flex-start', width: "50%" }}>
                        <Text style={styles.values}>{item.sDesig}</Text>
                      </Col>
                      <Col style={{ alignItems: 'flex-start', width: "30%" }}>
                        <Text style={styles.values}>{item.sPhone}</Text>
                      </Col>

                    </Row>
                    <Row>
                      <Col style={{ alignItems: 'flex-start', width: "50%" }}>
                        <Text style={styles.values}>{item.sEmail}</Text>
                      </Col>
                      <Col style={{ alignItems: 'flex-start', width: "50%" }}>
                        <Text style={styles.values}>{item.sMobile}</Text>
                      </Col>
                    </Row>
                  </Grid>

                </CardItem>
              </Card>
            }
            keyExtractor={(item, index) => index.toString()}
          />
        </ScrollView>
        <Toast ref="toast"
        />
      </View>
    )
  }
};
const styles = StyleSheet.create({
  tittle: {
    color: '#36428a',
    fontSize: RFValue(13)
  },
  values: {
    color: '#708090',
    fontSize: 12,
    fontFamily: 'Regular'
  },
  imagebutton: {
    width: 30,
    height: 30,
  },
  titleText: {
    flex: 1,
    flexWrap: 'wrap',
    color: white,
    fontSize: RFValue(12),
    padding: RFValue(8),
    fontFamily: 'Bold'
  },
});



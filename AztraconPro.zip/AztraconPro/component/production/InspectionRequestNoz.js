import React,{ Component }  from 'react';
import {View,FlatList,TouchableOpacity,StyleSheet,Text,Image,ScrollView,Alert,KeyboardAvoidingView,Platform,Modal} from 'react-native';
import { Col,Grid,Row } from 'react-native-easy-grid';
import { Card,CardItem,Item,Input,Form,Label,CheckBox } from 'native-base';
import { NavigationActions, StackActions } from 'react-navigation';
import {Button,Overlay,Divider} from 'react-native-elements'
import { FAB, Portal, Provider } from 'react-native-paper';
import Toast from 'react-native-whc-toast'
import axios from 'axios';
import {logouttask} from '../class/logout';
import color from '../res/colors'
import strings from '../res/strings'

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const colorprimary=color.values.Colors.colorPrimary;
const blue=color.values.Colors.skyblue;
const white=color.values.Colors.white;
const colorprimarydark=color.values.Colors.colorPrimaryDark;
const gray=color.values.Colors.gray;
const black=color.values.Colors.black;
const red=color.values.Colors.red;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class InspectionRequestNoz extends React.Component {
   static navigationOptions = ({ navigation }) => ({ 
    title: "Noz Inspection",
    headerStyle: {
      backgroundColor: colorprimary
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('../src/logout.png')} />
      </TouchableOpacity>
    ),
  });
  
constructor(props) {
    super(props);
    this.state = {
         UserID:"",handlelogin:'',DetailDataSource:[],selectedindex:-1,ismodify:false,testsource:'',
         istesttype:false,Spn_Project:false,Spn_project_code:'',Spn_p_cus_code:'',Spn_Project_desc:'',Spn_Project_status:'',
         Spn_Tag:'',Spn_tag_code:'',Spn_dwg_code:'',ed_description:'',
         projectsource:'',tagsource:'',dwgsource:'',Spn_Test:'',Spn_Test_Code:'',
         insbysource:'',isproject:false,isdwg:false,istag:false,istagwake:false,isinsby:false,isprojectwake:false,
         b_sno:'',b_piece:'',b_type:'',b_desc:'',b_thk:'',b_width:'',b_len:'',b_mat:'',
         ed_sno:'',ed_remarks:'',isadd:false,ed_edwg:'',ed_odwg:'',ed_dia:'',ed_size:'',ed_noz_no:'',
         iserrvisible:false,ErrorMessage:'',chk_rework:false
    };
    this.arrayholder = [];
}

login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
      this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}


componentDidMount(){

  console.disableYellowBox = true;

  this.props.navigation.setParams({
    handlelogin: this.login.bind(this)
    });

  this.setState({
    isprojectwake:true,
    UserID:this.props.navigation.getParam('UserID', '')})
  
}

oninsertclose()
{
  this.setState({
    ed_sno:'',
    ed_remarks:'',
    ed_edwg:'',
    ed_odwg:'',
    ed_dia:'',
    ed_size:'',
    ed_noz_no:'',
    isadd:!this.state.isadd
  })
}
//add delete
onadd(){
 
  const{ed_noz_no}=this.state

  if(ed_noz_no.length==0){
    this.setState({
      ErrorMessage:'Please enter noz. no',
      iserrvisible:true
    },()=>{
      this.error()
    })
    return;

  }else{
            let s_no

            if(this.state.DetailDataSource.length==0){
              s_no = 1
            }else{
              s_no = this.state.DetailDataSource.length + 1
            }
      
      let Data=[]

      Data={
        sno:s_no,
        remarks:this.state.ed_remarks,
        edwg:this.state.ed_edwg,
        odwg:this.state.ed_odwg,
        dia:this.state.ed_dia,
        size:this.state.ed_size,
        noz:this.state.ed_noz_no,
        isSelected:false,
      }

      this.arrayholder.push({
        sno:s_no,
        remarks:this.state.ed_remarks,
        edwg:this.state.ed_edwg,
        odwg:this.state.ed_odwg,
        dia:this.state.ed_dia,
        size:this.state.ed_size,
        noz:this.state.ed_noz_no,
      })
    
    this.state.DetailDataSource.push(Data) 

    this.setState({
      ed_sno:'',
      ed_remarks:'',
      ed_edwg:'',
      ed_odwg:'',
      ed_dia:'',
      ed_size:'',
      ed_noz_no:'',
      ismodify:true,
      isadd:!this.state.isadd
    })

  } 

}

Add(){
    let s_no

    if(this.state.DetailDataSource.length==0){
      s_no = 1
    }else{
      s_no = this.state.DetailDataSource.length + 1
    }


    this.setState({
        ed_sno:s_no.toString(),
        isadd:!this.state.isadd
      }) 

}

Delete(){

  if (this.state.selectedindex > -1) {

    Alert.alert(
      'Delete',
      'Would you like to Delete?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {text: 'OK', onPress: () => {


          this.state.DetailDataSource.splice(this.state.selectedindex, 1);
          this.arrayholder.splice(this.state.selectedindex,1)
      
          for(let i=0;i<this.state.DetailDataSource.length;i++){
            this.state.DetailDataSource[i].sno=i+1;     
            this.arrayholder[i].sno=i+1;
          }
      
          this.setState({
            ismodify:!this.state.ismodify,
            DetailDataSource:this.state.DetailDataSource,
            selectedindex:-1
          })
          


        } },
      ],
      {cancelable: false},
    );

 
  }else{
  this.refs.toast.showBottom('Select record to delete');
} 

}

changerowcolor(index){
   
   for(let i=0;i<this.state.DetailDataSource.length;i++){
      if(index!==i){
          this.state.DetailDataSource[i].isSelected=false;
      }else if(index===i){
          this.state.DetailDataSource[index].isSelected =true; 
      } 
  }
  this.setState({ismodify:!this.state.ismodify,selectedindex:index}) 

}

rework(){
    if(this.state.chk_rework){
        this.setState({chk_rework:false})
      }else{
        this.setState({chk_rework:true})
      }
}

//common funtion

error(){
  setTimeout(() => {
    this.setState({
      iserrvisible:false,
      ErrorMessage:''
    })
    }, 1000)
}
  
goback(){
  this.props.navigation.replace('HomeProductionActivity',{
   UserID:this.state.UserID
 }) 
}

onsave(){
  
  if(this.state.Spn_project_code.length==0){
    this.refs.toast.showBottom('Please select project')
    return
  }else if(this.state.ed_description.length==0){
    this.refs.toast.showBottom('Please enter description')
    return
  }else if(this.state.DetailDataSource.length==0){
      this.refs.toast.showBottom('Please fill details!')
  }
  else{

    this.setState({isLoading:true})
 
    axios({
      method: 'post',
      url:ip+'/addInsReqNoz',
      headers: {'currentToken':tokken}, 
      data: {
        Ins:{
          "PID":this.state.Spn_project_code,
          "TagID":this.state.Spn_tag_code,
          "DwgID":this.state.Spn_dwg_code,
          "Desc":this.state.ed_description,
          "InsBy":this.state.Spn_insby_code,
          "ReWork":this.state.chk_rework==true?'Y':'N',
          "UserID":this.state.UserID,
      },
      InsItems:this.arrayholder,
      }
    }).then(response=>{if(response.status===200){
      this.setState({isLoading:false},()=>{
        this.props.navigation.replace('HomeProductionActivity',{
                   UserID:this.state.UserID,
                 });
        this.refs.toast.showBottom('Success')
      })
    }else{
      this.refs.toast.showBottom('Failed')
    }})
    .catch(err => 
      {
        this.setState({
          isLoading:false
        },()=>{
         let error=err
         
         this.refs.toast.showBottom(error.toString())
         
        setTimeout(
          () => { 
            this.props.navigation.goBack();
           },
          2000
        )
  
        })
      }
      );


  }

}

oncancel(){
   this.props.navigation.goBack(); 
}

//Data function

getproject(){
  
   const config = {
      headers: {   
      'currentToken': tokken,
    }
    };

    this.setState({isLoading:true})
    axios.get(ip+'/production/getSpnProject', config)
    .then(response => this.setState({projectsource:response.data},() => {if(response.status==200){

        this.setState({isLoading:false,isproject:true});
      }}))
      .catch(err => 
        {
          this.setState({
            isLoading:false
          },()=>{
           let error=err
           
           this.refs.toast.showBottom(error.toString())
      
           setTimeout(
            () => { 
              this.props.navigation.goBack();
             },
            2000
          )
      
          })
        }
        ); 

}

gettag(){
  
   const config = {
    headers: {   
    'currentToken': tokken,
  },   
  params: {
    sqlQuery:"SELECT TagIDNo,TagID FROM ProjectTags WHERE ProjectID ='" + this.state.Spn_project_code + "' "
  } 
  };

    this.setState({isLoading:true})
    axios.get(ip+'/getSpinnerData', config)
    .then(response => this.setState({tagsource:response.data},() => {if(response.status==200){
     
      if(this.state.tagsource.length==0){
          this.setState({isLoading:false,istag:false},()=>{
            this.refs.toast.showBottom('There is No Tag Item For this Project')
          });
        }else{
          this.setState({isLoading:false,istag:true});
        }
       
      }}))
      .catch(err => 
        {
          this.setState({
            isLoading:false
          },()=>{
           let error=err
           
           this.refs.toast.showBottom(error.toString())
      
           setTimeout(
            () => { 
              this.props.navigation.goBack();
             },
            2000
          )
      
          })
        }
        ); 

}

getdwg(){
   const config = {
    headers: {   
    'currentToken': tokken,
  },params: {  
    tid:this.state.Spn_tag_code
  }
  };

  this.setState({isLoading:true})
  axios.get(ip+'/production/getSpnDwg', config)
  .then(response => this.setState({dwgsource:response.data},() => {if(response.status==200){

    if(this.state.dwgsource.length==0){
      this.setState({isLoading:false,isdwg:false},()=>{
        this.refs.toast.showBottom('There is No Drawing')
      });
    }else{
      this.setState({isLoading:false,isdwg:true});
    }

    }}))
    .catch(err => 
      {
        this.setState({
          isLoading:false
        },()=>{
         let error=err
         
         this.refs.toast.showBottom(error.toString())
    
         setTimeout(
          () => { 
            this.props.navigation.goBack();
           },
          2000
        )
    
        })
      }
      ); 
}

getinspectionby(){

   const config = {
    headers: {   
    'currentToken': tokken,
  },params:{  
   sqlQuery:"SELECT EmpID,EmpName FROM EmployeeMaster WHERE Department IN ('QAC','QCR') AND Active = 'Y'"
  }
  };

  this.setState({isLoading:true})
  axios.get(ip+'/getSpinnerData', config)
  .then(response => this.setState({insbysource:response.data},() => {if(response.status==200){

    if(this.state.insbysource.length==0){
      this.setState({isLoading:false,isinsby:false},()=>{
        this.refs.toast.showBottom('There is No Inspection By')
      });
    }else{
      this.setState({isLoading:false,isinsby:true});
    }

    }}))
    .catch(err => 
      {
        this.setState({
          isLoading:false
        },()=>{
         let error=err
         
         this.refs.toast.showBottom(error.toString())
    
         setTimeout(
          () => { 
            this.props.navigation.goBack();
           },
          2000
        )
    
        })
      }
      ); 
}


//layout wake 
onlayoutproject(){
  if(this.state.isprojectwake==true){
    this.getproject()
  }else{
    this.refs.toast.showBottom("Please Select Nothing")
  }
}

onlayouttag(){
  if(this.state.istagwake==true){
   this.gettag()
  }else{
    this.refs.toast.showBottom("Please Select Project")
  }
}

onlayoutdrawing(){
  if(this.state.isdwgwake==true){
    this.getdwg()
   }else{
     this.refs.toast.showBottom("Please Select Tag")
   }
}

//items

getprojectitem (data) {

  const{sPid,sCusCode,sPdesc,sStatus}=data
  
    this.setState({
      Spn_project_code:sPid,
      Spn_p_cus_code:sCusCode,
      Spn_Project_desc:sPdesc,
      Spn_Project_status:sStatus,
      Spn_Project:sPid+"  "+sPdesc,
      isproject:!this.state.isproject,
      istagwake:true,
      Spn_dwg_code:'',
      Spn_Dwg:'',
      Spn_tag_code:'',
      Spn_Tag:'',
    })
  
  }
  
gettagitem (code,desc) {
  
      this.setState({
        Spn_tag_code:code,
        Spn_Tag:code+"  "+desc,
        istag:!this.state.istag,
        isdwgwake:true,
        Spn_dwg_code:'',
        Spn_Dwg:'',

      })
    
    }

getdwgitem(data){

  const{sDid,sRNo,sFname,sDno}=data

  this.setState({
    Spn_dwg_code:sDid,
    Spn_Dwg:sDid+"  "+sFname,
    isdwg:!this.state.isdwg,
    isinsforwake:true
  })

}

getinsbyitem(code,desc){
  this.setState({
    Spn_insby_code:code,
    Spn_InspectionBy:code+"  "+desc,
    isinsby:!this.state.isinsby,
  })
}

render() {

  if (this.state.isLoading) {
    return (
      <Modal
      transparent={false}
      visible={this.state.isLoading}
      >
       <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
        <Image
        style={{width: 300, height: 200}}
        source={require('../src/gears.gif')}  />
        </View>     
      </Modal>
    )
  }
return (
<View style={{flex:1}}>

<ScrollView style={{height:'100%'}}>

   {/*      TOP FORM */}

       <Grid style={{width:'97%',alignSelf:'center'}}>
       <Form>
           <Row>
           <Col style={{width:'100%',alignItems:'flex-start'}}>
           <Item style={{ marginLeft: 0,marginTop:3}} floatingLabel onPress={this.onlayoutproject.bind(this)}>
           <Label style={styles.floatlabel}>Project</Label>
           <Input 
           editable={false}
           multiline={true}
           style={{ fontSize: 12 }}
           value={this.state.Spn_Project}/>
           </Item>
           </Col>
           </Row> 
       
           <Row style={styles.rowstyle}>
           <Col style={{width:'100%',alignItems:'flex-start'}}>
           <Item style={{ marginLeft: 0,marginTop:3 }}  floatingLabel  onPress={this.onlayouttag.bind(this)}>
           <Label style={styles.floatlabel}>Tag ID</Label>
           <Input 
           editable={false}
           style={styles.istyle}
           multiline={true}
           value={this.state.Spn_Tag}/>
           </Item>
           </Col>
           </Row> 

           <Row style={styles.rowstyle}>
           <Col style={{width:'100%',alignItems:'flex-start'}}>
           <Item style={{ marginLeft: 0,marginTop:3 }} floatingLabel   onPress={this.onlayoutdrawing.bind(this)}>
           <Label style={styles.floatlabel}>DWG ID</Label>
           <Input 
           editable={false}
           style={styles.istyle}
           multiline={true}
           value={this.state.Spn_Dwg}/>
           </Item>
           </Col>
           </Row> 

           <Row style={styles.rowstyle}>
           <Col style={{width:'100%',alignItems:'flex-start'}}>
           <Item style={{ marginLeft: 0,marginTop:3 }} floatingLabel   onPress={this.getinspectionby.bind(this)}>
           <Label style={styles.floatlabel}>Inspection by</Label>
           <Input 
           editable={false}
           style={styles.istyle}
           multiline={true}
           value={this.state.Spn_InspectionBy}/>
           </Item>
           </Col>
           </Row> 

          <Row style={styles.rowstyle}>
           <Col style={{width:'100%',alignItems:"flex-start"}}>
           <Item style={{ marginLeft: 0,marginTop:3 }} floatingLabel>
              <Label style={styles.floatlabel}>Description</Label>
              <Input 
                getRef={(input) => { this.description = input; }}
                returnKeyType='done'
                maxLength={100}
                style={styles.istyle}
                autoCorrect={false}
                autoCapitalize='words'
                keyboardType={'default'}
                value={this.state.ed_description}
                onChangeText={(ed_description) => this.setState({ ed_description })}
              />
            </Item>
            </Col>
           </Row>
           <Row style={{paddingTop:10}}>
               <Col style={{width:'10%',alignItems:'flex-start'}}>
               <CheckBox checked={this.state.chk_rework}
                 onPress={()=>this.rework()}  
                 color={colorprimarydark}/>
               </Col>
               <Col style={{width:'90%',alignItems:'flex-start'}}>
               <Text style={{fontSize:15,fontWeight:'bold',color:colorprimarydark}} 
                      onPress={()=>this.rework()}>Rework ?</Text>
               </Col>
           </Row>

       </Form>
       </Grid>
       

       <Grid style={{paddingTop:'2%'}}>
       <Row style={{backgroundColor:colorprimary,padding:5,width:'97%',alignSelf:'center',borderRadius:4}}>
       <Text style={styles.titleText}>Detail</Text>
       </Row>
       </Grid>

    
       <View style={{paddingTop:3}}>

        <FlatList
       data={ this.state.DetailDataSource}
       extraData={this.state.ismodify} 
       initialNumToRender={this.state.DetailDataSource.length}
       renderItem={({item,index}) =>  
            <Card style={{width:'97%',alignSelf:'center'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
            paddingLeft: 5,paddingRight: 5,paddingTop: 10,paddingBottom: 10}}>
            <Grid style={{backgroundColor:item.isSelected?blue:white}} 
                                   onPress={() => this.changerowcolor(index)}> 
            <Row style={{paddingTop:3}}>
            <Col style={{alignItems:'flex-start',width:'10%'}}>
            <Text style={{fontSize:13,color:item.isSelected?white:gray}}>{item.sno}</Text>
            </Col> 
            <Col style={{alignItems:'flex-start',width:'50%'}}>
            <Text style={{fontSize:13,color:item.isSelected?white:gray}}>{item.noz}</Text>
            </Col>
            <Col style={{alignItems:'flex-start',width:'20%'}}>
            <Text style={{fontSize:13,color:item.isSelected?white:gray}}>{item.size}</Text>
            </Col>
            <Col style={{alignItems:'flex-start',width:'20%'}}>
            <Text style={{fontSize:13,color:item.isSelected?white:gray}}>{item.dia}</Text>
            </Col>
            </Row>

            <Divider></Divider>
            
            <Row style={{paddingTop:3}}>
            <Col style={{alignItems:'center',width:'50%'}}>
                <Row>
                <Col style={{alignSelf:'center',width:'100%',alignItems:'center'}}>
                <Text style={{fontSize:13,color:colorprimary,fontWeight:'bold'}}>Ori. as per Dwg</Text>
                 </Col>
                </Row>
                <Row>
                <Col style={{alignSelf:'center',width:'100%',alignItems:'center'}}>
                 <Text style={{fontSize:13,color:item.isSelected?white:gray}}>{item.odwg}</Text>
                 </Col>
                </Row>
            </Col>
            <Col style={{alignItems:'center',width:'50%'}}>
                <Row>
                <Col style={{alignSelf:'center',width:'100%',alignItems:'center'}}>
                <Text style={{fontSize:13,color:colorprimary,fontWeight:'bold'}}>Ele. as per Dwg</Text>
                 </Col>
                </Row>
                <Row>
                <Col style={{alignSelf:'center',width:'100%',alignItems:'center'}}>
                 <Text style={{fontSize:13,color:item.isSelected?white:gray}}>{item.edwg}</Text>
                 </Col>
                </Row>
            </Col>
            </Row>

            <Divider></Divider>
   
            <Row style={{paddingTop:3}}>

            <Col style={{alignItems:'flex-start',width:'20%'}}>
            <Text style={{fontSize:13,color:colorprimary,fontWeight:'bold'}}>Remark : </Text>
            </Col>
         
            <Col style={{alignItems:'flex-start',width:'80%'}}>
            <Text style={{fontSize:13,color:colorprimary,fontWeight:'bold'}}>{item.remarks}</Text>
            </Col>
            </Row>
           
            </Grid>
            </CardItem>
            </Card>
        }
       keyExtractor={(item, index) => index.toString()}
       
      />


      </View>

      <Grid style={{paddingTop:4,width:'97%'}} >
       <Row>
         <Col style={{alignItems:'center',width:'100%'}}>
         <View style={styles.TButton}>
          <Button
            title="SUBMIT"
            buttonStyle={{
              borderRadius:10,
              backgroundColor:colorprimary
            }}
            onPress={this.onsave.bind(this)}/>
        </View>
         </Col>
       </Row>
   </Grid>
{/*Spinners*/}  

{/*Spinners Project*/}  

 <Overlay
  width="100%"
  height="100%"
  animationType="slide"
  isVisible={this.state.isproject}
  onBackdropPress={() => this.setState({ isproject: false })}> 
          
          <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress = {() =>
           {  
            this.setState({ isproject:!this.state.isproject})
           }}>

<Grid>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontWeight:'bold',alignSelf:'flex-start'}}>
              Select Project
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('../src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
 </Grid>

        

         </TouchableOpacity>
            
             <View  style={{ flex: 1,paddingTop:5}}>

             <FlatList
             data={ this.state.projectsource}
             initialNumToRender={this.state.projectsource.length}
             renderItem={({item}) => 
             
            <Card style={{width:'97%',alignSelf:'center'}}>
            <CardItem style={styles.carditem}>
            <Grid onPress={this.getprojectitem.bind(this,item)}>
            <Row>
            <Col style={{alignItems:'flex-start',width:'15%'}}>
            <Text style={{fontSize:13,fontWeight:'bold',color:colorprimary}}>{item.sPid}</Text>
            </Col> 
            <Col style={{alignItems:'flex-start',width:'15%'}}>
                <Text style={{fontSize:13,fontWeight:'bold',color:colorprimary}}>{item.sCusCode}</Text>
             </Col>
            <Col style={{alignItems:'flex-start',width:'70%'}}>
            <Grid>
              <Row>
                <Col style={{alignItems:'flex-start',width:'100%'}}>
                <Text style={{fontSize:13,fontWeight:'bold',color:colorprimary}}>{item.sPdesc}</Text>
                </Col>
              </Row>
              <Row>
                <Col style={{alignItems:'flex-start',width:'100%'}}>
                <Text style={{fontSize:13,fontStyle:'italic'}}>{item.sStatus}</Text>
                </Col>
              </Row>
            </Grid>
            </Col> 
            <Col>
            </Col>  
            </Row>
            </Grid>
            </CardItem>
            </Card>
            }
            keyExtractor={(item, index) => index.toString()}
            />
             </View>
 </Overlay>

{/*Spinners Tag*/}  

<Modal            
          animationType = {"slide"}  
          transparent = {true}  
          visible = {this.state.istag}  
          onRequestClose = {() =>{ console.log("Modal has been closed.") } }>  
          {/*All views of Modal*/}  
          <View style = {styles.modal}>  
          <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress = {() =>
           {  
            this.setState({ istag:!this.state.istag})
           }}>




          <Grid>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontWeight:'bold',alignSelf:'flex-start'}}>
             Tag List
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('../src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
          </Grid>
         
       

         </TouchableOpacity>
         
         <FlatList
         data={ this.state.tagsource }
         initialNumToRender={ this.state.tagsource.length }
         renderItem={({item}) => 
         <Card style={{width:'97%',alignSelf:'center'}}>
           <CardItem style={{alignItems:'flex-start',width:'100%',flexWrap:'wrap'}}>
           <Grid onPress={this.gettagitem.bind(this, item.sCode,item.sDesc)}>
           <Row>
              <Col style={{alignItems:'flex-start',width:'30%'}}>
              <Text style={{fontSize:13,fontWeight:"bold",color:colorprimary}}>{item.sCode}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'70%'}}>
              <Text style={{fontSize:13,fontWeight:'bold',color:colorprimary}}>{item.sDesc}</Text>
              </Col> 
              <Col>
             </Col>  
           </Row>
         </Grid>
           </CardItem>
         </Card>
    
        }
       keyExtractor={(item, index) => index.toString()}
      />

          </View>  
</Modal>

{/*Spinners Dwg*/} 

<Modal            
          animationType = {"slide"}  
          transparent = {true}  
          visible = {this.state.isdwg}  
          onRequestClose = {() =>{ console.log("Modal has been closed.") } }>  
          {/*All views of Modal*/}  
          <View style = {styles.modal}>  
          <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress = {() =>
           {  
            this.setState({ isdwg:!this.state.isdwg})
           }}>
        

        <Grid>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontWeight:'bold',alignSelf:'flex-start'}}>
             Drawing List
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('../src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
       </Grid>

        

         </TouchableOpacity>
         
         <FlatList
         data={ this.state.dwgsource }
         initialNumToRender={ this.state.dwgsource.length }
         renderItem={({item}) => 
         <Card style={{width:'97%',alignSelf:'center'}}>
         <CardItem style={styles.carditem}>
         <Grid onPress={this.getdwgitem.bind(this,item)}>
         <Row>
         <Col style={{alignItems:'flex-start',width:'20%'}}>
         <Text style={{fontSize:13,color:gray,fontWeight:'bold'}}>{item.sDid}</Text>
         </Col> 
         <Col style={{alignItems:'flex-start',width:'10%'}}>
         <Text style={{fontSize:13,color:gray,fontWeight:'bold'}}>{item.sRNo}</Text>
         </Col>
         <Col style={{alignItems:'flex-start',width:'70%'}}>
         <Text style={{fontSize:13,color:gray,fontStyle:'italic'}}>{item.sDno}</Text>
         </Col>
         </Row>
         </Grid>
         </CardItem>
         </Card>
    
        }
       keyExtractor={(item, index) => index.toString()}
      />

          </View>  
</Modal>

{/*Inspection By*/}

<Modal            
          animationType = {"slide"}  
          transparent = {true}  
          visible = {this.state.isinsby}  
          onRequestClose = {() =>{ console.log("Modal has been closed.") } }>  
          {/*All views of Modal*/}  
          <View style = {styles.modal}>  
          <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress = {() =>
           {  
            this.setState({ isinsby:!this.state.isinsby})
           }}>
         

         <Grid>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontWeight:'bold',alignSelf:'flex-start'}}>
             Inspection By
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('../src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
         </Grid>

     

         </TouchableOpacity>
         
         <FlatList
         data={ this.state.insbysource}
         initialNumToRender={ this.state.insbysource.length }
         renderItem={({item}) => 
         <Card style={{width:'97%',alignSelf:'center'}}>
         <CardItem style={styles.carditem}>
         <Grid onPress={this.getinsbyitem.bind(this,item.sCode,item.sDesc)}>
         <Row>
         <Col style={{alignItems:'flex-start',width:'20%'}}>
         <Text style={{fontSize:13,fontWeight:'bold',color:colorprimary}}>{item.sCode}</Text>
         </Col> 
         <Col style={{alignItems:'flex-start',width:'80%'}}>
         <Text style={{fontSize:13,fontWeight:'bold',color:colorprimary}}>{item.sDesc}</Text>
         </Col>
         </Row>
         </Grid>
         </CardItem>
         </Card>
    
        }
       keyExtractor={(item, index) => index.toString()}
      />

          </View>  
</Modal>

{/* Insert OverLay */}

<Overlay
  width="100%"
  height="68%"
  animationType="slide"
  isVisible={this.state.isadd}
  onBackdropPress={() => this.setState({ isadd: false })}> 
            <KeyboardAvoidingView 
            behavior='padding'
            keyboardVerticalOffset={ Platform.select({ ios: () => 0,android: () => 40})()}>
          <ScrollView style={{height:"100%"}}>

          <TouchableOpacity style={styles.headerback} activeOpacity={0.5} onPress = {() =>
           {  
            this.setState({ isadd:!this.state.isadd})
           }}>



        <Grid>
           <Row>
             <Col style={{width:'90%',alignItems:'center',alignSelf:'center'}}>
             <Text style={{paddingLeft:'3%',color:'#fff',textDecorationStyle:'solid',fontWeight:'bold',alignSelf:'flex-start'}}>
             Insert Inspection Noz Detail
             </Text>
             </Col>
           
             <Col style={{width:'10%',alignItems:'center',alignSelf:'center'}}>
             <Image
             source={require('../src/back.png')}
             style={{height:22,width:22}}         
             />
             </Col>
           </Row>
        </Grid>

      
         </TouchableOpacity>
            
        <View  style={{ flex: 1}}>
    
        <Grid style={{width:'97%',alignSelf:'center'}}>
          <Form>

           <Row style={styles.rowstyle}>
           <Col style={{width:'100%',alignItems:"flex-start"}}>
           <Item style={{ marginLeft: 0}}  floatingLabel>
              <Label style={styles.floatlabel}>SNo.</Label>
              <Input 
                autoFocus={false}
                style={styles.istyle}
                editable={false}
                value={this.state.ed_sno}
              />
            </Item>
            </Col>
           </Row> 

           <Row style={styles.rowstyle}>
           <Col style={{width:'100%',alignItems:"flex-start"}}>
           <Item style={{ marginLeft: 0}}  floatingLabel>
              <Label style={styles.floatlabel}>Nozzle No</Label>
              <Input 
                getRef={(input) => { this.nozno = input; }}
                autoFocus={false}
                returnKeyType='next'
                maxLength={30}
                style={styles.istyle}
                autoCorrect={true}
                clearButtonMode='always'
                autoCapitalize='words'
                keyboardType={'default'}
                value={this.state.ed_noz_no}
                onChangeText={(ed_noz_no) => this.setState({ ed_noz_no })}
                onSubmitEditing={() => { this.size._root.focus(); }}
              />
            </Item>
            </Col>
           </Row> 

           <Row style={styles.rowstyle}>
           <Col style={{width:'50%',alignItems:"flex-start"}}>
           <Item style={{ marginLeft: 0}}  floatingLabel>
              <Label style={styles.floatlabel}>Size</Label>
              <Input 
                getRef={(input) => { this.size = input; }}
                autoFocus={false}
                returnKeyType='next'
                maxLength={10}
                style={styles.istyle}
                autoCorrect={true}
                clearButtonMode='always'
                autoCapitalize='words'
                keyboardType={'decimal-pad'}
                value={this.state.ed_size}
                onChangeText={(ed_size) => this.setState({ ed_size })}
                onSubmitEditing={() => { this.dia._root.focus(); }}
              />
            </Item>
           </Col>
           <Col style={{width:'50%',alignItems:"flex-start"}}>
           <Item style={{ marginLeft: 0}}  floatingLabel>
              <Label style={styles.floatlabel}>Diameter</Label>
              <Input 
                getRef={(input) => { this.dia = input; }}
                autoFocus={false}
                returnKeyType='next'
                maxLength={10}
                style={styles.istyle}
                autoCorrect={true}
                clearButtonMode='always'
                autoCapitalize='words'
                keyboardType={'decimal-pad'}
                value={this.state.ed_dia}
                onChangeText={(ed_dia) => this.setState({ ed_dia })}
                onSubmitEditing={() => { this.ori._root.focus(); }}
              />
            </Item>
           </Col>
           </Row>

           <Row style={styles.rowstyle}>
           <Col style={{width:'50%',alignItems:"flex-start"}}>
           <Item style={{ marginLeft: 0}}  floatingLabel>
              <Label style={styles.floatlabel}>Ori. as per Dwg</Label>
              <Input 
                getRef={(input) => { this.ori = input; }}
                autoFocus={false}
                returnKeyType='next'
                maxLength={10}
                style={styles.istyle}
                autoCorrect={true}
                clearButtonMode='always'
                autoCapitalize='words'
                keyboardType={'decimal-pad'}
                value={this.state.ed_odwg}
                onChangeText={(ed_odwg) => this.setState({ ed_odwg })}
                onSubmitEditing={() => { this.ele._root.focus(); }}
              />
            </Item>
           </Col>
           <Col style={{width:'50%',alignItems:"flex-start"}}>
           <Item style={{ marginLeft: 0}}  floatingLabel>
              <Label style={styles.floatlabel}>Ele. as per Dwg</Label>
              <Input 
                getRef={(input) => { this.ele = input; }}
                autoFocus={false}
                returnKeyType='next'
                maxLength={10}
                style={styles.istyle}
                autoCorrect={true}
                clearButtonMode='always'
                autoCapitalize='words'
                keyboardType={'decimal-pad'}
                value={this.state.ed_edwg}
                onChangeText={(ed_edwg) => this.setState({ ed_edwg })}
                onSubmitEditing={() => { this.remark._root.focus(); }}
              />
            </Item>
           </Col>
           </Row>
           
           <Row style={styles.rowstyle}>
           <Col style={{width:'100%',alignItems:"flex-start"}}>
           <Item style={{ marginLeft: 0}}  floatingLabel>
              <Label style={styles.floatlabel}>Remark</Label>
              <Input 
                getRef={(input) => { this.remark = input; }}
                autoFocus={false}
                returnKeyType='done'
                maxLength={50}
                style={styles.istyle}
                autoCorrect={true}
                clearButtonMode='always'
                autoCapitalize='words'
                keyboardType={'default'}
                value={this.state.ed_remarks}
                onChangeText={(ed_remarks) => this.setState({ ed_remarks })}
                onSubmitEditing={() => { this.remark._root.focus(); }}
              />
            </Item>
            </Col>
           </Row> 

           <Row style={{paddingTop:5}}>
           <Col style={{alignItems:'center',width:'50%'}}>
           <View  style={{ alignSelf:'center',width:'80%',height:50,}}>
           <Button
            title="ADD"
            buttonStyle={{
              borderRadius:10,
              backgroundColor:colorprimary
            }}
              onPress={this.onadd.bind(this)}/>
            </View>
            </Col>
        
           <Col style={{alignItems:'center',width:'50%'}}>
           <View style={{ alignSelf:'center',width:'80%',height:50,}}>
           <Button
            title="CANCEL"
            buttonStyle={{
              borderRadius:10,
              backgroundColor:colorprimary
            }}
            onPress={this.oninsertclose.bind(this)}/>
            </View>
            </Col>

           </Row>
          </Form>
        </Grid>

        </View>
         
         <Grid style={{ position: 'absolute',bottom:0,borderRadius:15,backgroundColor:red,
         paddingTop:10,paddingBottom:10}}>
         <Row style={{display:this.state.iserrvisible?'flex':'none'}}>
             <Col style={{alignSelf:'center',width:'97%'}}>
             <Text style={{textAlign:'center',color:white,fontSize:13,fontWeight:'bold'}}>
               {this.state.ErrorMessage}
               </Text>
             </Col>
           </Row>
         </Grid>
        </ScrollView>
        </KeyboardAvoidingView>
 </Overlay>

<Toast ref="toast" />

</ScrollView>  


      <Provider>
          <Portal>
           <FAB.Group
             open={this.state.open}
             fabStyle={{backgroundColor:colorprimary}}
             style={{
               position: 'absolute',
               bottom:0}}
             icon={this.state.open ? 'menu' : 'menu'}
             color={white}
             actions={[
               { icon:'add-a-photo', label: 'Add',color:colorprimary,onPress: () => this.Add() },
               { icon:'delete', label: 'Delete',color:colorprimary, onPress: () => this.Delete() },
             ]}
             onStateChange={({ open }) => this.setState({ open })}
             onPress={() => {
               if (this.state.open) {
                 // do something if the speed dial is open
               }
             }}
           />
         </Portal>
      </Provider> 

</View>
)
}
}

const styles = StyleSheet.create({
    titleText: {
        flex:1,
        flexWrap:'wrap',
        color:white,
        fontSize:13,
        fontWeight:'bold'
      },
image:{
    width:40,
    height:40
},
textContent: {
    backgroundColor:colorprimary,
    fontSize: 12,
    padding:4,
    width:'97%',
    alignSelf:'center',
    color:white,
    fontWeight: 'bold'
  },
  imagebutton: {
    width:80,
    height: 80,
    alignSelf:'center'
  },
  imagetext:{
      color:colorprimary,
      fontSize:12,
      alignSelf:'center'
  },
  i: {
    paddingTop:10,
  },
  floatlabel:{
  color:colorprimarydark,
  fontSize:15,
  fontWeight:'bold',
  fontStyle:'italic'
  },
  TButton:{
    paddingTop:3,
    alignSelf:'center',
    width:'45%',
    height:50,
  },
  headerback: {
    flexDirection: 'row',
    alignItems:'center',
    backgroundColor: colorprimary,
    borderWidth: 0.5,
    borderColor:white,
    height: 40,
    width:'100%',
    borderRadius: 5,
  },
  modal: {  
    flex: 1,
    backgroundColor:white,
    height:'70%', 
    position: 'absolute',
    bottom: 0
     },
     modalbom: {  
      flex: 1,
      alignSelf:'center',
      width:'100%',
      backgroundColor:white,
      height:'100%', 
      position: 'absolute',
      bottom: 0
       },
  container: {
    backgroundColor:white,
    flex: 1,
    height: '100%',
    justifyContent: 'space-around',
    left: 0,
    position: 'absolute',
    top: 0,
    width: '100%'
  },
  rowstyle:{
    paddingTop:6,
  },
  istyle:{
   fontSize: 13 
  },
  carditem:{
    alignItems:"flex-start",width:'100%',flexWrap:'wrap',
          paddingLeft: 5,
          paddingRight: 5,
          paddingTop: 10,
          paddingBottom: 10,
  }
});

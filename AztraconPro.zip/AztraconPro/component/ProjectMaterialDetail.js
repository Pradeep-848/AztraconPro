import React,{ Component,PureComponent }  from 'react';
import {ScrollView,StyleSheet,Text,View,Modal,VirtualizedList,Image,Dimensions,TouchableOpacity} from 'react-native';
import { Col, Grid, Row } from 'react-native-easy-grid';
import axios from 'axios';
import {Card,CardItem} from 'native-base';
import { NavigationActions, StackActions } from 'react-navigation';
import { SearchBar } from 'react-native-elements'
import RadioGroup from 'react-native-radio-buttons-group';

//own lib
import {isPortrait} from './class/useOrientation'
import color from './res/colors';
import {logouttask} from './class/logout';
import strings from './res/strings'

//constant values
const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const colorprimarydark=color.values.Colors.colorPrimaryDark;

let selectedButton;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

//common style
const style_common = require('./class/style');

var { height, width } = Dimensions.get("window");

export default class ProjectMaterialDetails extends React.PureComponent {
  static navigationOptions = ({ navigation }) => ({ 
  
    title: "Project Material Detail",
    color:white,
    headerStyle: {
      backgroundColor: colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold'
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
      handlelogin:'',
      MCode:"",
      MDesc:"",
      isLoading: false, 
      dataSource:[],
      UserId:'',
      Mcode:'',
      category:'',
      verified:false,
      nonverified:true,
      radiovalues: [
        {
            label: 'Non Verified',
            value: "non",
            color:'#2452b2'
        },
        {
            label: 'Verified',
            value: 'ver',
            color:'#2452b2'
        }
    ],
    };
    this.arrayholder = [] ;
}

onPress = radiovalues => this.setState({ radiovalues},()=>{
  for(let i=0;i<this.state.radiovalues.length;i++){
    const{value,selected}=this.state.radiovalues[i]
    if(value=='non' && selected==true){
      this.getlist('N')
    }
    if(value=='ver' && selected==true){
      this.getlist('Y')
    }
  }
});


nonverified(){
  alert(this.state.Approve)
  this.setState({nonverified:!this.state.nonverified})
}
verified(){
  this.setState({verified:!this.state.verified})
}

login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
        this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}

gotophysical = (id) => {

const{seqNo,pid,itemCode,entryCode,qty,materialDesc,source,slNo,heatNo,length
,uom,itemValue,location,grade,verification}=this.state.dataSource[id]

this.props.navigation.navigate('PhysicalStockSaveActivity',{
  PID:pid,
  ItemCode:itemCode,
  EntryCode:entryCode,
  QTY:qty,
  MDESC:this.state.MDesc,
  SNo:seqNo,
  mdesc:materialDesc,
  MCODE:this.state.MCode,
  SlNo:slNo,
  Source:source,
  UserID:this.state.UserId,
  HeatNo:heatNo,
  Length:length,
  UOM:uom,
  ItemValue:itemValue,
  Location:location,
  Grade:grade,
  Verify:verification,
});
  
}


componentDidMount() {

  console.disableYellowBox = true;

  this.props.navigation.setParams({
    handlelogin: this.login.bind(this)
    });
    
  this.setState({
      category:this.props.navigation.getParam('MCODE', '')+" - "+this.props.navigation.getParam('Mdesc', ''),
      MDesc:this.props.navigation.getParam('Mdesc', ''),
      MCode:this.props.navigation.getParam('MCODE', ''),
      UserID:this.props.navigation.getParam('UserID', '')
  },()=>{this.getlist('N');})

  }
  getlist(ver){

    console.log(ver)

    const config = {
        headers: {   
        'currentToken': tokken,
      },
        params: {
            Mcode:this.state.MCode,
            Verify:ver,
        }
        
      };
    
      this.setState({isLoading:true})
      axios.get(ip+'/getMaterialDetail', config)
      .then(response => this.setState({ dataSource:response.data},() => {if(response.status==200){
        this.arrayholder = this.state.dataSource;
        console.log(this.state.dataSource)
        this.setState({isLoading:false})}}))
      .catch(err => console.log(err));  
  }


  filtersearch(text){
    const newData = this.arrayholder.filter(function(item){
    const itemData =item.pid.toString()+item.itemCode.toString()
    const textData = text.toUpperCase()
    return itemData.indexOf(textData) > -1
}
)
this.setState({
    dataSource: newData.sort(),
    text: text
})
}

  render() {
    selectedButton = this.state.radiovalues.find(e => e.selected == true);
    selectedButton = selectedButton ? selectedButton.value : this.state.radiovalues[0].label;   

    if (this.state.isLoading) {
      return (
        <Modal
        transparent={false}
        supportedOrientations={['portrait', 'landscape']}
        visible={this.state.isLoading}
        >
         <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
          style={{width: 300, height: 200}}
          source={require('./src/gears.gif')}  />
          </View>     
        </Modal>
           )
  }
    return (
   <ScrollView>
         
       <View style={{ flex: 1,paddingTop:5,alignItems:'center'}}>
       <Text style={styles.textContent}>{this.state.category}</Text>
       </View> 

       <View style={{ flex: 1,paddingTop:5,alignItems:'center',paddingBottom:5}}>
       <RadioGroup flexDirection='row' radioButtons={this.state.radiovalues} onPress={this.onPress} />
       </View>
       <Grid style={{paddingTop:10,paddingBottom:10}}>
         <Row>
         <SearchBar
        placeholder="Search PID/Item Code"
        onChangeText={(text) => this.filtersearch(text)}
        value={this.state.text}
        platform={'ios'}></SearchBar>
         </Row>
        </Grid>


  <View style={{ flex: 1,paddingTop:2,alignItems:'center'}}>
              <Grid style={{backgroundColor:'#36428a',padding:2,width:"98%",alignSelf:'center'}}>
              <Row>
              <Col style={{alignItems:'flex-start',width:"15%"}}>
              <Text style={{backgroundColor:'#36428a',fontSize: 12,padding:4,alignItems:'center',color: '#fff',fontWeight: 'bold',paddingLeft:8}}>PID</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:"25%"}}>
              <Text style={{backgroundColor:'#36428a',fontSize: 12,padding:4,alignItems:'center',color: '#fff',fontWeight: 'bold',paddingLeft:7}}>Item Code</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:"25%"}}>
              <Text style={{backgroundColor:'#36428a',fontSize: 12,padding:4,alignItems:'center',color: '#fff',fontWeight: 'bold',paddingLeft:5}}>Entry No</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:"35%"}}>
              <Text style={{backgroundColor:'#36428a',fontSize: 12,padding:4,alignItems:'center',color: '#fff',fontWeight: 'bold',paddingRight:15}}>Qty</Text>
              </Col> 
              </Row>
              </Grid>
    </View> 
    <VirtualizedList
          initialNumToRender={this.state.dataSource.length}
          windowSize={20}
          extraData={this.state}
          maxToRenderPerBatch={10} 
          data={this.state.dataSource}
          getItemCount={(data) => data.length}
          getItem={(data, index) => {
            return data[index];
          }}
          keyExtractor={(item, index) => {
            return index.toString();
          }}
          renderItem={({ item, index }) => {
            return (
            <TouchableOpacity activeOpacity={.6}   onPress={() => this.gotophysical(index)}>
            <Card style={{alignItems:'flex-start',width:'97%'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap'}}>
            <Grid>
            <Row>
              <Col style={{alignItems:'flex-start',width:"15%"}}>
              <Text style={{fontSize: 11,alignItems:"flex-start",color: '#000',}}>{item.pid}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:"25%"}}>
              <Text style={{fontSize: 11,alignItems:"flex-start",color: '#000',}}>{item.itemCode}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:"25%"}}>
              <Text style={{fontSize: 11,alignItems:"flex-start",color: '#000',}}>{item.entryCode}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:"35%"}}>
              <Text style={{fontSize: 11,alignSelf:'flex-end',color: '#000',}}>{item.qty}</Text>
              </Col> 
             </Row>    
             </Grid>  
             </CardItem>
           </Card>
           </TouchableOpacity>
            );
          }}
        />
   
    </ScrollView>
        )
      }
 };
 const styles = StyleSheet.create({
    textContent: {
        backgroundColor:'#36428a',
        fontSize: 12,
        padding:4,
        width:"98%",
        alignItems:'center',
        color: '#fff',
        fontWeight: 'bold'
      },
      textValue: {
        fontSize: 11,
        alignItems:"flex-start",
        color: '#000',
      },
      container: {
        flex: 1,
        flexDirection:'row',
        justifyContent: "center",
  
      },
      selectedTextHolder: {
        position: 'absolute',
        left: 0,
        right: 0,
        bottom: 0,
        padding: 15,
        backgroundColor: 'rgba(0,0,0,0.6)',
        justifyContent: 'center',
        alignItems: 'center'
      },
      selectedText: {
        fontSize: 18,
        color: 'white'
      },
      itemBlock: {
        flexDirection: 'row',
        paddingBottom: 5,
      },
      itemImage: {
        width: 50,
        height: 50,
        borderRadius: 25,
      },
      itemMeta: {
        marginLeft: 10,
        justifyContent: 'center',
      },
      itemName: {
        fontSize: 20,
      },
      itemLastMessage: {
        fontSize: 14,
        color: "#111",
      }
  });
  
  
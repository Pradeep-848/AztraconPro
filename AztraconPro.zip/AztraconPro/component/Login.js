import React, { Component } from "react";
import {
  StyleSheet,
  Text,
  View,
  Image,
  ImageBackground,
  Dimensions,
  Modal,
  BackHandler,
  ScrollView,
  TextInput,
  TouchableOpacity,
  StatusBar,
  LogBox,
  Alert,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { CheckBox, Icon } from "react-native-elements";
//import Icon from 'react-native-vector-icons/Ionicons.js';
import NetInfo from "@react-native-community/netinfo";
import Toast from "react-native-toast-message";
import axios from "axios";
import { Divider, Overlay, Button } from "react-native-elements";
import { Col, Grid, Row } from "react-native-easy-grid";
import * as Device from "expo-device";
import * as Network from "expo-network";
import { CustomButton } from "./custom-button.js";
import colors from "./res/colors";
import strings from "./res/strings";
import { DeviceType, getDeviceTypeAsync } from "expo-device";

//notification
//import * as Permissions from 'expo-permissions';
import * as Notifications from "expo-notifications";
// This refers to the function defined earlier in this guide, in Push Notifications Set Up

// Notifications.setNotificationHandler({
//   handleNotification: async () => ({
//     shouldShowAlert: true,
//     shouldPlaySound: false,
//     shouldSetBadge: false,
//   }),
// });

//update
import * as Updates from "expo-updates";

const screenWidth = Math.round(Dimensions.get("window").width);
const screenHeight = Math.round(Dimensions.get("window").height);

const ip = strings.values.commonvalues.ip;
const tokken = strings.values.commonvalues.tokken;
const ios_build_no = strings.values.commonvalues.ios_build_no;

const dark = colors.values.Colors.colorPrimaryDark;
const primary = colors.values.Colors.colorPrimary;
const white = colors.values.Colors.white;
const colorprimarydark = colors.values.Colors.colorPrimaryDark;
const darkblue = colors.values.Colors.colorPrimaryDark;

let PassUserID = "",
  PassFlag = "";

const deviceTypeMap = {
  [DeviceType.UNKNOWN]: "unknown",
  [DeviceType.PHONE]: "phone",
  [DeviceType.TABLET]: "tablet",
  [DeviceType.DESKTOP]: "desktop",
  [DeviceType.TV]: "tv",
};

var { height, width } = Dimensions.get("window");

export default class Login extends React.Component {
  static navigationOptions = ({ navigation }) => ({
    title: "AztraconPro",

    color: white,
    headerStyle: {
      color: primary,
      backgroundColor: primary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily: "Bold",
    },
    headerRight: (
      <TouchableOpacity
        style={{ paddingRight: 10 }}
        onPress={() => navigation.state.params.handlelogin()}
      >
        <Image
          style={{
            display: "none",
            height: 20,
            width: 20,
            alignSelf: "center",
            justifyContent: "center",
            resizeMode: "contain",
          }}
          source={require("./src/back.png")}
        />
      </TouchableOpacity>
    ),
  });

  constructor(props) {
    super(props);
    this.state = {
      handlelogin: "",
      username: "",
      password: "",
      showpass: false,
      remeber: false,
      isLoading: false,
      isVisible: false,
      isforgot: false,
      Object: "",
      passwordHidden: true,
      checkinternet: "",
      user: [],
      status: "",
      UserID: "",
      r: "",
      ForgotUser: "",
      forgotdata: [],
      code: "",
      otpcode: "",
      isotp: false,
      ischange: false,
      fpassword: "",
      hidePassword: true,
      //forgot
      isgetforgot: false,
      ForgotIQMA: "",
      fpuserid: "",
      fpusername: "",
      fpdesignation: "",
      fpiqamano: "",
      fpcount: "",
      ftest: "",
      fmail: "",
      iserror: false,
      message: "",
      from: "",
      isiqma: false,
      btndis: false,
      aFlag: "",
      devicetype: "",
      layout: {
        height: height,
        width: width,
      },
      //notification
      // notification: {},
    };
  }

  login = async () => {
    Alert.alert(
      "Exit",
      "Would you like to Exit ?",
      [
        {
          text: "Cancel",
          onPress: () => console.log("Cancel Pressed"),
          style: "cancel",
        },
        {
          text: "OK",
          onPress: () => {
            BackHandler.exitApp();
          },
        },
      ],
      { cancelable: false }
    );
  };

  componentDidMount() {
    LogBox.ignoreAllLogs();

    getDeviceTypeAsync().then((deviceType) => {
      this.setState({
        devicetype: deviceTypeMap[deviceType],
      });
    });

    this.setState({
      user: "",
    });

    this.props.navigation.setParams({
      handlelogin: this.login.bind(this),
    });

    AsyncStorage.getItem("UserID").then((value) =>
      this.setState({ username: value })
    );
    AsyncStorage.getItem("Password").then((value) =>
      this.setState({ password: value })
    );

    AsyncStorage.getItem("SaveLogin").then((value) => {
      if (value == "true") {
        this.setState({ remeber: true });
      } else {
        this.setState({ remeber: false });
      }
    });
    AsyncStorage.getItem("UserID").then((value) => {
      if (value !== null) {
        this.setState({ UserID: value });
      } else {
        this.setState({ UserID: "" });
      }
    });

    NetInfo.fetch().then((state) => {
      if (state.isConnected) {
        this.setState({ checkinternet: true });
      } else {
        this.setState({ checkinternet: false });
      }
    });

    //   console.log('here')
    // this.registerForPushNotificationsAsync();

    // Notifications.addNotificationReceivedListener(this._handleNotification);

    // Notifications.addNotificationResponseReceivedListener(this._handleNotificationResponse);
  }

  registerForPushNotificationsAsync = async () => {
    let token;

    if (Device.isDevice) {
      const { status: existingStatus } =
        await Notifications.getPermissionsAsync();
      let finalStatus = existingStatus;

      if (existingStatus !== "granted") {
        const { status } = await Notifications.requestPermissionsAsync();
        finalStatus = status;
      }

      if (finalStatus !== "granted") {
        alert("Failed to get push token for push notification!");
        return;
      }

      token = (await Notifications.getExpoPushTokenAsync()).data;
      console.log(token);
      this.setState({ expoPushToken: token });
    } else {
      alert("Must use physical device for Push Notifications");
    }

    if (Platform.OS === "android") {
      Notifications.setNotificationChannelAsync("default", {
        name: "default",
        importance: Notifications.AndroidImportance.MAX,
        sound: true,
        vibrationPattern: [0, 250, 250, 250],
        lightColor: "#FF231F7C",
      });
    }

    return token;
  };

  // registerForPushNotificationsAsync = async () => {
  //   if (Device.isDevice) {

  //     const { status: existingStatus } = await Permissions.getAsync(Permissions.NOTIFICATIONS);
  //     let finalStatus = existingStatus;
  //     if (existingStatus !== 'granted') {
  //       const { status } = await Permissions.askAsync(Permissions.NOTIFICATIONS);
  //       finalStatus = status;
  //     }
  //     if (finalStatus !== 'granted') {
  //       alert('Failed to get push token for push notification!');
  //       return;
  //     }
  //     const token = await Notifications.getExpoPushTokenAsync();
  //     console.log(token);
  //     this.setState({ expoPushToken: token });
  //   } else {
  //     alert('Must use physical device for Push Notifications');
  //   }

  //   if (Platform.OS === 'android') {
  //     Notifications.createChannelAndroidAsync('default', {
  //       name: 'default',
  //       sound: true,
  //       priority: 'max',
  //       vibrate: [0, 250, 250, 250],
  //     });
  //   }
  // };

  _handleNotification = (notification) => {
    this.setState({ notification: notification });
  };

  _handleNotificationResponse = (response) => {
    console.log(response);
  };

  managePasswordVisibility = () => {
    this.setState({ hidePassword: !this.state.hidePassword });
  };

  static getCurrentUser() {
    return PassUserID;
  }

  static getAFlag() {
    return PassFlag;
  }

  updatepopup = async () => {
    Alert.alert(
      "Info",
      "App Need Update Please Go And Update ?",
      [
        {
          text: "Cancel",
          onPress: () => console.log("Cancel Pressed"),
          style: "cancel",
        },
        { text: "OK", onPress: () => console.log("Ok Pressed") },
      ],
      { cancelable: false }
    );
  };

  checkAppAccess(data) {
    let loginstatus = "";

    const {
      Name,
      Designation,
      RCenter,
      Department,
      DeptHOD,
      JobPosition,
      AppAccess,
      IsSupervisor,
      Email,
      UType,
    } = data;

    //Customer
    if (UType == "C") {
      // this.props.navigation.replace('HomeCustomerActivity',{UserID:this.state.username,Name:Name,
      //   Designation:Designation,Company:Department,Email:Email})
    } else {
      //User
      if (Department == "WHS" && DeptHOD == this.state.username) {
        loginstatus = "Y";
        this.props.navigation.replace("HomeActivity", {
          username: Name,
          Designation: Designation,
          USER: this.state.username,
          RCenter: RCenter,
          Department: Department,
          DT: this.state.devicetype,
        });
      } else {
        if (
          (String(JobPosition).trim() == "5" ||
            String(JobPosition).trim() == "3" ||
            String(JobPosition).trim() == "4") &&
          AppAccess != "Y"
        ) {
          loginstatus = "Y";

          this.props.navigation.replace("HomeActivity", {
            username: Name,
            Designation: Designation,
            USER: this.state.username,
            RCenter: RCenter,
            Department: Department,
            DT: this.state.devicetype,
          });
        } else {
          if (AppAccess == "Y") {
            if (IsSupervisor != "Y") {
              loginstatus = "Y";

              //123
              this.props.navigation.replace("HomeActivity", {
                username: Name,
                Designation: Designation,
                USER: this.state.username,
                RCenter: RCenter,
                Department: Department,
                DT: this.state.devicetype,
              });
            } else if (IsSupervisor == "Y" && Department == "PRD") {
              loginstatus = "Y";
              this.props.navigation.replace("HomeActivity", {
                username: Name,
                Designation: Designation,
                USER: this.state.username,
                RCenter: RCenter,
                Department: Department,
                DT: this.state.devicetype,
              });
            } else {
              loginstatus = "N";
            }
          } else {
            loginstatus = "A";
          }
        }

        if (loginstatus == "N") {
          Toast.show({
            type: "error",
            text2: "Login Not Assigned!",
            visibilityTime: 2000,
            position: "bottom",
          });
          //this.refs.toast.showCenter('Login Not Assigned!')
        } else if (loginstatus == "A") {
          Toast.show({
            type: "error",
            text2: "App Access Not Provided!",
            visibilityTime: 2000,
            position: "bottom",
          });
          //.refs.toast.showCenter('App Access Not Provided!')
        } else {
          Toast.show({
            type: "success",
            text2: "Login Successfu",
            visibilityTime: 2000,
            position: "bottom",
          });
          //this.refs.toast.showCenter('Login Successful')
        }
      }
    }
  }

  async onLogin() {
    const { username, password } = this.state;

    const ip_Address = await Network.getIpAddressAsync();
    console.log("IP Address:", ip_Address);

    this.setState({
      user: "",
    });

    const config = {
      headers: {
        currentToken: tokken,
        oldToken: "",
        deviceInfo: Device.modelName + " " + Device.deviceName,
        deviceType: "I",
        deviceVer: ios_build_no,
      },
      params: {
        userid: username,
        password: password,
      },
    };

    if (username == null || username == "") {
      Toast.show({
        type: "error",
        text2: "Please enter Username",
        visibilityTime: 2000,
        position: "bottom",
      });
      //this.refs.toast.showCenter('Please enter Username');
    } else if (password == null || password == "") {
      Toast.show({
        type: "error",
        text2: "Please enter Password",
        visibilityTime: 2000,
        position: "bottom",
      });
      //this.refs.toast.showCenter('Please enter Password');
    } else {
      if (this.state.checkinternet) {
        this.setState({ isLoading: true });
        axios
          .get(ip + "/getUserInfoV3Ios", config)
          .then((response) =>
            this.setState({ user: response.data, isLoading: false }, () => {
              if (response.status == 200) {
                if (
                  this.state.user == undefined ||
                  this.state.user.length == 0 ||
                  this.state.user == null ||
                  this.state.user == ""
                ) {
                  Toast.show({
                    type: "info",
                    text2: "Invalid Credentials...Try Again..",
                    visibilityTime: 2000,
                    position: "bottom",
                  });
                  //this.refs.toast.showBottom('Invalid Credentials...Try Again..');
                } else {
                  if (this.state.remeber == true) {
                    AsyncStorage.setItem("UserID", this.state.username);
                    AsyncStorage.setItem("Password", this.state.password);
                  }

                  const {
                    Name,
                    Designation,
                    RCenter,
                    Department,
                    Flag,
                    AFlag,
                    Version,
                  } = this.state.user;

                  PassUserID = username;
                  PassFlag = AFlag;

                  AsyncStorage.setItem("AFlag", String(AFlag));

                  if (ios_build_no >= Version.toString()) {
                    this.checkAppAccess(this.state.user);
                  } else {
                    this.updatepopup();
                  }
                }
              }
            })
          )

          .catch((err) => {
            this.setState(
              {
                isLoading: false,
              },
              () => {
                let error = err;
                Toast.show({
                  type: "error",
                  text2: error.toString(),
                  visibilityTime: 2000,
                  position: "bottom",
                });
                //this.refs.toast.showBottom(error.toString())
                this.props.navigation.goBack();
              }
            );
          });
      } else {
        Toast.show({
          type: "info",
          text2: "No working Internet Available",
          visibilityTime: 2000,
          position: "bottom",
        });
        //this.refs.toast.showCenter('No working Internet Available');
      }
    }
  }

  ForgetClick = () => {
    this.setState({
      ForgotUser: "",
      fpuserid: "",
      fpusername: "",
      fpdesignation: "",
      fpiqamano: "",
      fpcount: "",
      ftest: "",
      isgetforgot: false,
      iserror: false,
      isiqma: true,
      isforgot: !this.state.isforgot,
      ForgotIQMA: "",
      btndis: false,
    });
  };

  changepwd() {
    const { fpassword } = this.state;

    if (fpassword.toString().length == 0) {
      Toast.show({
        type: "error",
        text2: "Please enter Password",
        visibilityTime: 2000,
        position: "bottom",
      });
      //this.refs.toast.showBottom("Please enter password")
    } else {
      const config = {
        headers: {
          currentToken: tokken,
          oldToken: "",
        },
        params: {
          userid: this.state.ForgotUser.toString(),
          pass: fpassword.toString(),
          from: this.state.from,
        },
      };

      this.setState({ isLoading: true });
      axios
        .get(ip + "/setPasswordIos", config)
        .then((response) =>
          this.setState({ isLoading: false }, () => {
            if (response.status == 200) {
              this.setState({ isLoading: false, ischange: false });
            }
          })
        )
        .catch((err) => {
          this.setState(
            {
              isLoading: false,
              ischange: false,
            },
            () => {
              let error = err;
              //this.refs.toast.showBottom(error.toString())
              this.props.navigation.goBack();
            }
          );
        });
    }
  }

  checkvaliduser() {
    const { ForgotUser } = this.state;

    if (ForgotUser == "") {
      this.setState({
        iserror: true,
        message: "Please enter User Id",
      });
    } else {
      const config = {
        headers: {
          currentToken: tokken,
        },
        params: {
          UserID: ForgotUser,
        },
      };

      if (ForgotUser == null || ForgotUser == "") {
        //this.refs.toast.showBottom('Please Enter UserID');
      } else {
        this.setState({ isLoading: true, forgotdata: "" });
        axios
          .get(ip + "/getForgetUserV1", config)
          .then((response) =>
            this.setState(
              { forgotdata: response.data, isLoading: false, iserror: false },
              () => {
                if (response.status == 200) {
                  if (
                    this.state.forgotdata == undefined ||
                    this.state.forgotdata.length == 0 ||
                    this.state.forgotdata == null ||
                    this.state.forgotdata == ""
                  ) {
                    this.setState({
                      isgetforgot: false,
                      message: "Invalid UserID or UserID Not Active",
                      iserror: true,
                    });
                  } else {
                    const {
                      UserID,
                      UserName,
                      Designation,
                      IqamaNo,
                      Count,
                      Test,
                      Mail,
                    } = this.state.forgotdata;
                    this.setState({
                      fpuserid: UserID,
                      fpusername: UserName,
                      fpdesignation: Designation,
                      fpiqamano: IqamaNo,
                      fpcount: Count,
                      ftest: Test,
                      fmail: Mail,
                      isgetforgot: true,
                    });
                  }
                }
              }
            )
          )
          .catch((err) => {
            this.setState({ isLoading: false }, () => {
              let error = err;
              //this.refs.toast.showBottom(error.toString())
              this.props.navigation.goBack();
            });
          });
      }
    }
  }

  sendMail() {
    const config = {
      headers: {
        currentToken: tokken,
      },
      params: {
        Mail: this.state.fmail,
        Pwd: this.state.ftest,
      },
    };

    this.setState({ isLoading: true });
    axios
      .get(ip + "/sendForgetMail", config)
      .then((response) =>
        this.setState({ isLoading: false, iserror: false }, () => {
          if (response.status == 200) {
            if (response.data == "1") {
              this.setState({
                isgetforgot: true,
                message: "Password Send To Mail Please Check Inbox",
                iserror: true,
              });
            } else {
              this.setState({
                isgetforgot: true,
                message: "Problem in Sending Mail Please Try Again Later",
                iserror: true,
              });
            }
          }
        })
      )
      .catch((err) => {
        this.setState({ isLoading: false }, () => {
          let error = err;
          //this.refs.toast.showBottom(error.toString())
          this.props.navigation.goBack();
        });
      });
  }

  checkForgot() {
    const {
      fpuserid,
      fpusername,
      fpdesignation,
      fpiqamano,
      fpcount,
      ftest,
      fmail,
    } = this.state;

    if (String(this.state.ForgotIQMA).length == 10) {
      if (String(this.state.ForgotIQMA) == String(fpiqamano)) {
        if (String(fmail) == "" || fmail.length == 0) {
          this.setState({
            btndis: true,
            iserror: true,
            message: "EmailID Not Found Please Contact Admin !!",
          });
        } else {
          this.setState(
            {
              btndis: true,
              iserror: false,
            },
            () => {
              this.sendMail();
            }
          );
        }
      } else {
        let count;
        count = parseInt(fpcount) - 1;

        this.setState({
          fpcount: count,
        });

        if (count >= 0) {
          if (count <= 3 && count > 0) {
            this.decreasecount();
            this.setState({
              iserror: true,
              message:
                "Invalid IQama..!! You have " + count + " more attempts left",
            });
          } else {
            this.decreasecount();
            this.setState({
              iserror: true,
              btndis: true,
              isiqma: false,
              message: "You have No More attempts left",
            });
          }
        } else {
          this.setState({
            iserror: true,
            btndis: true,
            isiqma: false,
            message: "You have No More attempts left",
          });
        }
      }
    } else {
      this.setState({
        iserror: true,
        message: "IQama Need 10 Numbers",
      });
    }
  }

  remeberme() {
    if (this.state.remeber) {
      this.setState({ remeber: false });
      AsyncStorage.setItem("UserID", "");
      AsyncStorage.setItem("Password", "");
      AsyncStorage.setItem("SaveLogin", "false");
    } else {
      this.setState({ remeber: true });
      AsyncStorage.setItem("UserID", this.state.username);
      AsyncStorage.setItem("Password", this.state.password);
      AsyncStorage.setItem("SaveLogin", "true");
    }
  }

  showpassword() {
    if (this.state.showpass) {
      this.setState({ showpass: false });
      this.setState({ passwordHidden: true });
    } else {
      this.setState({ showpass: true });
      this.setState({ passwordHidden: false });
    }
  }

  decreasecount() {
    const { fpuserid, fpcount } = this.state;

    const config = {
      headers: {
        currentToken: tokken,
        oldToken: "",
      },
      params: {
        userid: fpuserid,
        count: fpcount,
      },
    };

    this.setState({ isLoading: true });
    axios
      .get(ip + "/updatecount", config)
      .then((response) =>
        this.setState({ isLoading: false }, () => {
          if (response.status == 200) {
            this.setState({ isLoading: false });
          }
        })
      )
      .catch((err) => {
        this.setState(
          {
            isLoading: false,
          },
          () => {
            let error = err;
            //this.refs.toast.showBottom(error.toString())
            this.props.navigation.goBack();
          }
        );
      });
  }

  register() {
    this.props.navigation.navigate("RegisterActivity");
  }

  _onLayout = (event) => {
    this.setState({
      layout: {
        height: event.nativeEvent.layout.height,
        width: event.nativeEvent.layout.width,
      },
    });
  };

  render() {
    if (this.state.isLoading) {
      return (
        <Modal
          presentationStyle="fullScreen"
          statusBarTranslucent={true}
          transparent={false}
          supportedOrientations={["portrait", "landscape"]}
          visible={this.state.isLoading}
        >
          <View
            style={{ flex: 1, alignItems: "center", justifyContent: "center" }}
          >
            <Image
              useNativeDriver={true}
              style={{ width: 300, height: 200 }}
              source={require("./src/gears.gif")}
            />
          </View>
        </Modal>
      );
    }

    return (
      <View onLayout={this._onLayout} style={styles.container}>
        <ImageBackground
          source={require("./src/aztracon_bg.jpg")}
          style={{
            height: this.state.layout.height,
            width: this.state.layout.width,
          }}
        >
          <ScrollView
            contentContainerStyle={{
              alignItems: "center",
              alignSelf: "center",
              paddingBottom: 1,
            }}
            style={{ flex: 1 }}
          >
            <Image
              style={styles.image}
              source={require("./src/ic_aztracon.png")}
            />

            <View style={styles.tcenter}>
              <Text
                style={{
                  fontSize: 16,
                  color: dark,
                  fontFamily: "Bold",
                  paddingTop: "2%",
                  paddingBottom: "2%",
                }}
              >
                User ID
              </Text>

              <TextInput
                value={this.state.username}
                onChangeText={(username) => this.setState({ username })}
                placeholder={"User ID"}
                length={25}
                keyboardType="ascii-capable"
                style={styles.input}
                returnKeyType={"next"}
                ref="userid"
                onSubmitEditing={(event) => {
                  this.refs.pass.focus();
                }}
              />

              {/* <Icon name='close-circle' /> */}

              <Text
                style={{
                  fontSize: 16,
                  color: dark,
                  fontFamily: "Bold",
                  paddingTop: "2%",
                  paddingBottom: "2%",
                }}
              >
                Password
              </Text>

              <TextInput
                value={this.state.password}
                onChangeText={(password) => this.setState({ password })}
                placeholder={"Password"}
                length={20}
                secureTextEntry={this.state.passwordHidden}
                style={styles.input}
                ref="pass"
              />

              <View
                style={{
                  flex: 1,
                  flexDirection: "row",
                  alignItems: "center",
                  alignSelf: "center",
                }}
              >
                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    marginRight: 20,
                  }}
                >
                  <CheckBox
                    checked={this.state.showpass}
                    onPress={() => this.showpassword()}
                    checkedIcon={
                      <Icon
                        name="checkmark-circle"
                        type="ionicon"
                        size={25}
                        color={dark}
                      />
                    }
                    uncheckedIcon={
                      <Icon
                        name="ellipse-outline"
                        type="ionicon"
                        size={25}
                        color={dark}
                      />
                    }
                    containerStyle={{ padding: 0, margin: 0 }} // Remove padding/margin from the checkbox
                  />
                  <Text
                    style={{ fontFamily: "Regular" }}
                    onPress={() => this.showpassword()}
                  >
                    Show password
                  </Text>
                </View>

                {/* Remember Me Checkbox */}
                <View style={{ flexDirection: "row", alignItems: "center" }}>
                  <CheckBox
                    checked={this.state.remeber}
                    onPress={() => this.remeberme()}
                    checkedIcon={
                      <Icon
                        name="checkmark-circle"
                        type="ionicon"
                        size={25}
                        color={dark}
                      />
                    }
                    uncheckedIcon={
                      <Icon
                        name="ellipse-outline"
                        type="ionicon"
                        size={25}
                        color={dark}
                      />
                    }
                    containerStyle={{ padding: 0, margin: 0 }} // Remove padding/margin from the checkbox
                  />
                  <Text
                    style={{ fontFamily: "Regular" }}
                    onPress={() => this.remeberme()}
                  >
                    Remember me
                  </Text>
                </View>
              </View>
            </View>

            <View
              style={{
                flex: 1,
                flexDirection: "column",
                alignSelf: "center",
                paddingTop: "5%",
              }}
            >
              <CustomButton
                title="Login"
                onPress={() => this.onLogin()}
                style={{ backgroundColor: dark }}
                textStyle={{ fontSize: 13, fontFamily: "Bold" }}
              />

              <Text
                onPress={this.ForgetClick.bind(this)}
                style={{
                  fontSize: 15,
                  color: dark,
                  fontFamily: "ItalicBold",
                  paddingTop: "5%",
                }}
              >
                Forgot password ?
              </Text>

              <Text
                onPress={this.register.bind(this)}
                style={{
                  fontSize: 18,
                  fontFamily: "Bold",
                  color: dark,
                  textAlign: "center",
                }}
              ></Text>

              <Text
                style={{
                  fontSize: 12,
                  fontFamily: "Bold",
                  color: dark,
                  paddingTop: "12%",
                  textAlign: "center",
                }}
              >
                {ios_build_no}
              </Text>
            </View>
          </ScrollView>
        </ImageBackground>

        <Toast />

        <Overlay
          overlayStyle={{
            width: "90%",
            height: "35%",
            borderRadius: 15,
            backgroundColor: white,
          }}
          animationType="slide"
          isVisible={this.state.ischange}
          onBackdropPress={() => this.setState({ ischange: false })}
        >
          <ScrollView style={{ height: "20%" }}>
            <TouchableOpacity
              style={styles.headerback}
              activeOpacity={0.5}
              onPress={() => {
                this.setState({ ischange: !this.state.ischange });
              }}
            >
              <Grid>
                <Row>
                  <Col
                    style={{
                      width: "90%",
                      alignItems: "center",
                      alignSelf: "center",
                    }}
                  >
                    <Text
                      style={{
                        paddingLeft: "3%",
                        color: "#fff",
                        textDecorationStyle: "solid",
                        fontWeight: "bold",
                        alignSelf: "flex-start",
                      }}
                    >
                      Change Password
                    </Text>
                  </Col>

                  <Col
                    style={{
                      width: "10%",
                      alignItems: "center",
                      alignSelf: "center",
                    }}
                  >
                    <Image
                      source={require("./src/back.png")}
                      style={{ height: 22, width: 22 }}
                    />
                  </Col>
                </Row>
              </Grid>
            </TouchableOpacity>
          </ScrollView>
          <ScrollView style={{ height: "80%" }}>
            <Grid>
              <Row>
                <Text
                  style={{
                    fontSize: 16,
                    fontWeight: "bold",
                    color: darkblue,
                    paddingTop: "2%",
                    paddingBottom: "2%",
                  }}
                >
                  Password
                </Text>
              </Row>

              <Row>
                <Col style={{ width: "100%" }}>
                  <View style={styles.textBoxBtnHolder}>
                    <TextInput
                      underlineColorAndroid="transparent"
                      value={this.state.fpassword}
                      onChangeText={(fpassword) => this.setState({ fpassword })}
                      placeholder={"Password"}
                      length={10}
                      keyboardType={"default"}
                      returnKeyType={"done"}
                      secureTextEntry={this.state.hidePassword}
                      style={styles.inputDialog}
                    />
                    <TouchableOpacity
                      activeOpacity={0.8}
                      style={styles.visibilityBtn}
                      onPress={this.managePasswordVisibility}
                    >
                      <Image
                        source={
                          this.state.hidePassword
                            ? require("./src/hide.png")
                            : require("./src/view.png")
                        }
                        style={styles.btnImage}
                      />
                    </TouchableOpacity>
                  </View>
                </Col>
              </Row>

              <Row>
                <Col style={{ width: "100%" }}>
                  <CustomButton
                    title="Submit"
                    onPress={() => this.changepwd()}
                    style={{ backgroundColor: dark }}
                    textStyle={{ fontSize: 13, fontWeight: "bold" }}
                  />
                </Col>
              </Row>
            </Grid>
          </ScrollView>
        </Overlay>

        <Modal
          animationType={"slide"}
          transparent={true}
          visible={this.state.isforgot}
          onRequestClose={() => {
            console.log("Modal has been closed.");
          }}
        >
          {/*All views of Modal*/}
          <View style={styles.modal}>
            <TouchableOpacity
              style={styles.headerback}
              activeOpacity={0.5}
              onPress={() => {
                this.setState({ isforgot: !this.state.isforgot });
              }}
            >
              <Grid>
                <Row>
                  <Col
                    style={{
                      width: "90%",
                      alignItems: "center",
                      alignSelf: "center",
                    }}
                  >
                    <Text
                      style={{
                        paddingLeft: "3%",
                        color: "#fff",
                        textDecorationStyle: "solid",
                        fontFamily: "Bold",
                        alignSelf: "flex-start",
                      }}
                    >
                      Forgot Password
                    </Text>
                  </Col>

                  <Col
                    style={{
                      width: "10%",
                      alignItems: "center",
                      alignSelf: "center",
                    }}
                  >
                    <Image
                      source={require("./src/back.png")}
                      style={{ height: 22, width: 22 }}
                    />
                  </Col>
                </Row>
              </Grid>
            </TouchableOpacity>

            <ScrollView>
              <Grid style={{ width: "97%" }}>
                <Row>
                  <Text
                    style={{
                      fontSize: 16,
                      fontFamily: "Bold",
                      color: dark,
                      paddingTop: "2%",
                      paddingBottom: "2%",
                    }}
                  >
                    User ID
                  </Text>
                </Row>

                <Row>
                  <Col style={{ width: "100%" }}>
                    <TextInput
                      value={this.state.ForgotUser}
                      onChangeText={(ForgotUser) =>
                        this.setState({ ForgotUser })
                      }
                      placeholder={"Enter UserID"}
                      maxLength={5}
                      editable={this.state.isgetforgot ? false : true}
                      keyboardType="numeric"
                      style={styles.inputDialog}
                      returnKeyType={"done"}
                      ref="fuserid"
                    />
                  </Col>
                </Row>

                <Row
                  style={{ display: this.state.isgetforgot ? "flex" : "none" }}
                >
                  <Text
                    style={{
                      fontSize: 16,
                      fontFamily: "Bold",
                      color: dark,
                      paddingTop: "2%",
                      paddingBottom: "2%",
                    }}
                  >
                    Name
                  </Text>
                </Row>

                <Row
                  style={{ display: this.state.isgetforgot ? "flex" : "none" }}
                >
                  <Col style={{ width: "100%" }}>
                    <TextInput
                      value={this.state.fpusername}
                      placeholder={"Enter Name"}
                      editable={false}
                      style={styles.inputDialog}
                      returnKeyType={"done"}
                      ref="fname"
                    />
                  </Col>
                </Row>

                <Row
                  style={{ display: this.state.isgetforgot ? "flex" : "none" }}
                >
                  <Text
                    style={{
                      fontSize: 16,
                      fontFamily: "Bold",
                      color: dark,
                      paddingTop: "2%",
                      paddingBottom: "2%",
                    }}
                  >
                    Designation
                  </Text>
                </Row>

                <Row
                  style={{ display: this.state.isgetforgot ? "flex" : "none" }}
                >
                  <Col style={{ width: "100%" }}>
                    <TextInput
                      value={this.state.fpdesignation}
                      placeholder={"Enter Designation"}
                      editable={false}
                      style={styles.inputDialog}
                      returnKeyType={"done"}
                      ref="fuserid"
                    />
                  </Col>
                </Row>

                <Row
                  style={{ display: this.state.isgetforgot ? "flex" : "none" }}
                >
                  <Text
                    style={{
                      fontSize: 16,
                      fontFamily: "Bold",
                      color: dark,
                      paddingTop: "2%",
                      paddingBottom: "2%",
                    }}
                  >
                    Enter IQama / National ID
                  </Text>
                </Row>

                <Row
                  style={{ display: this.state.isgetforgot ? "flex" : "none" }}
                >
                  <Col style={{ width: "100%" }}>
                    <TextInput
                      value={this.state.ForgotIQMA}
                      onChangeText={(ForgotIQMA) =>
                        this.setState({ ForgotIQMA })
                      }
                      placeholder={"Enter IQama / National ID"}
                      maxLength={10}
                      editable={this.state.isiqma ? true : false}
                      focusable={true}
                      keyboardType="numeric"
                      style={styles.inputDialog}
                      returnKeyType={"done"}
                      ref="fqma"
                    />
                  </Col>
                </Row>

                <Row style={{ display: this.state.iserror ? "flex" : "none" }}>
                  <Col style={{ width: "100%" }}>
                    <Text
                      style={{
                        fontSize: 16,
                        fontFamily: "Bold",
                        color: dark,
                        paddingTop: "1%",
                        paddingBottom: "1%",
                        textAlign: "center",
                      }}
                    >
                      {this.state.message}
                    </Text>
                  </Col>
                </Row>

                <Row>
                  <Col
                    style={{
                      alignItems: "center",
                      width: "50%",
                      display: this.state.isgetforgot ? "none" : "flex",
                    }}
                  >
                    <Button
                      onPress={() => this.checkvaliduser()}
                      raised={true}
                      titleStyle={{
                        fontSize: 15,
                        textAlign: "center",
                        fontFamily: "Bold",
                      }}
                      buttonStyle={{
                        flex: 1,
                        borderRadius: 6,
                        width: 120,
                        height: 45,
                        backgroundColor: darkblue,
                      }}
                      title=" Next "
                    />
                  </Col>
                  <Col
                    style={{
                      alignItems: "center",
                      width: "50%",
                      display: this.state.isgetforgot ? "flex" : "none",
                    }}
                  >
                    <Button
                      onPress={() => this.checkForgot()}
                      raised={true}
                      disabled={this.state.btndis}
                      disabledStyle={{ display: "none" }}
                      titleStyle={{
                        fontSize: 15,
                        textAlign: "center",
                        fontFamily: "Bold",
                      }}
                      buttonStyle={{
                        flex: 1,
                        borderRadius: 6,
                        width: 120,
                        height: 45,
                        backgroundColor: darkblue,
                      }}
                      title=" Finish "
                    />
                  </Col>
                  <Col style={{ alignItems: "center", width: "50%" }}>
                    <Button
                      onPress={() =>
                        this.setState({ isforgot: !this.state.isforgot })
                      }
                      raised={true}
                      titleStyle={{
                        fontSize: 15,
                        textAlign: "center",
                        fontFamily: "Bold",
                      }}
                      buttonStyle={{
                        flex: 1,
                        borderRadius: 6,
                        width: 120,
                        height: 45,
                        backgroundColor: darkblue,
                      }}
                      title=" Cancel "
                    />
                  </Col>
                </Row>
              </Grid>
            </ScrollView>
          </View>
        </Modal>

        <StatusBar
          animationType={"slide"}
          animated={true}
          backgroundColor={primary}
        />
      </View>
    );
  }
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
  },
  image: {
    marginTop: 30,
    width: 100,
    height: 150,
    resizeMode: "stretch",
    justifyContent: "center",
  },

  tcenter: {
    flex: 1,
    marginTop: "4%",
  },
  tbutton: {
    height: 50,
  },

  input: {
    maxHeight: 100,
    borderColor: dark,
    borderWidth: 1,
    padding: 10,
    width: 320,
    marginBottom: 10,
    borderRadius: 5,
    fontFamily: "Regular",
  },
  inputDialog: {
    maxHeight: 100,
    borderColor: dark,
    borderWidth: 1,
    padding: 10,
    marginBottom: 10,
    borderRadius: 5,
    fontFamily: "Regular",
  },
  inputOTP: {
    borderColor: dark,
    borderWidth: 1,
    padding: 10,
    marginBottom: 10,
    borderRadius: 5,
    justifyContent: "center",
    alignItems: "center",
    alignSelf: "center",
  },
  imageStyle: {
    width: screenWidth,
    height: screenHeight,
    justifyContent: "center",
    alignItems: "center",
  },
  headerback: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: primary,
    borderWidth: 0.5,
    borderColor: white,
    height: 40,
    width: "100%",
    borderRadius: 5,
  },
  visibilityBtn: {
    position: "absolute",
    right: 3,
    height: 40,
    width: 35,
    padding: 5,
  },

  textBoxBtnHolder: {
    position: "relative",
    alignSelf: "stretch",
    justifyContent: "center",
  },

  textBox: {
    fontSize: 18,
    alignSelf: "stretch",
    height: 50,
    paddingRight: 45,
    paddingLeft: 8,
    borderWidth: 1,
    paddingVertical: 0,
    borderColor: colorprimarydark,
    borderRadius: 5,
  },

  btnImage: {
    resizeMode: "contain",
    height: "100%",
    width: "100%",
  },
  modal: {
    flex: 1,
    backgroundColor: white,
    height: "auto",
    position: "absolute",
    bottom: 0,
    width: "98%",
    alignSelf: "center",
  },
  headerback: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: primary,
    borderWidth: 0.5,
    borderColor: white,
    height: 40,
    width: "100%",
    borderRadius: 5,
  },
});

{
  /* <View
style={{
  flexDirection: "row",
  alignItems: "center",
  marginRight: 20,
}}
>
<CheckBox
  checked={this.state.showpass}
  onPress={() => this.showpassword()}
  checkedIcon={
    <Icon
      name="checkmark-circle"
      type="ionicon"
      size={25}
      color={dark}
    />
  }
  uncheckedIcon={
    <Icon
      name="ellipse-outline"
      type="ionicon"
      size={25}
      color={dark}
    />
  }
  containerStyle={{ padding: 0, margin: 0 }} // Remove padding/margin from the checkbox
/>
<Text
  style={{ fontFamily: "Regular" }}
  onPress={() => this.showpassword()}
>
  Show password
</Text>
</View>


<View style={{ flexDirection: "row", alignItems: "center" }}>
<CheckBox
  checked={this.state.remeber}
  onPress={() => this.remeberme()}
  checkedIcon={
    <Icon
      name="checkmark-circle"
      type="ionicon"
      size={25}
      color={dark}
    />
  }
  uncheckedIcon={
    <Icon
      name="ellipse-outline"
      type="ionicon"
      size={25}
      color={dark}
    />
  }
  containerStyle={{ padding: 0, margin: 0 }} // Remove padding/margin from the checkbox
/>
<Text
  style={{ fontFamily: "Regular" }}
  onPress={() => this.remeberme()}
>
  Remember me
</Text>
</View> */
}

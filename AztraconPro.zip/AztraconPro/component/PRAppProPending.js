import React,{ Component }  from 'react';
import {ScrollView,StyleSheet,Image,View,Modal,FlatList,Text,TouchableOpacity,Alert} from 'react-native';
import { Col, Grid,Row } from 'react-native-easy-grid';
import axios from 'axios';
import {Card,CardItem} from 'native-base';
import Toast from 'react-native-whc-toast'
import strings from './res/strings'
import color from './res/colors'
import { NavigationActions, StackActions } from 'react-navigation';
import {logouttask} from './class/logout';

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const lightblue=color.values.Colors.lightblue;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

 export default class PRAppProPending extends React.Component {
  static navigationOptions = ({ navigation }) => ({ 
    title: "Approval Pending",
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor:white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
      USER:'',
      isLoading: false, 
      dataSource:[],
      handlelogin:'',
    };

}


login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
        this.props.navigation.dispatch(resetAction);
      } },
    ],
    {cancelable: false},
  );
 
}

getPRlist=()=>{
    const config = {
        headers: {   
        'currentToken':tokken,
      },
        params: {
        approver:this.state.USER,
        }
        
      };
 this.setState({isLoading:true})
  axios.get(ip+'/getPRListAll', config)
    .then(response => this.setState({dataSource:response.data},() => {if(response.status==200){
     this.setState({isLoading:false}); }}))
     .catch(err => 
      {
        this.setState({
          isLoading:false
        },()=>{
         let error=err
         
         this.refs.toast.showBottom(error.toString())
  
         setTimeout(
          () => { 
            this.props.navigation.goBack();
           },
          2000
        )
        })
      }
      );
}
move=(PRNO,SeqNo,Atype)=>{

    var prno=PRNO;
    var seqno=SeqNo;
    var atype=Atype;
    var USER=this.state.USER;

    if(atype==='Project'){
        this.props.navigation.navigate('PRAppProActivity',{PRNo:prno,SeqNo:seqno,UserID:USER});
    }else{
        this.props.navigation.navigate('PRAppGenActivity',{PRNo:prno,SeqNo:seqno,UserID:USER});
    }  
}

componentDidMount(){


  this.setState({
    isLoading:true
  })

  console.disableYellowBox = true;

 const { navigation } = this.props;


 this.focusListener = navigation.addListener("didFocus", () => {


  this.setState({
    USER:this.props.navigation.getParam('UserID', '')
  },()=>{
    this.props.navigation.setParams({
      handlelogin: this.login.bind(this),
      });
      this.getPRlist();
  })
})


}
  render() {
    if (this.state.isLoading) {
      return (
        <Modal
        transparent={false}
        supportedOrientations={['portrait', 'landscape']}
        visible={this.state.isLoading}
        >
         <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
          style={{width: 300, height: 200}}
          source={require('./src/gears.gif')}  />
          </View>     
        </Modal>
      )
  }
    return (
 <ScrollView style={{backgroundColor:lightblue}}>
 <View style={{ flex: 1,paddingTop:'2%',alignItems:'center',width:"98%",alignSelf:'center'}}>
  <Grid style={{backgroundColor:colorprimary,padding:5,borderRadius:4}}>
             <Row>
              <Col style={{alignItems:'flex-start',width:"25%"}}>
              <Text style={styles.textContent}>Category</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:"25%"}}>
              <Text style={styles.textContent}>PR No</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:"50%"}}>
              <Text style={styles.textContent}>PR Type</Text>
              </Col> 
             </Row>
             </Grid>
    </View> 
    <FlatList
       data={ this.state.dataSource }
       initialNumToRender={this.state.dataSource.length}
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
           paddingLeft:5,paddingRight:5,paddingTop:8,paddingBottom:8}}>
            <Grid  onPress={this.move.bind(this,item.A,item.C,item.E)}>
              <Col style={{alignItems:'flex-start',width:'25%'}}>
              <Text style={{fontSize:13,fontFamily:'Bold'}}>{item.E}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'25%'}}>
              <Text style={{fontSize:13,fontFamily:'Regular'}}>{item.A}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'50%'}}>
              <Text style={{fontSize:13,fontFamily:'Regular'}}>{item.F}</Text>
              </Col> 
            </Grid>  
             </CardItem>
           </Card>
        }
             
       keyExtractor={(item, index) => index.toString()} 
      />
   
   <Toast ref="toast"/>
   
   </ScrollView>
        )
      }
 };
 const styles = StyleSheet.create({
    textContent: {
        fontSize: 13,
        color: '#fff',
        fontFamily:'Bold'
      },
  });
  
  
  
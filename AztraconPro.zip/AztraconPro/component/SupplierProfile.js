import React,{ Component }  from 'react';
import {ScrollView,Modal,StyleSheet,Text,View,Image,TouchableOpacity,
  Alert,ImageBackground,Dimensions,ActivityIndicator,ActivityIndicatorIOSProps } from 'react-native';
import { Col, Grid,Row} from 'react-native-easy-grid';
import Toast from 'react-native-whc-toast'
import axios from 'axios';
import {Card,CardItem} from 'native-base';
import { NavigationActions, StackActions } from 'react-navigation';
import {logouttask} from './class/logout';
import strings from './res/strings';
import color from './res/colors';

const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const dark=color.values.Colors.colorPrimaryDark;
const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const black=color.values.Colors.black;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

 export default class SupplierProfile extends React.Component {
  static navigationOptions = ({ navigation }) => ({ 
    title: "Supplier Profile",
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor:white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false, 
      data:'',
      handlelogin:'',
      UserID:'',SupID:'',SupName:'',add1:'',add2:'',add3:'',add4:'',
      cat:'',country:'',currency:'',payterm:'',email:'',mobile:'',fax:'',status:''
    };

}

login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
      this.props.navigation.dispatch(resetAction);
} },
    ],
    {cancelable: false},
  );
 
}
getProfile=()=>{
  const config = {
    headers: {   
    'currentToken':tokken,
  },
    params: {
    supid:this.state.SupID,
    }
    
  };

  this.setState({isLoading:true})
  axios.get(ip+'/getSupProfile', config)
  .then(response => this.setState({ data:response.data},() => {if(response.status==200){
  const {add1,add2,add3,add4,cat,country,currency,payterm,email,mobile,fax,status} = this.state.data;
   this.setState({
       add1:add1,
       add2:add2,
       add3:add3,
       add4:add4,
       cat:cat,
       country:country,
       currency:currency,
       payterm:payterm,
       email:email,
       mobile:mobile,
       fax:fax,
       status:status,
       isLoading:false
    });
  }}))
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
}



componentDidMount(){
  

  this.setState({
    isLoading:true
  })

  console.disableYellowBox = true;

 const { navigation } = this.props;


 this.focusListener = navigation.addListener("didFocus", () => {


  this.setState({
    UserID:this.props.navigation.getParam('UserID', ''),
    SupID:this.props.navigation.getParam('SupID', ''),
    SupName:this.props.navigation.getParam('SupName', '')
 },()=>{
      this.props.navigation.setParams({
       handlelogin: this.login.bind(this)
       });
  this.getProfile();

})


});

//   console.disableYellowBox = true;

// this.props.navigation.setParams({
//   handlelogin: this.login.bind(this)
//   });

//    this.setState({
//        UserID:this.props.navigation.getParam('UserID', ''),
//        SupID:this.props.navigation.getParam('SupID', ''),
//        SupName:this.props.navigation.getParam('SupName', '')
//     },()=>{this.getProfile();})
}
  render() {
    if (this.state.isLoading) {
      return (
       /*  <Modal transparent={true}>
        <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
        <ActivityIndicator size={'large'} animating={true} color={colorprimary} />
        </View>
       </Modal> */

         <Modal  supportedOrientations={['portrait', 'landscape']}>
          <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
           <Image
           useNativeDriver={true} //option 1
           style={{width: 300, height: 200}}
           source={require('./src/gears.gif')}  />
           </View>     
         </Modal> 

       /*  <Modal
        transparent={false}
        visible={this.state.isLoading}
        >
         <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
          useNativeDriver={true} //option 1
          style={{width: 300, height: 200}}
          source={require('./src/gears.gif')}  />
          </View>     
        </Modal> */
      )
  }
    return (

    
      <ImageBackground 
      source={require('./src/aztracon_bg.jpg')}
      style = {styles.imageStyle} >
     
    <ScrollView>
    <Text style={styles.textContent}>
              Profile Details
    </Text>

    <View style={{flexDirection: 'row',width:'98%',alignSelf:'center'}}>
     <View style={{backgroundColor: dark, height: 2, flex: 1, alignSelf: 'center'}} />
     <View style={{backgroundColor: dark, height: 2, flex: 1, alignSelf: 'center'}} />
     </View>

      <Text style={styles.titleText}>
          {this.state.SupID.toString().trim()+" - "+this.state.SupName}
      </Text>
   
      <View style={{borderBottomColor:'#36428a',borderBottomWidth: 1.5,height:5,width:'98%',alignSelf:'center'}}/>

        <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle} >Address1</Text>
          </Col> 
          <Col>
          <Text style={{fontSize:14,fontFamily:'Bold'}}>{this.state.add1}</Text>
          </Col> 
        </Grid>
      </View>
      <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle}>Address2</Text>
          </Col> 
          <Col>
          <Text style={{fontSize:14,fontFamily:'Bold'}}>{this.state.add2}</Text>
          </Col> 
        </Grid>
      </View>
      <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle}>Address3</Text>
          </Col> 
          <Col>
          <Text style={{fontSize:14,fontFamily:'Bold'}}>{this.state.add3}</Text>
          </Col> 
        </Grid>
      </View>
      <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle}>Address4</Text>
          </Col> 
          <Col>
          <Text style={{fontSize:14,fontFamily:'Bold'}}>{this.state.add4}</Text>
          </Col> 
        </Grid>
      </View>
      <View style={{borderBottomColor:'#36428a',borderBottomWidth: 1,paddingTop:2}}/>

      <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle}>Category</Text>
          </Col> 
          <Col>
          <Text style={{fontSize:14,fontFamily:'Bold'}}>{this.state.cat}</Text>
          </Col> 
        </Grid>
      </View>
      <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle}>Country</Text>
          </Col> 
          <Col>
          <Text style={{fontSize:14,fontFamily:'Bold'}}>{this.state.country}</Text>
          </Col> 
        </Grid>
      </View>
      <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle}>currency</Text>
          </Col> 
          <Col>
          <Text style={{fontSize:14,fontFamily:'Bold'}}>{this.state.currency}</Text>
          </Col> 
        </Grid>
      </View>
      <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle}>Pay Terms</Text>
          </Col> 
          <Col>
          <Text style={{fontSize:14,fontFamily:'Bold'}}>{this.state.payterm}</Text>
          </Col> 
        </Grid>
      </View>
      <View style={styles.b}>
        <Grid>
          <Col style={styles.C}>
          <Text style={styles.tittle}>Status</Text>
          </Col> 
          <Col>
          <Text style={{fontSize:14,fontFamily:'Bold'}}>{this.state.status}</Text>
          </Col> 
        </Grid>
      </View>
      <View style={{borderBottomColor:'#36428a',borderBottomWidth: 1.5,height:5,width:'98%',alignSelf:'center'}}/>

      <View style={styles.tcenter}>
      <Text style={{textAlign:'center',fontSize:15,paddingTop:2,fontFamily:'Bold'}}>{this.state.email}</Text>
      <Text style={{textAlign:'center',fontSize:15,paddingTop:2,fontFamily:'Bold'}}>{this.state.mobile}</Text>
       <Text style={{textAlign:'center',fontSize:15,paddingTop:2,fontFamily:'Bold'}}>{this.state.fax}</Text>

      </View>
      <View style={{borderBottomColor:'#36428a',borderBottomWidth: 2,height:5,width:'98%',alignSelf:'center'}}/>
      <Toast ref="toast"/>

      
    </ScrollView>

     </ImageBackground>

        )
      }
 };
 const styles = StyleSheet.create({
  imageStyle:{
    width: screenWidth, 
    height: screenHeight, 
   },
    container: {
      flex: 1,
      alignItems: 'stretch'
    },
    tcenter: {
      flex: 1,
      justifyContent:'flex-start',
      flexDirection: 'column',
      paddingLeft:10,
    },
    content: {
        flex:1,
        flexDirection: 'column',
      },
    image: {
      width: 50,
      height: 50,
      marginTop:5,
    },
    imagebutton: {
      width:80,
      height: 80,
      marginTop:3,
     justifyContent:"center",
     alignItems:"center"
      
    },
    textContent: {
      backgroundColor:'#fff',
      fontSize: 18,
      padding:8,
      textAlign:'center',
      color: '#36428a',
      fontFamily: 'Bold',
      textShadowColor: 'rgba(0, 0, 0, 0.75)',
      textShadowOffset: {width: -1, height: 1},
      textShadowRadius: 10
    },
    textHead: {
        backgroundColor:'#2452b2',
        fontSize: 15,
        paddingTop:3,
        padding:4,
        textAlign:'center',
        color: '#fff',
        fontFamily: 'Bold',
      },
    imagetext: {
      fontSize: 12,
      color: '#A0A0A0',
    },
    b: {
      width:'97%',
      alignSelf:'center',
      flex: 1,
      alignItems: 'center',
      justifyContent: 'center',
      paddingTop:5,
    },
    Head: {
        flex: 1,
        paddingTop:5,
      },

   tittle:{
    color:'#36428a',
    fontFamily: 'Bold',
    fontSize:14,
    paddingLeft:4
   },
   C:{
    alignItems:"flex-start",
    width:150
   },
   titleText: {
    flex:1,
    alignSelf:'center',
    flexWrap:'wrap',
    color:colorprimary,
    backgroundColor:white,
    fontFamily: 'Bold',
    fontSize:14,
    padding:5
  },

  });
  
  
  
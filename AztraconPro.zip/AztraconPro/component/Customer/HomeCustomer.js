import React,{ Component }  from 'react';
import {StyleSheet,TouchableOpacity,Alert,Text,View,Image,FlatList,ImageBackground,TextInput,ScrollView} from 'react-native';
import { Col, Grid,Row } from 'react-native-easy-grid';
import { NavigationActions, StackActions } from 'react-navigation';
import color from '../res/colors'
import {logouttask} from '../class/logout';
import { Card,CardItem } from 'native-base';

const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const greydark=color.values.Colors.greydark;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class HomeCustomer extends React.Component {
   static navigationOptions = ({ navigation }) => ({ 
    title: "Inspection",
    headerStyle: {
      backgroundColor: colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('../src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  
  constructor(props) {
    super(props);
    this.state = {
      UserID:'',
      RCenter:'',
      Name:'',
      Desig:'',
      handlelogin:'',
      MenudataProduction:[
        {
          "A": "Inspection Request",
          "B": require('../src/ic_ins.png'),
          "C": "InspectionRequestActivity",
        },
        {
          "A": "Stage Inspection Request",
          "B": require('../src/ic_ins_st.png'),
          "C": "InspectionRequestSTActivity",
        },
        {
          "A": "Nozzle Inspection Request",
          "B": require('../src/ic_ins_noz.png'),
          "C": "InspectionRequestNozActivity",
        },
        {
          "A": "Inspection Request RT",
          "B": require('../src/ic_ins_rt.png'),
          "C": "InspectionRequestRTActivity",
        },
      ],
    };
}
login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
        this.props.navigation.dispatch(resetAction);
      } },
    ],
    {cancelable: false},
  );
 
}

gotonextpage=(index)=>{

  const id=index

  const {C}=this.state.MenudataProduction[id]
  
  if(C=='undefined' || C==null || C.length==0){
    this.refs.toast.showBottom("This Feature Update Soon")
  }else{
    this.props.navigation.navigate(C,{
        UserID:this.state.UserID,
        RCenter:this.state.RCenter
  });

}

}

componentDidMount(){

console.disableYellowBox = true;

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
  this.setState({UserID:this.props.navigation.getParam('UserID', '')})
  this.setState({RCenter:this.props.navigation.getParam('RCenter', '')})
  this.setState({Name:this.props.navigation.getParam('Name', '')})
  this.setState({Desig:this.props.navigation.getParam('Designation', '')})
}

render() {
return (
<ImageBackground   source={require('../src/aztracon_bg.jpg')} style={{width: '100%', height: '100%'}}>
<View style={{flex:1}}>
<ScrollView style={{height:'100%'}}> 
<Grid style={{paddingTop:'2%'}}>
<Row style={{backgroundColor:colorprimary,padding:5,width:'97%',alignSelf:'center',borderRadius:4}}>
  <Text style={{color:white,fontFamily:'Bold',fontSize:13}}>Production</Text>
  </Row>
  </Grid>
<FlatList
       data={ this.state.MenudataProduction }
       renderItem={({item,index}) =>
     
       <Grid style={{flex: 1 / 3,paddingTop:10}}>
          <Col style={{alignItems:'center',width:'100%',alignSelf:'center'}}>
          <TouchableOpacity activeOpacity = { .5 } onPress={() => this.gotonextpage(index)}>
           <Card  style={{padding: 10, margin: 10,  borderRadius: 10,}}> 
         
            <Image  style={styles.imagebutton}
            source={item.B} />
         
            </Card> 
            </TouchableOpacity>

          <Text numberOfLines={1} 
          style={{alignSelf:'center',fontSize:12,fontFamily:'Bold',}}>
            {item.A}</Text>
     
          </Col> 
       </Grid>
      
      }
       numColumns={3}
       keyExtractor={(item, index) => index}
      />

      </ScrollView>
      </View>
      </ImageBackground>
    )
  }
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'stretch'
  },
  titleText: {
    padding:5,
    fontSize: 12,
    fontFamily:'Bold',
    color:colorprimary,
  },
  image: {
    width: 40,
    height: 40,
    marginTop:5,
    marginRight:10,
  },
  imagebutton: {
    width:60,
    height: 85,
    marginTop:3,
    resizeMode: 'contain' ,
   justifyContent:"center",
   alignItems:"center",
   alignSelf:'center'
  },
  textContent: {
    backgroundColor:'#36428a',
    fontSize: 12,
    padding:4,
    marginLeft:10,
    marginRight:10,
    color: '#fff',
    fontWeight: 'bold'
  },
  imagetext: {
    fontSize: 12,
    color: '#A0A0A0',
  },
  b: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop:10,
  },
  i: {
    paddingTop:10,
  },
});






import React,{ Component }  from 'react';
import {ScrollView,StyleSheet,Text,View,Dimensions,Modal,FlatList,Image,TouchableOpacity,Alert} from 'react-native';
import { Col, Grid, Row } from 'react-native-easy-grid';
import axios from 'axios';
import {SearchBar} from 'react-native-elements'
import { NavigationActions, StackActions } from 'react-navigation';
import {Card,CardItem} from 'native-base';
import Toast from 'react-native-whc-toast'
import {logouttask} from './class/logout';
import strings from './res/strings'
import color from './res/colors'

const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;
const lightblue=color.values.Colors.lightblue;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

 export default class AccountsReceivable extends React.Component {
  static navigationOptions = ({ navigation }) => ({ 
    title: "Accounts Receivable",
    color:white,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false, 
      dataSource:'',
      tot_ccb :'',
      UserID:'',
      handlelogin:'',
    };
    this.arrayholder = [] ;
}
login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
      this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}

format(x) {
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

gotocustomer=(index)=>{
  const id=index

  const {A,B}=this.state.dataSource[id]

  this.props.navigation.navigate('CustomerLedgerActivity',{
    CusID:A,
    CusName:B,
    UserID:this.state.UserID,
  });

}

getreceivable=()=>{
  const config = {
    headers: {   
    'currentToken': tokken,
  },

  };

  this.setState({isLoading:true})
  axios.get(ip+'/getAccReceive', config)
  .then(response => this.setState({ dataSource:response.data},() => {if(response.status==200){

    this.arrayholder = this.state.dataSource ;  

    let a=0;

    for(let i=0;i<this.state.dataSource.length;i++){
      const{E}=this.state.dataSource[i]
      if(E.toString().charAt(0)=='['){
        a=parseFloat(a)-parseFloat(E.toString().replace(/[^a-zA-Z0-9-. ]/g, "")) 
      }else{
        a=parseFloat(a)+parseFloat(E.toString().replace(/[^a-zA-Z0-9-. ]/g, "")) 
      }      
    }
    console.log(a)
    this.setState({tot_ccb:a.toString(),isLoading:false})}}))
    .catch(err => 
      {
        this.setState({
          isLoading:false
        },()=>{
         let error=err
         
         this.refs.toast.showBottom(error.toString())
  
         setTimeout(
          () => { 
            this.props.navigation.goBack();
           },
          2000
        )
  
        })
      }
      );
}

SearchFilterFunction(text){
  const newData = this.arrayholder.filter(function(item){
      const itemData = item.A.toString().toUpperCase()+item.B.toString().toUpperCase()
      const textData = text.toUpperCase()
      return itemData.indexOf(textData) > -1
  })
  this.setState({
      dataSource: newData,
      text: text
  })
}

componentDidMount(){

  console.disableYellowBox = true;

  this.props.navigation.setParams({
    handlelogin: this.login.bind(this)
    });
    
 this.setState({
      UserID:this.props.navigation.getParam('UserID', ''),
},()=>{this.getreceivable();})
}
  render() {
    if (this.state.isLoading) {
      return (
        <Modal
        transparent={false}
        supportedOrientations={['portrait', 'landscape']}
        visible={this.state.isLoading}
        >
         <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
          style={{width: 300, height: 200}}
          source={require('./src/gears.gif')}  />
          </View>     
        </Modal>
      )
  }
    return (
      <View style={{flex:1,backgroundColor:lightblue}}>
      <ScrollView style={{height:'16%'}}>
      <SearchBar
      placeholder="Search Customer ID/Name"
      onChangeText={(text) => this.SearchFilterFunction(text)}
      value={this.state.text}
      searchIcon={{ name: "search", size: 19, color: colorprimary }}
      clearIcon={{ name: "close-circle", size: 19 }}
      loadingProps={{ size: "small" }}
      platform={'ios'}
     />
            <View  style={{ flex: 1,paddingTop:'2%',paddingBottom:5}}>
             <Grid style={{backgroundColor:colorprimary,padding:5,width:"97%",alignSelf:'center',borderRadius:3}}>
             <Row style={{paddingTop:'1%',paddingBottom:'1%'}}>
             <Col style={{alignItems:'flex-start',width:'34%'}}>
             <Text style={styles.textContent}>Customer</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'22%'}}>
             <Text style={styles.textContent}>Year OB</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'22%'}}>
             <Text style={styles.textContent}>Month OB</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'22%'}}>
             <Text style={styles.textContent}>Current OB</Text>
             </Col> 
             </Row>
             </Grid>
             </View>
      </ScrollView>
      <ScrollView style={{height:'76%'}}>

    <FlatList
       data={ this.state.dataSource}
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
               paddingLeft:5,paddingRight:5,paddingTop:10,paddingBottom:10}}>
            <Grid  onPress={() => this.gotocustomer(index)}>
            <Row>
              <Col style={{alignItems:'flex-start',width:'34%'}}>
              <Text style={{fontSize:12,fontFamily:'ItalicBold'}}>{item.A}</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'22%'}}>
              <Text style={{fontSize:12,fontFamily:'ItalicBold'}}>{item.C}</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'22%'}}>
              <Text style={{fontSize:12,fontFamily:'ItalicBold'}}>{item.D}</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'22%'}}>
              <Text style={{fontSize:12,fontFamily:'ItalicBold'}}>{item.E}</Text>
              </Col>
             </Row>
             <Row>
             <Col style={{alignItems:'flex-start',width:'100%'}}>
             <Text style={{fontSize:12,fontFamily:'Italic'}}>{item.B}</Text>
             </Col> 
             </Row>
            </Grid>  
             </CardItem>
           </Card>
        }

       keyExtractor={(item, index) => index.toString()}
       
      />
     </ScrollView>

     <ScrollView style={{height:'8%'}}>  
  <Card style={{alignSelf:'center',width:'97%',height:40}}>
  <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
        paddingLeft:5,paddingRight:5,paddingTop:10,paddingBottom:10}}>
  <Row>
  <Col style={{alignItems:'flex-end',width:'78%'}}>
  <Text style={{fontSize:13,color:colorprimary,fontFamily:'ItalicBold'}}>Total :</Text>
  </Col>
  <Col style={{alignItems:'flex-end',width:'22%'}}>
  <Text style={{fontSize:13,fontFamily:'Bold'}}>{this.format(this.state.tot_ccb.toString())}</Text>
  </Col>
  </Row>
  </CardItem>
</Card>
      </ScrollView>
      <Toast ref="toast"
        />
      </View>
   
        )
      }
 };
 const styles = StyleSheet.create({
  titleText: {
    flex:1,
    flexWrap:'wrap',
    color:white,
    fontSize:12,
    padding:5,
    fontFamily:'Bold' 
  },
  textContent:{
    color:white,
    fontSize:12,
    fontFamily:'Bold'
  }
  });
  
  
  
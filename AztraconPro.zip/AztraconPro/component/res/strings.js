const strings = {
  values: {
    commonvalues: {
      //ip: 'http://51.211.180.25:2018',

      //ip: 'http://192.168.29.8:2018',
      ip: 'http://192.168.29.127:2018',
      //ip: 'http://192.168.33.228:2018',
      //ip: 'http://192.168.95.228:2018',

      //ip: 'http://37.224.104.233:2018',
      //ip: 'http://192.168.1.104:2018',
      //fileip: 'http://51.211.180.25:2019',
      tokken: 'Shfkhkjj*DJHsJbhjgJDjzzjvJHJ64T#4Dv',
      ios_build_no: '1.1.3',
    },
  }
}
export default strings


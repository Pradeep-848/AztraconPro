const colors = {
    values: {
      Colors: {
        blue: '#1565C0',
        colorPrimary:'#2452b2',
        primarylite:'#627ee5',
        colorPrimaryDark:'#36428a',
        colorAccent:'#36428a',
        white:'#fff',
        black:'#000',
        red:'#c0392b',
        gray:'#282828',
        loading:"#0000ff",
        greylight:'#708090',
        skyblue:"#1ca0ff",
        greydark:'#A0A0A0',
        darkblue:"'#2AC062'",
        lightblue:'#ecf0f1',
        darkgreen:'#16a085',
        orange:'#f39c12',
      },
    }
  }
  export default colors
  

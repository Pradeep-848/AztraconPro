import React,{ Component }  from 'react';
import { ScrollView,StyleSheet,Text,View,FlatList,Modal,Image,TouchableOpacity,Alert} from 'react-native';
import { Col, Grid,Row } from 'react-native-easy-grid';
import axios from 'axios';
import { NavigationActions, StackActions } from 'react-navigation';
import { Card,CardItem } from 'native-base';
import {logouttask} from './class/logout';
import strings from './res/strings'
import colors from './res/colors'
import Toast from 'react-native-whc-toast'

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const dark=colors.values.Colors.colorPrimaryDark;
const primary=colors.values.Colors.colorPrimary;
const lightblue=colors.values.Colors.lightblue;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class EmpSalaryPeriod extends React.Component {
  static navigationOptions = ({ navigation }) => ({ 
    title: "Salary Period",
    color:"#fff",
    headerStyle: {
      backgroundColor: "#2452b2",
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
      USER:'',
      handlelogin:'',
      isLoading: false, 
      dataSource:'',
    };

}
login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
      this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}

componentWillUnmount(){
  this.state.isLoading = false
}
componentDidMount(){ 
  console.disableYellowBox = true;

this.props.navigation.setParams({
  handlelogin: this.login.bind(this)
  });
  
    this.setState({USER:this.props.navigation.getParam('UserID', '')},()=>{this.salaryperiodlist()})
}

listitempress(index) {

  let  ID=index
    
    const{Date}=this.state.dataSource[ID]
    
    this.props.navigation.navigate('SalarySlipActivity',{SalaryDate:Date,UserID:this.state.USER});

}
salaryperiodlist(){

  const config = {
      headers: {   
      'currentToken':tokken,
    },
   params: {
    Empid:this.state.USER,
      }    
    };

    this.setState({isLoading:true})
   axios.get(ip+'/getSalPeriodlist', config)
  .then(response => this.setState({dataSource:response.data},() => {if(response.status==200){
    this.setState({isLoading:false}); }}))
    .catch(err => 
      {
        this.setState({
          isLoading:false
        },()=>{
         let error=err
         
         this.refs.toast.showBottom(error.toString())
  
         setTimeout(
          () => { 
            this.props.navigation.goBack();
           },
          2000
        )
  
        })
      }
      );
}

  render() {
    if (this.state.isLoading) {
      return (
        <Modal
        transparent={false}
        supportedOrientations={['portrait', 'landscape']}
        visible={this.state.isLoading}
        >
         <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
          style={{width: 300, height: 200}}
          source={require('./src/gears.gif')}  />
          </View>     
        </Modal>
      )
  }
    return (
<View style={{flex:1,backgroundColor:lightblue}}>     
<ScrollView style={{height:'6%'}}>
<View style={styles.Head}>
            <Grid style={{width:'97%',alignSelf:'center',backgroundColor:'#2452b2',borderRadius:4}}>
              <Row>
              <Col style={{alignItems:'flex-start',width:'100%'}}>
              <Text style={{color:'#fff',fontSize:13,padding:5,fontFamily:'Bold'}}>Salary Date</Text>
              </Col> 
              </Row>
            </Grid>  
</View> 
</ScrollView>
<ScrollView style={{height:'94%'}}>
    <FlatList
       data={this.state.dataSource}
       initialNumToRender={this.state.dataSource.length}
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
        paddingLeft:5,paddingRight:5,paddingTop:6,paddingBottom:6}}>
            <Grid onPress={()=>this.listitempress(index)}>
              <Col style={{alignItems:'flex-start',width:'100%'}}>
              <Text style={{fontSize:13,fontFamily:'Italic'}}>{item.Date}</Text>
              </Col> 
            </Grid>  
            </CardItem>
        </Card>
        }
       keyExtractor={(item, index) => index.toString()}
      />
        <Toast ref="toast"
        />
</ScrollView>
</View> 
        )
      }
 };
 const styles = StyleSheet.create({
     Head: {
        flex: 1,
        paddingTop:'2%',
      },
      
  });
  
  
  
import React,{ Component }  from 'react';
import {ScrollView,Modal,StyleSheet,Text,View,Image,Dimensions,FlatList,TouchableOpacity,Alert} from 'react-native';
import {logouttask} from './class/logout';
import { Col, Grid, Row } from 'react-native-easy-grid';
import { Divider } from 'react-native-elements';
import axios from 'axios';
import { NavigationActions, StackActions } from 'react-navigation';
import Toast from 'react-native-whc-toast'
import {Card,CardItem} from 'native-base';
import strings from './res/strings'
import color from './res/colors'

const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);

const ip=strings.values.commonvalues.ip;
const tokken=strings.values.commonvalues.tokken;

const lightblue=color.values.Colors.lightblue;
const blue=color.values.Colors.blue;
const colorprimary=color.values.Colors.colorPrimary;
const white=color.values.Colors.white;

const resetAction = StackActions.reset({
  index: 0,
  actions: [NavigationActions.navigate({ routeName: 'LoginActivity' })],
});

export default class SupplierLedger extends React.Component {
  static navigationOptions = ({ navigation }) => ({ 
    title: "Supplier Ledger",
    color:color,
    headerStyle: {
      backgroundColor:colorprimary,
    },
    headerTintColor: white,
    headerTitleStyle: {
      fontFamily:'Bold',
    },
    headerRight: (
      <TouchableOpacity style={{paddingRight:10}} onPress={() => 
      navigation.state.params.handlelogin()
      }>
      <Image
          style={{alignSelf:'center',justifyContent:'center'}}
          source={require('./src/logout.png')} />
      </TouchableOpacity>
    ),
    
  });
  constructor(props) {
    super(props);
    this.state = {
      handlelogin:'',
      isLoading: false, 
      dataSource:'',
      SupID:'',UserID:'',SupName:''
    };
}

format(x) {
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}


login = async () => 
{

  Alert.alert(
    'Logout',
    'Would you like to logout?',
    [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => { logouttask()
        this.props.navigation.dispatch(resetAction);} },
    ],
    {cancelable: false},
  );
 
}

getsupplierledger=()=>{
  const config = {
    headers: {   
    'currentToken': tokken,
  },
    params: {
        SupID:this.state.SupID,
    }
    
  };

  this.setState({isLoading:true})
  axios.get(ip+'/getSLedger', config)
  .then(response => this.setState({ dataSource:response.data},() => {if(response.status==200){this.setState({isLoading:false})}}))
  .catch(err => 
    {
      this.setState({
        isLoading:false
      },()=>{
       let error=err
       
       this.refs.toast.showBottom(error.toString())

       setTimeout(
        () => { 
          this.props.navigation.goBack();
         },
        2000
      )

      })
    }
    );
}

componentDidMount(){


  this.setState({
    isLoading:true
  })

  console.disableYellowBox = true;

 const { navigation } = this.props;


 this.focusListener = navigation.addListener("didFocus", () => {


  this.setState({
    SupID:this.props.navigation.getParam('SupID', ''),
    SupName:this.props.navigation.getParam('SupName', ''),
    UserID:this.props.navigation.getParam('UserID', ''),
 },()=>{
      this.props.navigation.setParams({
       handlelogin: this.login.bind(this)
       });
       this.getsupplierledger()

})

});

 
}
  render() {
    if (this.state.isLoading){
      return (
        <Modal
        transparent={false}
        supportedOrientations={['portrait', 'landscape']}
        visible={this.state.isLoading}
        >
         <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
          <Image
          style={{width: 300, height: 200}}
          source={require('./src/gears.gif')}  />
          </View>     
        </Modal>
      )
  }
    return (
<View style={{flex:1,backgroundColor:lightblue}}>
<ScrollView style={{height:'10%'}}> 
  <Grid style={{paddingTop:'2%'}}>

  <Row style={{backgroundColor:colorprimary,width:'97%',alignSelf:'center',borderRadius:3}}>
  <Text numberOfLines={1} style={styles.titleText}>
          {this.state.SupID.toString().trim()+" - "+this.state.SupName}
  </Text>
  </Row>

  <Divider style={{ backgroundColor:white}} />
  <Divider style={{ backgroundColor:white}} />

  </Grid>

  <View  style={{ flex: 1,paddingTop:5,paddingBottom:5}}>
    <Grid style={{backgroundColor:colorprimary,padding:4,width:"97%",alignSelf:'center',borderRadius:3}}>
             <Row> 
             <Col style={{alignItems:'flex-start',width:'50%'}}>
             <Text style={styles.textContent}>Voucher Details</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'25%'}}>
             <Text style={styles.textContent}>Debit</Text>
             </Col> 
             <Col style={{alignItems:'flex-end',width:'25%'}}>
             <Text style={styles.textContent}>Credit</Text>
             </Col>  
             </Row>
      </Grid>
    </View>

</ScrollView>

<ScrollView style={{height:'90%'}}>
    <FlatList
       data={ this.state.dataSource }
       initialNumToRender={this.state.dataSource.length}
       renderItem={({item,index}) =>  
       <Card style={{width:'97%',alignSelf:'center'}}>
            <CardItem style={{alignItems:"flex-start",width:'100%',flexWrap:'wrap',
        paddingLeft:5,paddingRight:5,paddingTop:10,paddingBottom:10}}>
            <Grid>
            <Row style={{paddingTop:2}}>
              <Col style={{alignItems:'flex-start',width:'15%'}}>
              <Text style={{fontSize:12,fontWeight:"bold"}}>{item.A}</Text>
              </Col> 
              <Col style={{alignItems:'flex-start',width:'25%'}}>
              <Text style={{fontSize:12,fontWeight:"bold"}}>{item.B}</Text>
              </Col> 
              <Col style={{alignItems:'center',width:'10%'}}>
              <Text style={{fontSize:12,fontWeight:"bold"}}>{item.C}</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'25%'}}>
              <Text style={{fontSize:12,fontWeight:"bold"}}>{this.format(item.E.toString())}</Text>
              </Col> 
              <Col style={{alignItems:'flex-end',width:'25%'}}>
              <Text style={{fontSize:12,fontWeight:"bold"}}>{this.format(item.F.toString())}</Text>
              </Col> 
             </Row>
             <Row  style={{paddingTop:3}}>
              <Col style={{alignItems:'flex-end',width:'100%'}}>
              <Text style={{fontSize:12,fontFamily:'Italic'}}>{item.D}</Text>
              </Col> 
             </Row>
            </Grid>  
             </CardItem>
           </Card>
        }
       keyExtractor={(item, index) => index.toString()}
       
      />
  <Toast ref="toast"/>
          </ScrollView>
          </View>      
        )
      }
 };
 const styles = StyleSheet.create({
  titleText: {
    flex:1,
    flexWrap:'wrap',
    color:white,
    fontSize:12,
    padding:5,
    fontFamily:'Bold'
  },
  textContent:{
    color:white,
    fontSize:13,
    fontFamily:'Bold'
  }
  });
  
  
  